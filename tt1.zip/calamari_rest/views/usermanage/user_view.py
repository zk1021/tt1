# -*- coding:utf-8 -*-

import base64
import logging

from django.contrib.auth import authenticate
from django.contrib.auth.models import User, Group

from calamari_common.config import CalamariConfig
from calamari_rest.constant import SUPER_USER_PERMISSIONS
from calamari_rest.common import delete_user as delete_user_by_sql
from calamari_rest.views.common import util, const, errno, op_log
from calamari_rest.views.onestor_common import ONEStorCommon
from calamari_rest.views.usermanage import HAUser, HAResponse

log = logging.getLogger('django.request')
config = CalamariConfig()

"""
    Author: dai.xinchun@h3c.com
    Date: 2016/06/30
    Description: ONEStor用户管理类
"""


class UserViewSet(ONEStorCommon):
    def __init__(self, *args, **kwargs):
        super(UserViewSet, self).__init__(*args, **kwargs)

    # @util.send_response(const.OP_LIST)
    # def list_user(self, request, fsid):
    #     """
    #     获取用户列表
    #     """
    #     if not request.user.is_superuser:
    #         yield {'success': False, 'error': errno.ERR_IS_NOT_SUPERUSER[2]}
    #
    #     users = User.objects.order_by('id').reverse()
    #     rt = []
    #     for user in users:
    #         usergroup = user.groups.all()
    #         # 过滤掉不是超级管理员且没有用户组的用户（即不显示网盘用户）
    #         if len(usergroup) == 0 and (not user.is_superuser):
    #             continue
    #         if user.username != const.USER_DEFAULT:
    #             rt.append({
    #                 'id': user.id,
    #                 'username': user.username,
    #                 'is_active': const.STATUS_ACTIVE if user.is_active else const.STATUS_STOPPED,
    #                 'group': usergroup[0].name if len(usergroup) != 0 and (not user.is_superuser) else ''
    #             })
    #     yield {'success': True, 'rt': rt}

    # @util.send_response(const.OP_LIST)
    # def list_user_permission(self, request, fsid):
    #     """
    #     获取用户的所有权限
    #     """
    #     # if not request.user.is_authenticated():
    #     #     yield {
    #     #         'success': False,
    #     #         'error': errno.ERR_USER_UNAUTHENTICATED[2]
    #     #     }
    #
    #     if request.user.is_superuser:
    #         yield {
    #             'success': True,
    #             'rt': SUPER_USER_PERMISSIONS,
    #             'userId': request.user.id,
    #             'userName': request.user.username
    #         }
    #     permissiontemps = request.user.get_group_permissions()
    #     permissions = {permission[22:]: True for permission in permissiontemps if permission.startswith(
    #         const.CALAMARI_REST_OPERATE)}
    #
    #     yield {
    #         'success': True,
    #         'rt': permissions,
    #         'userId': request.user.id,
    #         'userName': request.user.username
    #     }

    # @util.send_response(const.HA_CREATE_USER)
    # def create_user(self, request, fsid):
    #     """
    #     创建用户
    #     """
    #     username = request.DATA.get('username', None)
    #     groupname = request.DATA.get('groupname', None)
    #
    #     # 将操作日志的内容返回
    #     yield op_log.OP_CREATE_HANDY_USER.format(username)
    #
    #     # TODO 校验入参是否合法
    #     yield request.DATA
    #
    #     # 通过用户组是否存在来过滤对象网关用户，默认存在admin和default用户无用户组，但前台只显示admin，所以初始值为1。
    #     users = User.objects.all()
    #     user_num = 1
    #     for user in users:
    #         usergroup = user.groups.all()
    #         if usergroup:
    #             user_num += 1
    #         if user_num >= const.USER_LIMIT:
    #             yield HAResponse(is_success=False, error=errno.ERR_USER_LIMIT_EXCEED)
    #
    #     if not request.user.is_superuser:
    #         yield HAResponse(is_success=False, error=errno.ERR_IS_NOT_SUPERUSER)
    #
    #     group = None
    #
    #     try:
    #         group = Group.objects.get(name=groupname)
    #     except Group.DoesNotExist:
    #         yield HAResponse(is_success=False, error=errno.ERR_GROUP_NOT_EXIST)
    #
    #     try:
    #         User.objects.get(username=username)
    #     except User.DoesNotExist:
    #         user = User.objects.create_user(username=username, password=const.USER_DEFAULT_PASSWD)
    #         user.groups.add(group)
    #         user.save()
    #         rt = {
    #             'id': user.id,
    #             'username': user.username,
    #             'group': group.name,
    #             'is_active': const.STATUS_ACTIVE if user.is_active else const.STATUS_STOPPED
    #         }
    #         yield HAResponse(is_success=True, rt=rt)
    #     else:
    #         yield HAResponse(is_success=False, error=errno.ERR_USER_EXIST)

    # @util.send_response(const.HA_REMOVE_USER)
    # def remove_user(self, request, fsid):
    #     """
    #     删除用户
    #     """
    #     username = request.DATA.get('username', None)
    #
    #     # 将操作日志的内容返回
    #     yield op_log.OP_REMOVE_HANDY_USER.format(username)
    #
    #     # TODO 校验入参是否合法
    #     yield request.DATA
    #
    #     if not request.user.is_superuser:
    #         yield HAResponse(is_success=False, error=errno.ERR_IS_NOT_SUPERUSER)
    #
    #     try:
    #         user = User.objects.get(username=username)
    #     except User.DoesNotExist:
    #         yield HAResponse(is_success=False, error=errno.ERR_USER_NOT_EXIST)
    #     else:
    #         if user.is_superuser:
    #             yield HAResponse(is_success=False, error=errno.ERR_DELETE_SUPERUSER)
    #
    #         user.groups.clear()
    #         delete_user_by_sql(username)
    #         yield HAResponse(is_success=True, rt=username)

    # @util.send_response(const.HA_MODIFY_USER_PASSWD)
    # def modify_password(self, request, fsid):
    #     """
    #     修改用户的密码
    #     """
    #     username = request.user.username
    #     old_password = request.DATA.get('oldpwd', None)
    #     new_password = request.DATA.get('newpwd', None)
    #
    #     # 将操作日志的内容返回
    #     yield op_log.OP_MODIFY_HANDY_USER_PASSWD
    #
    #     # 对密码进行base64解码
    #     old_password = base64.b64decode(old_password)
    #     new_password = base64.b64decode(new_password)
    #
    #     # TODO 校验入参是否合法
    #     yield request.DATA
    #
    #     # 对用户进行一次验证，判断原密码是否正确
    #     user = authenticate(username=username, password=old_password)
    #
    #     if not user:
    #         yield HAResponse(is_success=False, error=errno.ERR_OLD_PASSWD_IS_WRONG)
    #     if user.is_active is not True:
    #         yield HAResponse(is_success=False, error=errno.ERR_USER_IS_STOPPED)
    #     if len(new_password) < 6 or len(new_password) > 30:
    #         yield HAResponse(is_success=False, error=errno.ERR_PASSWORD_IS_TOO_SIMPLE)
    #
    #     user.set_password(new_password)
    #     user.save()
    #
    #     yield HAResponse(is_success=True)

    @util.send_response(const.HA_MODIFY_USER_PASSWD)
    def reset_password(self, request, fsid):
        """
        重置用户的密码
        """
        username = request.DATA.get('username', None)

        # 将操作日志的内容返回
        yield op_log.OP_RESET_HANDY_USER_PASSWD.format(username)

        # TODO 校验入参是否合法
        yield request.DATA

        if not request.user.is_superuser:
            yield HAResponse(is_success=False, error=errno.ERR_IS_NOT_SUPERUSER)

        user = None

        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            # BEGIN ADD BY D10039 2016/03/22
            if 'true' != config.get('calamari_web', 'netdisk_switch'):
                yield HAResponse(is_success=True)
            # END ADD BY D10039 2016/03/22
            yield HAResponse(is_success=False, error=errno.ERR_USER_NOT_EXIST)

        if user.is_superuser:
            yield HAResponse(is_success=False, error=errno.ERR_RESET_SUPERUSER_PASSWD)

        user.set_password(const.USER_DEFAULT_PASSWD)
        user.save()
        rt = {
            'username': user.username
        }
        yield HAResponse(is_success=True, rt=rt)

    # @util.send_response(const.HA_MODIFY_USER_GROUP)
    # def change_user_group(self, request, fsid):
    #     """
    #     修改用户所在组
    #     """
    #     username = request.DATA.get('username', None)
    #     groupname = request.DATA.get('groupname', None)
    #
    #     # 将操作日志的内容返回
    #     yield op_log.OP_MODIFY_HANDY_USER_GROUP.format(username)
    #
    #     # TODO 校验入参是否合法
    #     yield request.DATA
    #
    #     if not request.user.is_superuser:
    #         yield HAResponse(is_success=False, error=errno.ERR_IS_NOT_SUPERUSER)
    #
    #     try:
    #         user = User.objects.get(username=username)
    #         group = Group.objects.get(name=groupname)
    #     except User.DoesNotExist:
    #         yield HAResponse(is_success=False, error=errno.ERR_USER_NOT_EXIST)
    #     except Group.DoesNotExist:
    #         yield HAResponse(is_success=False, error=errno.ERR_GROUP_NOT_EXIST)
    #     else:
    #         if user.is_superuser:
    #             yield HAResponse(is_success=False, error=errno.ERR_MODIFY_SUPERUSER_GROUP)
    #
    #         user.groups.clear()
    #         user.groups.add(group)
    #         rt = {
    #             'id': user.id,
    #             'username': user.username,
    #             'group': groupname,
    #             'is_active': user.is_active
    #         }
    #         yield HAResponse(is_success=True, rt=rt)
