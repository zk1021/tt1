# -*- coding:utf-8 -*-
import logging

from django.contrib.auth.models import User, Group, Permission

from calamari_rest.constant import PERMISSION_CUST
from calamari_rest.views.common import util, const, errno, op_log
from calamari_rest.views.onestor_common import ONEStorCommon
from calamari_rest.views.usermanage import HAGroup, HAResponse

log = logging.getLogger('django.request')

"""
    Author: dai.xinchun@h3c.com
    Date: 2016/06/30
    Description: ONEStor用户组管理类
"""


class GroupViewSet(ONEStorCommon):
    def __init__(self, *args, **kwargs):
        super(GroupViewSet, self).__init__(*args, **kwargs)

    # @util.send_response(const.OP_LIST)
    # def list_group(self, request, fsid):
    #     """
    #     获取用户组列表
    #     """
    #     groups = Group.objects.order_by('id').reverse()
    #     rt = [{'id': group.id, 'name': group.name, 'invator': u'普通'} for group in groups]
    #     yield {'success': True, 'rt': rt}

    # @util.send_response(const.OP_LIST)
    # def list_group_user(self, request, fsid):
    #     """
    #     获取用户组下的所有用户
    #     """
    #     if not request.user.is_superuser:
    #         yield {'success': False, 'error': errno.ERR_IS_NOT_SUPERUSER[2]}
    #
    #     groupname = request.GET.get('groupname', None)
    #     try:
    #         Group.objects.get(name=groupname)
    #     except Group.DoesNotExist:
    #         yield {'success': False, 'error': errno.ERR_GROUP_NOT_EXIST[2]}
    #     else:
    #         users = User.objects.all()
    #         group_users = []
    #         for user in users:
    #             if user.is_superuser or user.username == const.USER_DEFAULT:
    #                 continue
    #             if len(user.groups.all()) > 0 and user.groups.all()[0].name == groupname:
    #                 group_users.append(user.username)
    #         yield {'success': True, 'rt': group_users}

    # @util.send_response(const.OP_LIST)
    # def list_all_permissions(self, request, fsid):
    #     """
    #     获取所有的权限列表
    #     """
    #     if not request.user.is_superuser:
    #         yield {'success': False, 'error': errno.ERR_IS_NOT_SUPERUSER[2]}
    #
    #     permissions = Permission.objects.all()
    #     rt = [{'name': permission.name} for permission in permissions]
    #     yield {'success': True, 'rt': rt}

    # @util.send_response(const.OP_LIST)
    # def list_group_permission(self, request, fsid):
    #     """
    #     获取用户组的权限
    #     """
    #     groupname = request.GET.get('groupname', None)
    #
    #     if not request.user.is_superuser:
    #         yield {'success': False, 'error': errno.ERR_IS_NOT_SUPERUSER[2]}
    #
    #     group = Group.objects.get(name=groupname)
    #     permissionlist = group.permissions.all()
    #     grouppermissions = []
    #     for permis in permissionlist:
    #         if permis.name == const.PERMISSION_GROUPMANAGE or permis.name == const.PERMISSION_USERMANAGE \
    #                 or permis.name == const.PERMISSION_POOL_POLICY:
    #             continue
    #         grouppermissions.append({
    #             'id': permis.id,
    #             'name': PERMISSION_CUST[permis.name]
    #         })
    #     allpermissions = []
    #     permissions = Permission.objects.all()
    #     for permis in permissions:
    #         if permis.name == const.PERMISSION_GROUPMANAGE or permis.name == const.PERMISSION_USERMANAGE \
    #                 or permis.name == const.PERMISSION_POOL_POLICY:
    #             continue
    #         if permis.name.startswith(const.OPERATE):
    #             allpermissions.append({
    #                 'id': permis.id,
    #                 'name': PERMISSION_CUST[permis.name]
    #             })
    #     yield {
    #         'success': True,
    #         'rt': {
    #             'grouppermissions': grouppermissions,
    #             'allpermissions': allpermissions
    #         }
    #     }

    # @util.send_response(const.HA_CREATE_GROUP)
    # def create_group(self, request, fsid):
    #     """
    #     创建用户组
    #     """
    #     groupname = request.DATA.get('groupname', None)
    #
    #     # 将操作日志的内容返回
    #     yield op_log.OP_CREATE_GROUP.format(groupname)
    #
    #     # TODO 校验入参是否合法
    #     yield request.DATA
    #
    #     if len(Group.objects.all()) >= const.USER_GROUP_LIMIT:
    #         yield HAResponse(is_success=False, error=errno.ERR_GROUP_LIMIT_EXCEED)
    #
    #     if not request.user.is_superuser:
    #         yield HAResponse(is_success=False, error=errno.ERR_IS_NOT_SUPERUSER)
    #
    #     try:
    #         Group.objects.get(name=groupname)
    #     except Group.DoesNotExist:
    #         # 先去备Handy上创建用户组
    #         yield HAGroup(groupname)
    #
    #         # 再在本Handy上创建用户组
    #         group = Group.objects.create(name=groupname)
    #         group.save()
    #         rt = {
    #             'id': group.id,
    #             'name': group.name,
    #             'invator': const.USER_TYPE_COMMON
    #         }
    #         yield HAResponse(is_success=True, rt=rt)
    #     else:
    #         yield HAResponse(is_success=False, error=errno.ERR_GROUP_EXIST)

    # @util.send_response(const.HA_REMOVE_GROUP)
    # def remove_group(self, request, fsid):
    #     """
    #     删除用户组
    #     """
    #     groupname = request.DATA.get('groupname', None)
    #
    #     # 将操作日志的内容返回
    #     yield op_log.OP_REMOVE_GROUP.format(groupname)
    #
    #     # TODO 校验入参是否合法
    #     yield request.DATA
    #
    #     if not request.user.is_superuser:
    #         yield HAResponse(is_success=False, error=errno.ERR_IS_NOT_SUPERUSER)
    #
    #     # 用户组中存在用户则不允许删除
    #     users = User.objects.all()
    #     for user in users:
    #         # 排除超级管理员和default用户
    #         if user.is_superuser or user.username == const.USER_DEFAULT:
    #             continue
    #         if 0 < len(user.groups.all()) and user.groups.all()[0].name == groupname:
    #             yield HAResponse(is_success=False, error=errno.ERR_GROUP_EXIST_USER)
    #
    #     try:
    #         group = Group.objects.get(name=groupname)
    #     except Group.DoesNotExist:
    #         yield HAResponse(is_success=False, error=errno.ERR_GROUP_NOT_EXIST)
    #     else:
    #         # 先去备Handy上删除用户组
    #         yield HAGroup(groupname)
    #
    #         # 再在本Handy上删除用户组
    #         group.delete()
    #         yield HAResponse(is_success=True, rt={'name': groupname})

    # @util.send_response(const.HA_MODIFY_GROUP_PERMISSION)
    # def change_group_permission(self, request, fsid):
    #     """
    #     修改用户组权限
    #     """
    #     groupname = request.DATA.get('groupname', None)
    #     permission_list = request.DATA.get('permissionlist', None)
    #
    #     # 将操作日志的内容返回
    #     yield op_log.OP_MPDOFY_GROUP_PERMISSION.format(groupname)
    #
    #     # TODO 校验入参是否合法
    #     yield request.DATA
    #
    #     if not request.user.is_superuser:
    #         yield HAResponse(is_success=False, error=errno.ERR_IS_NOT_SUPERUSER)
    #
    #     try:
    #         group = Group.objects.get(name=groupname)
    #     except Group.DoesNotExist:
    #         yield HAResponse(is_success=False, error=errno.ERR_GROUP_NOT_EXIST)
    #     else:
    #         # 先去备Handy上修改用户组权限
    #         permissions_ha = [{'id': permission['id']} for permission in permission_list]
    #         yield HAGroup(groupname, permissions_ha)
    #
    #         # 再在本Handy上修改用户组权限
    #         permissions = [Permission.objects.get(
    #             id=permission['id']) for permission in permission_list]
    #         group.permissions.clear()
    #         group.permissions = permissions
    #         yield HAResponse(is_success=True, rt='')
