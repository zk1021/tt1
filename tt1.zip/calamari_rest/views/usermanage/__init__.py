# -*- coding:utf-8 -*-


class HAGroup:
    """
    用户组实体，HA传递用
    """

    def __init__(self, group_name, permissions=None):
        self.group_name = group_name
        self.permissions = permissions

    def to_json(self):
        return {
            'group_name': self.group_name,
            'permissions': self.permissions
        }


class HAUser:
    """
    用户实体，HA传递用
    """

    def __init__(self, user_name, group_name=None, password=None):
        self.user_name = user_name
        self.group_name = group_name
        self.password = password

    def to_json(self):
        return {
            'user_name': self.user_name,
            'group_name': self.group_name,
            'password': self.password
        }


class HAResponse:
    """
    HA响应实体
    """

    def __init__(self, is_success, rt=None, error=None, type=None):
        self.success = is_success
        self.error = error
        self.rt = rt
        self.type = type

    def to_json(self):
        return {
            'success': self.success,
            'rt': self.rt,
            'error': self.error,
            'type': self.type
        }
