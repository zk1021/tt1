#!/usr/bin/env python
# coding: utf-8

"""
单点登录配置
"""

import logging

from calamari_rest.views.onestor_common import ONEStorCommon
from calamari_rest.views.sso.sso_db import SsoConfigDatabase
from calamari_rest.views.common import util, const, errno, op_log
from rest_framework.response import Response
from calamari_common.config import CalamariConfig, ONEStorConfig
from calamari_common import cmdprocess
from rest_framework.decorators import api_view
from rest_framework.decorators import permission_classes
from rest_framework.permissions import AllowAny
from calamari_web import send_add_oplog_msg

LOG = logging.getLogger('django.request')
config = CalamariConfig()


class SsoViewSet(ONEStorCommon):
    """
    单点登录配置模块
    """
    def __init__(self, *args, **kwargs):
        super(SsoViewSet, self).__init__(*args, **kwargs)

    @util.send_response(
        ret_type=const.RETURN_TYPE_2
    )
    def change_cas_config(self, request, fsid):
        """
        修改单点登录配置信息
        :param request: 请求体
        :param fsid: 集群id
        :return:
        """
        cas_switch = request.DATA['cas_switch']
        if cas_switch:
            # 开启单点登录配置
            yield op_log.OP_OPEN_SSO
            login_url = request.DATA['login_url']
            auth_url = request.DATA['auth_url']
            logout_url = request.DATA['logout_url']
            cas_obj = {
                'login_url': login_url,
                'logout_url': logout_url,
                'auth_url': auth_url
            }
            LOG.info('open sso set url: {0}'.format(cas_obj))
            # ping_network
            domain_set = set([cas_obj[url].split('://')[1].split('/')[0].split(':')[0] for url in cas_obj])
            for domain in domain_set:
                if not self.sso_network_check(domain):
                    send_add_oplog_msg(
                        request,
                        (op_log.OP_OPEN_SSO, 'Open single sign on'),
                        errno.ERROR_SSO_NETWORK
                    )
                    raise errno.ONEStorError(errno.ERROR_SSO_NETWORK)
            # check url
            self._process_sso_url(login_url, 'login_url')
            self._process_sso_url(auth_url, 'auth_url')
            self._process_sso_url(logout_url, 'logout_url')
            # manage_network
            for domain in domain_set:
                if len(domain.split('.')) == 4:
                    if not self.check_manage_network(domain):
                        send_add_oplog_msg(
                            request,
                            (op_log.OP_OPEN_SSO, 'Open single sign on'),
                            errno.ERROR_SSO_MANAGE_NETWORK
                        )
                        raise errno.ONEStorError(errno.ERROR_SSO_MANAGE_NETWORK)

            SsoConfigDatabase.create_sso_config(cas_obj)
            send_add_oplog_msg(
                request,
                (op_log.OP_OPEN_SSO, 'Open single sign on'),
            )
        else:
            # 关闭单点登录配置
            yield op_log.OP_CLOSE_SSO
            LOG.info('close sso')
            SsoConfigDatabase.delete_sso_config()
            send_add_oplog_msg(
                request,
                (op_log.OP_CLOSE_SSO, 'Close single sign on'),
            )

    def check_manage_network(self, domain):
        """
        检测单点登录服务是否在管理网内
        :param domain:
        :return:
        """
        onestor_config = ONEStorConfig()
        manage_network = onestor_config.get('global', 'manage_network')
        return self.subnet_judge(manage_network, domain)

    def sso_network_check(self, ip, retry_times=3):
        """
        检测单点登录服务网络
        :param ip: ip或域名
        :param retry_times: 连接次数
        :return:
        """
        times = 0
        while times < retry_times:
            test_ping = self.exec_local_cmd(
                'ping -c 1 -W 3 %s 1>/dev/null 2>&1 && echo ok' % ip)
            if 'ok' == test_ping:
                return True
            times += 1
        LOG.info('<network_check> "{0}" is unreachable, retried {1} times'.format(ip, retry_times))
        return False

    @staticmethod
    def _process_sso_url(url, style):
        """
        校验url是否符合要求
        :param url: 单点登录url
        :param style: 类型
        :return:
        """
        try:
            url_result = cmdprocess.command(['curl', '-3', '-ksSfL', '%s' % url], timeout=5)
        except cmdprocess.TimeoutExpired:
            if style == 'login_url':
                raise errno.ONEStorError(errno.ERROR_SSO_LOGIN_URL)
            elif style == 'auth_url':
                raise errno.ONEStorError(errno.ERROR_SSO_AUTH_URL)
            elif style == 'logout_url':
                raise errno.ONEStorError(errno.ERROR_SSO_LOGOUT_URL)
            else:
                raise errno.ONEStorError(errno.ERROR_SSO_NETWORK)
        if style == 'login_url':
            if url_result['stderr'] \
                    or url_result['stdout'].find('/cas/login') < 0:
                raise errno.ONEStorError(errno.ERROR_SSO_LOGIN_URL)
        elif style == 'auth_url':
            if url_result['stderr'] \
                    or url_result['stdout'].find('cas:serviceResponse') < 0 \
                    or url_result['stdout'].find('cas:proxyFailure') > -1:
                raise errno.ONEStorError(errno.ERROR_SSO_AUTH_URL)
        elif style == 'logout_url':
            if url_result['stderr'] \
                    or url_result['stdout'].find('success') < 0:
                raise errno.ONEStorError(errno.ERROR_SSO_LOGOUT_URL)

    @util.send_response(
        op=const.OP_LIST
    )
    def get_cas_config(self, request, fsid):
        """
        获得单点登录配置信息
        :param request: 消息请求体
        :param fsid: 集群id
        :return:
        """
        cas_obj = self.get_config()
        yield {
            'success': True,
            'data': cas_obj
        }

    @util.send_response(
        op=const.OP_LIST
    )
    def get_cas_config_status(self, reqest, fsid):
        """
        获得单点登录配置信息和状态
        :param reqest: 消息请求体
        :param fsid: 集群id
        :return:
        """
        cas_obj = self.get_config()
        cas_obj['status'] = ''
        if not cas_obj['cas_switch']:
            yield {
                'success': True,
                'data': cas_obj
            }
        # ping_network
        domain_set = set(
            [cas_obj[url].split('://')[1].split('/')[0].split(':')[0]
             for url in cas_obj if url != 'cas_switch' and url != 'status'])
        for domain in domain_set:
            if not self.sso_network_check(domain):
                cas_obj['status'] = errno.ERROR_SSO_NETWORK[2]
                yield {
                    'success': True,
                    'data': cas_obj
                }

        try:
            self._process_sso_url(cas_obj['login_url'], 'login_url')
            self._process_sso_url(cas_obj['auth_url'], 'auth_url')
            self._process_sso_url(cas_obj['logout_url'], 'logout_url')
        except errno.ONEStorError as ex:
            cas_obj['status'] = ex.reason
        else:
            # manage_network
            for domain in domain_set:
                if len(domain.split('.')) == 4:
                    if not self.check_manage_network(domain):
                        cas_obj['status'] = errno.ERROR_SSO_MANAGE_NETWORK[2]
        yield {
            'success': True,
            'data': cas_obj
        }

    @staticmethod
    def get_config():
        """
        获得单点登录配置信息
        :return:
        """
        cas_obj = {
            'cas_switch': False,
            'login_url': '',
            'auth_url': '',
            'logout_url': ''
        }
        sso_config = SsoConfigDatabase.list_sso_config()
        if sso_config is not None:
            cas_obj['cas_switch'] = True
            cas_obj['login_url'] = sso_config['login_url']
            cas_obj['auth_url'] = sso_config['auth_url']
            cas_obj['logout_url'] = sso_config['logout_url']

        return cas_obj


@api_view(['GET'])
@permission_classes((AllowAny,))
def get_cas_config_api(request):
    """
    获得单点登录配置信息API
    :param request: 请求体
    :return:
    """
    cas_obj = SsoViewSet.get_config()
    return Response({
        'success': True,
        'data': cas_obj
    })
