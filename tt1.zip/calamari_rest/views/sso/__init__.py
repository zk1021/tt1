#!/usr/bin/env python
# coding: utf-8
__author__ = 'c13463'

# begin add by w15818 2017/11/18 PN:201711080279
"""
单点登录模块
"""

import time
import base64
import urllib

from M2Crypto import RSA

SINGLE_LENGTH = 21
PUB_KEY = '/opt/h3c/key/sso_pub'
PRI_KEY = '/opt/h3c/key/sso_pri'


def encrypt_string(key_path, string):
    """
    根据RSA算法进行加密并进行Base64编码
    :param key_path: rsa私钥路径
    :param string: 待加密的字符串
    :return: 加密完的字符串
    """
    priv_key = RSA.load_key(key_path)
    encrypt_str = priv_key.private_encrypt(string, RSA.pkcs1_padding)
    return base64.b64encode(encrypt_str)


def decrypt_string(key_path, string):
    """
    进行Base64解码后再用RSA算法解密
    :param key_path: rsa公钥路径
    :param string: 待解密的字符串
    :return: 解密完的字符串
    """
    public_key = RSA.load_pub_key(key_path)
    b64decode_str = base64.b64decode(string)
    decrypt_str = public_key.public_decrypt(b64decode_str, RSA.pkcs1_padding)
    return decrypt_str


def rsa_encrypt(username, password):
    """
    根据rsa算法对用户名和密码进行加密
    :param username: 用户名
    :param password: 密码
    :return: 加密后的密文
    """
    encrypt_data = ''
    current_time = time.time()
    original_data = '{0}\r\n{1}\r\n{2}'.format(username, current_time, password)
    for x in range(len(original_data) / SINGLE_LENGTH + 1):
        substr = original_data[x * SINGLE_LENGTH: (x + 1) * SINGLE_LENGTH]
        encrypt_data += encrypt_string(PRI_KEY, substr)
    return urllib.quote(encrypt_data)


def rsa_decrypt(encrypt_data):
    """
    根据rsa算法对用户名和密码进行解密
    :param encrypt_data: 加密的数据
    :return: 解密后的原文
    """
    destr = ''
    for x in range(len(encrypt_data) / 44):
        substr = encrypt_data[x * 44: (x + 1) * 44]
        destr += decrypt_string(PUB_KEY, substr)
    username, encrypt_time, password = destr.split('\r\n')
    # 校验token的时间，如果大于10分钟，则失效
    current_time = time.time()
    if current_time - float(encrypt_time) > 10 * 60:
        raise Exception('TOKEN_EXPIRED')
    return username, password
# end add by w15818 2017/11/18 PN:201711080279
