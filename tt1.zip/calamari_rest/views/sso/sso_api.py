#!/usr/bin/env python
# coding: utf-8

import logging

from django.contrib.auth.models import User, Group, Permission
from calamari_rest.constant import PERMISSION_CUST
from calamari_rest.common import delete_user as delete_user_by_sql
from calamari_rest.views.onestor_common import ONEStorCommon
from calamari_common.config import CalamariConfig
from calamari_rest.decorator import send_api_response, api_operate_log
from calamari_rest.views.common import util, const, errno, op_log, expno

LOG = logging.getLogger('django.request')
config = CalamariConfig()


class SsoApiSet(ONEStorCommon):
    """
    单点登录API实例
    """
    def __init__(self, *args, **kwargs):
        super(SsoApiSet, self).__init__(*args, **kwargs)

    @staticmethod
    def validate_param(exp, data):
        """
        校验传参
        :param exp: 正则表达式
        :param data: 传参
        :return:
        """
        if not expno.validate(exp, data):
            LOG.info('validate: "{0}" by rule: "{1}" not pass...'.format(data, exp))
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)

    @send_api_response
    def query_permission_list(self, request):
        """
        查询权限列表
        :param request: 请求体
        :return:
        """
        allpermissions = []
        permissions = Permission.objects.all()
        for permis in permissions:
            if permis.name == const.PERMISSION_GROUPMANAGE or permis.name == const.PERMISSION_USERMANAGE \
                    or permis.name == const.PERMISSION_POOL_POLICY:
                continue
            if permis.name.startswith(const.OPERATE):
                allpermissions.append({
                    'id': permis.id,
                    'name': permis.name[8:],
                    'description': PERMISSION_CUST[permis.name]
                })
        return allpermissions

    @staticmethod
    def _get_group_permission(group):
        """
        获得用户组权限
        :param group: 用户组对象
        :return:
        """
        permission_list = group.permissions.all()
        group_permissions = []
        for permission in permission_list:
            if permission.name == const.PERMISSION_GROUPMANAGE or permission.name == const.PERMISSION_USERMANAGE \
                    or permission.name == const.PERMISSION_POOL_POLICY:
                continue
            if permission.name.startswith(const.OPERATE):
                group_permissions.append({
                    'id': permission.id,
                    'name': permission.name[8:],
                    'description': PERMISSION_CUST[permission.name]
                })
        return {
            'id': group.id,
            'name': group.name,
            'permissions': group_permissions
        }

    def _get_group_list(self):
        """
        查询用户组列表
        :return:
        """
        groups = Group.objects.order_by('id').reverse()
        groups_json = []
        for group in groups:
            group_result = self._get_group_permission(group)
            groups_json.append(group_result)
        LOG.info(groups_json)
        return groups_json

    def _get_group_by_id(self, group_id):
        """
        根据id获得用户组
        :param group_id: 用户组id
        :return:
        """
        try:
            group = Group.objects.get(id=int(group_id))
        except Group.DoesNotExist:
            raise errno.APIError(errno.ERR_GROUP_NOT_EXIST)
        except ValueError:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        return self._get_group_permission(group)

    @send_api_response
    def query_group(self, request):
        """
        查询用户组列表或单个用户组
        :param request: 请求体
        :return:
        """
        group_id = request.GET.get('id', None)
        if group_id is None:
            return self._get_group_list()
        else:
            return self._get_group_by_id(group_id)

    @send_api_response
    @api_operate_log
    def add_group(self, request):
        """
        创建用户组
        :param request: 请求体
        :return:
        """
        groupname = request.DATA.get('name', None)
        permissions = request.DATA.get('permissions', None)
        request.session[const.OPERATE] = op_log.OP_CREATE_GROUP.format(groupname)
        if not request.user.is_superuser:
            raise errno.APIError(errno.ERR_IS_NOT_SUPERUSER)
        if not groupname or not permissions:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        self.validate_param(expno.EXP_USER_NAME, groupname)
        self.validate_param(expno.EXP_PERMISSIONS, permissions)

        opt = self._get_opt_permissions()
        add_permissions = []
        try:
            permissions = [int(permission) for permission in permissions.split(',')]
        except TypeError:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        except Exception:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        for permission in permissions:
            if permission not in opt['ids']:
                raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
            else:
                add_permissions.append(opt['permissions'][opt['ids'].index(permission)])

        try:
            Group.objects.get(name=groupname)
        except Group.DoesNotExist:
            group = Group.objects.create(name=groupname)
            group.save()

            group.permissions.clear()
            group.permissions = add_permissions
        else:
            raise errno.APIError(errno.ERR_GROUP_EXIST)

    @send_api_response
    @api_operate_log
    def modify_group(self, request):
        """
        修改用户组
        :param request:
        :return:
        """
        group_id = request.DATA.get('id', None)
        permissions = request.DATA.get('permissions', None)
        request.session[const.OPERATE] = op_log.OP_MPDOFY_GROUP_PERMISSION.format(group_id)
        if not request.user.is_superuser:
            raise errno.APIError(errno.ERR_IS_NOT_SUPERUSER)
        if not group_id or not permissions:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        self.validate_param(expno.EXP_PERMISSIONS, permissions)
        opt = self._get_opt_permissions()
        add_permissions = []
        permissions = [int(permission) for permission in permissions.split(',')]
        for permission in permissions:
            if permission not in opt['ids']:
                raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
            else:
                add_permissions.append(opt['permissions'][opt['ids'].index(permission)])

        try:
            group = Group.objects.get(id=int(group_id))
        except Group.DoesNotExist:
            raise errno.APIError(errno.ERR_GROUP_NOT_EXIST)
        except ValueError:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        else:
            group.permissions = add_permissions

    @send_api_response
    @api_operate_log
    def delete_group(self, request):
        """
        删除用户组
        :param request:
        :return:
        """
        group_id = request.GET.get('id', None)
        request.session[const.OPERATE] = op_log.OP_REMOVE_GROUP.format(group_id)
        if not request.user.is_superuser:
            raise errno.APIError(errno.ERR_IS_NOT_SUPERUSER)
        if not group_id:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        try:
            group = Group.objects.get(id=int(group_id))
        except Group.DoesNotExist:
            raise errno.APIError(errno.ERR_GROUP_NOT_EXIST)
        except ValueError:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        else:
            users = User.objects.all()
            for user in users:
                if user.is_superuser or user.username == const.USER_DEFAULT:
                    continue
                if 0 < len(user.groups.all()) and user.groups.all()[0].id == int(group_id):
                    raise errno.APIError(errno.ERR_GROUP_EXIST_USER)
            group.delete()

    @send_api_response
    @api_operate_log
    def associate_user_group(self, request):
        """
        改变用户所属用户组
        :param request:
        :return:
        """
        user_name = request.DATA.get('user_id', None)
        group_id = request.DATA.get('group_id', None)
        request.session[const.OPERATE] = op_log.OP_MODIFY_HANDY_USER_GROUP.format(user_name)
        if not request.user.is_superuser:
            raise errno.APIError(errno.ERR_IS_NOT_SUPERUSER)
        if not group_id or not user_name:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        self.validate_param(expno.EXP_USER_NAME, user_name)
        try:
            user = User.objects.get(username=user_name)
            group = Group.objects.get(id=int(group_id))
        except User.DoesNotExist:
            raise errno.APIError(errno.ERR_USER_NOT_EXIST)
        except Group.DoesNotExist:
            raise errno.APIError(errno.ERR_GROUP_NOT_EXIST)
        except ValueError:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        else:
            if user.is_superuser:
                raise errno.APIError(errno.ERR_MODIFY_SUPERUSER_GROUP)

            user.groups.clear()
            user.groups.add(group)

    @staticmethod
    def _get_opt_permissions():
        """
        获得OPERATE前缀的权限与id
        :return:
        """
        all_permissions = Permission.objects.all()
        opt_permissions = []
        opt_permission_ids = []
        for permission in all_permissions:
            if permission.name.startswith(const.OPERATE):
                opt_permissions.append(permission)
                opt_permission_ids.append(permission.id)

        return {
            'ids': opt_permission_ids,
            'permissions': opt_permissions
        }

    @send_api_response
    @api_operate_log
    def create_user(self, request):
        """
        创建用户
        """
        user_name = request.DATA.get('user_id', None)
        group_id = request.DATA.get('group_id', None)
        request.session[const.OPERATE] = op_log.OP_CREATE_HANDY_USER.format(user_name)
        if not request.user.is_superuser:
            raise errno.APIError(errno.ERR_IS_NOT_SUPERUSER)
        if not user_name or not group_id:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        self.validate_param(expno.EXP_USER_NAME, user_name)
        try:
            group = Group.objects.get(id=int(group_id))
        except Group.DoesNotExist:
            raise errno.APIError(errno.ERR_GROUP_NOT_EXIST)
        except ValueError:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)

        try:
            User.objects.get(username=user_name)
        except User.DoesNotExist:
            user = User.objects.create_user(username=user_name, password=const.USER_DEFAULT_PASSWD)
            user.groups.add(group)
            user.save()
        else:
            raise errno.APIError(errno.ERR_USER_EXIST)

    @send_api_response
    def query_user_list(self, request):
        """
        查询用户列表
        :return: 请求体
        """
        users = User.objects.order_by('id').reverse()
        users_json = []
        for user in users:
            if len(user.groups.all()) > 0:
                users_json.append({
                    'user_id': user.id,
                    'user_name': user.username,
                    'group_id': user.groups.all()[0].id,
                    'group_name': user.groups.all()[0].name
                })
        return users_json

    @send_api_response
    @api_operate_log
    def delete_user(self, request):
        """
        删除用户
        :param request:
        :return:
        """
        user_name = request.GET.get('user_id', None)
        request.session[const.OPERATE] = op_log.OP_REMOVE_HANDY_USER.format(user_name)
        if not request.user.is_superuser:
            raise errno.APIError(errno.ERR_IS_NOT_SUPERUSER)
        if not user_name:
            raise errno.APIError(errno.ERROR_ILLEGAL_PARAMETER)
        self.validate_param(expno.EXP_USER_NAME, user_name)
        try:
            user = User.objects.get(username=user_name)
        except User.DoesNotExist:
            raise errno.APIError(errno.ERR_USER_NOT_EXIST)
        else:
            if user.is_superuser:
                raise errno.APIError(errno.ERR_DELETE_SUPERUSER)

        user.groups.clear()
        delete_user_by_sql(user_name)
