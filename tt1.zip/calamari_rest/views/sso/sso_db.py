#!/usr/bin/env python
# coding: utf-8

"""
SsoConfig数据库操作实例
"""

import logging

from calamari_rest.models import SsoConfig

LOG = logging.getLogger('django.request')


class SsoConfigDatabase(object):
    """
    SsoConfig数据库操作实例
    """

    @staticmethod
    def create_sso_config(config_info):
        """
        创建SsoConfig
        :param config_info:
        :return:
        """
        LOG.info('add sso config info to db: %s' % config_info)
        sso_config_db = SsoConfig.objects.all()
        if len(sso_config_db) > 0:
            sso_config_db[0].login_url = config_info['login_url']
            sso_config_db[0].logout_url = config_info['logout_url']
            sso_config_db[0].auth_url = config_info['auth_url']
            sso_config_db[0].save()
        else:
            SsoConfig.objects.create(
                login_url=config_info['login_url'],
                logout_url=config_info['logout_url'],
                auth_url=config_info['auth_url']
            )

    @staticmethod
    def delete_sso_config():
        """
        删除SsoConfig
        :return:
        """
        LOG.info('remove sso config from db.')
        SsoConfig.objects.all().delete()
        return True

    @staticmethod
    def list_sso_config():
        """
        查询SsoConfig
        :return:
        """
        sso_config_db = SsoConfig.objects.all()
        data = None
        if len(sso_config_db) > 0:
            data = {
                'login_url': sso_config_db[0].login_url,
                'logout_url': sso_config_db[0].logout_url,
                'auth_url': sso_config_db[0].auth_url
            }
        return data
