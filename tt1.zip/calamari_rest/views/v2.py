﻿# -*- coding:utf-8 -*-
import os
import sys
import os.path
import math
from collections import defaultdict
from dateutil.parser import parse as dateutil_parse
import logging
import shlex
import codecs
import xlwt
import datetime
import rados
import traceback
import time
import socket
import re
import copy
import tarfile
import subprocess
import calamari_web
import platform
from django.http import Http404
from rest_framework.exceptions import ParseError, APIException, PermissionDenied
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from django.contrib.auth.decorators import login_required

from calamari_rest.parsers.v2 import CrushMapParser
from calamari_rest.serializers.v2 import PoolSerializer, CrushRuleSetSerializer, \
    CrushRuleSerializer, CrushNodeSerializer, ServerSerializer, SimpleServerSerializer, \
    SaltKeySerializer, RequestSerializer, ClusterSerializer, EventSerializer, LogTailSerializer, \
    OsdSerializer, ConfigSettingSerializer, MonSerializer, OsdConfigSerializer, CliSerializer
from calamari_rest.views.database_view_set import DatabaseViewSet
from calamari_rest.views.exceptions import ServiceUnavailable
from calamari_rest.views.paginated_mixin import PaginatedMixin
from calamari_rest.views.remote_view_set import RemoteViewSet
from calamari_rest.views.rpc_view import RPCViewSet, DataObject
from calamari_rest.common import send_request_onestord
from calamari_common.config import CalamariConfig, ONEStorConfig
from calamari_common.types import CRUSH_MAP, CRUSH_RULE, CRUSH_NODE, POOL, OSD, \
    USER_REQUEST_COMPLETE, USER_REQUEST_SUBMITTED, OSD_IMPLEMENTED_COMMANDS, MON, \
    OSD_MAP, SYNC_OBJECT_TYPES, ServiceId
from calamari_common.db.event import Event, severity_from_str, SEVERITIES

from django.views.decorators.csrf import csrf_exempt
from calamari_rest.views.server_metadata import get_local_grains, get_remote_grains
from calamari_common import cmdprocess
from rest_framework.decorators import permission_classes
from rest_framework.permissions import AllowAny
from calamari_rest.decorator import module_required
from calamari_rest.decorator import module_required, assert_tgtd_normal, check_remove_osd_event, check_cluster_dispace
from calamari_rest.decorator import permit_login

import onebackup
from onebackup import message
from onebackup import scheduler
from onebackup import connect
from onebackup import const
# ADD BY D10039 2016/09/02
from calamari_rest.views.backup import messanger
from calamari_rest.views.backup import constant as back_constant
from calamari_rest.views.backup import utils as back_utils
# MODIFY BY KF6618 2016/08/01 PN:201607270198
from calamari_rest.alarm_db.db import get_alarm_failed, alarmdb

import csv
import json
import base64
from django import http
from calamari_common.radosgw_swift_api import listObjects, addObject, getObject, removeObject, addFolder, \
    removeFolder, createContainer, createUserBatch, makeTempUrl, cancelShare
from django.contrib.auth import get_user_model, authenticate
from onestor import onestor
from onestor import database
from calamari_rest.views.onestor import http_request

import threading
from time import sleep
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import ensure_csrf_cookie
from django.contrib.auth.models import User, Group, Permission

from calamari_rest.constant import PERMISSION_CUST, SUPER_USER_PERMISSIONS, USER_DEFAULT_PASSWORD, COUNTRYS
from calamari_rest.common import delete_user as delete_user_by_sql, is_email, is_name, is_phone
from calamari_rest.common import send_mail
from calamari_rest.common import get_onestor_host

# ADD BY D10039 2016/08/16 FOR HANDY HA
from calamari_rest.views.common.util import HandyUtil
from calamari_rest.views.onestor_common import ONEStorCommon, ONEBackupError
from calamari_rest.views.common import const
from calamari_rest.views.common import cmd
from calamari_rest.views.common import errno
from calamari_rest.views.host.host_util import HostUtil

from calamari_rest.plat import leader_router as plat_leader_router
from calamari_rest.views.common.forward import ForwardView
from calamari_web import send_add_oplog_msg
from calamari_rest.views.language_db import LanguageDatabase

reload(sys)
sys.setdefaultencoding('utf8')

config = CalamariConfig()

log = logging.getLogger('django.request')
cluster_head_net = u'存储前端网段'
cluster_behind_net = u'存储后端网段'
public_net = u'存储前端网'
manage_net = u'管理网段'

if log.level <= logging.DEBUG:
    logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)
    for handler in log.handlers:
        logging.getLogger('sqlalchemy.engine').addHandler(handler)


@api_view(['GET'])
@login_required
def grains(request):
    """
The salt grains for the host running Calamari server.  These are variables
from Saltstack that tell us useful properties of the host.

The fields in this resource are passed through verbatim from SaltStack, see
the examples for which fields are available.
    """
    return Response(get_local_grains())


def get_block_service_segment():
    block_service_segment = ''
    result = database.list_objs("block_service_network")
    if not result:
        return block_service_segment
    network_list = result['block_service_network']
    if network_list:
        for instance in network_list:
            if instance['id'] == 1:
                block_service_segment = instance['block_service_network']
    return block_service_segment


class ONEStorError(Exception):
    """
    请求处理错误
    """

    def __init__(self, error_code, reason=None):
        super(ONEStorError, self).__init__()
        self.error_code = error_code
        self.reason = reason

    def __str__(self):
        ret = "error code: {0}, \r\nreason: {1}".format(self.error_code, self.reason)
        return ret


class RequestViewSet(RPCViewSet, PaginatedMixin):
    """
Calamari server requests, tracking long-running operations on the Calamari server.  Some
API resources return a ``202 ACCEPTED`` response with a request ID, which you can use with
this resource to learn about progress and completion of an operation.  This resource is
paginated.

May optionally filter by state by passing a ``?state=<state>`` GET parameter, where
state is one of 'complete', 'submitted'.

The returned records are ordered by the 'requested_at' attribute, in descending order (i.e.
the first page of results contains the most recent requests).

To cancel a request while it is running, send an empty POST to ``request/<request id>/cancel``.
    """
    serializer_class = RequestSerializer

    def cancel(self, request, request_id):
        user_request = DataObject(self.client.cancel_request(request_id))
        return Response(self.serializer_class(user_request).data)

    def retrieve(self, request, **kwargs):
        request_id = kwargs['request_id']
        user_request = DataObject(self.client.get_request(request_id))
        return Response(self.serializer_class(user_request).data)

    def list(self, request, **kwargs):
        fsid = kwargs.get('fsid', None)
        filter_state = request.GET.get('state', None)
        valid_states = [USER_REQUEST_COMPLETE, USER_REQUEST_SUBMITTED]
        if filter_state is not None and filter_state not in valid_states:
            raise ParseError("State must be one of %s" %
                             ", ".join(valid_states))

        requests = self.client.list_requests(
                {'state': filter_state, 'fsid': fsid})
        return Response(self._paginate(request, requests))


class CrushMapViewSet(RPCViewSet):
    """
Allows retrieval and replacement of a crushmap as a whole
    """
    parser_classes = (CrushMapParser,)

    def retrieve(self, request, fsid):
        crush_map = self.client.get_sync_object(fsid, 'osd_map')[
            'crush_map_text']
        return Response(crush_map)

    def replace(self, request, fsid):
        return Response(self.client.update(fsid, CRUSH_MAP, None, request.DATA))


class CrushNodeViewSet(RPCViewSet):
    """
The CRUSH algorithm distributes data objects among storage devices according to a per-device weight value,
approximating a uniform probability distribution. CRUSH distributes objects and their replicas according
to the hierarchical cluster map you define. Your CRUSH map represents the available storage devices and
the logical elements that contain them.
    """

    serializer_class = CrushNodeSerializer

    def create(self, request, fsid):
        serializer = self.serializer_class(data=request.DATA)
        if serializer.is_valid(request.method):

            # TODO semantic validation
            # type exists, name and id are unique
            create_response = self.client.create(
                    fsid, CRUSH_NODE, serializer.get_data())
            # TODO: handle case where the creation is rejected for some reason (should
            # be passed an errors dict for a clean failure, or a zerorpc exception
            # for a dirty failure)
            assert 'request_id' in create_response
            return Response(create_response, status=status.HTTP_202_ACCEPTED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def list(self, request, fsid):
        crush_nodes = self.client.list(fsid, CRUSH_NODE, {})
        return Response(self.serializer_class(crush_nodes).data)

    def retrieve(self, request, fsid, node_id):
        crush_node = self.client.get(fsid, CRUSH_NODE, int(node_id))
        if crush_node:
            return Response(self.serializer_class(DataObject(crush_node)).data)
        return Response(status=status.HTTP_404_NOT_FOUND)

    def destroy(self, request, fsid, node_id):
        delete_response = self.client.delete(
                fsid, CRUSH_NODE, int(node_id), status=status.HTTP_202_ACCEPTED)
        return Response(delete_response, status=status.HTTP_202_ACCEPTED)

    def update(self, request, fsid, node_id):
        serializer = self.serializer_class(data=request.DATA)
        if serializer.is_valid(request.method):
            updates = serializer.get_data()

            response = self.client.update(
                    fsid, CRUSH_NODE, int(node_id), updates)
            assert 'request_id' in response
            return Response(response, status=status.HTTP_202_ACCEPTED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CrushRuleViewSet(RPCViewSet):
    """
A CRUSH ruleset is a collection of CRUSH rules which are applied
together to a pool.
    """
    serializer_class = CrushRuleSerializer

    def list(self, request, fsid):
        rules = self.client.list(fsid, CRUSH_RULE, {})
        osds_by_rule_id = self.client.get_sync_object(
                fsid, 'osd_map', ['osds_by_rule_id'])
        for rule in rules:
            rule['osd_count'] = len(osds_by_rule_id[rule['rule_id']])
        return Response(CrushRuleSerializer([DataObject(r) for r in rules], many=True).data)


class CrushRuleSetViewSet(RPCViewSet):
    """
A CRUSH rule is used by Ceph to decide where to locate placement groups on OSDs.
    """
    serializer_class = CrushRuleSetSerializer

    def list(self, request, fsid):
        rules = self.client.list(fsid, CRUSH_RULE, {})
        osds_by_rule_id = self.client.get_sync_object(
                fsid, 'osd_map', ['osds_by_rule_id'])
        rulesets_data = defaultdict(list)
        for rule in rules:
            rule['osd_count'] = len(osds_by_rule_id[rule['rule_id']])
            rulesets_data[rule['ruleset']].append(rule)

        rulesets = [DataObject({
            'id': rd_id,
            'rules': [DataObject(r) for r in rd_rules]
        }) for (rd_id, rd_rules) in rulesets_data.items()]

        return Response(CrushRuleSetSerializer(rulesets, many=True).data)


class SaltKeyViewSet(RPCViewSet):
    """
Ceph servers authentication with the Calamari using a key pair.  Before
Calamari accepts messages from a server, the server's key must be accepted.
    """
    serializer_class = SaltKeySerializer

    def list(self, request):
        return Response(self.serializer_class(self.client.minion_status(None), many=True).data)

    def partial_update(self, request, minion_id):
        serializer = self.serializer_class(data=request.DATA)
        if serializer.is_valid(request.method):
            self._partial_update(minion_id, serializer.get_data())
            return Response(status=status.HTTP_204_NO_CONTENT)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def _partial_update(self, minion_id, data):
        valid_status = ['accepted', 'rejected']
        if 'status' not in data:
            raise ParseError({'status': "This field is mandatory"})
        elif data['status'] not in valid_status:
            raise ParseError(
                    {'status': "Must be one of %s" % ",".join(valid_status)})
        else:
            key = self.client.minion_get(minion_id)
            transition = [key['status'], data['status']]
            if transition == ['pre', 'accepted']:
                self.client.minion_accept(minion_id)
            elif transition == ['pre', 'rejected']:
                self.client.minion_reject(minion_id)
            else:
                raise ParseError({'status': ["Transition {0}->{1} is invalid".format(
                        transition[0], transition[1]
                )]})

    def _validate_list(self, request):
        keys = request.DATA
        if not isinstance(keys, list):
            raise ParseError("Bulk PATCH must send a list")
        for key in keys:
            if 'id' not in key:
                raise ParseError(
                        "Items in bulk PATCH must have 'id' attribute")

    def list_partial_update(self, request):
        self._validate_list(request)

        keys = request.DATA
        log.debug("KEYS %s", keys)
        for key in keys:
            self._partial_update(key['id'], key)

        return Response(status=status.HTTP_204_NO_CONTENT)

    def destroy(self, request, minion_id):
        self.client.minion_delete(minion_id)
        return Response(status=status.HTTP_204_NO_CONTENT)

    def list_destroy(self, request):
        self._validate_list(request)
        keys = request.DATA
        for key in keys:
            self.client.minion_delete(key['id'])

        return Response(status=status.HTTP_204_NO_CONTENT)

    def retrieve(self, request, minion_id):
        return Response(self.serializer_class(self.client.minion_get(minion_id)).data)


class PoolDataObject(DataObject):
    """
    Slightly dressed up version of the raw pool from osd dump
    """

    FLAG_HASHPSPOOL = 1
    FLAG_FULL = 2

    @property
    def hashpspool(self):
        return bool(self.flags & self.FLAG_HASHPSPOOL)

    @property
    def full(self):
        return bool(self.flags & self.FLAG_FULL)


class RequestReturner(object):
    """
    Helper for ViewSets that sometimes need to return a request handle
    """

    def _return_request(self, request):
        if request:
            return Response(request, status=status.HTTP_202_ACCEPTED)
        else:
            return Response(status=status.HTTP_304_NOT_MODIFIED)


class NullableDataObject(DataObject):
    """
    A DataObject which synthesizes Nones for any attributes it doesn't have
    """

    def __getattr__(self, item):
        if not item.startswith('_'):
            return self.__dict__.get(item, None)
        else:
            raise AttributeError


class ConfigViewSet(RPCViewSet):
    """
Configuration settings from a Ceph Cluster.
    """
    serializer_class = ConfigSettingSerializer

    def _get_config(self, fsid):
        ceph_config = self.client.get_sync_object(fsid, 'config')
        if not ceph_config:
            raise ServiceUnavailable("Cluster configuration unavailable")
        else:
            return ceph_config

    def list(self, request, fsid):
        ceph_config = self._get_config(fsid)
        settings = [DataObject({'key': k, 'value': v})
                    for (k, v) in ceph_config.items()]
        return Response(self.serializer_class(settings, many=True).data)

    def retrieve(self, request, fsid, key):
        ceph_config = self._get_config(fsid)
        try:
            setting = DataObject({'key': key, 'value': ceph_config[key]})
        except KeyError:
            raise Http404("Key '%s' not found" % key)
        else:
            return Response(self.serializer_class(setting).data)


def _config_to_bool(config_val):
    return {'true': True, 'false': False}[config_val.lower()]


class ClusterViewSet(ONEStorCommon):
    """
A Ceph cluster, uniquely identified by its FSID.  All Ceph services such
as OSDs and mons are namespaced within a cluster.  Servers may host services
for more than one cluster, although usually they only hold one.

Note that the ``name`` attribute of a Ceph cluster has no uniqueness,
code consuming this API should always use the FSID to identify clusters.

Using the DELETE verb on a Ceph cluster will cause the Calamari server
to drop its records of the cluster and services within the cluster.  However,
if the cluster still exists on servers managed by Calamari, it will be immediately
redetected: only use DELETE on clusters which really no longer exist.
    """
    serializer_class = ClusterSerializer

    def list(self, request):
        comp_op = plat_leader_router.OP_QUERY_CLUSTER
        response = ForwardView().send_request_to_leader(comp_op, unistor_api=False)
        if 0 == response['result'][0]:
            data = response['data']
            if data['id']:
                return Response({'success': True, 'result': data})
            else:
                return Response({'success': False, 'status': 1, 'errorcode': 'NO_CLUSTER_EXIST'})
        else:
            return Response({'success': False, 'status': 0, 'errorcode': 'REQUEST_TIMEOUT'})
        # else:
        # clusters = [DataObject(c) for c in self.client.list_clusters()]
        # # if calamari can not get cluster， get by CLI
        # calamari_clusters = ClusterSerializer(clusters, many=True).data

    def retrieve(self, request, pk):
        cluster_data = self.client.get_cluster(pk)
        if not cluster_data:
            return Response(status=status.HTTP_404_NOT_FOUND)
        else:
            cluster = DataObject(cluster_data)
            return Response(ClusterSerializer(cluster).data)

    def destroy(self, request, pk):
        self.client.delete_cluster(pk)
        return Response(status=status.HTTP_204_NO_CONTENT)


class PoolViewSet(ONEStorCommon, RequestReturner):
    """
Manage Ceph storage pools.

To get the default values which will be used for any fields omitted from a POST, do
a GET with the ?defaults argument.  The returned pool object will contain all attributes,
but those without static defaults will be set to null.

    """
    serializer_class = PoolSerializer
    CEPH_CONF_FILE = '/etc/ceph/ceph.conf'

    def _defaults(self, fsid):
        # Issue overlapped RPCs first
        ceph_config = self.client.get_sync_object(fsid, 'config', async=True)
        rules = self.client.list(fsid, CRUSH_RULE, {}, async=True)
        ceph_config = ceph_config.get()
        rules = rules.get()

        if not ceph_config:
            return Response("Cluster configuration unavailable", status=status.HTTP_503_SERVICE_UNAVAILABLE)

        if not rules:
            return Response("No CRUSH rules exist, pool creation is impossible",
                            status=status.HTTP_503_SERVICE_UNAVAILABLE)

        # Ceph does not reliably inform us of a default ruleset that exists, so we check
        # what it tells us against the rulesets we know about.
        ruleset_ids = sorted(list(set([r['ruleset'] for r in rules])))
        if int(ceph_config['osd_pool_default_crush_rule']) in ruleset_ids:
            # This is the ceph<0.80 setting
            default_ruleset = ceph_config['osd_pool_default_crush_rule']
        elif int(ceph_config.get('osd_pool_default_crush_replicated_ruleset', -1)) in ruleset_ids:
            # This is the ceph>=0.80
            default_ruleset = ceph_config[
                'osd_pool_default_crush_replicated_ruleset']
        else:
            # Ceph may have an invalid default set which
            # would cause undefined behaviour in pool creation (#8373)
            # In this case, pick lowest numbered ruleset as default
            default_ruleset = ruleset_ids[0]

        defaults = NullableDataObject({
            'size': int(ceph_config['osd_pool_default_size']),
            'crush_ruleset': int(default_ruleset),
            'min_size': int(ceph_config['osd_pool_default_min_size']),
            'hashpspool': _config_to_bool(ceph_config['osd_pool_default_flag_hashpspool']),
            # Crash replay interval is zero by default when you create a pool, but when ceph creates
            # its own data pool it applies 'osd_default_data_pool_replay_window'.  If we add UI for adding
            # pools to a filesystem, we should check that those data pools have
            # this set.
            'crash_replay_interval': 0,
            'quota_max_objects': 0,
            'quota_max_bytes': 0
        })

        return Response(PoolSerializer(defaults).data)

    def check_rootSsd(self, request, fsid):
        results = self.onestor_request(fsid, 'onestor.osd_tree', [])
        if None != results:
            host_list = []
            rack_list = []
            ssd_children = []

            if 'data' in results.keys() and 'nodes' in results['data'].keys():
                for x in results['data']['nodes']:
                    if x['name'] == 'ssd_root':
                        ssd_children = x['children']
                    if x['type'] == 'rack':
                        rack_list.append(x)
                    elif x['type'] == 'host':
                        host_list.append(x)

                for rack in rack_list:
                    if rack['id'] in ssd_children:
                        ssd_rack_children = rack['children']
                        for host in host_list:
                            if host['id'] in ssd_rack_children:
                                if host['children'] != []:
                                    return Response('true')

            return Response('false')
        else:
            log.error("Failed to get root_ssd")

        return Response('false')

    def list(self, request, fsid):
        if 'defaults' in request.GET:
            return self._defaults(fsid)

        results = self.onestor_request(
                fsid, 'onestor.getPoolStat', [self.CEPH_CONF_FILE])
        gateway_pools = const.RGW_POOLS_WITHOUT_BUCKETS + ['.onestor', '.backup']

        try:
            returned = []
            for pool in results['data']:
                if pool['name'] not in gateway_pools and not pool['name'].startswith(".capfs."):
                    if 'default.rgw.buckets.data' == pool['name']:
                        pool['name'] = u'对象存储'
                    returned.append(pool)
        except Exception, e:
            returned = results['data']
            log.error("list pool occur error, %s", e)

        if None != returned:
            return Response(returned)

        return Response({'errorcode': 'INTERNAL_SERVER_ERROR'})

    # add by l11544
    def poolInfoAll(self, request, fsid):
        if 'defaults' in request.GET:
            return self._defaults(fsid)

        results = self.onestor_request(fsid, 'onestor.getPoolStat', [self.CEPH_CONF_FILE])

        gateway_pools = ['default.rgw.buckets.data']
        gateway_others = const.RGW_POOLS_WITHOUT_BUCKETS + ['.onestor']
        try:
            returned = []
            for pool in results['data']:
                poolCur = {}
                poolCur['name'] = pool['name']
                poolCur['id'] = pool['id']
                if pool['name'] in gateway_pools:
                    poolCur['radosgwJudge'] = True
                else:
                    poolCur['radosgwJudge'] = False
                if pool['name'] not in gateway_others:
                    returned.append(poolCur)

            returned.append({'status': 'success'})
        except Exception, e:
            returned = results['data']
            returned.append({'status': 'error'})
            log.error("list pool occur error, %s" % e)

        if None != returned:
            return Response(returned)

        return Response([])

    def get_pool_id_info(self, request, fsid):
        """
        获取存储池信息，并区分是否为对象存储
        """
        results = self.onestor_request(fsid, 'onestor.getPoolStat', [self.CEPH_CONF_FILE])
        status, pool_info_all, return_info = 'success', list(), list()
        try:
            pool_info_all = results['data']
        except KeyError, e:
            log.error("get pool info failed, detail is: %s", e)
        except Exception, e:
            log.error("get pool info failed, detail is: %s", e)
        # 处理获取的存储池信息
        if pool_info_all:
            for pool_info in pool_info_all:
                return_info.append({
                    'name': pool_info['name'],
                    'id': pool_info['id'],
                    'radosgwJudge': True if pool_info['name'] in const.RGW_POOLS else False
                })
        else:
            status = 'error'

        return Response({'status': status, 'data': return_info})

# end by l11544
    def retrieve(self, request, fsid, pool_id):
        pool = PoolDataObject(self.client.get(fsid, POOL, int(pool_id)))
        return Response(PoolSerializer(pool).data)

    def create(self, request, fsid):
        serializer = self.serializer_class(data=request.DATA)
        if serializer.is_valid(request.method):
            response = self._validate_semantics(
                    fsid, None, serializer.get_data())
            if response is not None:
                return response

            create_response = self.client.create(
                    fsid, POOL, serializer.get_data())

            # TODO: handle case where the creation is rejected for some reason (should
            # be passed an errors dict for a clean failure, or a zerorpc exception
            # for a dirty failure)
            assert 'request_id' in create_response
            return Response(create_response, status=status.HTTP_202_ACCEPTED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, fsid, pool_id):
        try:
            pool_name = request.DATA['name']
            pool_uname = request.DATA['uname']
            kind = request.DATA['kind']
            size = request.DATA['size']
        except Exception:
            self.addOperationlog(fsid, request, u'修改Pool“%s”' %
                                 pool_name, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误', 'errorcode': 'PARAMETER_ERROR'})

        result = self.onestor_request(fsid, 'onestor.updatePool', [
            pool_name, pool_uname, size, kind])

        self.addOperationlog(fsid, request, u'修改Pool“%s”' % pool_name, result)

        return Response(result)

    def destroy(self, request, fsid, pool_id):
        try:
            pool_name = request.GET.get('pool_name')
            # kind = request.GET.get('kind')
            # tie_kind = request.GET.get('tie_kind')
        except Exception:
            self.addOperationlog(fsid, request, u'删除Pool“%s”' %
                                 pool_name, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误', 'errorcode': 'PARAMETER_ERROR'})

        # 检查pool下是否还有rbd
        try:
            results = self.onestor_request(
                    fsid, 'database.list_objs', ['rbdlist'])
            for rbd in results['rbdlist']:
                if rbd['pool_name'] == pool_name:
                    self.addOperationlog(
                            fsid, request, u'删除Pool “%s”' % pool_name, u'Pool上存在块设备')
                    return Response({'status': 'error', 'reason': u'删除失败，Pool “%s” 上存在块设备' \
                                                                  % pool_name, 'errorcode': 'POOL_EXIST_RBD'})
        except Exception, e:
            log.error(e)

        '''
        if tie_kind == 'ssd':
            result = self.onestor_request(fsid, 'onestor.remove_cache_tier', [pool_name+'_ssd', pool_name+'_hdd'])
            if result['status'] == 'success':
                results = self.onestor_request(fsid, 'onestor.remove_pool', [pool_name+'_ssd'])
                results = self.onestor_request(fsid, 'onestor.remove_pool', [pool_name+'_hdd'])
        else:
            if kind == 'hdd':
                pool_name = '%s_hdd' % pool_name
            if kind == 'ssd':
                pool_name = '%s_ssd' % pool_name
        '''
        # 获取所有pool数据
        poolCurrId = ''
        poolObjJudge = False
        poolNameCurr = pool_name

        if u'对象存储' == pool_name:
            gateway_list = self.onestor_request(
                    fsid, 'database.list_objs', ['gateway'])
            if 0 != len(gateway_list['gateway']):
                self.addOperationlog(
                        fsid, request, u'删除Pool “%s”' % pool_name, u'请先删除所有的对象网关')
                return Response({'status': 'error', 'reason': u'删除失败，请先删除所有的对象网关', 'errorcode': 'GATEWAY_IS_NOT_NULL'})

            rgw_pools = const.RGW_POOLS.keys()

            for pool in rgw_pools:
                self.onestor_request(fsid, 'onestor.remove_pool', [pool])
            # 获取对象存储的pool Id，现在没有用 // add by l11544
            poolInfoAll = self.onestor_request(fsid, 'onestor.getPoolStat', [self.CEPH_CONF_FILE])
            for pool in poolInfoAll['data']:
                if pool['name'] in rgw_pools:
                    poolCurrId += str(pool['id'])
                    poolCurrId += ','
            poolObjJudge = True
            # end by l11544

            # 检查是否所有的pool都删除干净了
            try:
                failed_pools = []
                remain_pools = json.loads(
                        self.exec_local_cmd('ceph osd pool ls -f json'))
                for pool in rgw_pools:
                    if pool in remain_pools:
                        failed_pools.append(pool)

                if 0 != len(failed_pools):
                    self.addOperationlog(
                            fsid, request, u'删除Pool “%s”' % pool_name, u'Pool “%s” 残留' % failed_pools)
                    return Response({'status': 'error', 'reason': u'删除失败，Pool “%s” 残留' \
                                                                  % failed_pools,
                                     'errorcode': 'GATEWAY_POOL_IS_NOT_NULL'})
                # DELETE BY KF6602 监控项目不需要清除graphite监控数据

                # PN: 201702220489 删除对象存储池删除成功，但操作日志中未显示删除信息
                self.addOperationlog(fsid, request, u'删除Pool“%s”' % pool_name, 'success')
                # end by l11544 2017/3/11
                return Response({'status': 'success'})
            except Exception, e:
                log.error('[ONEStor] remove gateway Pool, %s', e)
        else:
            poolCurrId += pool_id

        # BEGIN ADD BY D10039 2016/06/22 PN:201606200379
        with rados.Rados(conffile='/etc/ceph/ceph.conf') as cluster:
            pool_name = str(pool_name)
            if cluster.pool_exists(pool_name):
                log.warn('[ONEStor] remove pool before, pool_name is %s', pool_name)
                self.exec_local_cmd('ceph osd pool delete {0} {0} --yes-i-really-really-mean-it'
                                    .format(pool_name))
                log.warn('[ONEStor] remove pool after, pool_name is %s', pool_name)
            else:
                log.error('[ONEStor] remove pool, pool %s not exist', pool_name)
                self.addOperationlog(fsid, request, u'删除Pool“%s”' % pool_name, u'Pool “%s” 不存在' % pool_name)
                return Response({'status': 'error', 'reason': u'Pool “%s” 不存在' % pool_name,
                                 'errorcode': 'POOL_NOT_EXIST'})
        # END ADD BY D10039 2016/06/22 PN:201606200379

        # DELETE BY KF6602 监控项目不需要清除graphite监控数据

        # BEGIN MODIFY BY D10039 2016/06/22 PN:201606200379 判断Pool是否删除成功
        pools_curr = self.exec_local_cmd_json('timeout 600 ceph osd pool ls -f json')
        if (pools_curr is not None) and (pool_name in pools_curr):
            reason = u'无法删除Pool “%s”，请刷新后重试' % pool_name
            time.sleep(1)
            self.addOperationlog(fsid, request, u'删除Pool“%s”' % pool_name, reason)
            return Response({'status': 'error', 'reason': reason, 'errorcode': 'POOL_DELETE_ERROR'})

        time.sleep(1)
        self.addOperationlog(fsid, request, u'删除Pool“%s”' % pool_name, 'success')
        return Response({'status': 'success'})
        # END MODIFY BY D10039 2016/06/22 PN:201606200379

    def _validate_semantics(self, fsid, pool_id, data):
        errors = defaultdict(list)
        self._check_name_unique(fsid, data, errors)
        self._check_crush_ruleset(fsid, data, errors)
        self._check_pgp_less_than_pg_num(data, errors)
        self._check_pg_nums_dont_decrease(fsid, pool_id, data, errors)
        self._check_pg_num_inside_config_bounds(fsid, data, errors)

        if errors.items():
            if 'name' in errors:
                return Response(errors, status=status.HTTP_409_CONFLICT)
            else:
                return Response(errors, status=status.HTTP_400_BAD_REQUEST)

    def _check_pg_nums_dont_decrease(self, fsid, pool_id, data, errors):
        if pool_id is not None:
            detail = self.client.get(fsid, POOL, int(pool_id))
            for field in ['pg_num', 'pgp_num']:
                expanded_field = 'pg_placement_num' if field == 'pgp_num' else 'pg_num'
                if field in data and data[field] < detail[expanded_field]:
                    errors[field].append(
                            'must be >= than current {field}'.format(field=field))

    def _check_crush_ruleset(self, fsid, data, errors):
        if 'crush_ruleset' in data:
            rules = self.client.list(fsid, CRUSH_RULE, {})
            rulesets = set(r['ruleset'] for r in rules)
            if data['crush_ruleset'] not in rulesets:
                errors['crush_ruleset'].append(
                        "CRUSH ruleset {0} not found".format(data['crush_ruleset']))

    def _check_pg_num_inside_config_bounds(self, fsid, data, errors):
        ceph_config = self.client.get_sync_object(fsid, 'config')
        if not ceph_config:
            return Response("Cluster configuration unavailable", status=status.HTTP_503_SERVICE_UNAVAILABLE)
        if 'pg_num' in data and data['pg_num'] > int(ceph_config['mon_max_pool_pg_num']):
            errors['pg_num'].append('requested pg_num must be <= than current limit of {max}'.format(
                    max=ceph_config['mon_max_pool_pg_num']))

    def _check_pgp_less_than_pg_num(self, data, errors):
        if 'pgp_num' in data and 'pg_num' in data and data['pg_num'] < data['pgp_num']:
            errors['pgp_num'].append('must be >= to pg_num')

    def _check_name_unique(self, fsid, data, errors):
        if 'name' in data and data['name'] in [x.pool_name \
                                               for x in [PoolDataObject(p) for p in self.client.list(fsid, POOL, {})]]:
            errors['name'].append(
                    'Pool with name {name} already exists'.format(name=data['name']))


class OsdViewSet(ONEStorCommon, RequestReturner):
    """
Manage Ceph OSDs.

Apply ceph commands to an OSD by doing a POST with no data to
api/v2/cluster/<fsid>/osd/<osd_id>/command/<command>
where <command> is one of ("scrub", "deep-scrub", "repair")

e.g. Initiate a scrub on OSD 0 by POSTing {} to api/v2/cluster/<fsid>/osd/0/command/scrub

Filtering is available on this resource:

::

    # Pass a ``pool`` URL parameter set to a pool ID to filter by pool, like this:
    /api/v2/cluster/<fsid>/osd?pool=1

    # Pass a series of ``id__in[]`` parameters to specify a list of OSD IDs
    # that you wish to receive.
    /api/v2/cluster/<fsid>/osd?id__in[]=2&id__in[]=3

    """
    serializer_class = OsdSerializer

    def flashCachelist(self, request, fsid):
        try:
            osd_node = request.GET.get('osd_node')
            # BEGIN MODIFY BY C13463 安分区获得journal_size，flashcache_size 数据
            partition_name = request.GET.get('partition_name')
            host_query_response = send_request_onestord('COMP_CS', 'DOMAIN_query', {})
            partition_list = host_query_response['response']['data']['query_partition_info']
            osd_partition = None
            for partition in partition_list:
                if partition['partition_name'] == partition_name:
                    osd_partition = partition
            if osd_partition is not None:
                journal_size = int(osd_partition['journal_size'])
                flashcache_size = int(osd_partition['flashcache_size'])
            else:
                journal_size = 10
                flashcache_size = 40
            # END MODIFY BY C13463
            journal_disks = []
            disk_info = self.exec_remote_ssh_cmd(osd_node, \
                                                 '/opt/h3c/bin/python /var/lib/ceph/shell/onestor.py list_journal_and_flashcache_info %s %s' \
                                                 % (journal_size, flashcache_size))
            results = json.loads(disk_info)

            journal_disks = []
            journal_partition_num = 0
            if results['journal_detail'] != '0':
                journal_detail = results['journal_detail'].split(',')
                for disk in journal_detail:
                    journal_disks.append(disk.split(':')[0])
                    journal_partition_num = journal_partition_num + int(disk.split(':')[1].split('|')[0])

            flash_disks = []
            flash_partition_num = 0
            if results['flash_detail'] != '0':
                flash_detail = results['flash_detail'].split(',')
                for disk in flash_detail:
                    flash_disks.append(disk.split(':')[0])
                    flash_partition_num = flash_partition_num + int(disk.split(':')[1].split('|')[0])

            return Response({'flash_partition_num': flash_partition_num, 'flash_disks': flash_disks, \
                             'journal_disks': journal_disks, 'journal_partition_num': journal_partition_num, \
                             'journal_size': journal_size * 1024 * 1024 * 1024,
                             'flashcache_size': flashcache_size * 1024 * 1024 * 1024})

        except Exception, e:
            log.error(e)
            cluster_config = self.get_config_from_conf_file()
            journal_size = int(cluster_config['journal_size']) * 1024 * 1024
            flashcache_size = int(cluster_config['flashcache_size']) * 1024 * 1024
            return Response(
                    {'flash_partition_num': 0, 'flash_disks': [], 'journal_disks': [], 'journal_partition_num': 0, \
                     'journal_size': journal_size, 'flashcache_size': flashcache_size})

    def list(self, request, fsid):
        # Get data needed for filtering
        list_filter = {}

        if 'pool' in request.GET:
            try:
                pool_id = int(request.GET['pool'])
            except ValueError:
                return Response("Pool ID must be an integer", status=status.HTTP_400_BAD_REQUEST)
            list_filter['pool'] = pool_id

        if 'id__in[]' in request.GET:
            try:
                ids = request.GET.getlist("id__in[]")
                list_filter['id__in'] = [int(i) for i in ids]
            except ValueError:
                return Response("Invalid OSD ID in list", status=status.HTTP_400_BAD_REQUEST)

        # Get data
        osds = self.client.list(fsid, OSD, list_filter, async=True)
        osd_to_pools = self.client.get_sync_object(
                fsid, 'osd_map', ['osd_pools'], async=True)
        crush_nodes = self.client.get_sync_object(
                fsid, 'osd_map', ['osd_tree_node_by_id'], async=True)
        osds = osds.get()

        # Get data depending on OSD list
        server_info = self.client.server_by_service(
                [ServiceId(fsid, OSD, str(osd['osd'])) for osd in osds], async=True)
        osd_commands = self.client.get_valid_commands(
                fsid, OSD, [x['osd'] for x in osds], async=True)

        # Preparation complete, await all data to serialize result
        osd_to_pools = osd_to_pools.get()
        crush_nodes = crush_nodes.get()
        server_info = server_info.get()
        osd_commands = osd_commands.get()

        # Build OSD data objects
        for o in osds:
            # An OSD being in the OSD map does not guarantee its presence in the CRUSH
            # map, as "osd crush rm" and "osd rm" are separate operations.
            try:
                o.update(
                        {'reweight': float(crush_nodes[o['osd']]['reweight'])})
            except KeyError:
                log.warning(
                        "No CRUSH data available for OSD {0}".format(o['osd']))
                o.update({'reweight': 0.0})

        for o, (service_id, fqdn) in zip(osds, server_info):
            o['server'] = fqdn

        for o in osds:
            o['pools'] = osd_to_pools[o['osd']]

        for o in osds:
            o.update(osd_commands[o['osd']])

        return Response(self.serializer_class([DataObject(o) for o in osds], many=True).data)

    @csrf_exempt
    def retrieve(self, request, fsid, osd_id):
        osd = self.client.get_sync_object(
                fsid, 'osd_map', ['osds_by_id', int(osd_id)])
        crush_node = self.client.get_sync_object(
                fsid, 'osd_map', ['osd_tree_node_by_id', int(osd_id)])
        osd['reweight'] = float(crush_node['reweight'])
        osd['server'] = self.client.server_by_service(
                [ServiceId(fsid, OSD, osd_id)])[0][1]

        pools = self.client.get_sync_object(
                fsid, 'osd_map', ['osd_pools', int(osd_id)])
        osd['pools'] = pools

        osd_commands = self.client.get_valid_commands(fsid, OSD, [int(osd_id)])
        osd.update(osd_commands[int(osd_id)])

        return Response(self.serializer_class(DataObject(osd)).data)

    def update(self, request, fsid, osd_id):
        serializer = self.serializer_class(data=request.DATA)
        if serializer.is_valid(request.method):
            return self._return_request(self.client.update(fsid, OSD, int(osd_id), serializer.get_data()))
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def apply(self, request, fsid, osd_id, command):
        if command in self.client.get_valid_commands(fsid, OSD, [int(osd_id)]).get(int(osd_id)).get('valid_commands'):
            return Response(self.client.apply(fsid, OSD, int(osd_id), command), status=202)
        else:
            return Response('{0} not valid on {1}'.format(command, osd_id), status=403)

    def get_implemented_commands(self, request, fsid):
        return Response(OSD_IMPLEMENTED_COMMANDS)

    def get_valid_commands(self, request, fsid, osd_id=None):
        osds = []
        if osd_id is None:
            osds = self.client.get_sync_object(
                    fsid, 'osd_map', ['osds_by_id']).keys()
        else:
            osds.append(int(osd_id))

        return Response(self.client.get_valid_commands(fsid, OSD, osds))

    def validate_command(self, request, fsid, osd_id, command):
        valid_commands = self.client.get_valid_commands(
                fsid, OSD, [int(osd_id)]).get(int(osd_id)).get('valid_commands')

        return Response({'valid': command in valid_commands})

    # PN:201601210379 批量删除硬盘前先停止osd进程
    # 创建日期 ：2016年3月3日
    # 作 者 ：戴新春 d10039
    # 函数描述 ：批量删除硬盘前先停止osd进程
    # 输入参数 ：无
    # 输出参数 ：无
    # 返 回 值 :
    # 注意事项 :
    # ------------------------------------------------------------------
    # 修改历史
    # 日期 姓名 描述
    # ------------------------------------------------------------------
    def stop_disk_daemon(self, request, fsid):
        try:
            osd_ids = request.DATA['osd_ids']
            hostname = request.DATA['hostname']

            stop_daemon_command = 'date'
            for _id in osd_ids:
                # MODIFY BY Z11524 2016/07/27 PN:201607230334
                distro = platform.dist()[0]
                if distro == "centos":
                    stop_daemon_command += \
                       ' && mv /var/lib/ceph/osd/ceph-{osd_id}/ready /var/lib/ceph/osd/ceph-{osd_id}/ready_bak' \
                        ' && systemctl stop ceph-osd@{osd_id}.service'.format(osd_id=_id)
                else:
                    stop_daemon_command += \
                       ' && mv /var/lib/ceph/osd/ceph-{osd_id}/ready /var/lib/ceph/osd/ceph-{osd_id}/ready_bak' \
                        ' && stop ceph-osd id={osd_id}'.format(osd_id=_id)

            self.exec_remote_ssh_cmd(hostname, stop_daemon_command)

            return Response({'success': True})

        except KeyError:
            return Response({'success': False, 'error': u'输入参数错误'})
        finally:
            # BEGIN ADD BY D10039 2016/05/28 PN:201607290233 增加定时检查网络的功能
            if os.path.exists('/tmp/.remove_disk_network_error'):
                self.exec_local_cmd('rm -f /tmp/.remove_disk_network_error')
                return Response({'success': False, 'error': 'NETWORK_FAULT'})
                # END ADD BY D10039 2016/05/28 PN:201607290233


class OsdConfigViewSet(RPCViewSet, RequestReturner):
    """
    Manage flags in the OsdMap
    """
    serializer_class = OsdConfigSerializer

    def osd_config(self, request, fsid):
        osd_map = self.client.get_sync_object(fsid, OSD_MAP, ['flags'])
        return Response(osd_map)

    def update(self, request, fsid):
        serializer = self.serializer_class(data=request.DATA)
        if not serializer.is_valid(request.method):
            return Response(serializer.errors, status=403)

        response = self.client.update(
                fsid, OSD_MAP, None, serializer.get_data())

        return self._return_request(response)


class SyncObject(RPCViewSet):
    """
These objects are the raw data received by the Calamari server from the Ceph cluster,
such as the cluster maps
    """

    def retrieve(self, request, fsid, sync_type):
        return Response(self.client.get_sync_object(fsid, sync_type))

    def describe(self, request, fsid):
        return Response([s.str for s in SYNC_OBJECT_TYPES])


class DebugJob(RPCViewSet, RequestReturner):
    """
For debugging and automated testing only.
    """

    def create(self, request, fqdn):
        cmd = request.DATA['cmd']
        args = request.DATA['args']

        # Avoid this debug interface being an arbitrary execution mechanism.
        if not cmd.startswith("ceph.selftest"):
            raise PermissionDenied(
                    "Command '%s' is not a self test command".format(cmd))

        return self._return_request(self.client.debug_job(fqdn, cmd, args))


class ServerClusterViewSet(RPCViewSet):
    """
View of servers within a particular cluster.

Use the global server view for DELETE operations (there is no
concept of deleting a server from a cluster, only deleting
all record of it from any/all clusters).
    """
    serializer_class = ServerSerializer

    def metadata(self, request):
        m = super(ServerClusterViewSet, self).metadata(request)
        m['name'] = "Server (within cluster)"
        return m

    def _addr_to_iface(self, addr, ip_interfaces):
        """
        Resolve an IP address to a network interface.

        :param addr: An address string like "1.2.3.4"
        :param ip_interfaces: The 'ip_interfaces' salt grain
        """
        for iface_name, iface_addrs in ip_interfaces.items():
            if addr in iface_addrs:
                return iface_name

        return None

    def _lookup_ifaces(self, servers):
        """
        Resolve the frontend/backend addresses (known
        by cthulhu via Ceph) to network interfaces (known by salt from its
        grains).
        """
        server_to_grains = get_remote_grains([s['fqdn'] for s in servers])

        for server in servers:
            fqdn = server['fqdn']
            grains = server_to_grains[fqdn]
            server['frontend_iface'] = None
            server['backend_iface'] = None
            if grains is None:
                # No metadata available for this server
                continue
            else:
                try:
                    if server['frontend_addr']:
                        server['frontend_iface'] = self._addr_to_iface(
                                server['frontend_addr'], grains['ip_interfaces'])
                    if server['backend_addr']:
                        server['backend_iface'] = self._addr_to_iface(
                                server['backend_addr'], grains['ip_interfaces'])
                except KeyError:
                    # Expected network metadata not available, we cannot infer
                    # front/back interfaces so leave them null
                    pass

    def list(self, request, fsid):
        servers = self.client.server_list_cluster(fsid)
        self._lookup_ifaces(servers)
        return Response(self.serializer_class(
                [DataObject(s) for s in servers], many=True).data)

    def retrieve(self, request, fsid, fqdn):
        server = self.client.server_get_cluster(fqdn, fsid)
        self._lookup_ifaces([server])
        return Response(self.serializer_class(DataObject(server)).data)


class ServerViewSet(RPCViewSet):
    """
Servers which are in communication with Calamari server, or which
have been inferred from the OSD map.  If a server is in communication
with the Calamari server then it is considered *managed*.

If a server is only known via the OSD map, then the FQDN attribute
will be set to the hostname.  This server is later added as a managed
server then the FQDN will be modified to its correct value.
    """
    serializer_class = SimpleServerSerializer

    def retrieve_grains(self, request, fqdn):
        grains = get_remote_grains([fqdn])[fqdn]
        if not grains:
            return Response(status=status.HTTP_404_NOT_FOUND)
        else:
            return Response(grains)

    def retrieve(self, request, fqdn):
        return Response(
                self.serializer_class(DataObject(
                        self.client.server_get(fqdn))).data
        )

    def list(self, request):
        return Response(self.serializer_class([DataObject(s) for s in self.client.server_list()], many=True).data)

    def destroy(self, request, fqdn):
        self.client.server_delete(fqdn)
        return Response(status=status.HTTP_204_NO_CONTENT)

    # Begin added by wuxiangwei@h3c.com
    def apply(self, request, fqdn):
        try:
            command = request.DATA['command']
        except KeyError:
            raise ParseError("'command' field is required")
        else:
            if not (isinstance(command, basestring)):
                raise ParseError("'command' must be a string")

        try:
            cwd = request.DATA['directory']
        except:
            cwd = '/root/'

        cwd = ''.join(['cwd=', cwd])

        res = self.client.server_apply(fqdn, 'cmd.run', [cwd, command])

        return Response(res)

    def sync(self, request, fqdn):
        try:
            src = request.DATA['src']
            dst = request.DATA['dst']
        except KeyError:
            raise ParseError("'src' and 'dest' field is required")
        else:
            if not (isinstance(src, basestring) or isinstance(dst, basestring)):
                raise ParseError("'src' and 'dst' must be a string")

        src = ''.join(['salt://', src])
        dst = ''.join(['dest=', dst])

        result = self.client.server_apply(
                fqdn, 'cp.get_file', [src, dst, 'makedirs=true'])
        return Response(result)

    def salt_config(self, request, fqdn):
        try:
            minion_ip = request.DATA['ip']
            user = request.DATA['user']
            passwd = request.DATA['passwd']
            master_ip = request.DATA['master']
        except KeyError:
            raise ParseError("invalid parameters")

        minions = [{'ip': minion_ip, 'user': user, 'password': passwd}]
        ret = self.client.config_minions(minions, master_ip)

        return Response(ret)

    def salt_cp(self, request, fqdn):
        try:
            file_path = request.DATA['file_path']
        except KeyError:
            raise ParseError("invalid parameters")

        res = self.client.push_file(fqdn, file_path)

        return Response(res)

        # End added by wuxiangwei@h3c.com


class EventViewSet(DatabaseViewSet, PaginatedMixin):
    """
Events generated by Calamari server in response to messages from
servers and Ceph clusters.  This resource is paginated.

Note that events are not visible synchronously with respect to
all other API resources.  For example, you might read the OSD
map, see an OSD is down, then quickly read the events and find
that the event about the OSD going down is not visible yet (though
it would appear very soon after).

The ``severity`` attribute mainly follows a typical INFO, WARN, ERROR
hierarchy.  However, we have an additional level between INFO and WARN
called RECOVERY.  Where something going bad in the system is usually
a WARN message, the opposite state transition is usually a RECOVERY
message.

This resource supports "more severe than" filtering on the severity
attribute.  Pass the desired severity threshold as a URL parameter
in a GET, such as ``?severity=RECOVERY`` to show everything but INFO.

    """
    serializer_class = EventSerializer

    @property
    def queryset(self):
        return self.session.query(Event).order_by(Event.when.desc())

    def _filter_by_severity(self, request, queryset=None):
        if queryset is None:
            queryset = self.queryset
        severity_str = request.GET.get("severity", "INFO")
        try:
            severity = severity_from_str(severity_str)
        except KeyError:
            raise ParseError("Invalid severity '%s', must be on of %s" % (severity_str,
                                                                          ",".join(SEVERITIES.values())))

        return queryset.filter(Event.severity <= severity)

    def list(self, request):
        return Response(self._paginate(request, self._filter_by_severity(request)))

    def list_cluster(self, request, fsid):
        return Response(self._paginate(request, self._filter_by_severity(request, self.queryset.filter_by(fsid=fsid))))

    def list_server(self, request, fqdn):
        return Response(self._paginate(request, self._filter_by_severity(request, self.queryset.filter_by(fqdn=fqdn))))


class LogTailViewSet(RemoteViewSet):
    """
A primitive remote log viewer.

Logs are retrieved on demand from the Ceph servers, so this resource will return a 503 error if no suitable
server is available to get the logs.

GETs take an optional ``lines`` parameter for the number of lines to retrieve.
    """
    serializer_class = LogTailSerializer

    def get_cluster_log(self, request, fsid):
        """
        Retrieve the cluster log from one of a cluster's mons (expect it to be in /var/log/ceph/ceph.log)
        """

        lines = request.GET.get('lines', 500)

        # Resolve FSID to name
        name = self.client.get_cluster(fsid)['name']

        # Resolve FSID to list of mon FQDNs
        servers = self.client.server_list_cluster(fsid)
        # Sort to get most recently contacted server first; drop any
        # for whom last_contact is None
        servers = [s for s in servers if s['last_contact']]
        servers = sorted(servers,
                         key=lambda t: dateutil_parse(t['last_contact']),
                         reverse=True)
        mon_fqdns = []
        for server in servers:
            for service in server['services']:
                service_id = ServiceId(*(service['id']))
                if service['running'] and service_id.service_type == MON and service_id.fsid == fsid:
                    mon_fqdns.append(server['fqdn'])

        log.debug("LogTailViewSet: mons for %s are %s", fsid, mon_fqdns)
        # For each mon FQDN, try to go get ceph/$cluster.log, if we succeed return it, if we fail try the next one
        # NB this path is actually customizable in ceph as
        # `mon_cluster_log_file` but we assume user hasn't done that.
        for mon_fqdn in mon_fqdns:
            results = self.client.get_server_log(
                    mon_fqdn, "ceph/{name}.log".format(name=name), lines)
            if results:
                return Response({'lines': results[mon_fqdn]})
            else:
                log.info("Failed to get log from %s", mon_fqdn)

        # If none of the mons gave us what we wanted, return a 503 service
        # unavailable
        return Response("mon log data unavailable", status=status.HTTP_503_SERVICE_UNAVAILABLE)

    def list_server_logs(self, request, fqdn):
        results = self.client.list_server_logs(fqdn)
        if not results:
            return Response(status=status.HTTP_503_SERVICE_UNAVAILABLE)
        return Response(sorted(results[fqdn]))

    def get_server_log(self, request, fqdn, log_path):
        lines = request.GET.get('lines', 500)
        results = self.client.get_server_log(fqdn, log_path, lines)
        if not results:
            return Response(status=status.HTTP_503_SERVICE_UNAVAILABLE)
        else:
            return Response({'lines': results[fqdn]})


class MonViewSet(RPCViewSet):
    """
Ceph monitor services.

Note that the ID used to retrieve a specific mon using this API resource is
the monitor *name* as opposed to the monitor *rank*.

The quorum status reported here is based on the last mon status reported by
the Ceph cluster, and also the status of each mon daemon queried by Calamari.

For debugging mons which are failing to join the cluster, it may be
useful to show users data from the /status sub-url, which returns the
"mon_status" output from the daemon.

    """
    serializer_class = MonSerializer

    def _get_mons(self, fsid):
        mon_status = self.client.get_sync_object(fsid, 'mon_status')
        if not mon_status:
            raise Http404("No mon data available")

        mons = mon_status['monmap']['mons']
        service_ids = [ServiceId(fsid, MON, mon['name']) for mon in mons]
        services_info = self.client.status_by_service(service_ids)

        # Use this to invalidate any statuses we can prove are outdated
        lowest_valid_epoch = mon_status['election_epoch']

        # Step 1: account for the possibility that our cluster-wide mon_status object
        # could be out of date with respect to local mon_status data that we get
        # from each mon service.
        for mon, service_info in zip(mons, services_info):
            if service_info and service_info['status']:
                local_epoch = service_info['status']['election_epoch']
                if local_epoch > lowest_valid_epoch:
                    # Evidence that the cluster mon status is out of date, and we have
                    # a more recent one to replace it with.
                    log.warn(
                            "Using mon '%s' local status as it is most recent", mon['name'])
                    mon_status = service_info['status']
                    lowest_valid_epoch = mon_status['election_epoch']
                elif local_epoch == lowest_valid_epoch and service_info['status']['quorum'] != mon_status['quorum']:
                    # Evidence that the cluster mon status is out of date, and we
                    # have to assume that anyone it claimed was in quorum no
                    # longer is.
                    log.warn(
                            "Disregarding cluster mon status because '%s' disagrees", mon['name'])
                    lowest_valid_epoch = local_epoch + 1

        # Step 2: Reconcile what the cluster mon status thinks about this mon with
        # what it thinks about itself.
        for mon, service_info in zip(mons, services_info):
            mon['server'] = service_info['server'] if service_info else None

            cluster_opinion = mon['rank'] in mon_status[
                'quorum'] and mon_status['election_epoch'] >= lowest_valid_epoch
            if service_info is None or service_info['status'] is None:
                # Handle local data being unavailable, e.g. if our agent
                # is not installed on one or more mons
                mon['status'] = None
                mon['in_quorum'] = cluster_opinion
                continue

            status = service_info['status']
            mon['status'] = status

            local_opinion = service_info['running'] and (status['rank'] in status['quorum']) and \
                            status['election_epoch'] >= lowest_valid_epoch

            if cluster_opinion != local_opinion:
                log.warn("mon %s/%s local state disagrees with cluster state",
                         mon['name'], mon['rank'])

                if status['election_epoch'] == 0 or not service_info['running']:
                    # You're claiming not to be in quorum, I believe you because I have
                    # no way of knowing the cluster map is more up to date than
                    # your info.
                    mon['in_quorum'] = local_opinion
                elif status['election_epoch'] < mon_status['election_epoch']:
                    # The cluster map is unambiguously more up to date than your info, so
                    # I believe it.
                    mon['in_quorum'] = cluster_opinion
                else:
                    # Your data is newer than the cluster map, I believe you.
                    mon['in_quorum'] = local_opinion
            else:
                mon['in_quorum'] = cluster_opinion

        # Step 3: special case, handle when our local inferrences about mon status
        # make it impossible for us to believe what the cluster mon status is
        # telling us.
        if len([m for m in mons if m['in_quorum']]) < (len(mons) / 2 + 1):
            log.warn(
                    "Asserting that there is no quorum even if cluster map says there is")
            # I think the cluster map is lying about there being a quorum at
            # all
            for m in mons:
                m['in_quorum'] = False

        return mons

    def retrieve(self, request, fsid, mon_id):
        mons = self._get_mons(fsid)
        try:
            mon = [m for m in mons if m['name'] == mon_id][0]
        except IndexError:
            raise Http404("Mon '%s' not found" % mon_id)

        return Response(self.serializer_class(DataObject(mon)).data)

    def retrieve_status(self, request, fsid, mon_id):
        service_info = self.client.status_by_service(
                [ServiceId(fsid, 'mon', mon_id)])[0]
        if service_info is None:
            raise Http404("Mon not found '%s'" % mon_id)

        return Response(service_info['status'])

    def list(self, request, fsid):
        return Response(self.serializer_class([DataObject(m) for m in self._get_mons(fsid)], many=True).data)


class CliViewSet(RemoteViewSet):
    """
Access the `ceph` CLI tool remotely.

To achieve the same result as running "ceph osd dump" at a shell, an
API consumer may POST an object in either of the following formats:

::

    {'command': ['osd', 'dump']}

    {'command': 'osd dump'}


The response will be a 200 status code if the command executed, regardless
of whether it was successful, to check the result of the command itself
read the ``status`` attribute of the returned data.

The command will be executed on the first available mon server, retrying
on subsequent mon servers if no response is received.  Due to this retry
behaviour, it is possible for the command to be run more than once in
rare cases; since most ceph commands are idempotent this is usually
not a problem.
    """
    serializer_class = CliSerializer

    def create(self, request, fsid):
        # Validate
        try:
            command = request.DATA['command']
        except KeyError:
            raise ParseError("'command' field is required")
        else:
            if not (isinstance(command, basestring) or isinstance(command, list)):
                raise ParseError("'command' must be a string or list")

        # Parse string commands to list
        if isinstance(command, basestring):
            command = shlex.split(command)

        name = self.client.get_cluster(fsid)['name']
        result = self.run_mon_job(fsid, "ceph.ceph_command", [name, command])
        log.debug("CliViewSet: result = '%s'", result)

        if not isinstance(result, dict):
            # Errors from salt like "module not available" come back as strings
            raise APIException("Remote error: %s" % str(result))

        return Response(self.serializer_class(DataObject(result)).data)


class LocalCmd(RPCViewSet):
    """
add by d10039 2014/12/02
execute local command in calamari server
    """

    def execute(self, request):
        reload(sys)
        sys.setdefaultencoding("utf8")
        try:
            command = request.DATA['command']
        except KeyError:
            raise ParseError("'command' field is required")
        else:
            if not (isinstance(command, basestring)):
                raise ParseError("'command' must be a string")

        res = os.popen(command).read()

        return Response({'result': res})


class NetDiskViewSet(RPCViewSet):
    """
add by d10039 2014/12/20
execute upload file to server
    """

    def upload(self, request):
        try:
            dir = request.DATA['dir']
            radosgw = request.DATA['radosgw']
            username = request.DATA['username']
            container = request.DATA['container']
            isIEBrowser = request.DATA['isIEBrowser']
            if isIEBrowser == 'true':
                try:
                    number = int(request.DATA['fileCounter'])
                except Exception:
                    pass

                files = ['infile%s' % i for i in range(1, number + 1)]
                for file_name in files:
                    try:
                        upload_file = request.FILES[file_name]
                        if (upload_file):
                            addObject(radosgw, username, '123456',
                                      container, dir, upload_file)
                    except Exception:
                        pass

                    try:
                        tmp_path = upload_file.temporary_file_path()
                        os.system('rm -rf %s' % tmp_path)
                    except Exception:
                        log.debug('upload file size is lower than 2M.')

                return Response(status=status.HTTP_202_ACCEPTED)
            else:
                upload_file = request.FILES['infile']
                res = addObject(radosgw, username, '123456',
                                container, dir, upload_file)

                try:
                    tmp_path = upload_file.temporary_file_path()
                    os.system('rm -rf %s' % tmp_path)
                except Exception:
                    log.debug('upload file size is lower than 2M.')

                return Response({'result': res})

        except Exception:
            return Response(status=status.HTTP_400_BAD_REQUEST)

    def list(self, request, dir):
        radosgw = request.GET.get('radosgw')
        username = request.GET.get('username')
        container = request.GET.get('container')
        res = listObjects(radosgw, username, '123456', container, dir)
        return Response(res)

    def remove(self, request, dir, filename):
        radosgw = request.GET.get('radosgw')
        username = request.GET.get('username')
        container = request.GET.get('container')
        res = removeObject(radosgw, username, '123456',
                           container, dir, filename)
        return Response({'result': res})

    def download(self, request, dir, filename):
        radosgw = request.GET.get('radosgw')
        username = request.GET.get('username')
        container = request.GET.get('container')
        return getObject(radosgw, username, '123456', container, dir, filename)

    def add_floder(self, request, dir, foldername):
        radosgw = request.GET.get('radosgw')
        username = request.GET.get('username')
        container = request.GET.get('container')
        res = addFolder(radosgw, username, '123456',
                        container, dir, foldername)
        return Response({'result': res})

    def remove_floder(self, request, foldername):
        radosgw = request.GET.get('radosgw')
        username = request.GET.get('username')
        container = request.GET.get('container')
        res = removeFolder(radosgw, username, '123456', container, foldername)
        return Response({'result': res})

    def create_user(self, request, username):
        try:
            passwd = request.DATA['passwd']
            # 对密码进行base64解码
            passwd = base64.b64decode(passwd)
            if 'true' == config.get('calamari_web', 'netdisk_switch'):
                user_model = get_user_model()
                user_model.objects.create_user(
                        username=username,
                        password=passwd,
                        email='%s@h3c.com' % username
                )
            return Response({'result': 'success'})
        except Exception, e:
            return Response({'result': 'ERROR_CREATE_USER:%s' % e})

    def change_password(self, request):
        try:
            username = request.DATA['username']
            password_old = request.DATA['passwd_old']
            password_new = request.DATA['passwd_new']
            user = authenticate(username=username, password=password_old)
            if user is not None and user.is_active:
                user.set_password(password_new)
                user.save()
                return Response({'result': 'success'})
            else:
                return Response({'result': 'ERROR_WRONG_PASSWORD'})
        except Exception, e:
            return Response({'result': 'ERROR_CHANGE_PASSWORD:%s' % e})

    def create_container(self, request, containername):
        radosgw = request.DATA['radosgw']
        username = request.DATA['username']
        res = createContainer(radosgw, username, '123456', containername)
        return Response({'result': res})

    def create_user_batch(self, request):
        try:
            upload_file = request.FILES['infile']
        except KeyError:
            raise ParseError("'upload_file' field is required")

        res = createUserBatch(upload_file)
        result = '[begin]%s[end]' % json.dumps(res).replace('\"', '\'')
        return Response(result)

    def make_temp_url(self, request):
        radosgw = request.GET.get('radosgw')
        container = request.GET.get('container')
        filepath = request.GET.get('filepath')
        expire_time = request.GET.get('expire_time')
        rnd_str = request.GET.get('rnd_str')
        filename = request.GET.get('filename')
        isShared = request.GET.get('isShared')
        share_type = request.GET.get('share_type')
        res = makeTempUrl(radosgw, container, filepath,
                          expire_time, rnd_str, filename, isShared, share_type)
        return Response(res)

    def cancel_share(self, request):
        radosgw = request.GET.get('radosgw')
        user = request.GET.get('user')
        path = request.GET.get('path')
        res = cancelShare(radosgw, user, path)
        return Response({'result': res})


class HostConfigViewSet(ONEStorCommon):
    """
    add by d10039 2015/02/05
    """

    def get_disk_info(self, disks):
        disk_ret = '['
        for index, disk in enumerate(disks):
            if 0 != len(disk):
                disk_ret = disk_ret + '{"name":"' + disk.split(',')[0].split(':')[0].split('Disk ')[1] \
                           + '","size":"' + disk.split(',')[0].split(':')[1].lstrip() \
                           + '","type":"' + disk.split(',')[2] + '"}'
                if index != len(disks) - 1:
                    disk_ret = disk_ret + ','
        disk_ret = json.loads(disk_ret + ']')
        return disk_ret

    def connect_host(self, request):
        try:
            hostip = request.DATA['hostip']
            username = request.DATA['username']
            password = request.DATA['password']
            master = request.DATA['master']

            filepath = os.path.split(os.path.realpath(__file__))[0]
            ret = os.popen('/opt/h3c/bin/python %s/handy_common.py connect_host %s %s %s %s' %
                           (filepath, hostip, username, password, master)).read().rstrip()

            if "400" == ret:
                return Response({'status': 400, 'ip': hostip})
            else:
                disks = ret.split(
                        ',disks->')[1].split('available disk -->')[1].split(';')
                disk_ret = self.get_disk_info(disks)
                return Response({'status': 200, 'ip': hostip, 'hostname': ret.split(',disks->')[0], 'disk': disk_ret})

        except Exception, e:
            return Response({'status': 400, 'exception': str(e)})

    def exec_remote_cmd(self, filepath, node, default_user, default_passwd, command):
        # add by l11544 2016/7/1 for onestor_hosts
        ip_exchange = self.name_to_ip(node)
        # end by l11544
        _result = os.popen("/opt/h3c/bin/python %s/handy_common.py exec_remote_cmd %s %s \"%s\" \"%s\"" %
                           (filepath, ip_exchange, default_user, default_passwd, command)).read().rstrip()
        return _result

    def __validate_public_ip(self, result, public_network_segment=None):
        """
        校验业务网IP地址，主机有且只能包含一个业务网IP
        """
        result['has_public_network'] = False
        if public_network_segment:
            public_network = public_network_segment
        else:
            cluster_config = self.get_config_from_conf_file()
            public_network = cluster_config['public_network']
        result['repeat_public_ip'] = False
        public_ip_count = 0
        if result['connect']:
            for _net in result['net_info']:
                if self.subnet_judge(public_network, _net):
                    result['has_public_network'] = True
                    public_ip_count += 1
            if public_ip_count > 1:
                result['repeat_public_ip'] = True

    def scanHost(self, request):
        try:
            filepath = os.path.split(os.path.realpath(__file__))[0]
            host_ip = request.DATA['host_ip']
            default_user = request.DATA['default_user']
            default_password = request.DATA['default_password']
            action = request.DATA['action']
            handyName = os.popen('hostname').read().rstrip()
            # public_network_segment = None
            if action == 'addHost':
                fsid = os.popen('ceph fsid').read().rstrip()
            else:
                fsid = '-1'
                # public_network_segment = request.DATA['public_network']

            scan_result = self.exec_local_cmd('timeout 300 /opt/h3c/bin/python %s/handy_common.py scanHost %s %s "%s"' % (
                filepath, host_ip, default_user, default_password))
            if '' == scan_result:
                result = {'connect': False}
            else:
                result = json.loads(scan_result)
                # BEGIN add BY d11564 2017/1/18 PN:201701020045 添加判断多个业务网ip
                # self.__validate_public_ip(result, public_network_segment)
                # end add by d11564
                from calamari_rest.views.lics.lics_view import LicsViewSet
                result['is_X10000'] = LicsViewSet().check_x10000(host_ip, default_user, default_password)
            try:
                if action == 'addHost':
                    if result['connect']:
                        # begin delete by d11564 2017/1/19 PN:201701020045
                        # BEGIN ADD by z11524 2016/06/20 PN:201606200399
                        result['has_public_network'] = False
                        cluster_config = self.get_config_from_conf_file()
                        public_network = cluster_config['public_network']
                        for _net in result['net_info']:
                            if self.subnet_judge(public_network, _net):
                                result['has_public_network'] = True
                                break
                        # END ADD by z11524 2016/06/20 PN:201606200399

                        # DELETE FOR HANDY HA 2017/03/09

                        # judge if this server is handy and not osd node
                        if result['hostname'] == handyName:
                            handy_ip_list = os.popen("ip addr |grep 'inet ' |grep -v ' lo' " \
                                                     "|awk '{print $2}' |cut -d / -f 1").read().rstrip()
                            # add by z11524 2017.2.17 兼容业务高可用开启负载均衡
                            public_has_cfg = self.exec_local_cmd_json('ceph config-key get highavailableconfig')
                            public_has = []
                            if public_has_cfg and 'highavailableconfig' in public_has_cfg:
                                for public_ha in public_has_cfg['highavailableconfig']:
                                    public_has.append(public_ha['vip'])
                            handy_ip_list = list(set(handy_ip_list.split('\n')) - set(public_has))
                            # end by z11524 2017.2.17 兼容业务高可用开启负载均衡
                            for handy_ip in handy_ip_list:
                                if host_ip == handy_ip:
                                    result['cluster_exist'] = False
                                    topo = json.loads(self.exec_local_cmd(
                                            'ceph osd tree -f json'))
                                    for info in topo['nodes']:
                                        if info['type'] == 'host' and info['name'].split('.')[0] == result['hostname']:
                                            result['cluster_exist'] = True
                                            break
                                    break
                        else:
                            # MODIFY FOR HANDY HA 2017/03/09
                            if result['cluster_same']:
                                result['cluster_exist'] = False
                                topo = json.loads(self.exec_local_cmd(
                                        'ceph osd tree -f json'))
                                for info in topo['nodes']:
                                    if info['type'] == 'host' and info['name'].split('.')[0] == result['hostname']:
                                        result['cluster_exist'] = True
                                        break

                        # BEGIN ADD by d10039 2016/02/24 PN:201602170609
                        # 获取Handy本地/etc/onestor_hosts文件里的主机名，不能与当前扫描主机的名称相同
                        if not result['cluster_exist']:
                            host_name_in_file = os.popen("cat /etc/onestor_hosts | awk '{print $1,$2}'"
                                                         ).read().strip().split('\n')
                            for _hostname in host_name_in_file:
                                # modified by l11544
                                if _hostname.strip().split()[1] == result['hostname']:
                                    # 主机名称匹配时还需要判断当前IP是否为该节点的已有IP
                                    result['cluster_exist'] = True
                                    for _net in result['net_info']:
                                        if _net == _hostname.strip().split()[0]:
                                            # end by l11544
                                            result['cluster_exist'] = False
                                            break
                                    # 如果已经匹配到该主机的IP地址没有变化，则直接跳出外层循环
                                    if not result['cluster_exist']:
                                        break
                                        # END ADD by d10039 2016/02/24 PN:201602170609

            except Exception, e:
                log.exception(e)
                result['cluster_exist'] = False

            result['success'] = True
            return Response(result)

        except Exception, e:
            return Response({'success': False, 'error': e})

    def get_host_performance(self, request, fsid=''):
        host_ip = request.DATA.get('host_ip')
        user = request.DATA.get('default_user')
        passwd = request.DATA.get('default_password')
        result = self._do_get_host_performance(host_ip, user, passwd)
        if '' == result:
            return Response({'connect': False})
        return Response(json.loads(result))

    def _do_get_host_performance(self, host_ip, user, passwd):
        filepath = os.path.split(os.path.realpath(__file__))[0]
        log.info('start do get host {} performance'.format(host_ip))
        command = 'timeout 600 /opt/h3c/bin/python {0}/handy_common.py get_host_performance {1} {2} {3}'.format(
            filepath, host_ip, user, passwd)
        performance_result = self.exec_local_cmd(command)
        log.info('end do get host {} performance, cmd is {}, result is {}'.format(host_ip, command, performance_result))
        return performance_result

    def isHostInCluster(self, fsid, hostname, host_ip, result):
        try:
            handyName = os.popen('hostname').read().rstrip()
            cluster_config = self.get_clusterconfig()
            mon_fqdns = cluster_config['mon_fqdns']
            gateway_list = self.onestor_request(fsid, 'database.list_objs', ['gateway'])
            gateway_fqdns = []
            for gateway in gateway_list['gateway']:
                gateway_fqdns.append(gateway['hostname'])
            mon_and_gateway = set(mon_fqdns + gateway_fqdns)
            # judge if this server is handy and not osd node
            if hostname == handyName:
                handy_ip_list = os.popen(
                        "ip addr|grep 'inet ' |grep -v ' lo' |awk  '{print $2}' |cut -d / -f 1"
                ).read().rstrip()
                for handy_ip in handy_ip_list.split('\n'):
                    if host_ip == handy_ip:
                        result['cluster_exist'] = False
                        topo = json.loads(self.exec_local_cmd('ceph osd tree -f json'))
                        for info in topo['nodes']:
                            if info['type'] == 'host' and info['name'] == hostname:
                                result['cluster_exist'] = True
                                break
                        break
            else:
                # judge if this server is only mon or gateway and not osd node
                if hostname in mon_and_gateway:
                    result['cluster_exist'] = False
                    topo = json.loads(self.exec_local_cmd('ceph osd tree -f json'))
                    for info in topo['nodes']:
                        if info['type'] == 'host' and info['name'] == hostname:
                            result['cluster_exist'] = True
                            break
        except KeyError:
            result['cluster_exist'] = False
        except:
            result['cluster_exist'] = False

    def scanHostInfo(self, request):
        try:
            filepath = os.path.split(os.path.realpath(__file__))[0]
            host_ip = request.GET.get('host_ip')
            username = request.GET.get('username')
            password = request.GET.get('password')

            if None == host_ip:
                return Response({'success': False, 'error': u'IP地址为空', 'errorcode': 'IP_ADDR_NULL'})

            if None == username:
                return Response({'success': False, 'error': u'用户名为空', 'errorcode': 'USERNAME_NULL'})

            if None == password:
                return Response({'success': False, 'error': u'密码为空', 'errorcode': 'PASSWORD_NULL'})

            scan_result = os.popen('timeout 300 /opt/h3c/bin/python %s/handy_common.py scanHost %s %s %s' \
                                   % (filepath, host_ip, username, password)).read().rstrip()

            if '' == scan_result:
                return Response({'success': False, 'connect': False, 'errorcode': 'NETWORK_UNREACHABLE'})
            else:
                returned = {}
                result = json.loads(scan_result)

                if not result['connect']:
                    return Response({'success': False, 'connect': False, 'errorcode': 'NETWORK_UNREACHABLE'})

                try:
                    fsid_result = cmdprocess.command(['ceph', 'fsid'], 20)
                    if '' != fsid_result['stdout']:
                        self.isHostInCluster(fsid_result['stdout'].rstrip(), result['hostname'], host_ip, result)
                except cmdprocess.TimeoutExpired:
                    pass

                returned['linux_version'] = result['linux_version']
                returned['cluster_exist'] = result['cluster_exist']
                returned['hostname'] = result['hostname']
                returned['connect'] = result['connect']
                returned['success'] = True

                returned['disks'] = []
                if result['disk_info'].find('available disk -->') != -1:
                    if 'available disk -->' == result['disk_info'].strip():
                        return Response(returned)

                    disk_info = result['disk_info'].split('available disk -->')

                    all_disk = disk_info[1].split(';')
                    for disk in all_disk:
                        returned['disks'].append({
                            'name': disk.split(':')[0].split('Disk ')[1],
                            'size': disk.split(',')[1].split(' bytes')[0].strip(),
                            'type': 'SSD' if '0' == disk.split(',')[2] else 'HDD'
                        })

            return Response(returned)
        except KeyError:
            return Response({'success': False, 'errorcode': 'KeyError'})
        except Exception, e:
            return Response({'success': False, 'error': e, 'errorcode': 'INTERNAL_SERVER_ERROR'})

    def scanHostBatch(self, request):
        try:
            network_segment = request.GET.get('network_segment')
            if None == network_segment:
                return Response({'error': u'%s为空' % cluster_head_net, 'errorcode': 'NETWORK_SEGMENT_NULL'})

            # BEGIN ADD BY D10039 2016/04/23 PN:201604210580 UISM扫描支持IP前导为0
            network_segment_array = [item.split('/')[0] for item in network_segment.split('.')]
            if 4 != len(network_segment_array):
                return Response({'error': u'非法的%s' % cluster_head_net, 'errorcode': 'ILLEGAL_SEGMENT'})

            for i in range(4):
                network_single = network_segment_array[i]
                if 3 < len(network_single) or 0 > int(network_single) or 255 < int(network_single):
                    return Response({'error': u'非法的%s' % cluster_head_net, 'errorcode': 'ILLEGAL_SEGMENT'})

            network_segment = '.'.join([str(int(net)) for net in network_segment_array]) + '/24'

            if not network_segment.endswith('0/24'):
                return Response({'error': u'只支持扫描24位掩码的网段', 'errorcode': 'UNSUPPORT_SEGMENT'})
            # END ADD BY D10039 2016/04/23

            all_node_ip = os.popen('/opt/h3c/salt/salt/shell/ping.sh %s' \
                                   % (network_segment.split('.0/')[0])).read().strip()
            all_ip = json.loads(all_node_ip)
            return Response(all_ip)
        except ValueError:
            # MODIFY BY D10039 2016/04/23 PN:201604210580 UISM扫描支持IP前导为0
            return Response({'error': u'非法的%s' % cluster_head_net, 'errorcode': 'ILLEGAL_SEGMENT'})
        except Exception, e:
            # MODIFY BY D10039 2016/04/23 PN:201604210580 UISM扫描支持IP前导为0
            return Response({'error': e, 'errorcode': 'ILLEGAL_SEGMENT'})

    def scanExistHostDisk(self, request):
        try:
            HANDY_SHELL_PATH = '/var/lib/ceph/shell'
            fqdn = request.GET['fqdn']
            list_disk_command = '/opt/h3c/bin/python %s/list_disk.py' % HANDY_SHELL_PATH
            results = self.exec_remote_ssh_cmd(fqdn, list_disk_command)
            if results.find('available disk -->') != -1:
                if 'available disk -->' == results.strip():
                    return Response({'success': True, 'disks': []})

                disk_info = results.split('available disk -->')

                all_disk_return = []
                all_disk = disk_info[1].split(';')
                for disk in all_disk:
                    all_disk_return.append({
                        'name': disk.split(':')[0].split('Disk ')[1],
                        'size': disk.split(',')[1].split(' bytes')[0].strip(),
                        'type': 'SSD' if '0' == disk.split(',')[2] else 'HDD'
                    })
                return Response({'success': True, 'disks': all_disk_return})
            else:
                return Response({'success': False, 'error': results, 'errorcode': 'INTERNAL_SERVER_ERROR'})
        except KeyError:
            return Response({'success': False, 'errorcode': 'INTERNAL_SERVER_ERROR'})
        except Exception, e:
            return Response({'success': False, 'error': str(e), 'errorcode': 'INTERNAL_SERVER_ERROR'})

    def getHandyPublicIP(self, request):
        filepath = os.path.split(os.path.realpath(__file__))[0]
        public_network = request.DATA['public_network']

        publicIP = os.popen('/opt/h3c/bin/python %s/handy_common.py getHandyPublicIP %s' %
                            (filepath, public_network)).read().rstrip()
        return Response({'status': 'success', 'data': publicIP})

    def add_host_results(self, osd_nodes):
        try:
            all_osd_node = []
            topo = json.loads(self.exec_local_cmd('ceph osd tree -f json'))
            for info in topo['nodes']:
                if info['type'] == 'host':
                    all_osd_node.append(info['name'])

            failed_node_str = ''
            add_node = osd_nodes.split(',')
            for node in add_node:
                if node not in all_osd_node:
                    failed_node_str += node + ','

            return {'success': True, 'failed_node_str': failed_node_str.rstrip(',')}

        except Exception, e:
            log.error('get add host results error: %s', e)
            return {'success': False}

    def __clean_mon_nodes(self, mon_nodes):
        """
        部署新的集群之前清理mon节点上的目录
        :param mon_nodes:
        :return:
        """
        try:
            self.exec_local_cmd('rm -f /home/ceph-cluster/*')
            self.multi_thread_task(
                    mon_nodes, 'rm -rf /var/lib/ceph/mon/*', ssh=True)
            self.multi_thread_task(
                    mon_nodes, 'rm -rf /etc/ceph/*', ssh=True)
            self.multi_thread_task(
                    mon_nodes, 'rm -rf /var/run/ceph/*', ssh=True)
            distro = platform.dist()[0]
            if distro == "centos":
                self.multi_thread_task(
                        mon_nodes, 'systemctl stop ceph-mon.target && systemctl start ceph-mon.target', ssh=True)
            else:
                self.multi_thread_task(
                        mon_nodes, 'stop ceph-mon-all && start ceph-mon-all', ssh=True)
        except KeyError:
            log.exception('clean mon nodes error')
        except Exception, e:
            log.exception(e)

    def _save_cluster_config_to_ldb(self, handy_name, cluster_hosts):
        """
        PN:201609180302 将集群配置（包括handy_key和cluster_hosts）保存到level db中
        return: 1-成功 0-失败
        Author: dai.xinchun@h3c.com
        """
        # PN:201512260085 将Handy的id_rsa.pub保存到数据库中
        pub_key = self.exec_local_cmd('cat /root/.ssh/id_rsa.pub')
        put_handy_key_cmd = "timeout 30 ceph config-key put handy_key '{\"ssh_pub_key\": [{\"%s\": \"%s\"}]}'"
        put_cluster_hosts_cmd = "timeout 30 ceph config-key put cluster_hosts '%s'"
        # 循环5次保存信息，防止因MON挂住导致无法保存
        has_handy_key_tb = False
        has_cluster_hosts_tb = False
        for index in range(5):
            log.info('save_cluster_config_to_ldb with %s time', (index + 1))
            # 判断如果数据库中无此数据就保存
            if '' == self.exec_local_cmd('timeout 30 ceph config-key get handy_key'):
                self.exec_local_cmd(put_handy_key_cmd % (handy_name, pub_key))
            else:
                has_handy_key_tb = True
            # 将主机名对应的业务网IP保存到数据库中
            if '' == self.exec_local_cmd('timeout 30 ceph config-key get cluster_hosts'):
                self.exec_local_cmd(put_cluster_hosts_cmd % json.dumps(cluster_hosts))
            else:
                has_cluster_hosts_tb = True
            # 两个表的数据都存入时返回成功
            if has_handy_key_tb and has_cluster_hosts_tb:
                return 1
        return 0

    def _rollback_rack(self, rack_info):
        try:
            rack_name = rack_info.split(',')[0]
            if rack_info.split(',')[1] == '0':
                self.exec_local_cmd('ceph osd crush remove %s_ssd' % rack_name)
                self.exec_local_cmd('ceph osd crush remove %s' % rack_name)
        except Exception, e:
            log.error('_roll_back_rack error: %s', e)

    def _clear_cluster_config(self, node):
        try:
            # Handy和监控节点不清除配置文件
            log.debug('[ONEStor] clear cluster config for %s', node)

            is_need_to_clear = True

            cluster_config = self.get_config_from_conf_file()
            mon_fqdns = cluster_config['mon_fqdns']
            for mon in mon_fqdns:
                if node == mon:
                    is_need_to_clear = False
                    break

            handy_name = self.exec_local_cmd('hostname')
            if node == handy_name:
                is_need_to_clear = False

            if is_need_to_clear:
                clear_config_command = 'cp /etc/ceph/ceph.log /tmp/ && rm -rf /etc/ceph/* ' \
                                       '&& mv /tmp/ceph.log /etc/ceph/ceph.log'
                self.exec_remote_ssh_cmd(node, clear_config_command)
            # 节点添加失败，还原NTP配置 add by l11544 2016/8/17
            try:
                # 如果已经是对象网关，也不需要还原
                if is_need_to_clear:
                    gateway_list = self.exec_local_cmd_json('ceph config-key get gateway')
                    for gateway_info in gateway_list:
                        if node == gateway_info['hostname']:
                            is_need_to_clear = False
            except Exception:
                log.debug('cluster do not have gateway')
            if is_need_to_clear:
                self.exec_remote_ssh_cmd(node, '/opt/h3c/bin/python /var/lib/ceph/shell/ntp_task.py ntp_return')
                # end by l11544

        except Exception, e:
            log.error('_clear_cluster_config error: %s', e)

    def _clear_cluster_config_batch(self, osd_nodes):
        try:
            threads = []
            nloops = range(len(osd_nodes.split(',')))

            def clear_config(node):
                self._clear_cluster_config(node)

            for node in osd_nodes.split(','):
                t = threading.Thread(target=clear_config, args=(node,))
                threads.append(t)

            for i in nloops:
                threads[i].start()

            for i in nloops:
                threads[i].join()

        except Exception, e:
            log.error('_clear_cluster_config_batch error: %s', e)

    def recovery_hosts_conf(self, all_node):
        try:
            threads = []
            nloops = range(len(all_node))

            def recovery_conf(node_name):
                # add by l11544 2016/7/1 for onestor_hosts
                node_ip = self.name_to_ip(node_name)
                # end by l11544
                recovery_conf_command = 'scp /etc/ceph/ceph.conf  [%s]:/etc/ceph/ceph.conf' % node_ip
                self.exec_local_cmd(recovery_conf_command)
                # BEGIN ADD BY l11544 for loadBalance 2016/7/11
                self.exec_remote_ssh_cmd(
                        node_name, "/opt/h3c/bin/python /var/lib/ceph/shell/rewrite_config.py ceph_config_fix")
                # end by l11544
                # PN: 201612260612 写入集群主机的业务网IP配置
                self.exec_remote_ssh_cmd(
                        node_ip,
                        '/opt/h3c/bin/python /var/lib/ceph/shell/rewrite_config.py ceph_judge_timer_rewrite {0}'.format(node_ip))
                # end by l11544 2016/12/27

            for node in all_node:
                t = threading.Thread(target=recovery_conf, args=(node,))
                threads.append(t)

            for i in nloops:
                threads[i].start()

        except IOError:
            log.error('[ONEStor] [recovery_hosts_conf] IOError')
        except Exception, e:
            log.error('[ONEStor] [recovery_hosts_conf] %s', e, exc_info=True)

    def collect_logs(self, request, fsid):
        file_name = request.GET.get('filename')

        # BEGIN MODIFY BY D10039 2016/05/27 PN:201605130545 将文件拷贝到temp目录下并通过apache下载
        temp_dir = '/opt/h3c/webapp/content/temp/'
        if not os.path.exists(temp_dir):
            self.exec_local_cmd('mkdir -p %s' % temp_dir)
            self.exec_local_cmd('chmod 755 %s' % temp_dir)
            # 适配CentOS
            self.exec_local_cmd('chown {user}:{user} {dir_name}'.format(
                    user='apache' if os.path.exists('/etc/redhat-release') else 'www-data',
                    dir_name=temp_dir)
            )

        # 删除上一次搜集日志残留的日志文件
        self.exec_local_cmd('rm -f %slogs_*.tar.gz' % temp_dir)

        # 将日志文件从temp目录移动到apache目录中
        self.exec_local_cmd('mv {log_file} {dist_dir}'.format(log_file=file_name, dist_dir=temp_dir))

        # 判断文件是否移动成功
        file_real_name = file_name.split('/tmp/')[1]
        file_dist_path = temp_dir + file_real_name

        if not os.path.exists(file_dist_path):
            return Response({'status': 'error', 'reason': u'下载系统日志失败', 'errorcode': 'NO_SUCH_FILE'})

        return Response({'status': 'success', 'path': '/static/temp/%s' % file_real_name})
        # END MODIFY BY D10039 2016/05/27 PN:201605130545


class ONEStorViewSet(ONEStorCommon):
    '''
    Author: dai.xinchun@h3c.com
    Date: 2015/07/14
    '''
    CEPH_CONF_FILE = '/etc/ceph/ceph.conf'

    def post_passwd_param(self, request, fsid):
        try:
            # BEGIN MODIFY BY C13463 20170311 PN:201703030661
            expire_time = request.DATA.get('expire_time', None)
            lose_efficacy_time = request.DATA.get('lose_efficacy_time', None)
            duplicate_limit = request.DATA.get('duplicate_limit', None)

            calamari_path, message = '/etc/calamari/calamari.conf', ''
            calamari_config = CalamariConfig()
            if os.path.exists("/.dockerenv"):
                self.exec_local_cmd('chmod 777 %s' % calamari_path)
            else:
                self.exec_local_ssh_cmd('chmod 777 %s' % calamari_path)
            self.exec_local_cmd('cp {0} {0}_bak'.format(calamari_path))
            config_update = False
            if expire_time is not None:
                calamari_config.set('password_param', 'expire_time', str(expire_time))
                config_update = True
            if expire_time is not None:
                calamari_config.set('password_param', 'lose_efficacy_time', str(lose_efficacy_time))
                config_update = True
            if expire_time is not None:
                calamari_config.set('password_param', 'duplicate_limit', str(duplicate_limit))
                config_update = True
            if config_update:
                calamari_config.write(open(calamari_path, 'w'))
            # 获取高可用信息，若已经配置高可用，则进行同步
            syn_result = self.syn_calamari_conf()
            if syn_result:
                self.exec_local_cmd('rm -f %s_bak' % calamari_path)
            else:
                self.exec_local_cmd('mv {0}_bak {0}'.format(calamari_path))
                send_add_oplog_msg(
                    request,
                    ('密码策略配置', 'password strategy config'),
                    (-80000, 'Fail to sync config to slave node', '同步配置到管理高可用非工作节点失败')
                )
                return Response({'status': 'error', 'reason': ['Fail to sync config to slave node', u'同步配置到管理高可用非工作节点失败']})
            # 改回权限
            if os.path.exists("/.dockerenv"):
                self.exec_local_cmd('chmod 644 %s' % calamari_path)
            else:
                self.exec_local_ssh_cmd('chmod 644 %s' % calamari_path)
            if '' == message:
                message = 'success'
            send_add_oplog_msg(
                request,
                ('修改集群服务配置', 'Modify cluster service config')
            )
            return Response({'status': 'success', 'message': message})
        except Exception, e:
            log.error(e)
            send_add_oplog_msg(
                request,
                ('修改集群服务配置', 'Modify cluster service config'),
                (-80000, str(e), str(e))
            )
            return Response({'status': 'error', 'reason': str(e)})

    def get_passwd_param(self, request, fsid):
        try:
            result = {}
            calamari_config = CalamariConfig()

            result['expire_time'] = int(calamari_config.get('password_param', 'expire_time'))
            result['lose_efficacy_time'] = int(calamari_config.get('password_param', 'lose_efficacy_time'))
            result['duplicate_limit'] = int(calamari_config.get('password_param', 'duplicate_limit'))
            return Response({'status': 'success', 'data': result})
        except Exception, e:
            log.error(e)
            return Response({'status': 'error', 'reason': str(e)})


    @staticmethod
    def query_onestor_conf(request):
        log.info('begin query onestor conf')
        import ConfigParser
        cf = ConfigParser.SafeConfigParser()
        cf.read(const.ONESTOR_CONF)
        result = {}
        options = cf.options('platform')
        for option in options:
            if cf.has_option('product', option):
                if option.startswith('min'):
                    if float(cf.get('product', option)) >= float(cf.get('platform', option)):
                        # 产品配置下限 大于 平台配置下限
                        result[option] = cf.get('product', option)
                    else:
                        # 产品配置下限 小于 平台配置下限
                        result[option] = cf.get('platform', option)
                elif option.startswith('max'):
                    if float(cf.get('product', option)) <= float(cf.get('platform', option)):
                        # 产品配置上限 小于 平台配置上限
                        result[option] = cf.get('product', option)
                    else:
                        # 产品配置上限 大于 平台配置上限
                        result[option] = cf.get('platform', option)
                else:
                    result[option] = [ele for ele in cf.get('product', option).split(',') if ele in cf.get('platform', option).split(',')]
            else:
                result[option] = cf.get('platform', option)
        log.info('end query onestor conf, result is {}'.format(result))
        return Response({'data': result})

    def get_all_vips(self, request, fsid):
        """
        ADD BY KF6602 2017/3/20 PN:201701110100
        获取集群中所有的虚IP
        """
        try:
            vips = []
            result_handyha = self.list_handyha()
            result_ha = self.exec_local_cmd_json('ceph config-key get highavailableconfig')
            if result_handyha and 'handyha' in result_handyha:
                vips.append(result_handyha['handyha'][0]['vip'])
            if result_ha and 'highavailableconfig' in result_ha:
                for ha in result_ha['highavailableconfig']:
                    vips.append(ha['vip'])
            return Response({'status': 'success', 'vips': vips})
        except KeyError:
            return Response({'status': 'error', 'reason': u'获取集群内vip失败'})
        except Exception, ex:
            return Response({'status': 'error', 'reason': u'获取集群内vip失败'})

    def getClusterCapacity(self, request, fsid):
        try:
            capacity_final = []
            pools = []
            top = []
            replicatedSize = []
            rgw_pool_byte = 0
            sum_pool_capacity = 0
            with rados.Rados(conffile='/etc/ceph/ceph.conf') as cluster:
                cluster_stats = cluster.get_cluster_stats()
                all_pools = cluster.list_pools()
            rgw_pools = ['default.rgw.control', 'default.rgw.log', 'default.rgw.buckets.index', 'default.rgw.buckets.non-ec',
                         '.rgw.root', 'default.rgw.meta', 'default.rgw.buckets.data', '.backup']
            user_pools = []
            for pool in all_pools:
                if pool not in rgw_pools:
                    user_pools.append(pool)

            results = self.onestor_request(
                    fsid, 'onestor.getPoolStat', [self.CEPH_CONF_FILE])
            # 对象存储是否部署 For灾备
            obs_deployed = False
            for pool in results['data']:
                if pool['name'] not in rgw_pools and not pool['name'].startswith('.'):
                    pools.append({'name': pool['name'], 'value': pool[
                        'raw_bytes_used']})
                    replicatedSize.append(
                            {'poolName': pool['name'], 'replicatedSize': pool['size'], 'min_size': pool['min_size'],
                             'type': pool['type']})
                else:
                    if pool['name'] == 'default.rgw.buckets.data':
                        # 对象存储是否部署 For灾备
                        obs_deployed = True
                        rgw_pool_byte = int(pool['raw_bytes_used'])
                        replicatedSize.append(
                                {'poolName': '对象存储', 'replicatedSize': pool['size'], 'min_size': pool['min_size'],
                                 'type': pool['type']})
            # 对象存储是否部署 For灾备
            if obs_deployed:
                pools.append({'name': u'对象存储', 'value': rgw_pool_byte})
            pools.sort(key=lambda *args: args[0]['value'], reverse=1)
            if (len(pools) > 5):
                top = pools[:5]
                capacity = top
            else:
                capacity = pools

            for sumpool in capacity:
                sum_pool_capacity = int(sumpool['value']) + sum_pool_capacity

            capacity_final.append(capacity)
            capacity_final.append(replicatedSize)
            capacity_final.append({
                'total_kb': int(cluster_stats['kb']) * 1024,
                'kb_avail': int(cluster_stats['kb_avail']) * 1024,
                'kb_used': int(cluster_stats['kb_used']) * 1024,
                'count': len(pools),
                'sum_pool_capacity': sum_pool_capacity
            })

            return Response({'status': 'success', 'pool': capacity_final})

        except Exception, e:
            return Response({'status': 'error', 'reason': str(e)})

    def getClusterCapacityV3(self, request, fsid):
        try:
            cluster_capacity_response = send_request_onestord('COMP_CS', 'CLUSTER_capacity_query', {})
            if 'success' == cluster_capacity_response['status']:
                capacity_final = cluster_capacity_response['response']['data']['cluster_capacity']
                return Response({'status': 'success', 'pool': capacity_final})
            else:
                capacity_final = cluster_capacity_response['response']
                return Response({'status': 'error', 'reason': capacity_final})
        except Exception, e:
            return Response({'status': 'error', 'reason': str(e)})

    def saveOperationLog(self, request, fsid):
        user = request.DATA['user']
        ip = request.META.get("REMOTE_ADDR", None)
        _time = self._get_current_time_cst('ms')
        content = request.DATA['content']
        status = request.DATA['status']
        params = [user, ip, _time, content, status]

        if 'unknown' == fsid:
            clusters = self.client.list_clusters()
            for cluster in clusters:
                cluster_id = cluster['id']
                self.saveOperationLogRPC(cluster_id, params)
            return Response([])

        return Response(self.saveOperationLogRPC(fsid, params))

    def create_snmp(self, request):
        comp_op = plat_leader_router.OP_SNMP_CREATE
        data = request.DATA
        response = ForwardView().send_request_to_leader(comp_op, data, unistor_api=False)
        if 0 == response['result'][0]:
            return Response({'success': True})
        else:
            return Response({'success': False, 'reason': response['result']})

    def getObjUser(self, request, fsid):
        results = self.onestor_request(
                fsid, 'database.list_objs', ['gatewayuser'])

        if None != results:
            return Response(results['gatewayuser'])

        return Response([])

    def delete_snmp(self, request):
        comp_op = plat_leader_router.OP_SNMP_DELETE
        data = request.GET
        response = ForwardView().send_request_to_leader(comp_op, data, unistor_api=False)
        if 0 == response['result'][0]:
            return Response({'success': True})
        else:
            return Response({'success': False, 'reason': response['result']})

    def deleteObjUser(self, request, fsid):
        try:
            uname = request.GET.get('name')
            uid = request.GET.get('id')
            user_type = request.GET.get('user_type')
            operation_log_title = u'删除S3用户“%s”' % uname \
                if 'S3' == user_type else u'删除Swift用户“%s”' % uname
        except Exception:
            self.addOperationlog(fsid, request, operation_log_title, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误'})

        # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
        gateway_ip, client_name, node = self._get_useful_gateway()
        if gateway_ip is None:
            self.addOperationlog(fsid, request, operation_log_title, u'无可用的对象网关')
            return Response({'status': 'error', 'reason': u'无可用的对象网关'})
        # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

        results = self.onestor_request_node_ssh(
                node, 'remove_gateway_user', uname, client_name)

        if 'success' == results['status']:
            self.onestor_request(fsid, 'database.del_obj',
                                 ['gatewayuser', uid])
            self.addOperationlog(fsid, request, operation_log_title, 'success')
            return Response(results)
        else:
            if -1 != results['reason'].find('user does not exist'):
                reason = u'用户“%s”不存在' % uname
            elif -1 != results['reason'].find('could not remove bucket'):
                reason = u'用户“%s”正在被使用' % uname
            elif '' == results['reason']:
                reason = u'用户“%s”删除失败' % uname
            elif 'EXIST_BUCKET' == results['reason']:
                reason = u'请先删除用户“%s”的容器' % uname
            else:
                # BEGIN MODIFY BY D10039 2016/09/05 PN:201607210518
                log.error('delete user error: %s', results['reason'])
                reason = u'操作失败，详见后台日志'
                # END MODIFY BY D10039 2016/09/05 PN:201607210518

        self.addOperationlog(fsid, request, operation_log_title, reason)
        return Response({'status': 'error', 'reason': reason})

    # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
    def _get_useful_gateway(self):
        gateway_list = self.exec_local_cmd_json('ceph config-key get gateway')
        if not gateway_list:
            return None, None, None

        for gateway in gateway_list['gateway']:
            # 通过curl测试对象网关状态是否正常
            curl_ret = os.popen('curl --connect-timeout 2 --max-time 2 %s' % gateway['hostip']).read()
            if -1 != curl_ret.find('<?xml version="1.0" encoding="UTF-8"?>'):
                gateway_ip = gateway['hostip']
                client_name = 'client.radosgw.%s' % gateway['hostname']
                node = gateway['hostname']

                return gateway_ip, client_name, node

        return None, None, None

    # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

    def createObjUser(self, request, fsid):
        try:
            email = request.DATA['email']
            uname = request.DATA['name']
            bucket = request.DATA['bucket']
            user_type = request.DATA['user_type']
            key_string = request.DATA['key_string']
            operation_log_title = u'创建S3用户“%s”' % uname \
                if 'S3' == user_type else u'创建Swift用户“%s”' % uname
        except Exception:
            self.addOperationlog(fsid, request, operation_log_title, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误'})

        # BEGIN ADD by d10039 2016/02/24 PN:201511140169
        self.exec_local_cmd('touch /tmp/test_file_for_radosgw')

        # 往.users.uid里写入测试文件，如果无法正常写入，则返回失败
        put_users_result = self.exec_local_cmd(
            'timeout 10 rados put -p default.rgw.meta _test_file_for_radosgw '
            '/tmp/test_file_for_radosgw && echo OK')
        if 'OK' != put_users_result:
            self.addOperationlog(fsid, request, operation_log_title, u'无法写入数据到对象存储')
            return Response({'status': 'error', 'reason': u'无法写入数据到对象存储'})

        # 删除.users.uid里的测试文件
        self.exec_local_cmd('timeout 10 rados rm -p default.rgw.meta _test_file_for_radosgw')

        # ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
        gateway_ip, client_name, node = self._get_useful_gateway()

        # MODIFY BY KF6602 2016/8/16 PN:201607300001
        if gateway_ip is None:
            self.addOperationlog(fsid, request, operation_log_title, u'无可用的对象网关')
            return Response({'status': 'error', 'reason': u'无可用的对象网关'})
        # END ADD by d10039 2016/02/24 PN:201511140169

        if 'Swift' == user_type:
            results = self.onestor_request_node_ssh(
                    node, 'create_gateway_user', '-' if '' == email else email, uname, bucket, client_name)
        else:
            results = self.onestor_request_node_ssh(
                    node, 'create_gateway_user_s3', '-' if '' == email else \
                        email, uname, bucket, client_name, key_string)

        if 'success' == results['status']:
            # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
            gateway_ip, client_name, node = self._get_useful_gateway()
            if gateway_ip is None:
                self.addOperationlog(fsid, request, operation_log_title, u'无可用的对象网关')
                return Response({'status': 'error', 'reason': u'无可用的对象网关'})
            # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

            # S3用户无需创建container，直接赋值为success即可
            res = 'success' if 'S3' == user_type or 'true' != config.get(
                'calamari_web', 'netdisk_switch') else createContainer(
                    gateway_ip, '%s:%s' % (uname, uname), '123456', '%s_container' % uname)

            if 'success' != res:
                self.onestor_request_node_ssh(
                        node, 'remove_gateway_user', uname, client_name)
                # BEGIN MODIFY BY KF6602 2016/8/27 PN:201607300001
                log.error('create user error: %s', res)
                reason = u'操作失败，详见后台日志'
                self.addOperationlog(fsid, request, operation_log_title, reason)
                return Response({'status': 'error', 'reason': reason})
                # END MODIFY BY KF6602 2016/8/27 PN:201607300001

            self.onestor_request(fsid, 'database.add_obj', ['gatewayuser', [
                uname, email, bucket, 'enable', '-1', user_type]])
            self.addOperationlog(fsid, request, operation_log_title, 'success')
            return Response(results)

        if -1 != results['reason'].find(
                'could not create subuser: unable to create subuser, unable to store user info'):
            reason = u'%s用户“%s”已经存在' % (user_type, uname)
        # BEGIN ADD BY KF6602 2016/6/16 PN:201606140275
        elif -1 != results['reason'].find('could not create user: unable to create user, user:'):
            reason = u'%s用户“%s”已经存在' % (user_type, uname)
        elif -1 != results['reason'].find('could not create user: unable to create user, email:'):
            reason = u'%s邮箱“%s”已经存在' % (user_type, email)
        # END ADD BY KF6602 2016/6/16 PN:201606140275
        else:
            log.error('create user error: %s', results['reason'])
            reason = u'操作失败，详见后台日志'

        self.addOperationlog(fsid, request, operation_log_title, reason)
        return Response({'status': 'error', 'reason': reason})

    def createObjUsers(self, request, fsid):
        try:
            uname = request.DATA['name']
            passwd = request.DATA['passwd']
            max_size = request.DATA['max_size']
        except Exception:
            self.addOperationlog(fsid, request, u'创建Swift用户“%s”' % uname, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误'})

        # 对密码进行base64解码
        passwd = base64.b64decode(passwd)

        # BEGIN ADD by d10039 2016/02/24 PN:201511140169
        self.exec_local_cmd('touch /tmp/test_file_for_radosgw')

        # 往.users.uid里写入测试文件，如果无法正常写入，则返回失败
        put_users_result = self.exec_local_cmd(
                'timeout 10 rados put -p .users.uid _test_file_for_radosgw /tmp/test_file_for_radosgw && echo OK')
        if 'OK' != put_users_result:
            self.addOperationlog(fsid, request, u'创建Swift用户“%s”' % uname, u'无法写入数据到对象存储')
            return Response({'status': 'error', 'reason': u'无法写入数据到对象存储'})

        # 删除.users.uid里的测试文件
        self.exec_local_cmd('timeout 10 rados rm -p .users.uid _test_file_for_radosgw')

        # ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
        gateway_ip, client_name, node = self._get_useful_gateway()

        # MODIFY BY KF6602 2016/8/16 PN:201607300001
        if gateway_ip is None:
            self.addOperationlog(fsid, request, u'创建Swift用户“%s”' % uname, u'无可用的对象网关')
            return Response({'status': 'error', 'reason': u'无可用的对象网关'})
        # END ADD by d10039 2016/02/24 PN:201511140169

        results = self.onestor_request_node_ssh(
                node, 'create_gateway_user_batch', uname, max_size, client_name)

        if 'success' == results['status']:

            # 创建本地数据库用户，云网盘分离后需要删除掉
            if 'true' == config.get('calamari_web', 'netdisk_switch'):
                user_model = get_user_model()
                user_model.objects.create_user(
                        username=uname,
                        password=passwd,
                        email='%s@h3c.com' % uname
                )

            # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
            gateway_ip, client_name, node = self._get_useful_gateway()
            if gateway_ip is None:
                self.addOperationlog(fsid, request, u'创建Swift用户“%s”' % uname, u'无可用的对象网关')
                return Response({'status': 'error', 'reason': u'无可用的对象网关'})
            # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

            # 创建容器
            res = 'success'
            if 'true' == config.get('calamari_web', 'netdisk_switch'):
                res = createContainer(gateway_ip, '%s:%s' % (
                    uname, uname), '123456', '%s_container' % uname)
            if 'success' != res:
                self.onestor_request_node_ssh(
                        node, 'remove_gateway_user', uname, client_name)
                # BEGIN MODIFY BY KF6602 2016/8/27 PN:201607300001
                log.error('create users error: %s', res)
                reason = u'操作失败，详见后台日志'
                self.addOperationlog(fsid, request, u'创建Swift用户“%s”' % uname, reason)
                return Response({'status': 'error', 'reason': reason})
                # END MODIFY BY KF6602 2016/8/27 PN:201607300001

            # 保存到数据库
            self.onestor_request(fsid, 'database.add_obj', ['gatewayuser', [
                uname, '', 1000, 'enable', max_size, 'Swift']])
            self.addOperationlog(fsid, request, u'创建Swift用户“%s”' % uname, 'success')

            return Response(results)

        if -1 != results['reason'].find(
                'could not create subuser: unable to create subuser, unable to store user info'):
            reason = u'用户“%s”已经存在' % uname
        # BEGIN ADD BY KF6602 2016/6/16 PN:201606140275
        elif -1 != results['reason'].find('could not create user: unable to create user, user:'):
            reason = u'用户“%s”已经存在' % uname
        elif -1 != results['reason'].find('could not create user: unable to create user, email:'):
            reason = u'邮箱“%s@h3c.com”已经存在' % uname
        # END ADD BY KF6602 2016/6/16 PN:201606140275
        else:
            log.error(results['reason'])
            reason = u'操作失败，详见后台日志'

        self.addOperationlog(fsid, request, u'创建Swift用户“%s”' % uname, reason)

        return Response({'status': 'error', 'reason': u'创建用户失败'})

    def suspendObjUser(self, request, fsid):
        try:
            email = request.DATA['email']
            uname = request.DATA['name']
            bucket = request.DATA['bucket']
            uid = request.DATA['id']
            status = request.DATA['status']
            quota = request.DATA['quota']
            user_type = request.DATA['user_type']
            operation_log_title = u'停用S3用户“%s”' % uname \
                if 'S3' == user_type else u'停用Swift用户“%s”' % uname
        except Exception:
            self.addOperationlog(fsid, request, operation_log_title, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误'})

        # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
        gateway_ip, client_name, node = self._get_useful_gateway()
        if gateway_ip is None:
            self.addOperationlog(fsid, request, operation_log_title, u'无可用的对象网关')
            return Response({'status': 'error', 'reason': u'无可用的对象网关'})
        # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

        results = self.onestor_request_node_ssh(
                node, 'suspend_gateway_user', uname, client_name)

        if 'success' == results['status']:
            self.onestor_request(fsid, 'database.update_obj', [
                'gatewayuser', uid, [uname, email, bucket, status, quota]])
            self.addOperationlog(fsid, request, operation_log_title, 'success')
            return Response(results)

        log.error('suspend user error: %s', results)
        self.addOperationlog(fsid, request, operation_log_title, u'操作失败，详见后台日志')
        return Response({'status': 'error', 'reason': u'停用用户失败'})

    def enableObjUser(self, request, fsid):
        try:
            email = request.DATA['email']
            uname = request.DATA['name']
            bucket = request.DATA['bucket']
            uid = request.DATA['id']
            status = request.DATA['status']
            quota = request.DATA['quota']
            user_type = request.DATA['user_type']
            operation_log_title = u'启用S3用户“%s”' % uname \
                if 'S3' == user_type else u'启用Swift用户“%s”' % uname
        except Exception:
            self.addOperationlog(fsid, request, operation_log_title, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误'})

        # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
        gateway_ip, client_name, node = self._get_useful_gateway()
        if gateway_ip is None:
            self.addOperationlog(fsid, request, operation_log_title, u'无可用的对象网关')
            return Response({'status': 'error', 'reason': u'无可用的对象网关'})
        # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

        results = self.onestor_request_node_ssh(
                node, 'enable_gateway_user', uname, client_name)

        if 'success' == results['status']:
            self.onestor_request(fsid, 'database.update_obj', [
                'gatewayuser', uid, [uname, email, bucket, status, quota]])
            self.addOperationlog(fsid, request, operation_log_title, 'success')
            return Response(results)

        log.error('enable user error: %s', results)
        self.addOperationlog(fsid, request, operation_log_title, u'操作失败，详见后台日志')
        return Response({'status': 'error', 'reason': u'启用用户失败'})

    def updateObjUser(self, request, fsid):
        try:
            email = request.DATA['email']
            uname = request.DATA['name']
            bucket = request.DATA['bucket']
            ObjUserId = request.DATA['id']
            status = request.DATA['status']
            quota = request.DATA['quota']
            user_type = request.DATA['user_type']
            operation_log_title = u'修改S3用户“%s”的邮箱' % uname \
                if 'S3' == user_type else u'修改Swift用户“%s”的邮箱' % uname

        except Exception:
            self.addOperationlog(fsid, request, operation_log_title, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误'})

        # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
        gateway_ip, client_name, node = self._get_useful_gateway()
        if gateway_ip is None:
            self.addOperationlog(fsid, request, operation_log_title, u'无可用的对象网关')
            return Response({'status': 'error', 'reason': u'无可用的对象网关'})
        # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

        results = self.onestor_request_node_ssh(
                node, 'update_gateway_user', '-' if '' == email else email, uname, bucket, client_name)

        if 'success' == results['status']:
            self.onestor_request(fsid, 'database.update_obj', [
                'gatewayuser', ObjUserId, [uname, email, bucket, status, quota]])
            self.addOperationlog(fsid, request, operation_log_title, 'success')
            return Response(results)

        if results['reason'].find('could not modify user: unable to modify user, cannot add duplicate email') != -1:
            reason = u'此邮箱已被其他用户使用'
        else:
            log.error('update user error: %s', results)
            reason = u'操作失败，详见后台日志'

        self.addOperationlog(fsid, request, operation_log_title, reason)
        return Response({'status': 'error', 'reason': reason})

    def getObjUserQuota(self, request, fsid):
        try:
            uname = request.DATA['uname']
        except Exception:
            return Response({'status': 'error', 'reason': u'输入参数错误'})

        # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
        gateway_ip, client_name, node = self._get_useful_gateway()
        if gateway_ip is None:
            return Response({'status': 'error', 'reason': u'无可用的对象网关'})
        # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

        results = self.onestor_request_node_ssh(
                node, 'get_gateway_user_quota', uname, client_name)
        return Response({'result': json.loads(results['reason'])})

    def objUserQuota(self, request, fsid):
        try:
            uname = request.DATA['uname']
            switch = request.DATA['swift']
            max_objs = request.DATA['max_objs']
            max_size = request.DATA['max_size']
            user_type = request.DATA['user_type']
            operation_log_title = u'修改S3用户 “%s” 的配额' % uname \
                if 'S3' == user_type else u'修改Swift用户 “%s” 的配额' % uname
        except Exception:
            self.addOperationlog(
                    fsid, request, operation_log_title, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误'})

        # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
        gateway_ip, client_name, node = self._get_useful_gateway()
        if gateway_ip is None:
            self.addOperationlog(fsid, request, operation_log_title, u'无可用的对象网关')
            return Response({'status': 'error', 'reason': u'无可用的对象网关'})
        # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

        results = self.onestor_request_node_ssh(
                node, 'set_gateway_user_quota', uname, client_name, max_objs, max_size, switch)

        # 更新数据库中的配额信息
        try:
            users_info = database.find_one('gatewayuser', [{'uname': uname}])
            user_info = users_info[0] if 1 == len(users_info) else None

            if None != user_info:
                database.update_obj('gatewayuser', user_info['id'], [user_info['uname'], user_info[
                    'email'], user_info['max_bucket'], user_info['status'], max_size])
        except Exception, e:
            log.error('[ONEStor] set user quota error, %s', str(e))

        if 'success' == results['status']:
            self.addOperationlog(fsid, request, operation_log_title, results)
            return Response(results)

        log.error('quota user error: %s', results)
        reason = u'操作失败，详见后台日志'

        self.addOperationlog(fsid, request, operation_log_title, reason)
        return Response({'status': 'error', 'reason': reason})

    def listBuckets(self, request, fsid):

        # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
        gateway_ip, client_name, node = self._get_useful_gateway()
        if gateway_ip is None:
            return Response({'status': 'error', 'reason': u'无可用的对象网关'})
        # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

        # update by z11524 date:2017/8/12 PN:201709140342
        results = self.onestor_request_node_ssh(node, 'list_user_buckets', client_name)
        try:
            rt = json.loads(results['reason'])
        except ValueError:
            rt = {'status': 'error', 'reason': u'获取容器列表失败'}
        finally:
            return Response(rt)

    def listClusterLog(self, request, fsid):
        # PN: 201704110653 手动停止主监控节点的ceph-mon-all服务，系统日志中不再显示最新的日志内容
        # 优先获取主mon的ceph日志
        leader_mon_info = self.exec_local_cmd_json("ceph quorum_status")
        mon_ip_use = None
        if None != leader_mon_info:
            mon_ip_use = self.name_to_ip(leader_mon_info['quorum_leader_name'])
        else:
            cluster_config = self.get_config_from_conf_file()
            mon_ips = cluster_config['mon_ip']
            mon_result = self.multi_thread_task(mon_ips, 'echo ok')
            for mon_ip in mon_result:
                if 'ok' == mon_result[mon_ip]:
                    mon_ip_use = mon_ip
                    break

        if None != mon_ip_use:
            results = self.onestor_request_node_ssh(mon_ip_use, 'list_cluster_log', 500)
            return Response({'lines': results['reason']})
            # end by l11544 2017/4/14

        return Response({'lines': ''})

    def collect_system_log(self, request, fsid):
        """collect cluster monitory host logs when the cluster health is bad"""

        try:
            is_cluster_health = request.GET.get('isClusterHealth')
            cluster_path = '/opt/h3c/webapp/content/temp/cluster/'

            # 日志包输出路径处理
            if os.path.exists(cluster_path):
                self.exec_local_cmd('rm -rf %s' % cluster_path)
            self.exec_local_cmd(
                    'mkdir -p %s && chmod 755 %s' % (cluster_path, cluster_path))
            # 适配CentOS
            if os.path.exists('/etc/redhat-realease'):
                self.exec_local_cmd('chown apache:apache %s' % cluster_path)
            else:
                self.exec_local_cmd('chown www-data:www-data %s' % cluster_path)

            # 获取各个监控节点的日志包
            results = self.onestor_request_all_node('collect_system_log', is_cluster_health)

            failed_nodes = []
            message = 'success'
            if not results['success']:
                failed_nodes = results['nodes']

                cluster_config = self.get_config_from_conf_file()
                mon_ips = cluster_config['mon_ip']
                message = u'导出主机"%s"上的日志失败' % results['nodes']
                log.error(
                        '[ONEStor] Fail to export syslog from %s, reason is %s', results['nodes'], results['error'])
                if len(failed_nodes) == len(mon_ips):
                    # self.addOperationlog(fsid, request, u'导出系统日志', message)
                    return Response({'status': 'error', 'reason': message})

            # BEGIN ADD BY D10039 2016/03/25 PN:201603140608 DES:导出日志前先判断系统盘空间是否足够
            log_size_ret = self.multi_thread_task(
                    results['success_nodes'], "ssh $$ ls -lb /tmp/##.tar.gz | awk {'print $5'}")

            # 将各个节点上的日志大小累加起来
            log_total_size_byte = 0
            for _host in log_size_ret:
                try:
                    log_total_size_byte += float(log_size_ret[_host])
                except ValueError:
                    log.error('%s do not get the package', _host)
                except Exception, e:
                    log.error(e)
            # 将各个节点上的日志大小累加起来
            # 获取Handy系统盘剩余空间
            df_info = self.exec_local_cmd("df | awk '{print $4,$6}'")
            handy_avail_size_byte = 0
            for _directory in df_info.split('\n'):
                avail_size = _directory.split(' ')[0]
                mounted = _directory.split(' ')[1]

                if '/' == mounted:
                    handy_avail_size_byte = float(avail_size) * 1024
                    break

            # 如果日志大小大于系统盘剩余空间的一半（压缩需要额外占用空间）则返回失败
            if log_total_size_byte * 2 > handy_avail_size_byte:
                message = u'系统盘空间不足'
                return Response({'status': 'error', 'reason': u'导出日志失败，系统盘空间不足'})
            # END ADD BY D10039 2016/03/25

            self.exec_local_cmd('mkdir -p /tmp/logs')
            self.multi_thread_task(
                    results['success_nodes'], 'scp [$$]:/tmp/##.tar.gz /tmp/logs/')

            current_time = self._get_current_time_from_apache("%Y%m%d%H%M%S")
            filename = self.exec_local_cmd(
                    '/opt/h3c/bin/python /opt/h3c/salt/salt/shell/collect-logs.py %s' % current_time)

            return Response({'status': 'success', 'data': filename, 'failed_nodes': failed_nodes})
        except Exception, e:
            message = u'服务器内部错误'
            return Response({'status': 'error', 'reason': str(e)})
        finally:
            # ADD BY KF6618 2016/08/06 PN:201607220108
            if 'bad' != is_cluster_health:
                self.addOperationlog(fsid, request, u'导出所有系统日志', message)

    # 包括监控、存储和Handy在内的所有节点,可以使用ip和节点名,只提供/opt/h3c/bin/python脚本
    def all_nodes_multi_thread(self, node_ips, file_path, method, _timeout, *params):
        """multi thread execute the method"""
        fail_results = {'nodes': [], 'reason': []}
        fail_results_lock = threading.Lock()
        success_nodes = []
        success_nodes_lock = threading.Lock()
        result = []
        result_lock = threading.Lock()
        threads = []

        # 获取所有的节点IP
        nloops, handy_list = range(len(node_ips)), list()
        if 'collect_past_log' == method:
            handy_list = self.get_handy_public_ip_list()

        def execute(node):
            """execute every node in the same time"""
            # add by l11544 2016/7/1 for onestor_hosts
            node_ip = self.name_to_ip(node)
            # end by l11544

            test_ping = self.exec_local_cmd(
                    'timeout 5 ssh %s echo ok' % node_ip)
            if 'ok' != test_ping:
                with fail_results_lock:
                    fail_results['nodes'].append(node)
                    fail_results['reason'].append('Host is unreachable')
                log.error(
                        '[thread] all_nodes_multi_thread %s:Host is unreachable', node)
            else:
                try:
                    temp = ""
                    shared_params = copy.deepcopy(params)
                    # 对于普通节点，去除历史日志handy选项
                    for param in shared_params:
                        if isinstance(param, dict) or isinstance(param, list):
                            if isinstance(param, list) and 'handy' in param:
                                if node not in handy_list:
                                    param.remove('handy')
                            temp += " "
                            temp += base64.b64encode(json.dumps(param))
                        else:
                            temp = temp + " " + str(param)
                    ret = self.exec_local_cmd("ssh %s timeout %s /opt/h3c/bin/python %s %s %s" % (
                        node_ip, _timeout, file_path, method, temp))
                    log.debug('%s %s %s', node, temp, ret)
                    if (-1 == str(ret).find('{') and '0' == str(ret)) or \
                            (-1 != str(ret).find('{') and 'success' == eval(ret)['status']):
                        # 防止结果异常，先进行赋值
                        with success_nodes_lock:
                            success_nodes.append(node)
                        try:
                            with result_lock:
                                result.append({'node': node, 'result': eval(ret)["data"]})
                                # result = eval(ret)["data"]
                        except ValueError:
                            log.error('key value error')
                        except Exception, e:
                            log.warning('operation %s meet error, current node is: %s, reason is: %s', method, node_ip, e)
                    else:
                        with fail_results_lock:
                            fail_results['nodes'].append(node)
                            if -1 != str(ret).find('{'):
                                fail_results['reason'].append(eval(ret)['reason'])
                            else:
                                fail_results['reason'].append(ret)
                        log.error('the function execute is error')
                except Exception, e:
                    with fail_results_lock:
                        fail_results['nodes'].append(node)
                        fail_results['reason'].append(e)
                        log.error('the multi execute is error')

        # 多线程进行
        for node in node_ips:
            t = threading.Thread(target=execute, args=(node,))
            threads.append(t)

        for i in nloops:
            threads[i].start()

        for i in nloops:
            threads[i].join()
        if 0 != len(fail_results['nodes']):
            log.info(fail_results)
            return {
                'success': False,
                'success_nodes': success_nodes,
                'nodes': ','.join([str(node) for node in fail_results['nodes']]),
                'error': fail_results['reason'],
                'all': True if len(fail_results['nodes']) == len(node_ips) else False
            }
        return {'success': True, 'success_nodes': success_nodes, 'data': result}

    # 判断Handy系统剩余空间是否够用
    def system_log_judge(self, log_size_all):
        """judge whether the system have encough capacity"""
        # 将各个节点上的日志大小累加起来
        log_total_size_byte, used_size = 0, 0
        handy_avail_size_byte, handy_total_size_byte, used_percent = 0, 0, 0
        for _host in log_size_all:
            try:
                log_total_size_byte += float(log_size_all[_host])
            except ValueError:
                log.error('do not get host %s file package size and value error', _host)
            except Exception, e:
                log.error(e)
                log.error('get host %s file size outer error', _host)

        # 获取Handy系统盘剩余空间
        df_info = self.exec_local_cmd("df | awk '{print $3,$4,$6}'")
        for _directory in df_info.split('\n'):
            used_size = _directory.split(' ')[0]
            avail_size = _directory.split(' ')[1]
            mounted = _directory.split(' ')[2]

            if '/' == mounted:
                handy_avail_size_byte = float(avail_size) * 1024
                handy_total_size_byte = (float(avail_size) + float(used_size)) * 1024
                break
        # 计算日志包总和所占系统盘的总和百分比
        used_percent = round((float(used_size) * 1024 + log_total_size_byte * 2) / handy_total_size_byte, 6)

        # 如果日志大小大于系统盘剩余空间的一半（压缩需要额外占用空间）则返回失败
        if log_total_size_byte * 2 > handy_avail_size_byte or used_percent >= 0.9:
            return False
        return True

    # 日志盘分区占用检测，查看CAS日志盘占用是否超出了90%
    def log_disk_judge(self):
        over_judge, used_percent = True, 0
        # 遍历寻找CAS日志盘分区
        df_info = self.exec_local_cmd("df | awk '{print $5,$6}'")
        for _directory in df_info.split('\n'):
            mounted = _directory.split(' ')[1]
            if '/var/log' == mounted:
                used_percent = _directory.split(' ')[0]
                used_percent = float(used_percent.split('%')[0])
                if used_percent >= 90:
                    over_judge = False
        return over_judge

    # 收集之前检查Handy业务网和集群状况
    def handy_network_check(self):
        handy_name = self.exec_local_cmd('hostname')
        local_test = self.test_ping_single(handy_name)
        if not local_test:
            return {'status': 'error', 'reason': u'管理节点%s无法连接' % public_net}
        status = self.exec_local_cmd('timeout 15 ceph -s -f json')
        if '' == status:
            return {'status': 'error', 'reason': u'无法获取集群信息'}
        return {'status': 'success'}

    # 导出历史日志 onestor_request_all_node
    def history_log_package(self, request, fsid):
        """package the history log"""
        try:
            start_time = request.GET.get('startTime')
            end_time = request.GET.get('endTime')
            reserved = request.GET.get('reserved')
            log_module_list = request.GET.get('moduleHistory').split(',')

            handy_name = os.popen('hostname').read().strip()
            history_path = "/var/log/onestor_past/"
            history_stor_path = '/tmp/onestor_past/'
            history_package_path = '/opt/h3c/webapp/content/temp/past/'
            file_path = '/var/lib/ceph/shell/collect_log.py'

            # 增加Handy的网络检查
            handy_check = self.handy_network_check()
            if 'success' != handy_check['status']:
                self.addOperationlog(fsid, request, u'导出历史日志', handy_check['reason'])
                return Response({'status': 'error', 'reason': handy_check['reason']})
            # 防止因为Handy系统盘占用过高的问题
            capa_judge = self.system_log_judge([])
            if not capa_judge:
                self.addOperationlog(fsid, request, u'导出历史日志', u'系统盘占用过高，请先清理管理节点再导出历史日志')
                return Response({'status': 'error', 'reason': u'系统盘占用过高，请先清理管理节点再导出历史日志'})
            # 检测CAS日志盘分区占用
            log_judge = self.log_disk_judge()
            if not log_judge:
                self.addOperationlog(fsid, request, u'导出历史日志', u'日志盘占用过高，请先清理管理节点再导出历史日志')
                return Response({'status': 'error', 'reason': u'日志盘占用过高，请先清理管理节点再导出历史日志'})

            # 创建文件夹
            if os.path.exists(history_stor_path):
                self.exec_local_ssh_cmd('rm -rf %s' % history_stor_path)
            self.exec_local_ssh_cmd('mkdir -p %s' % history_stor_path)
            if os.path.exists(history_package_path):
                self.exec_local_ssh_cmd('rm -rf %s' % history_package_path)
            self.exec_local_ssh_cmd(
                    'mkdir -p %s && chmod 755 %s' % (history_package_path, history_package_path))
            # 适配CentOS
            if os.path.exists('/etc/redhat-realease'):
                self.exec_local_cmd('chown apache:apache %s' % history_package_path)
            else:
                self.exec_local_cmd('chown www-data:www-data %s' % history_package_path)

            # 将时间戳转为日期标准格式
            start_time = time.strftime("%Y-%m-%d", time.localtime(float(start_time)))
            end_time = time.strftime("%Y-%m-%d", time.localtime(float(end_time)))
            # 将日期转为时间戳
            # endTime = time.mktime(time.strptime(endTime,"%Y-%m-%d"))
            _timeout = 10 * 60
            log.info('start to package the history log')

            # 检查是否有管理高可用，若存在需要到高可用上收集handy模块日志
            handy_list = self.get_handy_public_ip_list()
            # 对传递参数进行判断，若只有Handy不再去非Handy节点收集
            if 1 == len(log_module_list) and 'handy' == log_module_list[0]:
                node_ips = handy_list
            else:
                node_ips = self.get_all_ip()

            results = self.all_nodes_multi_thread(
                    node_ips, file_path, 'collect_past_log', _timeout, log_module_list, start_time, end_time, reserved)
            # 打包失败处理
            failed_nodes, node_exit_ips = [], results['success_nodes']
            message = ''
            if not results['success']:
                failed_nodes = results['nodes'].split(',')
                log.error(
                    '[systemlog] Fail to export syslog from %s, reason is %s', results['nodes'], results['error'])
                # 再次前往失败节点获取压缩节点日志失败原因
                collect_result = self.multi_thread_task(
                    failed_nodes, "/opt/h3c/bin/python %s collect_failed_reason" % file_path, ssh=True)
                log.info("check compress failed nodes “%s” reason start", failed_nodes)
                size_over_nodes, network_error_nodes = list(), list()
                for failed_node, failed_reason in collect_result.iteritems():
                    if 'NETWORK_FAULT' != failed_reason:
                        # 获取因文件过大导致的失败节点
                        try:
                            failed_info = json.loads(failed_reason)
                            if failed_info['size_over']:
                                size_over_nodes.append(failed_node)
                        except ValueError as err:
                            log.info('node %s failed reason %s is not json str', failed_node, failed_reason)
                            log.exception(err)
                            network_error_nodes.append(failed_node)
                    else:
                        network_error_nodes.append(failed_node)
                other_failed_nodes = list(set(failed_nodes) - set(network_error_nodes) - set(size_over_nodes))
                # 文件过大导致的失败错误
                if size_over_nodes:
                    log.error("nodes %s have over size syslog, please check", size_over_nodes)
                    if len(size_over_nodes) == len(node_ips):
                        message = u'节点“%s”日志文件过大' % ','.join(str(node) for node in size_over_nodes)
                    else:
                        message = u'节点“%s”日志文件过大，' % ','.join(str(node) for node in size_over_nodes)
                # 获取网络问题导致的失败
                if network_error_nodes:
                    if len(size_over_nodes) + len(network_error_nodes) == len(node_ips):
                        message += u'节点“%s”网络异常' % ','.join(str(node) for node in network_error_nodes)
                    else:
                        message += u'节点“%s”网络异常，' % ','.join(str(node) for node in network_error_nodes)
                # 其它压缩错误
                if other_failed_nodes:
                    if len(failed_nodes) == len(node_ips):
                        message += u'节点“%s”压缩失败' % ','.join(str(node) for node in other_failed_nodes)
                    else:
                        message += u'节点“%s”压缩失败，' % ','.join(str(node) for node in other_failed_nodes)
                if len(failed_nodes) == len(node_ips):
                    self.addOperationlog(fsid, request, u'导出历史日志', message)
                    return Response({'status': 'error', 'reason': message})

            # 正常导出日志
            # BEGIN ADD BY D10039 2016/03/25 PN:201603140608 DES:导出日志前先判断系统盘空间是否足够
            # 去各个节点获取文件的大小
            log.info('judge the Handy system capacity')
            log_size_ret = self.multi_thread_task(node_exit_ips,
                                                  "timeout 60 ssh $$ /opt/h3c/bin/python %s get_history_package_size" % file_path)
            # 将各个节点上的日志大小累加起来
            size_judge = self.system_log_judge(log_size_ret)

            # 如果日志大小大于系统盘剩余空间的一半（压缩需要额外占用空间）或系统盘占用过高则返回失败
            if not size_judge:
                message = u'系统盘占用过高，请先清理管理节点再导出历史日志'
                self.addOperationlog(fsid, request, u'导出历史日志', message)
                return Response({'status': 'error', 'reason': message})
            # END ADD BY D10039 2016/03/25
            log.info('cp the history log to temp list')
            # 将集群节点的日志包传送到临时目录
            self.multi_thread_task(node_exit_ips, "timeout 300 ssh $$ /opt/h3c/bin/python %s cp_history_log" % file_path)
            # 将节点文件传递到Handy
            failed_nodes = list()    # 重新初始化失败节点，作为导出失败的统一提示
            handy_ip = self.name_to_ip(self.exec_local_cmd("timeout 30 hostname"))
            if handy_ip in node_exit_ips:
                if os.path.exists(history_stor_path):
                    if (0 == len(os.listdir(history_stor_path))):
                        failed_nodes.append(handy_ip)
                else:
                    failed_nodes.append(handy_ip)
                node_exit_ips.remove(handy_ip)
            # 将其他节点的历史日志拷贝到Handy
            log.info('scp the history package to Handy')
            if len(node_exit_ips) > 0:
                scp_result = self.multi_thread_task(node_exit_ips,
                                                    'timeout %s scp [$$]:/tmp/onestor_past/*.tar.gz %s 1>/dev/null 2>&1 '
                                                    '&& echo ok' % (_timeout, history_stor_path))
                for ip in scp_result:
                    if 'ok' != scp_result[ip]:
                        failed_nodes.append(ip)
                failed_nodes = list(set(failed_nodes))
                if len(failed_nodes) == len(node_exit_ips):
                    if message:
                        message += u'节点“%s”收集失败，' % ','.join(str(node) for node in failed_nodes)
                    else:
                        message = u'收集失败，'
                    message += u'请重试或后台收集'
                    self.addOperationlog(fsid, request, u'导出历史日志', message)
                    return Response({'status': 'error', 'reason': message})

            # 获取历史日志打包文件名
            log.info('get the history log package name')
            file_name = history_package_path
            file_name += 'history_log_'
            file_name += time.strftime("%Y%m%d%H%M%S", time.localtime(float(time.time())))
            file_name += '.tar.gz'

            # 对各节点日志包进行再打包
            try:
                with tarfile.open(file_name, "w:gz") as tar:
                    for root, dir_temp, files in os.walk("/tmp/onestor_past/"):
                        for file_temp in files:
                            fullpath = os.path.join(root, file_temp)
                            tar.add(fullpath)
            except Exception, e:
                log.error('failed to out past log %s', e)
                self.addOperationlog(fsid, request, u'导出历史日志', u'历史日志导出失败，请重试或后台收集')
                return Response({'status': 'error', 'reason': u'历史日志导出失败，请重试或后台收集'})
            # tar_result = self.exec_local_ssh_cmd(
            #     "timeout 600 tar -cvf %s /tmp/onestor_past/* > /dev/null && echo ok" % file_name)
            # 并不是全部节点正常获取到压缩包的处理
            if not message:
                message = 'success'
            else:
                if failed_nodes:
                    log.error("nodes %s collect failed, please check", failed_nodes)
                    message += u'节点“%s”收集失败，' % ','.join(str(ip) for ip in failed_nodes)
                message += u'请重试或后台收集'
            # 将集群各节点的历史日志包临时文件删除
            self.multi_thread_task(node_ips, "timeout 60 ssh $$ /opt/h3c/bin/python %s clean_history_package" % file_path)
            self.addOperationlog(fsid, request, u'导出历史日志', message)
            return Response({'status': 'success', 'data': file_name, 'message': message})
        except SyntaxError:
            self.addOperationlog(fsid, request, u'导出历史日志', u'参数处理有误')
            return Response({'status': 'error', 'reason': u'参数处理有误'})
        except Exception, e:
            log.error('package history log error outer, reason is: %s', e)
            self.addOperationlog(fsid, request, u'导出历史日志', u'历史日志导出失败，请重试或后台收集')
            return Response({'status': 'error', 'reason': str(e)})

    def live_log_remove_handy(self, ip_list):
        """若Handy只当管理节点，则移除Handy不再开启、关闭和获取实时日志"""
        handy_name = self.exec_local_ssh_cmd('hostname')
        handy_ip = self.name_to_ip(handy_name)
        handy_role = self.get_host_roles_by_name(handy_name)
        if handy_role['handy'] and 1 == handy_role['role_num'] and handy_ip in ip_list:
            ip_list.remove(handy_ip)
        return ip_list

    # 获取实时日志的相关信息，导出是否完毕、以及上次的收集时间
    def get_live_log_info(self, request, fsid):
        """get live log info"""
        path_time = '/etc/ceph/time.txt'
        result = {}
        iterval_check = request.GET.get('iterval')
        # 增加Handy网络检查
        handy_check = self.handy_network_check()
        if 'success' != handy_check['status']:
            if 'false' == iterval_check:
                self.addOperationlog(fsid, request, u'获取实时日志信息', handy_check['reason'])
            return Response({'status': 'error', 'reason': handy_check['reason']})

        if not os.path.exists(path_time):
            self.addOperationlog(fsid, request, u'获取实时日志信息', u'时间记录文件不存在，开启实时日志后将重新创建')
            log.error("Failed to get log_info, because the time.txt is not exist")
            result['live_process'] = False
            return Response({'status': 'success', 'data': result})
        try:
            # 各个节点判断实时日志是否正在收集
            current_path = '/etc/ceph/collect_current_log.json'
            host_ips = self.get_all_hostIp()
            # 判断Handy的角色,若只当管理节点则过滤掉不再开启实时日志
            host_ips = self.live_log_remove_handy(host_ips)
            # 多线程判断
            alive_results = self.multi_thread_task(
                    host_ips, 'timeout 10 ssh $$ /opt/h3c/bin/python /var/lib/ceph/shell/collect_log.py live_collect_judge %s'
                              % current_path)
            log.debug(alive_results)
            # 只要有一个节点是在收集，则默认节点是开启的
            result['live_process'] = False
            live_collect_ip = None
            test_error, close_error = [], []
            for ip in alive_results:
                # 增加错误返回的判断
                if '' == alive_results[ip]:
                    test_error.append(ip)
                elif 'False' == alive_results[ip]:
                    close_error.append(ip)
            for ip in alive_results:
                if 'True' == alive_results[ip]:
                    result['live_process'] = True
                    live_collect_ip = ip
                    break
            result['test_error'] = test_error
            result['close_error'] = close_error
            # 定时获取实时日志是否开启信息，不需要打入操作日志等其他操作，可直接返回。
            if 'false' != iterval_check:
                return Response({'status': 'success', 'data': result})

            # 若有实时日志开启，则返回开启的时长
            if result['live_process']:
                init_time = float(self.exec_local_cmd("cat %s |grep startTime |awk '{print $2}'" % path_time))
                time_curr = time.time()
                result['initTime'] = int(float(time_curr)) - int(init_time)
                live_info = eval(self.exec_remote_ssh_cmd(live_collect_ip, "cat /etc/ceph/collect_current_log.json"))
                result['module'] = live_info['item']
                result['level'] = live_info['level']
            # 获取配置文件信息
            result['endJudge'] = self.exec_local_cmd("cat %s |grep endJudge |awk '{print $2}'" % path_time)
        except OSError:
            log.error('Input/Output error')
        except Exception, e:
            log.error(e)
            self.addOperationlog(fsid, request, u'获取实时日志信息', u'实时日志记录文件信息错误')
            return Response({'status': 'error', 'reason': u'实时日志记录文件信息错误'})
        self.addOperationlog(fsid, request, u'获取实时日志信息', u'success')
        return Response({'status': 'success', 'data': result})

    # 开启实时日志
    def open_live_log(self, request, fsid):
        """open live log start to collect"""
        path_time = '/etc/ceph/time.txt'
        try:
            open_first = request.DATA['openFirst']
            module_list = request.DATA['item']
            log_reserved = request.DATA['reserved']
            log_level = request.DATA['level']

            # 增加Handy的网络检查
            handy_check = self.handy_network_check()
            if 'success' != handy_check['status']:
                self.addOperationlog(fsid, request, u'开启实时日志', handy_check['reason'])
                return Response({'status': 'error', 'reason': handy_check['reason']})

            # 防止因为Handy系统盘占用过高的问题
            capa_judge = self.system_log_judge([])
            if not capa_judge:
                self.addOperationlog(fsid, request, u'开启实时日志', u'系统盘占用过高，请先清理管理节点再开启实时日志')
                return Response({'status': 'error', 'reason': u'系统盘占用过高，请先清理管理节点再开启实时日志'})
            # 检测CAS日志盘分区占用
            log_judge = self.log_disk_judge()
            if not log_judge:
                self.addOperationlog(fsid, request, u'开启实时日志', u'日志盘占用过高，请先清理管理节点再开启实时日志')
                return Response({'status': 'error', 'reason': u'日志盘占用过高，请先清理管理节点再开启实时日志'})
            # 执行开启
            _timeout = 60 * 3
            file_path = '/var/lib/ceph/shell/collect_log.py'
            live_file = '/etc/ceph/collect_current_log.json'
            remove_ips = []
            test_ips, open_ips = [], []
            node_ips = self.get_all_hostIp()
            # 判断Handy的角色,若只当管理节点则过滤掉不再开启实时日志
            node_ips = self.live_log_remove_handy(node_ips)
            # 检查已经开启的IP节点，不再去开启
            for ip in node_ips:
                temp_ip = []
                live_result = self.exec_remote_ssh_cmd(ip, 'cat %s' % live_file)
                if isinstance(live_result, dict) and 'error' == live_result['status']:
                    # remove_ips.append(ip)
                    test_ips.append(ip)
                    continue
                if '' != live_result:
                    # 获取json前去关闭再重新开启，若关闭仍失败，则移除，不再去开启该节点
                    temp_ip.append(ip)
                    results = self.all_nodes_multi_thread(
                            temp_ip, file_path, 'collect_current_log_stop', _timeout, eval(live_result)['item'])
                    if not results['success']:
                        log.error('start live log, close the living log failed')
                        # remove_ips.append(ip)
                        open_ips.append(ip)
            remove_ips = list(set(test_ips + open_ips))
            # 将无法正常开启的节点移除
            if len(remove_ips) > 0:
                for ip in remove_ips:
                    node_ips.remove(ip)

            message = ''
            if len(test_ips) > 0:
                message = u'“%s”主机无法连接' % ','.join(str(ip) for ip in test_ips)
            if len(open_ips) > 0:
                if '' != message:
                    message += '，'
                message = u'“%s”主机实时日志已经开启收集' % ','.join(str(ip) for ip in open_ips)
            if len(remove_ips) == len(node_ips):
                # 默认已经所有主机关闭，返回成功
                self.addOperationlog(fsid, request, u'开启实时日志', message)
                return Response({'status': 'success', 'data': message})

            # if len(remove_ips) > 0:
            #     message = u'%s主机无法连接或实时日志已经开启' % ','.join(str(ip) for ip in remove_ips)
            results = self.all_nodes_multi_thread(
                    node_ips, file_path, 'collect_current_log_start', _timeout, module_list, log_level, log_reserved)
            # 实时日志开启失败
            if not results['success']:
                log.error(
                        '[systemlog] Fail to start live log from %s, reason is %s', results['nodes'], results['error'])
                if '' != message:
                    message += '，'
                message = u'开启“%s”主机实时日志失败' % results['nodes']
                # 全部开启失败，则返回失败
                if len(results['nodes'].split(',')) == len(node_ips):
                    self.addOperationlog(fsid, request, u'开启实时日志', message)
                    return Response({'status': 'error', 'reason': message})
            # 写入实时日志开始时间
            system_time = time.time()
            # 向配置文件中重新写入时间信息
            if open_first or not os.path.exists(path_time):
                self.exec_local_ssh_cmd('echo initTime: %s > %s' % (system_time, path_time))
                self.exec_local_ssh_cmd(
                        'echo endJudge: false >> %s && echo startTime: %s >> %s' % (path_time, system_time, path_time))
            else:
                # 修改写入的开启日志时间
                self.exec_local_ssh_cmd(
                        "sed -i '/startTime/d' %s && echo startTime: %s >> %s" % (path_time, system_time, path_time))
            # 实时日志开启成功
            if '' == message:
                message = 'success'
            self.addOperationlog(fsid, request, u'开启实时日志', message)
            return Response({'status': 'success', 'data': message})
        except SyntaxError:
            self.addOperationlog(fsid, request, u'开启实时日志', u'参数处理有误')
            return Response({'status': 'error', 'reason': u'参数处理有误'})
        except Exception, e:
            log.error(e)
            self.addOperationlog(fsid, request, u'开启实时日志', e)
            return Response({'status': 'error', 'reason': e})

    # 停止正在收集的实时日志
    def close_live_log(self, request, fsid):
        """close the living log collect"""
        module_list = request.GET.get('item')
        try:
            _timeout = 60 * 5
            file_path = '/var/lib/ceph/shell/collect_log.py'
            live_file = '/etc/ceph/collect_current_log.json'

            # 增加Handy的网络检查
            handy_check = self.handy_network_check()
            if 'success' != handy_check['status']:
                self.addOperationlog(fsid, request, u'关闭实时日志', handy_check['reason'])
                return Response({'status': 'error', 'reason': handy_check['reason']})

            node_ips = self.get_all_hostIp()
            # 判断Handy的角色,若只当管理节点则过滤掉不再关闭实时日志
            node_ips = self.live_log_remove_handy(node_ips)
            # 检查已经关闭的IP节点，不再去关闭
            remove_ips = []
            test_ips, stop_ips = [], []
            for ip in node_ips:
                live_result = self.exec_remote_ssh_cmd(ip, 'cat %s 1>/dev/null 2>&1 && echo ok' % live_file)
                if isinstance(live_result, dict) and 'error' == live_result['status']:
                    test_ips.append(ip)
                elif 'ok' != live_result:
                    stop_ips.append(ip)
            remove_ips = list(set(test_ips + stop_ips))
            message = ''
            if len(remove_ips) > 0:
                if len(test_ips) > 0:
                    message = u'“%s”主机无法连接' % ','.join(str(ip) for ip in test_ips)
                if len(stop_ips) > 0:
                    if '' != message:
                        message += '，'
                    message = u'“%s”主机实时日志已经停止收集' % ','.join(str(ip) for ip in stop_ips)
                if len(remove_ips) == len(node_ips):
                    # 默认已经所有主机关闭，返回成功
                    self.addOperationlog(fsid, request, u'关闭实时日志', message)
                    return Response({'status': 'success', 'data': message})
                # message = u'%s主机无法连接或实时日志已经关闭' % ','.join(str(ip) for ip in remove_ips)

                # 移除已经关闭的节点不再关闭
                for ip in remove_ips:
                    if ip in node_ips:
                        node_ips.remove(ip)

            results = self.all_nodes_multi_thread(
                    node_ips, file_path, 'collect_current_log_stop', _timeout, eval(module_list))
            log.debug(results)
            # 实时日志关闭失败
            if not results['success']:
                log.error(
                        '[systemlog] Fail to stop live log from %s, reason is %s', results['nodes'], results['error'])
                if '' != message:
                    message += u'，'
                message = u'关闭主机“%s”上的日志失败' % results['nodes']
                # 若全部关闭失败，则返回失败
                if len(node_ips) == len(results['nodes'].split(',')):
                    self.addOperationlog(fsid, request, u'关闭实时日志', message)
                    return Response({'status': 'error', 'reason': message})

            # 实时日志关闭成功
            if '' == message:
                message = 'success'
            self.addOperationlog(fsid, request, u'关闭实时日志', message)
            return Response({'status': 'success', 'data': message})
        except KeyError:
            self.addOperationlog(fsid, request, u'关闭实时日志', u'参数处理有误')
            return Response({'status': 'error', 'reason': u'参数处理有误'})
        except Exception, e:
            log.error('stop live log error')
            self.addOperationlog(fsid, request, u'关闭实时日志', e)
            return Response({'status': 'error', 'reason': e})

    # 导出实时日志
    def live_log_package(self, request, fsid):
        """package the live log and out of the Handy"""
        path_time = '/etc/ceph/time.txt'
        live_path = '/var/log/onestor_current/'
        live_stor_path = '/tmp/onestor_current/'
        live_package_path = '/opt/h3c/webapp/content/temp/current/'
        file_path = '/var/lib/ceph/shell/collect_log.py'
        handy_name = os.popen('hostname').read().strip()
        try:
            # 增加Handy的网络检查
            handy_check = self.handy_network_check()
            if 'success' != handy_check['status']:
                self.addOperationlog(fsid, request, u'导出实时日志', handy_check['reason'])
                return Response({'status': 'error', 'reason': handy_check['reason']})
            # 防止因为Handy系统盘占用过高的问题
            # capa_judge = self.system_log_judge([])
            # if not capa_judge:
            #     self.addOperationlog(fsid, request, u'导出实时日志', u'系统盘占用过高，请先清理管理节点再导出实时日志')
            #     return Response({'status': 'error', 'reason': u'系统盘占用过高，请先清理管理节点再导出实时日志'})
            # 如果是CAS环境，检测CAS日志盘分区占用
            log_judge = self.log_disk_judge()
            if not log_judge:
                self.addOperationlog(fsid, request, u'导出实时日志', u'日志盘占用过高，请先清理管理节点再导出实时日志')
                return Response({'status': 'error', 'reason': u'日志盘占用过高，请先清理管理节点再导出实时日志'})

            # 打包存放路径处理
            if os.path.exists(live_stor_path):
                self.exec_local_ssh_cmd('rm -rf %s' % live_stor_path)
            self.exec_local_ssh_cmd('mkdir -p %s && chmod 755 %s' % (live_stor_path, live_stor_path))
            if os.path.exists(live_package_path):
                self.exec_local_ssh_cmd('rm -rf %s' % live_package_path)
            self.exec_local_ssh_cmd(
                    'mkdir -p %s && chmod 755 %s' % (live_package_path, live_package_path))
            # 适配CentOS
            if os.path.exists('/etc/redhat-realease'):
                self.exec_local_ssh_cmd('chown apache:apache %s' % live_package_path)
            else:
                self.exec_local_ssh_cmd('chown www-data:www-data %s' % live_package_path)

            # 获取所有节点的IP,判断系统盘占用,并将实时日志包拷贝到Handy存储目录
            host_ips = self.get_all_hostIp()
            # 判断Handy的角色,若只当管理节点则过滤掉不再获取实时日志
            host_ips = self.live_log_remove_handy(host_ips)

            start_time = self.exec_local_cmd("cat %s |grep initTime |awk '{print $2}'" % path_time)
            # 判断系统空间是否足够
            log.info('judge the Handy system capacity for the live log')
            log_size_ret = self.multi_thread_task(
                    host_ips, "timeout 300 ssh $$ /opt/h3c/bin/python %s get_live_package_size %s" % (file_path, start_time))
            size_judge = self.system_log_judge(log_size_ret)
            # 如果日志大小大于系统盘剩余空间的一半（压缩需要额外占用空间）以及超出90%，则返回失败
            if not size_judge:
                self.addOperationlog(fsid, request, u'导出实时日志', u'系统盘占用过高，请先清理管理节点再导出实时日志')
                return Response({'status': 'error', 'reason': u'系统盘占用过高，请先清理管理节点再导出实时日志'})

            # 将日志文件包拷贝到临时目录
            log.info('cp live log package to temp list')
            self.multi_thread_task(host_ips, "timeout 300 ssh $$ /opt/h3c/bin/python %s cp_live_log %s" % (file_path, start_time))

            # 判断Handy自身要有日志包
            handy_ip = self.name_to_ip(handy_name)
            failed_nodes = []
            if os.path.exists(live_stor_path):
                if (0 == len(os.listdir(live_stor_path)) and handy_ip in host_ips):
                    failed_nodes.append(handy_ip)
            else:
                failed_nodes.append(handy_ip)
            log.info('scp the live package to Handy')
            # 将节点文件传递到Handy
            host_cp_ips = copy.deepcopy(host_ips)
            if handy_ip in host_cp_ips:
                host_cp_ips.remove(handy_ip)
            scp_result = self.multi_thread_task(
                    host_cp_ips, 'timeout 300 scp [$$]:/tmp/onestor_current/*.tar.gz %s 1>/dev/null 2>&1 && echo ok'
                                 % live_stor_path)
            log.debug(scp_result)
            for ip in scp_result:
                if 'ok' != scp_result[ip]:
                    failed_nodes.append(ip)
            failed_nodes = list(set(failed_nodes))
            if len(failed_nodes) == len(host_ips):
                self.addOperationlog(fsid, request, u'导出实时日志', u'实时日志导出失败，请检查')
                return Response({'status': 'error', 'reason': u'实时日志导出失败，请检查'})

            # 获取打包文件名
            file_name = live_package_path
            file_name += 'current_log_'
            file_name += time.strftime("%Y%m%d%H%M%S", time.localtime(float(time.time())))
            file_name += '.tar.gz'
            # 将所有的压缩包进行再打包
            try:
                with tarfile.open(file_name, "w:gz") as tar:
                    for root, dir_temp, files in os.walk("/tmp/onestor_current/"):
                        for file_temp in files:
                            fullpath = os.path.join(root, file_temp)
                            tar.add(fullpath)
            except Exception, e:
                log.error('failed to out live log %s', e)
                self.addOperationlog(fsid, request, u'导出实时日志', u'实时日志导出失败，请检查')
                return Response({'status': 'error', 'reason': u'实时日志导出失败，请检查'})

            # tar_result = self.exec_local_ssh_cmd(
            #     "timeout 600 tar -cvf %s /tmp/onestor_current/* > /dev/null && echo ok" % file_name)

            # 成功导出日志后的处理
            # 成功后,将时间判断置为true
            self.exec_local_ssh_cmd("sed -i 's/false/true/g' %s" % path_time)

            log.debug(file_name)
            if len(failed_nodes) > 0:
                message = u'“%s”节点的实时日志导出失败，请检查' % ','.join(str(ip) for ip in failed_nodes)
            else:
                message = 'success'
            # 对各节点的实时日志临时目录进行处理
            self.multi_thread_task(host_ips, "timeout 60 ssh $$ /opt/h3c/bin/python %s clean_live_package" % file_path)

            self.addOperationlog(fsid, request, u'导出实时日志', message)
            return Response({'status': 'success', 'data': file_name, 'message': message})
        except KeyError:
            self.addOperationlog(fsid, request, u'导出实时日志', u'参数值处理有误')
            return Response({'status': 'error', 'reason': u'参数值处理有误'})
        except Exception, e:
            log.error('live log package out error')
            self.addOperationlog(fsid, request, u'导出实时日志', u'失败')
            log.error(e)
            return Response({'status': 'error', 'reason': u'失败'})

    # end by l11544

    # add by d11564 20150815
    def saveSnapshotRPC(self, fsid, params):
        results = self.onestor_request(
                fsid, 'database.add_obj', ['snapshot', params])

        if None != results:
            return results

        return []

    def saveSnapshot(self, request, fsid):
        snap_name = request.DATA['snap_name']
        size = request.DATA['rbd_size']
        status = request.DATA['status']
        snap_type = request.DATA['snap_type']
        rbd_name = request.DATA['rbd_name']
        pool_name = request.DATA['pool_name']
        create_time = self._get_current_time_cst('ms')
        params = [snap_name, size, status, snap_type,
                  rbd_name, pool_name, create_time]
        return Response(self.saveSnapshotRPC(fsid, params))

    # end by d11564

    def getSnapstatus(self, request, fsid):
        """
        add by r13889 PN 201706180018
        :param request:
        :param fsid:
        :return:
        """
        image = request.GET.get('image')
        data = {'image': image}
        log.info('begin send message to Leader...')
        result = send_request_onestord('COMP_SCRUB', 'SCRUB_get_clonelen', data, model='SCRUB')
        log.info('send_request_onestord, result is %s', result)
        return Response(result)

    def list(self, request, fsid):
        pool = request.GET.get('pool')

        results = self.onestor_request(
                fsid, 'onestor.list', [self.CEPH_CONF_FILE, pool])

        if None != results:
            return Response(results)

        return Response([])

    def getRbdlistsFromDB(self, request, fsid):
        partition = request.GET.get('partition')
        pool = request.GET.get('pool')
        results = self.onestor_request(fsid, 'database.list_objs', ['rbdlist'])

        # 将rbd_size转化为int类型
        for rbd in results['rbdlist']:
            rbd['rbd_size'] = int(rbd['rbd_size'])

        if pool == None:
            return Response(sorted(results['rbdlist'], key=lambda x: (-x['id'])))
        list_key = 'pool_name'
        if None != partition:
            pool = '.' + partition + '.rbd'
            list_key = 'matadata'
        if results:
            rbdlists = results['rbdlist']
            getlistBypool = []
            for rbdlist in rbdlists:
                if rbdlist[list_key] == pool:
                    getlistBypool.append(rbdlist)

            return Response(sorted(getlistBypool, key=lambda x: (-x['id'])))
        else:
            log.error("Failed to get rbdlist")
        return Response([])

    def space(self, request, fsid):
        # ADD BY D10039 2016/03/12 For UIS 获取集群可用容量
        space_type = request.GET.get('space_type')
        data = dict()
        data['type'] = space_type
        comp_op = plat_leader_router.OP_QUERY_SPACE
        response = ForwardView().send_request_to_leader(comp_op, data, unistor_api=False)
        if 0 == response['result'][0]:
            return Response(response['data'])


    def poolspace(self, request, fsid):
        pool_name = request.GET.get('pool_name')

        results = self.onestor_request(fsid, 'onestor.poolspace', [
            self.CEPH_CONF_FILE, pool_name])

        if None != results:
            return Response(results)

        return Response(0)

    def getOperationlog(self, request, fsid):
        results = self.onestor_request(
                fsid, 'database.list_objs', ['operationlog'])

        if None != results:
            operationlogs = results['operationlog']
            if len(operationlogs) >= const.LOG_COUNT_TO_BROWSER:
                # modify by w15818 PN:201712121050
                return Response(sorted(operationlogs[:const.LOG_COUNT_TO_BROWSER], key=lambda x: (-x['time'])))
            else:
                return Response(sorted(operationlogs, key=lambda x: (-x['id'])))

        return Response([])

    def count_pg(self, request, fsid):
        results = self.onestor_request(fsid, 'onestor.count_pg_num', [])

        if None != results:
            return Response(results)

        return Response([])

    def download_operation_log(self, fsid):
        """
        导出操作日志
        """
        results = self.onestor_request(
                fsid, 'database.list_objs', ['operationlog'])

        if None != results:
            csvfile = file('/tmp/operationLogs.csv', 'wb')

            dict_writer = csv.writer(csvfile)
            dict_writer.writerow(
                    ['用户名', '登陆IP', '操作时间', '操作内容', '操作结果', '失败原因'])
            logs = results['operationlog']

            # DELETE BY KF6618 2016/07/21 PN:201607200038

            diff_hour = self._get_time_zone_diff()

            for line in logs:
                nowTime = int(line['time'])
                current_time_cst = nowTime / 1000 - (diff_hour * 60 * 60)
                operationTime = time.strftime(
                        "%Y-%m-%d %H:%M:%S", time.localtime(current_time_cst))

                if (line['status'] == 'success'):
                    dict_writer.writerow(
                            [line['user'], line['ip'], operationTime, line['content'], '成功', ''])
                else:
                    dict_writer.writerow([line['user'], line['ip'], operationTime, line[
                        'content'], '失败', line['status']])

            csvfile.close()

            otherStyleTime = self._get_current_time_from_apache(
                    "%Y%m%d%H%M%S", diff_hour)

            response = http.HttpResponse()
            response[
                'Content-Disposition'] = 'attachment; filename=operationLogs-%s.csv' % otherStyleTime
            response['Content-Type'] = 'text/plain'

            f = open("/tmp/operationLogs.csv", "rb")
            data = f.read()
            f.close()
            os.remove('/tmp/operationLogs.csv')
            response.write(codecs.BOM_UTF8)
            response.write(data.encode('utf-8'))
            return response

        return None

    def downOperationLog(self, request, fsid):
        status = 'success'
        try:
            logs = self.download_operation_log(fsid)
            if logs is None:
                status = '服务器内部错误'
                return Response([])
            return logs
        finally:
            self.addOperationlog(fsid, request, u'导出操作日志', status)

    def downSystemLogExcel(self, request, fsid):
        status = 'success'
        try:
            cluster_config = self.get_config_from_conf_file()
            mon_fqdns = cluster_config['mon_fqdns']
            # BEGIN ADD BY KF6618 2016/08/05 PN:201608040271
            for mon in mon_fqdns:
                results = self.onestor_request_node_ssh(mon, 'list_cluster_log', 500)
                if results['reason'] != 'Host is unreachable':
                    break
            # END ADD BY KF6618 2016/08/05 PN:201608040271

            promises = results['reason']
            lines = promises.split('\n')

            workbook = xlwt.Workbook()
            worksheet = workbook.add_sheet('My Worksheet')
            worksheet.write(0, 0, u'时间')
            worksheet.write(0, 1, u'对象')
            worksheet.write(0, 2, u'IP地址')
            worksheet.write(0, 3, u'详细信息')
            linenum = 1
            lines.reverse()
            for line in lines:
                if (len(line) > 0):
                    logs = line.split(' ')
                    timestamp = logs[0] + " " + logs[1].split('.')[0]
                    unit = logs[2]
                    address = logs[3]
                    rest = ""
                    for i in logs[6:]:
                        rest += i + ' '
                    rest = rest.strip()
                    worksheet.write(linenum, 0, timestamp)
                    worksheet.write(linenum, 1, unit)
                    worksheet.write(linenum, 2, address)
                    worksheet.write(linenum, 3, rest)
                    linenum += 1

            otherStyleTime = self._get_current_time_from_apache("%Y%m%d%H%M%S")
            workbook.save('/tmp/systemLogs-%s.xls' % otherStyleTime)

            f = open('/tmp/systemLogs-%s.xls' % otherStyleTime, "rb")
            data = f.read()
            f.close()
            os.remove('/tmp/systemLogs-%s.xls' % otherStyleTime)

            response = http.HttpResponse()
            response[
                'Content-Disposition'] = 'attachment; filename=systemLogs-%s.xls' % otherStyleTime
            response['Content-Type'] = 'text/plain'

            response.write(data)
            return response
        except Exception:
            status = u'服务器内部错误'
            return Response({'status': 'error', 'reason': u'服务器内部错误'})
        finally:
            self.addOperationlog(fsid, request, u'导出excel格式的系统日志', status)

    def downSystemLog(self, request, fsid):
        status = 'success'
        try:
            cluster_config = self.get_config_from_conf_file()
            mon_fqdns = cluster_config['mon_fqdns']

            # BEGIN ADD BY KF6618 2016/08/05 PN:201608040271
            for mon in mon_fqdns:
                results = self.onestor_request_node_ssh(mon, 'list_cluster_log', 500)
                if results['reason'] != 'Host is unreachable':
                    break
            # END ADD BY KF6618 2016/08/05 PN:201608040271

            promises = results['reason']
            lines = promises.split('\n')
            lines.reverse()

            csvfile = file('/tmp/systemLogs.csv', 'wb')
            dict_writer = csv.writer(csvfile, dialect='excel')
            dict_writer.writerow(['时间', '对象', 'IP地址', '详细信息'])
            for line in lines:
                if (len(line) > 0):
                    logs = line.split(' ')
                    timestamp = logs[0] + " " + logs[1].split('.')[0]
                    unit = logs[2]
                    address = logs[3]
                    rest = ""
                    for i in logs[6:]:
                        rest += i + ' '
                    rest = rest.strip()
                    dict_writer.writerow([timestamp, unit, address, rest])
            csvfile.close()
            otherStyleTime = self._get_current_time_from_apache("%Y%m%d%H%M%S")
            response = http.HttpResponse()
            response[
                'Content-Disposition'] = 'attachment; filename=systemLogs-%s.csv' % otherStyleTime
            response['Content-Type'] = 'text/plain'

            f = open("/tmp/systemLogs.csv", "rb")
            data = f.read()
            f.close()
            os.remove('/tmp/systemLogs.csv')
            response.write(codecs.BOM_UTF8)
            response.write(data.encode('utf-8'))

            return response
        except Exception:
            status = u'服务器内部错误'
            return Response({'status': 'error', 'reason': u'服务器内部错误'})
        finally:
            self.addOperationlog(fsid, request, u'导出csv格式的系统日志', status)

    def createPool(self, request, fsid):
        try:
            pool_name = request.DATA['pool_name']
            pool_size = request.DATA['pool_size']
            pool_kind = request.DATA['pool_kind']
            # cache_tier = request.DATA['cache_tier']
            pool_erasure_status = int(request.DATA['pool_erasure_status'])
            k = int(request.DATA['k'])
            m = int(request.DATA['m'])
            host_num = request.DATA['host_num']
        except Exception:
            self.addOperationlog(fsid, request, u'创建Pool“%s”' %
                                 pool_name, u'输入参数错误')
            return Response({'status': 'error', 'reason': 'Invalid argument', 'errorcode': 'PARAMETER_ERROR'})
        # begin add by d11564 2017/04/06 PN:201703290636
        if int(pool_size) < 2:
            self.addOperationlog(fsid, request, u'创建Pool“%s”' % pool_name, u'副本个数不能小于2')
            return Response({'status': 'error', 'reason': u'副本个数不能小于2', 'errorcode': 'POOL_SIZE_EXCEED'})
        # 判断pool个数是否大于64
        try:
            all_pools = json.loads(
                self.exec_local_cmd('ceph osd pool ls -f json'))
            rgw_pools = const.RGW_POOLS_WITHOUT_BUCKETS + ['default.rgw.buckets.data', '.onestor']
            user_pools = []
            for pool in all_pools:
                if pool not in rgw_pools:
                    user_pools.append(pool)

            if len(user_pools) > 4:
                self.addOperationlog(fsid, request, u'创建Pool“%s”' %
                                     pool_name, u'已达到Pool个数上限（5）')
                return Response({'status': 'error', 'reason': u'已达到Pool个数上限（5）', 'errorcode': 'POOL_NUM_EXCEED'})
        except Exception, e:
            log.error(e)

        if pool_kind == '主副本':
            crush_rule = 2
        elif pool_kind == '数据存储':
            crush_rule = 1
        elif pool_kind == '开启':
            crush_rule = 3
        else:
            crush_rule = 0

        if crush_rule == 3:
            cache_tier = True
        else:
            cache_tier = False

        # ADD BY D10039 2016/06/18 PN:201606170432 PG数根据副本个数自动生成
        if pool_erasure_status == 0:
            pool_pg = self.onestor_request(fsid, 'onestor.count_pg_num', [pool_size])['pg_num']
        else:
            pool_pg = self.onestor_request(fsid, 'onestor.count_pg_num', [k + m])['pg_num']

        if not cache_tier:
            results = self.onestor_request(fsid, 'onestor.add_pool',
                                           [self.CEPH_CONF_FILE, pool_name, pool_size, '0', pool_erasure_status,
                                            pool_pg, k, m, host_num])

        else:
            # Create storage pool
            self.onestor_request(fsid, 'onestor.add_pool', [
                self.CEPH_CONF_FILE, pool_name + '_hdd', pool_size, '0', pool_erasure_status, pool_pg, k, m, host_num])

            # Create cache pool
            self.onestor_request(fsid, 'onestor.add_pool', [
                self.CEPH_CONF_FILE, pool_name + '_ssd', pool_size, '1', pool_erasure_status, pool_pg, k, m, host_num])

            # Set Cache tier
            results = self.onestor_request(fsid, 'onestor.set_cache_tier', [
                pool_name + '_ssd', pool_name + '_hdd'])

        # BEGIN ADD BY D10039 2016/05/27 PN:201605270261 判断Pool是否创建成功，如果不成功则返回失败
        pools_curr = self.exec_local_cmd_json('ceph osd pool ls -f json')
        if (pools_curr is not None) and (pool_name not in pools_curr):
            results = {'status': 'error', 'errorcode': 'ERROR_CREATE_POOL', 'reason': u'系统繁忙，无法创建Pool'}
        # END ADD BY D10039 2016/05/27 PN:201605270261

        if None != results:
            # PN:201702220489 统一删除和创建仅仅为.rgw.buckets池时的操作日志名称 2017/3/11 l11544
            pool_name = '对象存储' if 'default.rgw.buckets.data' == pool_name else pool_name
            self.addOperationlog(fsid, request, u'创建Pool“%s”' % pool_name, results)
            return Response(results)

        return Response([])

    def test_ping(self, nodes_ip):
        failed_nodes = []
        threads = []
        nloops = range(len(nodes_ip))

        def test(ip):
            # add by l11544 2016/7/1 for onestor_hosts
            node_ip = self.name_to_ip(ip)
            # end by l11544

            # begin modify by z11524 2017/3/23 PN:201702090527 集群部署失败，增加网络ping次数
            if not self.network_check(node_ip, retry_times=3):
                failed_nodes.append(ip)
                # end modify by d11564

        for ip in nodes_ip:
            t = threading.Thread(target=test, args=(ip,))
            threads.append(t)

        for i in nloops:
            threads[i].start()

        for i in nloops:
            threads[i].join()

        return failed_nodes

    def test_vip_connect(self, vip, nodes_ip, ha_port):
        failed_nodes = []
        connect_node = []
        threads = []
        if ha_port == "3260":
            app_type = 'tgtd'
        else:
            app_type = 'radosgw'
        nloops = range(len(nodes_ip))

        def test(ip):
            test_command = "ip addr | grep '%s/' | wc -l && netstat -apn | " \
                           "grep '%s:%s' | grep ESTABLISHED | grep %s | wc -l" % (vip, vip, ha_port, app_type)
            result = self.exec_remote_ssh_cmd(ip, test_command)
            try:
                if result['status'] == 'error':
                    failed_nodes.append(ip)
            except IOError:
                pass
            except:
                test_result = result.rstrip().split('\n')
                if test_result[0] != '0' and test_result[1] != '0':
                    connect_node.append(ip)

        for ip in nodes_ip:
            t = threading.Thread(target=test, args=(ip,))
            threads.append(t)

        for i in nloops:
            threads[i].start()

        for i in nloops:
            threads[i].join()

        return {'failed_nodes': failed_nodes, 'connect_node': connect_node}

    def availableVrid(self, request, fsid):
        try:
            HANDY_SHELL_PATH = '/var/lib/ceph/shell'
            get_vrid_command = 'timeout 300 /opt/h3c/bin/python %s/getvrid_tgt_ha.py' % HANDY_SHELL_PATH
            get_vrid_ret = self.exec_local_cmd(get_vrid_command).rstrip()
            if get_vrid_ret.find('success'):
                vrid = get_vrid_ret.rstrip(',')[0]
                return Response({'success': True, 'vrid': vrid})
            else:
                return Response({'success': False, 'vrid': '-1'})

        except ValueError:
            return Response({'success': False, 'vrid': '-1'})
        except Exception, e:
            log.error(e)
            return Response({'success': False, 'vrid': '-1'})

    def _process_get_working_node(self, vip):
        """
        PN:201607290193 等待获取新创建的HA工作节点
        """
        # 从数据库中获取所有高可用配置
        ha_cfgs = database.list_objs('highavailableconfig')

        pre_time = datetime.datetime.now()
        while True:
            ha_ip_list = self._get_working_nodes(ha_cfgs['highavailableconfig'])
            if vip in ha_ip_list.keys():
                break

            log.info('Waiting for get ha working nodes...')
            time.sleep(5)
            new_time = datetime.datetime.now()
            if new_time - pre_time > datetime.timedelta(minutes=5):
                break

    def check_loadbalance(self, ha_nodes):
        """
        限制负载均衡vip的创建,
        不同组的负载均衡主备节点不能重合
        :param ha_nodes: 高可用节点
        :return:
        """
        date_base_list = self.exec_local_cmd_json_v2('ceph config-key list')
        if 'highavailableconfig' not in date_base_list:
            return "success"

        ha_list = self.exec_local_cmd_json('ceph config-key get highavailableconfig') \
            ['highavailableconfig']
        list1 = []
        for ha in ha_list:
            if '1' == ha['balance_switch']:
                list1 = list1 + [ha['master']] + ha['slave'].split(',')

        set_old = set(list1)
        set_new = set(ha_nodes)
        set1 = set_new & set_old
        if not set1:
            return "success"
        else:
            return "不同组的负载均衡主备节点重合"

    def remove_get_arp(self, ):
        """
        获取arp
        :return:
        """
        date_base_list = self.exec_local_cmd_json_v2('ceph config-key list')
        if 'highavailableconfig' not in date_base_list:
            return '0'
        ha_list = self.exec_local_cmd_json('ceph config-key get highavailableconfig') \
            ['highavailableconfig']
        num = 0
        switch_arp = '0'
        for ha in ha_list:
            if '1' == ha['balance_switch']:
                num += 1

        if 1 == num:
            switch_arp = '2'

        return switch_arp

    def ha_rollback(self, ha_switch, balance_switch, result, vip, vrid, opt_type):
        """
        回滚操作
        :param ha_switch:
        :param balance_switch:
        :param result:
        :param vip:
        :param vrid:
        :param opt_type:
        :return:
        """
        if '1' == balance_switch:
            command = '/opt/h3c/bin/python /var/lib/ceph/shell/ha_rollback.py %s %s %s %s' % (result, vip, vrid, opt_type)
        else:
            command = '/opt/h3c/bin/python /var/lib/ceph/shell/ha_rollback.py %s %s 256 %s' % (result, vip, opt_type)

        self.command_all_nodes(ha_switch, command)

    def create_disasterha_conf(self, request, fsid):
        """
        创建主站点配置
        """
        try:
            HANDY_SHELL_PATH = '/var/lib/ceph/shell'
            vip = str(request.DATA['vip'])
            master = request.DATA['master']
            slave = request.DATA['slave']
            ha_switch = request.DATA['haSwitch']
            balance_switch = request.DATA['balanceSwitch']
            seconde_scheduler = str(request.DATA['secondeScheduler'])
            disaster_switch = request.DATA['disasterSwitch']

            # PN: 201705250003 运维管理操作日志中对创建主备站点失败的操作内容描述不准，容易引起误解
            op_log_content = u'创建容灾主站点高可用IP“%s”' % vip

            if '1' == disaster_switch:
                disaster_type = request.DATA['disasterType']
                # 增加清理灾备高可用IP配置处理，可能会残留灾备高可用IP
                clear_succeed = back_utils.DisasterUtils().clear_disaster_ha_conf()
                if not clear_succeed:
                    error_message = u'清理容灾配置失败'
                    self.addOperationlog(fsid, request, op_log_content, error_message)
                    return Response({'success': False, 'error': error_message})
                    # add by l11544 2017/6/8
            disaster_info = {}

            if master in slave.split(','):
                self.addOperationlog(fsid, request, op_log_content, u'主备节点IP不能相同')
                return Response({'success': False, 'error': u'主备节点IP不能相同'})

            # 创建主站点需要先判断是否已经有高可用ip
            highavailabe_list = self.onestor_request(fsid, 'database.list_objs', ['highavailableconfig'])
            ha_list = highavailabe_list['highavailableconfig']
            if len(ha_list) == 0:
                self.addOperationlog(fsid, request, op_log_content, u'请先创建一个Target高可用IP')
                return Response({'success': False, 'error': u'请先创建一个Target高可用IP'})

            all_nodes = [master] + slave.split(',')

            cluster_config = self.get_clusterconfig()
            disaster_network = cluster_config['disaster_network']
            publicIpJudge = self.subnet_judge(disaster_network, vip)

            if not publicIpJudge:
                self.addOperationlog(fsid, request, op_log_content, u'本站点高可用IP不在灾备网段内')
                return Response({'success': False, 'error': u'本站点高可用IP不在灾备网段内'})

        except IOError:
            pass
        except:
            self.addOperationlog(fsid, request, op_log_content, u'输入参数错误')
            return Response({'success': False, 'error': u'输入参数错误'})

        # PN: 201705190550 创建主站点需要校验虚IP是否已经被使用了
        if 1 != len(self.test_ping(vip.split(','))):
            self.addOperationlog(fsid, request, op_log_content, u'IP地址“%s”已经被使用' % vip)
            return Response({'success': False, 'error': u'IP地址“%s”已经被使用' % vip})

        # PN: 201704180694 创建主站点需要是否已成功创建备站点
        if self.test_ping(seconde_scheduler.split(',')):
            self.addOperationlog(fsid, request, op_log_content, u'无法连接备站点高可用IP')
            return Response({'success': False, 'error': u'无法连接备站点高可用IP'})

        try:
            failed_nodes = self.test_ping(all_nodes)
            if len(failed_nodes) != 0:
                reasons = ''
                for node in failed_nodes:
                    if reasons == '':
                        reasons = node
                    else:
                        reasons += ', ' + node

                self.addOperationlog(fsid, request, op_log_content, u'主机“%s”存在网络故障' % reasons)
                return Response({'success': False, 'error': u'主机“%s”存在网络故障' % reasons})

            # 检查主备节点的掩码是否正确
            try:
                unmatch_mask_nodes = self.check_node_mask(all_nodes, const.DISASTER_NETWORK)
                if unmatch_mask_nodes:
                    err_msg = u'主机“{0}”的掩码配置与集群{1}不一致'.format(
                        ','.join(unmatch_mask_nodes), const.DISASTER_NETWORK_CN)
                    self.addOperationlog(fsid, request, op_log_content, err_msg)
                    return Response({'success': False, 'error': err_msg})
            except errno.ONEStorError, e:
                self.addOperationlog(fsid, request, op_log_content, e.reason)
                return Response({'success': False, 'error': e.reason})

            # 获取可用VRID
            get_vrid_command = 'timeout 300 /opt/h3c/bin/python %s/getvrid_tgt_ha.py' % HANDY_SHELL_PATH
            get_vrid_ret = self.exec_local_ssh_cmd(get_vrid_command).rstrip()
            if get_vrid_ret.find('success') != -1:
                vrid = get_vrid_ret.split('::')[1]
            else:
                log.error(get_vrid_ret)
                self.addOperationlog(fsid, request, op_log_content, u'无法获取可用的vrid')
                return Response({'success': False, 'error': u'无法获取可用的vrid'})

            failed_reasons = {}
            failed_nodes = []
            priority_list = {}
            priority = 240

            # 配置主用节点
            priority_list[master] = priority
            create_command = 'timeout 300 /opt/h3c/bin/python %s/open_tgt_ha.py %s %s %s %s %s %s' % (HANDY_SHELL_PATH, \
                                                                                         vip, priority, vrid, ha_switch,
                                                                                         balance_switch, 'onebackup')
            result = self.exec_remote_ssh_cmd(master, create_command)
            try:
                if result == 'error':
                    failed_reasons[master] = 'Host is unreachable'
                    failed_nodes.append(master)
            except IOError:
                pass
            except:
                if result.strip() != 'success':
                    failed_reasons[master] = result
                    failed_nodes.append(master)

            # 配置备用节点
            threads = []
            nloops = range(len(slave.split(',')))
            lock = threading.Lock()

            def create(node, priority):
                create_command = 'timeout 300 /opt/h3c/bin/python %s/open_tgt_ha.py %s %s %s %s %s %s' \
                                 % (HANDY_SHELL_PATH, vip, priority, vrid, ha_switch, balance_switch, 'onebackup')
                result = self.exec_remote_ssh_cmd(node, create_command)
                try:
                    if result['status'] == 'error':
                        with lock:
                            failed_reasons[node] = 'Host is unreachable'
                            failed_nodes.append(node)
                except IOError:
                    pass
                except:
                    if result.strip() != 'success':
                        with lock:
                            failed_reasons[node] = result
                            failed_nodes.append(node)

            for node in slave.split(','):
                priority -= 1
                priority_list[node] = priority
                t = threading.Thread(target=create, args=(node, priority))
                threads.append(t)

            for i in nloops:
                threads[i].start()

            for i in nloops:
                threads[i].join()

            # 结果检测
            if len(failed_nodes) == 0:
                # 如果创建成功,选择一个tgt高可用的vip，作为agentVip供应用程序使用
                # 创建高可用vip,刚创建时还不能生效，需要等待5s,vip才会生效（后台提供的时间）
                time.sleep(5)
                agent_vips = []
                for ha in ha_list:
                    if ha['disaster_switch'] == '0':
                        agent_vips.append(ha['vip'])
                if len(agent_vips) > 0:
                    agent_vip = agent_vips[0]

                data = {
                    'fsid': fsid,
                    'scheduler_address': vip,
                    'agent_proxy': str(agent_vip),
                    'secondary_scheduler': seconde_scheduler,
                }

                scheduler_request = scheduler.schedulerops.make_request(
                    scheduler.schedulerops.OP_CREATE_PRIMARY_STATIONS)
                scheduler_request.data = data
                result_msg = connect.send_to_scheduler(scheduler_request, vip)

                # 成功，返回消息ok
                if result_msg.req_id == scheduler_request.req_id and result_msg.is_successful():
                    if disaster_switch == '1':
                        disaster_info['disaster_type'] = disaster_type
                        disaster_info['seconde_scheduler'] = seconde_scheduler
                        disaster_info['agent_vip'] = agent_vip

                    params = [
                        vip, master, slave, vrid, priority_list,
                        ha_switch, balance_switch, disaster_switch,
                        disaster_info
                    ]
                    db_results = self.onestor_request(fsid,
                                                      'database.add_obj', ['highavailableconfig', params])
                    # 判断数据库写入是否成功
                    if db_results['status'] != 'error':
                        self.addOperationlog(fsid, request, op_log_content, 'success')
                        return Response({'success': True})
                    # 失败，回退高可用ip
                    else:
                        self.ha_rollback(ha_switch, balance_switch, "fault", vip, vrid, "add")
                        self.addOperationlog(fsid, request, op_log_content, db_results['reason'])
                        return Response({'success': False, 'error': db_results['reason']})
                else:
                    log.error(result_msg)
                    # 失败处理
                    self.addOperationlog(fsid, request, op_log_content, result_msg.result[2])
                    self.ha_rollback(ha_switch, balance_switch, "fault", vip, vrid, "add")
                    return Response({'success': False, 'error': result_msg.result[2]})
            else:
                # 如果创建失败
                self.ha_rollback(ha_switch, balance_switch, "fault", vip, vrid, "add")
                reasons = ''
                for node in failed_nodes:
                    if reasons == '':
                        reasons = '“' + node + '”: ' + failed_reasons[node]
                    else:
                        reasons += ', ' + '“' + node + '”: ' + failed_reasons[node]

                self.addOperationlog(fsid, request, op_log_content, reasons)
                return Response({'success': False, 'error': u'创建容灾主站点高可用IP“%s”失败' % vip})

        except ValueError:
            return Response({'success': False, 'error': 'ValueError'})
        except Exception, e:
            log.error(e, exc_info=True)
            self.addOperationlog(fsid, request, op_log_content, str(e))
            return Response({'success': False, 'error': str(e)})

    def list_disasterha_conf(self, request, fsid):
        """
        获取灾备配置，显示在拓扑配置列表
        """
        try:
            update_database = request.GET.get('updateDb')
            HANDY_SHELL_PATH = '/var/lib/ceph/shell'
            results = self.onestor_request(fsid, 'database.list_objs', ['highavailableconfig'])
            ha_list = self.onestor_request(fsid, 'database.find_one',
                                           ['highavailableconfig', [{'disaster_switch': '1'}]])
            if ha_list:

                # 获取所有配置了高可用的节点
                all_nodes = []
                ha_ips = ''
                for ha in ha_list:
                    all_nodes = all_nodes + [ha['master']] + ha['slave'].split(',')
                    ha_ips = ha_ips + ha['vip'] + ','

                all_nodes = set(all_nodes)

                list_ha_command = 'timeout 100 /opt/h3c/bin/python %s/list_ha.py %s' % (HANDY_SHELL_PATH, ha_ips.rstrip(','))
                ha_ip_list = {}
                threads = []
                nloops = range(len(all_nodes))

                def list_ha(node):
                    result = self.exec_remote_ssh_cmd(node, list_ha_command)
                    try:
                        if result != 'error' and result != 'none':
                            for ha_ip in result.split(','):
                                ha_ip_list[ha_ip] = node

                    except IOError:
                        pass
                    except:
                        pass

                for node in all_nodes:
                    t = threading.Thread(target=list_ha, args=(node,))
                    threads.append(t)

                for i in nloops:
                    threads[i].start()

                for i in nloops:
                    threads[i].join()

            if None != results:
                if ha_list:
                    results['ha_ip_list'] = ha_ip_list
                else:
                    results['ha_ip_list'] = ''
                disaster = []
                site_status = {}
                is_primary = onebackup.metadata.is_primary()
                backup_pool = onebackup.metadata.BackupPool()
                status = backup_pool.status.to_json()
                for result in results['highavailableconfig']:
                    if result['disaster_switch'] == '1':
                        result['status'] = status['status']
                        result['connect_status'] = status['connect_status']
                        disaster.append(result)
                results['highavailableconfig'] = disaster

                disaster_info = {}
                update = False
                # 当在进行主备切换时，定时任务开启，判断元数据的is_primary是否改变
                if update_database:
                    for result in results['highavailableconfig']:
                        # 由主站点切换为备站点，更新数据库
                        if result['disaster_info']['disaster_type'] != is_primary and False == is_primary:
                            disaster_info['disaster_type'] = is_primary
                            database.update_one('highavailableconfig',
                                                {'disaster_switch': '1', '$set': {'disaster_info': disaster_info}})
                            update = True
                            return Response({'success': True, 'data': results, 'update': update})
                        # 由备站点切换为主站点，更新数据库
                        if result['disaster_info']['disaster_type'] != is_primary and True == is_primary:
                            disaster_info['disaster_type'] = is_primary
                            disaster_info['secondary_scheduler'] = ''
                            onebackup_pool = onebackup.metadata.BackupPool()
                            agent_vip = onebackup_pool.primary.to_json()
                            agent_proxy = agent_vip['agent_proxy']
                            disaster_info['agent_vip'] = agent_proxy
                            database.update_one('highavailableconfig',
                                                {'disaster_switch': '1', '$set': {'disaster_info': disaster_info}})
                            update = True
                            return Response({'success': True, 'data': results, 'update': update, \
                                             'agent_vip': disaster_info['agent_vip']})
                return Response({'success': True, 'data': results, 'update': update})

            return Response({'success': False})

        except KeyError:
            return Response({'success': False, 'error': 'KeyError'})
        except Exception, ex:
            log.error('[ONEStor] get disaster ha config list execute exception %s.', ex)
            return Response({'success': False, 'error': str(ex)})

    def create_disater_available(self, request, fsid):
        """
        增加创建灾备备站点接口
        :param request:
        :param fsid:
        :return:
        """
        return self.createHighAvailable(request, fsid)

    def tgt_lb_config(self, vrid, vip, nodes_list, opt_type, send2nodes, rollback=True):
        """
        TGT 中的负载均衡组的回滚
        :param nodes:负载均衡组内节点
        :param send2nodes:执行命令的节点
        :param vip:
        :param vrid:
        :param opt_type:针对某个操作 add/del/modify
        :param rollback:执行失败后是否回滚（回滚操作失败时不进行回滚）
        :return:
        author: yuxin 15632
        """
        success_nodes = []
        failed_nodes = [i for i in send2nodes]
        nodes = ""
        for n in nodes_list:
            nodes += (str(n) + "/")

        nodes = nodes[:-1]

        if opt_type == 'add':
            command = 'timeout 300 python /var/lib/ceph/shell/tgt_load_balance.py add {0} {1} {2}'.\
                format(vrid, vip, nodes)
            for node in send2nodes:
                result = self.exec_remote_ssh_cmd(node, command)

                if isinstance(result, dict):
                    if result['status'] == 'error' and rollback:
                        self.tgt_lb_config(vrid, vip, nodes, 'del', success_nodes, False)
                        log.error("ADD LB group {} failed at {}!".format(vrid, node))
                        return False, failed_nodes
                elif result.strip() != 'success' and rollback:
                    self.tgt_lb_config(vrid, vip, nodes, 'del', success_nodes, False)
                    log.error("ADD LB group {} failed at {}!".format(vrid, node))
                    return False, failed_nodes
                # success
                else:
                    success_nodes.append(node)
                    failed_nodes.remove(node)
            log.info("ADD LB group {} successfully!".format(vrid))
            return True, failed_nodes

        elif opt_type == 'del':
            command = 'timeout 300 python /var/lib/ceph/shell/tgt_load_balance.py del {0} {1} {2}'.\
                format(vrid, vip, nodes)
            for node in send2nodes:
                result = self.exec_remote_ssh_cmd(node, command)

                if isinstance(result, dict):
                    if result['status'] == 'error' and rollback:
                        self.tgt_lb_config(vrid, vip, nodes, 'add', success_nodes, False)
                        log.error("DELETE LB group {} failed at {}!".format(vrid, node))
                        return False, failed_nodes
                elif result.strip() != 'success' and rollback:
                    self.tgt_lb_config(vrid, vip, nodes, 'add', success_nodes, False)
                    log.error("DELETE LB group {} failed at {}!".format(vrid, node))
                    return False, failed_nodes
                # success
                else:
                    success_nodes.append(node)
                    failed_nodes.remove(node)

            log.info("DELETE LB group {} successfully!".format(vrid))
            return True, failed_nodes

        elif opt_type == 'modify':

            command = 'timeout 300 python /var/lib/ceph/shell/tgt_load_balance.py modify {0} {1} {2}'.\
                format(vrid, vip, nodes)
            for node in send2nodes:
                result = self.exec_remote_ssh_cmd(node, command)

                if isinstance(result, dict):
                    if result['status'] == 'error' and rollback:
                        self.tgt_lb_conf(vrid, vip, nodes, 'modify', success_nodes, False)
                        log.error("MODIFY LB group {} failed at {}!".format(vrid, node))
                        return False, failed_nodes
                elif result.strip() != 'success' and rollback:
                    self.tgt_lb_conf(vrid, vip, nodes, 'modify', success_nodes, False)
                    log.error("MODIFY LB group {} failed at {}!".format(vrid, node))
                    return False, failed_nodes
                # success
                else:
                    success_nodes.append(node)
                    failed_nodes.remove(node)
            log.info("MODIFY LB group {} successfully!".format(vrid))
            return True, failed_nodes

    @check_remove_osd_event(const.OP_CREATE_HA_CFG)
    def createHighAvailable(self, request, fsid):
        try:
            HANDY_SHELL_PATH = '/var/lib/ceph/shell'
            vip = request.DATA['vip']
            master = request.DATA['master']
            slave = request.DATA['slave']
            ha_switch = request.DATA['haSwitch']
            balance_switch = request.DATA['balanceSwitch']
            disaster_switch = request.DATA['disasterSwitch']
            if '1' == disaster_switch:
                disaster_type = request.DATA['disasterType']
                # PN: 201705250003 运维管理操作日志中对创建主备站点失败的操作内容描述不准，容易引起误解
                op_log_content = u'创建容灾备站点高可用IP“%s”' % vip
                # 增加清理灾备高可用IP配置处理，可能会残留灾备高可用IP
                clear_succeed = back_utils.DisasterUtils().clear_disaster_ha_conf()
                if not clear_succeed:
                    error_message = u'集群有灾备高可用配置残留，且清理失败'
                    self.addOperationlog(fsid, request, u'创建高可用IP“%s”' % vip, error_message)
                    return Response({'success': False, 'error': error_message})
            else:
                op_log_content = u'创建业务高可用IP“%s”' % vip

            disaster_info = {}
            if master in slave.split(','):
                self.addOperationlog(fsid, request, op_log_content, u'主备节点IP不能相同')
                return Response({'success': False, 'error': u'主备节点IP不能相同'})

            all_nodes = [master] + slave.split(',')

            cluster_config, segment_network = self.get_clusterconfig(), ''
            if disaster_switch == '0':
                public_network = cluster_config['public_network']
                segment_network = public_network
                if ha_switch == '1':
                    # tgt高可用的Vip只能在块服务网段内
                    block_service_segment = ''
                    network_list = list()
                    result = database.list_objs('block_service_network')
                    if result:
                        network_list = result['block_service_network']
                    if network_list:
                        for instance in network_list:
                            if instance['id'] == 1:
                                block_service_segment = instance['block_service_network']
                    blockipjudge = self.subnet_judge(block_service_segment, vip)
                    if not blockipjudge:
                        self.addOperationlog(fsid, request, op_log_content, u'tgt高可用IP不在块服务网段内')
                        return Response({'success': False, 'error': u'tgt高可用IP不在块服务网段内'})
                else:
                    publicIpJudge = self.subnet_judge(public_network, vip)
                    if not publicIpJudge:
                        self.addOperationlog(fsid, request, op_log_content, u'高可用IP不在存储前端网段内')
                        return Response({'success': False, 'error': u'高可用IP不在存储前端网段内'})
            if disaster_switch == '1':
                disaster_network = cluster_config['disaster_network']
                segment_network = disaster_network
                disasterIpJudge = self.subnet_judge(disaster_network, vip)
                if not disasterIpJudge:
                    self.addOperationlog(fsid, request, op_log_content, u'高可用IP不在灾备网段内')
                    return Response({'success': False, 'error': u'高可用IP不在灾备网段内'})
            # 检查使用的虚IP是否为可用的
            mask = int(segment_network.split('/')[1])
            if not self.check_ip_used_correct(vip, mask):
                log.error('ip %s is unusable in mask network %s', vip, mask)
                self.addOperationlog(fsid, request, op_log_content, errno.ERROR_IP_MASK[2])
                return Response({'success': False, 'error': errno.ERROR_IP_MASK[2]})

        except IOError:
            pass
        except:
            self.addOperationlog(fsid, request, op_log_content, u'输入参数错误')
            return Response({'success': False, 'error': u'输入参数错误'})

        if 1 != len(self.test_ping(vip.split(','))):
            self.addOperationlog(fsid, request, op_log_content, u'IP地址“%s”已经被使用' % vip)
            return Response({'success': False, 'error': u'IP地址“%s”已经被使用' % vip})

        if ha_switch == '1':
            app = 'tgt'
        else:
            app = 'rgw'
        try:
            if balance_switch == '1':
                if ha_switch != '1':
                    ret = self.check_loadbalance(all_nodes)
                    if ret != "success":
                        self.addOperationlog(fsid, request, op_log_content, ret)
                        return Response({'success': False, 'error': u'开启“%s”负载均衡失败，%s' % (app, ret)})

            failed_nodes = self.test_ping(all_nodes)
            if len(failed_nodes) != 0:
                reasons = ''
                for node in failed_nodes:
                    if reasons == '':
                        reasons = node
                    else:
                        reasons += ', ' + node

                self.addOperationlog(fsid, request, op_log_content, u'节点“%s”存在网络故障' % reasons)
                return Response({'success': False, 'error': u'节点“%s”存在网络故障' % reasons})

            # 检查主备节点的掩码是否正确
            if disaster_switch == '1':
                network_type = const.DISASTER_NETWORK
                network_type_cn = const.DISASTER_NETWORK_CN
            else:
                network_type = const.PUBLIC_NETWORK
                network_type_cn = const.PUBLIC_NETWORK_CN

            try:
                unmatch_mask_nodes = self.check_node_mask(all_nodes, network_type)
                if unmatch_mask_nodes:
                    err_msg = u'主机“{0}”的掩码配置与集群{1}不一致'.format(
                        ','.join(unmatch_mask_nodes), network_type_cn)
                    self.addOperationlog(fsid, request, op_log_content, err_msg)
                    return Response({'success': False, 'error': err_msg})
            except errno.ONEStorError, e:
                self.addOperationlog(fsid, request, op_log_content, e.reason)
                return Response({'success': False, 'error': e.reason})

            # 获取可用VRID
            get_vrid_command = 'timeout 300 /opt/h3c/bin/python %s/getvrid_tgt_ha.py' % HANDY_SHELL_PATH
            get_vrid_ret = self.exec_local_ssh_cmd(get_vrid_command).rstrip()
            if get_vrid_ret.find('success') != -1:
                vrid = get_vrid_ret.split('::')[1]
            else:
                log.error(get_vrid_ret)
                self.addOperationlog(fsid, request, op_log_content, u'无法获取可用的vrid')
                return Response({'success': False, 'error': u'无法获取可用的vrid'})

            failed_reasons = {}
            failed_nodes = []
            priority_list = {}
            priority = 240
            tgt_lb_enable = False

            # 所有TGT开启负载均衡
            if '1' == balance_switch and app is 'tgt':
                tgt_lb_enable = True
                tgt_lb_result = self.tgt_lb_config(vrid, vip, all_nodes, 'add', all_nodes)
                if not tgt_lb_result[0]:
                    return Response({'success': False,
                                     'error': u'节点{}配置负载均衡失败!'.format(tgt_lb_result[1])})
                log.info("Create Load Balance Group {} successfully!".format(vrid))

            # 屏蔽后续开启LVS的负载均衡的操作
            old_balance_switch = balance_switch
            if app is 'tgt':
                balance_switch = '2'
            # 配置主用节点
            priority_list[master] = priority
            if '1' == balance_switch:
                switch_arp = '1'
                command = 'timeout 300 /opt/h3c/bin/python %s/config_realserver.py add' % HANDY_SHELL_PATH
                self.command_all_nodes(ha_switch, command, vip, vrid, switch_arp)

            _service = 'tgt' if '0' == disaster_switch else 'onebackup'
            create_command = 'timeout 300 /opt/h3c/bin/python %s/open_tgt_ha.py %s %s %s %s %s %s' \
                             % (HANDY_SHELL_PATH, vip, priority, vrid, ha_switch, balance_switch, _service)
            result = self.exec_remote_ssh_cmd(master, create_command)
            try:
                if result['status'] == 'error':
                    failed_reasons[master] = 'Host is unreachable'
                    failed_nodes.append(master)
            except IOError:
                pass
            except:
                if result.strip() != 'success':
                    failed_reasons[master] = result
                    failed_nodes.append(master)

            # 配置备用节点
            threads = []
            nloops = range(len(slave.split(',')))

            lock = threading.Lock()

            def create(node, priority):
                _service = 'tgt' if '0' == disaster_switch else 'onebackup'
                create_command = 'timeout 300 /opt/h3c/bin/python %s/open_tgt_ha.py %s %s %s %s %s %s' \
                                 % (HANDY_SHELL_PATH, vip, priority, vrid, ha_switch, balance_switch, _service)
                result = self.exec_remote_ssh_cmd(node, create_command)
                try:
                    if result['status'] == 'error':
                        with lock:
                            failed_reasons[node] = 'Host is unreachable'
                            failed_nodes.append(node)
                except IOError:
                    pass
                except:
                    if result.strip() != 'success':
                        with lock:
                            failed_reasons[node] = result
                            failed_nodes.append(node)

            for node in slave.split(','):
                priority -= 1
                priority_list[node] = priority
                t = threading.Thread(target=create, args=(node, priority))
                threads.append(t)

            for i in nloops:
                threads[i].start()

            for i in nloops:
                threads[i].join()

            # 结果检测
            if len(failed_nodes) == 0:
                # 创建高可用vip,刚创建时还不能生效，需要等待5s,vip才会生效（后台提供的时间）
                time.sleep(5)
                # 如果创建成功，如果是灾备的高可用，创建备站点，发送消息给后台
                if disaster_switch == '1':
                    data = {
                        'fsid': fsid,
                        'scheduler_address': vip,
                    }
                    disaster_info['disaster_type'] = disaster_type

                    scheduler_request = scheduler.schedulerops.make_request(
                        scheduler.schedulerops.OP_CREATE_SECONDARY_STATIONS)
                    scheduler_request.data = data
                    result_msg = connect.send_to_scheduler(scheduler_request, vip)

                    if result_msg.result[0] == -1:
                        self.addOperationlog(fsid, request, op_log_content, result_msg.result[2])
                        return Response({'status': 'error', 'reason': result_msg.result[2]})
                    if scheduler_request.req_id == result_msg.req_id:
                        if not result_msg.is_successful():
                            self.ha_rollback(ha_switch, balance_switch, "fault", vip, vrid, "add")
                            self.addOperationlog(fsid, request, op_log_content, result_msg.result[2])
                            return Response({'status': 'error', 'reason': result_msg.result[2]})
                params = [vip, master, slave, vrid, priority_list, ha_switch, old_balance_switch, disaster_switch,
                          disaster_info]
                db_results = self.onestor_request(fsid, 'database.add_obj', ['highavailableconfig', params])
                # 判断数据库写入是否成功
                if db_results['status'] != 'error':
                    # BEGIN ADD BY S11435 2016/08/24 PN: 201607290193
                    self.ha_rollback(ha_switch, balance_switch, "success", vip, vrid, "add")
                    self._process_get_working_node(vip)
                    self.addOperationlog(fsid, request, op_log_content, 'success')
                    return Response({'success': True})
                else:
                    self.ha_rollback(ha_switch, balance_switch, "fault", vip, vrid, "add")
                    # 回滚操作失败了就不再回滚
                    if tgt_lb_enable:
                        self.tgt_lb_config(vrid, vip, all_nodes, 'del', all_nodes, False)
                    self.addOperationlog(fsid, request, op_log_content, db_results['reason'])
                    return Response({'success': False, 'error': db_results['reason']})
            else:
                # 如果创建失败
                self.ha_rollback(ha_switch, balance_switch, "fault", vip, vrid, "add")
                # 回滚操作失败了就不再回滚
                if tgt_lb_enable:
                    self.tgt_lb_config(vrid, vip, all_nodes, 'del', all_nodes, False)
                reasons = ''
                for node in failed_nodes:
                    if reasons == '':
                        reasons = '“' + node + '”: ' + failed_reasons[node]
                    else:
                        reasons += ', ' + '“' + node + '”: ' + failed_reasons[node]

                self.addOperationlog(fsid, request, op_log_content, reasons)
                return Response({'success': False, 'error': u'创建业务高可用IP“%s”失败' % vip})

        except ValueError:
            return Response({'success': False, 'error': 'ValueError'})
        except Exception, e:
            log.error(e)
            self.addOperationlog(fsid, request, op_log_content, u'操作失败，详见后台日志')
            return Response({'success': False, 'error': u'操作失败，详见后台日志'})

    def _get_working_nodes(self, ha_cfgs):
        """
        获取所有工作节点
        """
        all_nodes, ha_ip_list, ha_ips = [], {}, ''

        if not ha_cfgs:
            return ha_ip_list

        for ha in ha_cfgs:
            # 过滤掉灾备的本地IP
            if '0' == ha['disaster_switch']:
                all_nodes = all_nodes + [ha['master']] + ha['slave'].split(',')
            ha_ips = ha_ips + ha['vip'] + ','

        # 去掉重复的节点
        all_nodes = set(all_nodes)

        # MODIFY BY KF6602 2016/9/26 PN:201609230190
        list_ha_command = \
            'timeout 300 ssh -o ConnectTimeout=2 $$ /opt/h3c/bin/python /var/lib/ceph/shell/list_ha.py %s' % ha_ips.rstrip(',')

        # 远程登录到每个高可用节点上获取当前工作节点
        list_ha_results = self.multi_thread_task(all_nodes, list_ha_command)

        for node, result in list_ha_results.items():
            if 'error' != result and 'none' != result:
                for ha_ip in result.split(','):
                    # ADD BY KF6602 2016/7/22 PN:201607210137
                    if ha_ip != '':
                        ha_ip_list[ha_ip] = node

        return ha_ip_list

    def __convert_disaster_ip_to_public(self, ha_cfgs):
        """
        PN：201707060351 将灾备网段内的IP地址转换为业务网段IP
        :param ha_cfgs: 高可用的配置信息
        :return: 转换完之后的高可用配置信息
        """
        for _ha_cfg in ha_cfgs:
            if '0' == _ha_cfg['disaster_switch']:
                continue
            _ha_cfg['master'] = self.get_public_ip_by_disaster_ip(_ha_cfg['master'])
            final_slave = []
            for _slave in _ha_cfg['slave'].split(','):
                _slave = self.get_public_ip_by_disaster_ip(_slave)
                final_slave.append(_slave)
            _ha_cfg['slave'] = ','.join(final_slave)

    def listHighAvailable(self, request, fsid):
        try:
            # 是否需要获取容灾的高可用信息
            need_disaster = request.GET.get('with_disaster', False)
            # 从数据库中获取所有高可用配置
            ha_cfgs = database.list_objs('highavailableconfig')
            # 获取所有工作节点
            ha_working_nodes = self._get_working_nodes(ha_cfgs['highavailableconfig'])
            # 将工作节点更新到结果中
            ha_cfgs['ha_ip_list'] = ha_working_nodes
            # begin add by z11524 2017/11/2 PN:201710200205
            public_network = self.get_clusterconfig()['public_network']
            # 灾备返回高可用配置
            if need_disaster is False:
                ha_cfgs['highavailableconfig'] = \
                    [ha_cfg for ha_cfg in ha_cfgs['highavailableconfig'] if ha_cfg['disaster_switch'] == '0']
            else:
                # ADD BY D10039 2017/07/15 PN：201707060351 需要将容灾IP转换为业务网IP
                self.__convert_disaster_ip_to_public(ha_cfgs['highavailableconfig'])
            # 返回数据给页面
            return Response({'success': True, 'data': ha_cfgs, 'mask': public_network})
        except KeyError:
            return Response({'success': False, 'error': 'KeyError'})
        except Exception, e:
            log.error(e)
            return Response({'success': False, 'error': str(e)})

    @check_remove_osd_event(const.OP_REMOVE_HA_CFG)
    def removeHighAvailable(self, request, fsid):
        try:
            HANDY_SHELL_PATH = '/var/lib/ceph/shell'
            database_id = request.GET.get('database_id')
            vip = request.GET.get('vip')
            vrid = request.GET.get('vrid')
            master = request.GET.get('master')
            balance_switch = request.GET.get('balance_switch')
            ha_switch = request.GET.get('ha_switch')
            slave = request.GET.get('slave')
            all_nodes = [master] + slave.split(',')
            ha_port = "3260" if ha_switch == "1" else "8082"

        except KeyError:
            return Response({'success': False, 'error': u'输入参数错误'})
        op_log_content = u'删除业务高可用IP“%s”' % vip
        try:
            disaster_exist = self.disaster_pool_exist()
            if disaster_exist:
                # 检测如果该高可用IP是被灾备用作proxy_agent,不允许删除
                backup_pool = onebackup.metadata.BackupPool()
                primary_info = backup_pool.primary.to_json()
                agent_vip = primary_info['agent_proxy']
                if agent_vip == vip:
                    self.addOperationlog(
                            fsid, request, op_log_content, u'该高可用IP正在被异地灾备使用')
                    return Response({'success': False, 'error': u'该高可用IP正在被异地灾备使用'})

            if '1' == ha_switch:
                # 如果Target的高可用IP只剩最后一个且有异地灾备配置，不允许删除
                ha_cfgs = database.list_objs('highavailableconfig')
                tgt_ha_cfg = \
                    [ha_cfg for ha_cfg in ha_cfgs['highavailableconfig'] if '0' == ha_cfg['disaster_switch'] and
                     '1' == ha_cfg['ha_switch']]
                onebackup_ha_cfg = \
                    [ha_cfg for ha_cfg in ha_cfgs['highavailableconfig'] if '1' == ha_cfg['disaster_switch']]
                if onebackup_ha_cfg and 1 == len(tgt_ha_cfg):
                    error_message = u'异地灾备至少需要保留一个Target的高可用IP，请先关闭容灾功能'
                    self.addOperationlog(fsid, request, op_log_content, error_message)
                    return Response({'success': False, 'error': error_message})

            # 检测高可用IP是否正在使用
            if balance_switch == "1":
                nodelist = []
                if "1" == ha_switch:
                    nodelist = self._get_mon_stor()
                else:
                    gateway = self.exec_local_cmd_json('ceph config-key get gateway')['gateway']
                    for gw in gateway:
                        index = gw['hostip'].find(":")
                        if "-1" != index:
                            gw['hostip'] = gw['hostip'][:index]
                        nodelist.append(gw['hostip'])
                test_vip = self.test_vip_connect(vip, nodelist, ha_port)
            else:
                test_vip = self.test_vip_connect(vip, all_nodes, ha_port)

            if len(test_vip['failed_nodes']) == 0:
                if len(test_vip['connect_node']) != 0:
                    self.addOperationlog(fsid, request, op_log_content, u'该高可用IP正在使用中')
                    return Response({'success': False, 'error': u'该高可用IP正在使用中'})
            else:
                reasons = ''
                for node in test_vip['failed_nodes']:
                    if reasons == '':
                        reasons = node
                    else:
                        reasons += ', ' + node

                self.addOperationlog(fsid, request, op_log_content, u'节点“%s”存在网络故障' % reasons)
                return Response({'success': False, 'error': u'删除业务高可用IP“%s”失败，有节点存在网络故障' % vip})

            # 检测配置的节点是否可以ping通
            failed_nodes = self.test_ping(all_nodes)
            if len(failed_nodes) != 0:
                reasons = ''
                for node in failed_nodes:
                    if reasons == '':
                        reasons = node
                    else:
                        reasons += ', ' + node

                self.addOperationlog(fsid, request, op_log_content, u'节点“%s”存在网络故障' % reasons)
                return Response({'success': False, 'error': u'删除业务高可用IP“%s”失败，有节点存在网络故障' % vip})

            tgt_lb_disable = False
            if '1' == balance_switch:
                # 删除tgt的负载均衡
                if ha_switch == '1':
                    tgt_lb_disable = True
                    tgt_lb_result = self.tgt_lb_config(vrid, vip, all_nodes, 'del', all_nodes)
                    if not tgt_lb_result[0]:
                        return Response({'status': 'error',
                                         'reason': u'节点{}配置负载均衡失败!'.format(tgt_lb_result[1])})
                    log.info("Delete Load Balance Group {}".format(vrid))
                else:
                    switch_arp = self.remove_get_arp()
                    command = 'timeout 300 /opt/h3c/bin/python %s/config_realserver.py del' % HANDY_SHELL_PATH
                    self.command_all_nodes(ha_switch, command, vip, vrid, switch_arp)

            remove_high_switch = self.onestor_request(fsid, 'database.find_by_id', ['highavailableconfig', database_id])
            disaster_switch = remove_high_switch['disaster_switch']
            _service = 'tgt' if '0' == disaster_switch else 'onebackup'
            remove_command = 'timeout 300 /opt/h3c/bin/python %s/close_tgt_ha.py %s %s %s' % (HANDY_SHELL_PATH, vip, vrid, _service)

            failed_reasons = {}
            failed_nodes = []
            threads = []
            nloops = range(len(all_nodes))
            lock = threading.Lock()

            def remove(node):
                result = self.exec_remote_ssh_cmd(node, remove_command)
                try:
                    if result['status'] == 'error':
                        with lock:
                            failed_reasons[node] = 'Host is unreachable'
                            failed_nodes.append(node)
                except IOError:
                    pass
                except:
                    if result.strip() != 'success' and result.find('the specify ip address do not exist') == -1:
                        with lock:
                            failed_reasons[node] = result
                            failed_nodes.append(node)

            for node in all_nodes:
                t = threading.Thread(target=remove, args=(node,))
                threads.append(t)

            for i in nloops:
                threads[i].start()

            for i in nloops:
                threads[i].join()

            if len(failed_nodes) == 0:
                results = self.onestor_request(fsid, 'database.del_obj', ['highavailableconfig', database_id])
                if results['status'] != 'error':
                    self.ha_rollback(ha_switch, balance_switch, "success", vip, vrid, "del")
                    self.addOperationlog(fsid, request, op_log_content, 'success')
                    return Response({'success': True})
                else:
                    self.ha_rollback(ha_switch, balance_switch, "fault", vip, vrid, "del")
                    if tgt_lb_disable:
                        self.tgt_lb_config(vrid, vip, all_nodes, 'add', all_nodes, False)
                    self.addOperationlog(fsid, request, op_log_content, results)
                    return Response({'success': False, 'error': results['reason']})
            else:
                if tgt_lb_disable:
                    self.tgt_lb_config(vrid, vip, all_nodes, 'add', all_nodes, False)
                self.ha_rollback(ha_switch, balance_switch, "fault", vip, vrid, "del")
                reasons = ''
                for node in failed_nodes:
                    if reasons == '':
                        reasons = '“' + node + '”: ' + failed_reasons[node]
                    else:
                        reasons += ', ' + '“' + node + '”: ' + failed_reasons[node]
                self.addOperationlog(fsid, request, op_log_content, reasons)
                return Response({'success': False, 'error': u'删除业务高可用IP“%s”失败' % vip})

        except ValueError:
            self.addOperationlog(fsid, request, op_log_content, u'操作失败，详见后台日志')
            return Response({'success': False, 'error': u'操作失败，详见后台日志'})
        except Exception, e:
            log.exception(e)
            self.addOperationlog(fsid, request, op_log_content, u'操作失败，详见后台日志')
            return Response({'success': False, 'error': u'操作失败，详见后台日志'})

    def check_param_and_net(self, args):
        """
        校验参数
        :param args:
        :return:
        """
        err_msg = u''
        if args[2] in args[3].split(','):
            err_msg = u'主备节点IP不能相同'
        block_service_segment = get_block_service_segment()
        if not block_service_segment:
            return u'未配置块服务网段'
        flag = self.subnet_judge(block_service_segment, args[1])
        if not flag:
            err_msg = u'高可用ip不在块服务网段内'
        if len(self.test_ping(args[1].split(','))) != 1:
            err_msg = u'IP地址“%s”已经被使用' % args[1]
        all_nodes = [args[2]] + args[3].split(',')

        failed_nodes = self.test_ping(all_nodes)
        if failed_nodes:
            reason = ''
            for node in failed_nodes:
                reason += ',' + node
            reason = ','.join(reason.split(','))
            err_msg = u'节点“%s”存在网络故障' % reason
        network_type = const.PUBLIC_NETWORK
        network_type_cn = const.PUBLIC_NETWORK_CN
        flag = self.check_node_mask(all_nodes, network_type)
        if flag:
            err_msg = u'主机“{0}”的掩码配置与集群{1}不一致'.format(','.join(flag), network_type_cn)
        return err_msg

    def check_enable_result(self, failed_nodes, failed_reasons, args, request):
        """
        检验完成结果，写入到数据库
        :param failed_nodes:
        :param failed_reasons:
        :param args:
        :param state:
        :param request:
        :return:
        """

        fsid = args[8]
        op_log_content = u'启用业务高可用IP“%s”' % args[1]
        if not failed_nodes:
            # 创建高可用vip,刚创建时还不能生效，需要等待5s,vip才会生效（后台提供的时间）
            time.sleep(5)
            params = [args[1], args[3], args[7], {}, args[5], 'running']
            results = self.onestor_request(fsid, 'database.update_obj', ['highavailableconfig', args[0], params])
            # 判断数据库写入是否成功
            if results['status'] != 'error':
                # BEGIN ADD BY S11435 2016/08/24 PN: 201607290193
                self.ha_rollback(args[4], args[5], "success", args[1], args[6], "add")
                self._process_get_working_node(args[1])
                self.addOperationlog(fsid, request, op_log_content, 'success')
                response = Response({'success': True})
            else:
                log.warn('modify highavailableconfig failed, try again...')
                results = self.onestor_request(
                            fsid, 'database.update_obj', ['highavailableconfig', args[0], params])
                # self.ha_rollback(args[4], args[5], "fault", args[1], args[6], "add")
                self.addOperationlog(fsid, request, op_log_content, results['reason'])
                response = Response({'success': False, 'error': results['reason']})
        else:
            # 如果创建失败
            self.ha_rollback(args[4], args[5], "fault", args[1], args[6], "add")
            flag = ''
            for node in failed_nodes:
                if flag == '':
                    flag = '“' + node + '”: ' + failed_reasons[node]
                else:
                    flag += ', ' + '“' + node + '”: ' + failed_reasons[node]

            self.addOperationlog(fsid, request, op_log_content, flag)
            response = Response({'success': False, 'error': u'启用高可用IP“%s”失败' % args[1]})

        return response

    def config_back_up(self, args, failed_reasons, failed_nodes):
        """
        配置backup节点
        :param args:
        :param failed_reasons:
        :param failed_nodes:
        :return:
        """
        threads = []
        nloops = range(len(args[3].split(',')))
        lock = threading.Lock()
        handy_shell_path = '/var/lib/ceph/shell'

        def create(node, priority):
            '''
            创建函数
            :param node:
            :param priority:
            :return:
            '''
            # _service = 'tgt'
            create_command = 'timeout 300 python %s/open_tgt_ha.py %s %s %s %s %s %s' \
                                 % (handy_shell_path, args[1], priority, args[6], args[4], args[5], 'tgt')
            result = self.exec_remote_ssh_cmd(node, create_command)
            if isinstance(result, dict):
                if result['status'] == 'error':
                    with lock:
                        failed_reasons[node] = 'Host is unreachable'
                        failed_nodes.append(node)
            elif result.strip() != 'success':
                with lock:
                    failed_reasons[node] = result
                    failed_nodes.append(node)

        for node in args[3].split(','):
            priority = args[7][node]
            thread_tmp = threading.Thread(target=create, args=(node, priority))
            threads.append(thread_tmp)

        for i in nloops:
            threads[i].start()

        for i in nloops:
            threads[i].join()

    def create_loadbalance(self, args, failed_reasons, failed_nodes):
        """
        创建高可用组内的负载均衡
        :param args:
        :return:
        """
        master = args[2]
        vrid = args[6]
        vip = args[1]
        all_nodes = [master] + args[3].split(',')
        result_tmp = self.\
                    tgt_lb_config(vrid, vip, all_nodes, 'add', all_nodes)
        if not result_tmp[0]:
            msg = "MODIFY Load Balance Group {} failed at {}".format(vrid, result_tmp[1])
            log.error(msg)
            return Response({'success': False, 'error': msg})

    @check_remove_osd_event(const.OP_HA_GROUP_ENABLE)
    def enablehighavailable(self, request, fsid):
        """
        启用高可用组IP
        :param request:
        :param fsid:
        :return:
        """
        try:
            ha_id = request.DATA['id']
        except KeyError:
            return Response({'success': False, 'error': "输入参数错误"})
        config = database.find_by_id('highavailableconfig', ha_id)
        handy_shell_path = '/var/lib/ceph/shell'
        # current_id = request.DATA['id']
        # vip = request.DATA['vip']
        # master = request.DATA['master']
        # slave = request.DATA['slave']
        # ha_switch = request.DATA['haSwitch']
        # balance_switch = request.DATA['balanceSwitch']
        # vrid = request.DATA['vrid']
        # priority_list = request.DATA['priority_list']

        args = list()
        args.append(config['id'])
        args.append(config['vip'])
        args.append(config['master'])
        args.append(config['slave'])
        args.append(config['ha_switch'])
        args.append(config['balance_switch'])
        args.append(config['vrid'])
        args.append(config['priority_list'])
        args.append(fsid)

        if config['state'] == 'running':
            log.error("the state of the highavailable vip {0}  is already running".format(config['vip']))
            return Response({'success': False, 'error': "the state of the highavailable group is already running"})
        # 对参数进行检验
        err_msg = self.check_param_and_net(args)
        if err_msg:
            return Response({'success': False, 'error': err_msg})

        failed_reasons = {}
        failed_nodes = []

        # 配置master节点
        # switch_arp = '1'
        if args[5] == '1':
            # command = 'timeout 300 python %s/config_realserver.py add' % handy_shell_path
            # self.command_all_nodes(args[4], command, args[1], args[6], '1')
            self.create_loadbalance(args, failed_reasons, failed_nodes)
        if failed_nodes:
            return Response({'success': False, 'error': 'can not crete loadbalance'})

        # _service = 'tgt'
        create_command = 'timeout 300 python %s/open_tgt_ha.py %s %s %s %s %s %s' \
                             % (handy_shell_path, args[1], args[7][args[2]], args[6], args[4], args[5], 'tgt')
        ret = self.exec_remote_ssh_cmd(args[2], create_command)
        if isinstance(ret, dict):
            if ret['status'] == 'error':
                failed_reasons[args[2]] = 'Host is unreachable'
                failed_nodes.append(args[2])
        elif ret.strip() != 'success':
            failed_reasons[args[2]] = ret
            failed_nodes.append(args[2])
        log.info("config master finish")

        self.config_back_up(args, failed_reasons, failed_nodes)

        return self.check_enable_result(failed_nodes, failed_reasons, args, request)

    def disable_all_nodes(self, args, failed_reasons, failed_nodes, request):
        """
        删除节点上的高可用组配置
        :param args:
        :param failed_reasons:
        :param failed_nodes:
        :param fsid:
        :return:
        """

        vip = args[1]
        master = args[2]
        slave = args[3]
        balance_switch = args[5]
        vrid = args[6]
        old_all_nodes = [master] + slave.split(',')
        # handy_shell_path = '/var/lib/ceph/shell'
        if balance_switch == '1':
            result_tmp = self.\
                        tgt_lb_config(vrid, vip, old_all_nodes, 'del', old_all_nodes)
            if not result_tmp[0]:
                msg = "MODIFY Load Balance Group {} failed at {}".format(vrid, result_tmp[1])
                log.error(msg)
                return Response({'success': False, 'error': msg})

        remove_command = 'timeout 300 python %s/close_tgt_ha.py %s %s %s' % ('/var/lib/ceph/shell', args[1], args[6], 'tgt')
        threads = []
        all_nodes = [args[2]] + args[3].split(',')
        nloops = range(len(all_nodes))
        lock = threading.Lock()

        def remove(node):
            """
            执行脚本
            :param node:
            :param priority:
            :return:
            """
            result = self.exec_remote_ssh_cmd(node, remove_command)
            if result['status'] == 'error':
                with lock:
                    failed_reasons[node] = 'Host is unreachable'
                    failed_nodes.append(node)

            if result.strip() != 'success' and result.find('the specify ip address do not exist') == -1:
                with lock:
                    failed_reasons[node] = result
                    failed_nodes.append(node)

        for node in all_nodes:
            thread_tmp = threading.Thread(target=remove, args=(node,))
            threads.append(thread_tmp)

        for i in nloops:
            threads[i].start()

        for i in nloops:
                threads[i].join()
        self.addOperationlog(args[8], request, u'关闭高可用IP“%s”' % all_nodes, u'success')


    def check_disable_results(self, args, failed_nodes, failed_reasons, request):
        """
        检查禁用高可用ip结果，修改数据库
        :param args:
        :param failed_nodes:
        :param failed_reasons:
        :param request:
        :return:
        """
        fsid = args[8]
        if not failed_nodes:
            params = [args[1], args[3], args[7], {}, args[5], 'stop']
            results = self.onestor_request(fsid, 'database.update_obj', ['highavailableconfig', args[0], params])
            if results['status'] != 'error':
                self.ha_rollback(args[5], args[4], "success", args[1], args[2], "del")
                self.addOperationlog(fsid, request, u'关闭高可用IP“%s”' % args[1], 'success')
                return Response({'success': True})

            # self.ha_rollback(args[5], args[4], "fault", args[1], args[2], "del")
            log.warn('modify highavailableconfig failed, try again...')
            results = self.onestor_request(
                            fsid, 'database.update_obj', ['highavailableconfig', args[0], params])
            self.addOperationlog(fsid, request, u'关闭高可用IP“%s”' % args[1], results)
            return Response({'success': False, 'error': results['reason']})
        else:
            self.ha_rollback(args[5], args[4], "fault", args[1], args[2], "del")
            reasons = ''
            for node in failed_nodes:
                if reasons == '':
                    reasons = '“' + node + '”: ' + failed_reasons[node]
                else:
                    reasons += ', ' + '“' + node + '”: ' + failed_reasons[node]
            self.addOperationlog(fsid, request, u'关闭高可用IP“%s”' % args[1], reasons)
            return Response({'success': False, 'error': u'关闭高可用IP“%s”失败' % args[1]})

    def check_ping_vip(self, args, request, ha_port):
        """
        检测高可用IP是否正在使用
        :param args:
        :param request:
        :param ha_port:
        :return:
        """
        all_nodes = [args[2]] + args[3].split(',')
        fsid = args[8]
        response = ''
        if args[4] == "1":
            nodelist = self._get_mon_stor()
            test_vip = self.test_vip_connect(args[1], nodelist, ha_port)
        else:
            test_vip = self.test_vip_connect(args[1], all_nodes, ha_port)

        if not test_vip['failed_nodes']:
            if test_vip['connect_node']:
                self.addOperationlog(fsid, request, u'关闭高可用IP“%s”' % args[1], u'该高可用IP正在使用中')
                response = Response({'success': False, 'error': u'该高可用IP正在使用中'})
        else:
            reasons = ' '
            for node in test_vip['failed_nodes']:
                # if reasons == '':
                #     reasons = node
                # else:
                #     reasons += ', ' + node
                reasons += node + ' '
            reasons = ','.join(reasons.split())

            self.addOperationlog(fsid, request, u'关闭高可用IP“%s”' % args[1], u'节点“%s”存在网络故障' % reasons)
            response = Response({'success': False, 'error': u'关闭高可用IP“%s”失败，有节点存在网络故障' % args[1]})
        return response

    @check_remove_osd_event(const.OP_HA_GROUP_DISABLE)
    def disablehighavailable(self, request, fsid):
        """
        禁用高可用组IP
        :param request:
        :param fsid:
        :return:
        """
        try:
            ha_id = request.DATA['id']
        except KeyError:
            return Response({'success': False, 'error': "输入参数错误"})
        config = database.find_by_id('highavailableconfig', ha_id)
        args = list()
        args.append(config['id'])
        args.append(config['vip'])
        args.append(config['master'])
        args.append(config['slave'])
        args.append(config['ha_switch'])
        args.append(config['balance_switch'])
        args.append(config['vrid'])
        args.append(config['priority_list'])
        # args.append(request.DATA['disaster_info'])
        args.append(fsid)

        if config['state'] == 'stop':
            log.error("the state of the highavailable vip {0}  is already stop".format(config['vip']))
            return Response({'success': False, 'error': "the state of the highavailable group is already stop"})
        ha_port = 3260
        # all_nodes = args[2] + args[3].split(',')
        # 如果Target的高可用IP只剩最后一个且有异地灾备配置，不允许禁用该高可用组
        ha_cfgs = database.list_objs('highavailableconfig')
        tgt_ha_cfg = \
                    [ha_cfg for ha_cfg in ha_cfgs['highavailableconfig'] if ha_cfg['disaster_switch'] == '0' and
                     ha_cfg['ha_switch']] == '1'
        onebackup_ha_cfg = \
                    [ha_cfg for ha_cfg in ha_cfgs['highavailableconfig'] if ha_cfg['disaster_switch']] == '1'
        if onebackup_ha_cfg and len(tgt_ha_cfg) == 1:
            error_message = u'异地灾备至少需要保留一个Target的高可用IP，请先关闭容灾功能'
            self.addOperationlog(fsid, request, u'关闭高可用IP“%s”' % args[1], error_message)
            return Response({'success': False, 'error': error_message})

        err_msg = self.check_ping_vip(args, request, ha_port)
        if err_msg:
            return err_msg

            # 检测配置的节点是否可以ping通
        failed_nodes = self.test_ping([args[2]] + args[3].split(','))
        if failed_nodes:
            reasons = ' '
            for node in failed_nodes:
                reasons += ' ' + node
            reasons = ','.join(reasons.split())

            self.addOperationlog(fsid, request, u'关闭高可用IP“%s”' % args[1], u'节点“%s”存在网络故障' % reasons)
            return Response({'success': False, 'error': u'关闭高可用IP“%s”失败，有节点存在网络故障' % args[1]})
        failed_reasons = {}
        failed_nodes = []

        self.disable_all_nodes(args, failed_reasons, failed_nodes, request)
        return self.check_disable_results(args, failed_nodes, failed_reasons, request)

    def patch_disater_available(self, request, fsid):
        """
        增加修改灾备备站点接口
        :param request:
        :param fsid:
        :return:
        """
        return self.patchHighAvailable(request, fsid)

    @check_remove_osd_event(const.OP_MODIFY_HA_CFG)
    def patchHighAvailable(self, request, fsid):
        try:
            HANDY_SHELL_PATH = '/var/lib/ceph/shell'
            current_id = request.DATA['id']
            old_vip = request.DATA['oldVip']
            current_vip = request.DATA['currentVip']
            master = request.DATA['master']
            old_slave = request.DATA['oldSlave']
            current_slave = request.DATA['currentSlave']
            priority_list = request.DATA['priorityList']
            ha_switch = request.DATA['ha_switch']
            balance_switch = request.DATA['balance_switch']
            vrid = request.DATA['vrid']
            new_balance_switch = balance_switch

            ha_port = "3260" if ha_switch == "1" else "8082"

            backup_exist = self.disaster_pool_exist()

            disaster_switch = request.DATA.get('disasterSwitch', '0')
            reconnect_site = request.DATA.get('reconnect_site', False)
            disaster_info = {}
            if disaster_switch == '1':
                disaster_type = request.DATA['disasterType']
                disaster_info['disaster_type'] = disaster_type
                if disaster_type:
                    seconde_scheduler = str(request.DATA['secondeSchedulerVip'])
                    disaster_info['seconde_scheduler'] = seconde_scheduler
                    operationlog_name = '修改主站点异地灾备拓扑配置，修改后本站点业务高可用IP为“{0}”，备站点业务高可用IP为“{1}”，' \
                                        '主用节点为“{2}”， 备用节点为“{3}”'.format(current_vip, seconde_scheduler, master,
                                                                        current_slave)
                    if reconnect_site:
                        operationlog_name = '重新连接异地灾备主备站点'
                else:
                    operationlog_name = '修改备站点异地灾备拓扑配置，修改后本站点业务高可用IP为“{0}”，' \
                                        '主用节点为“{1}”， 备用节点为“{2}”'.format(current_vip, master, current_slave)
                    # 修改备站点，需要提示用户先断开主站点连接
                    if backup_exist:
                        backup_pool = onebackup.metadata.BackupPool()
                        status = backup_pool.status.to_json()
                        if 'connected' == status['connect_status']:
                            self.addOperationlog(fsid, request, operationlog_name, u'主站点的连接未断开')
                            return Response({'success': False, 'error': u'修改失败，请先断开主站点的连接'})
            else:
                operationlog_name = '修改业务高可用IP“{0}”相关配置，修改后业务高可用IP为“{1}”，' \
                                    '主用节点为“{2}”， 备用节点为“{3}”'.format(old_vip, current_vip, master, current_slave)
                # 如果修改的不是异地灾备的高可用配置，需要检查当前修改的IP是否为灾备Proxy使用的VIP
                if backup_exist:
                    backup_pool = onebackup.metadata.BackupPool()
                    primary_info = backup_pool.primary.to_json()
                    agent_vip = primary_info['agent_proxy']
                    if agent_vip == old_vip:
                        self.addOperationlog(fsid, request, operationlog_name, u'该高可用IP正在被异地灾备使用')
                        return Response({'success': False, 'error': u'修改失败，该高可用IP正在被异地灾备使用'})

            if disaster_switch == '0' and ha_switch == '1':
                new_balance_switch = request.DATA['new_balance_switch']

            all_nodes = set(old_slave.split(',') + current_slave.split(',') + [master])
            # 用于负载均衡回滚
            old_all_nodes = old_slave.split(',') + [master]
            new_all_nodes = current_slave.split(',') + [master]

            cluster_config = self.get_clusterconfig()
            if disaster_switch == '0':
                public_network = cluster_config['public_network']
                if ha_switch == '1':
                    # tgt高可用的Vip只能在块服务网段内
                    block_service_segment = get_block_service_segment()
                    blockipjudge = self.subnet_judge(block_service_segment, current_vip)
                    if not blockipjudge:
                        self.addOperationlog(fsid, request, operationlog_name, u'tgt高可用IP不在块服务网段内')
                        return Response({'success': False, 'error': u'tgt高可用IP不在块服务网段内'})
                else:
                    publicIpJudge = self.subnet_judge(public_network, current_vip)
                    if not publicIpJudge:
                        self.addOperationlog(fsid, request, operationlog_name, u'高可用IP不在存储前端网段内')
                        return Response({'success': False, 'error': u'高可用IP不在存储前端网段内'})
            if disaster_switch == '1':
                disaster_network = cluster_config['disaster_network']
                disasterIpJudge = self.subnet_judge(disaster_network, current_vip)
                if not disasterIpJudge:
                    self.addOperationlog(fsid, request, operationlog_name, u'高可用IP不在灾备网段内')
                    return Response({'success': False, 'error': u'高可用IP不在灾备网段内'})
        except KeyError:
            self.addOperationlog(fsid, request, u'修改高可用IP', u'输入参数错误')
            return Response({'success': False, 'error': u'输入参数错误'})

        # BEGIN ADD BY Z11524 2016/08/22 FOR PN:201607270491
        if old_vip != current_vip and 1 != len(self.test_ping(current_vip.split(','))):
            self.addOperationlog(fsid, request, operationlog_name, u'IP地址“%s”已经被使用' % current_vip)
            return Response({'success': False, 'error': u'IP地址“%s”已经被使用' % current_vip})
        # END ADD BY Z11524 2016/08/22 FOR PN:201607270491

        try:
            failed_nodes = self.test_ping(all_nodes)
            if len(failed_nodes) != 0:
                reasons = ''
                for node in failed_nodes:
                    if reasons == '':
                        reasons = node
                    else:
                        reasons += ', ' + node

                self.addOperationlog(fsid, request, operationlog_name, u'节点“%s”存在网络故障' % reasons)
                return Response({'success': False, 'error': '有节点存在网络故障'})

            del_slave = []
            add_slave = []
            keeped_slave = []
            # 获取新加入的节点
            tmp = current_slave.split(',')
            for node in old_slave.split(','):
                try:
                    tmp.remove(node)
                except ValueError:
                    pass

            add_slave = tmp

            # 获取删除的节点
            tmp = old_slave.split(',')
            for node in current_slave.split(','):
                try:
                    tmp.remove(node)
                except ValueError:
                    pass

            del_slave = tmp

            # 获取当前已用的优先级
            for node in del_slave:
                try:
                    del priority_list[node]
                except ValueError:
                    pass

            # 获取未变更的节点
            tmp = old_slave.split(',')
            for node in del_slave:
                try:
                    tmp.remove(node)
                except ValueError:
                    pass

            keeped_slave = tmp

            # 检测高可用IP是否正在使用
            test_vip = {}
            if balance_switch == "1":
                if old_vip == current_vip:
                    test_vip = self.test_vip_connect(old_vip, del_slave, ha_port)
                else:
                    test_vip = self.test_vip_connect(old_vip, all_nodes, ha_port)
            elif old_vip != current_vip:
                nodelist = []
                if "1" == ha_switch:
                    nodelist = self._get_mon_stor()
                else:
                    gateway = self.exec_local_cmd_json('ceph config-key get gateway')['gateway']
                    for gw in gateway:
                        index = gw['hostip'].find(":")
                        if "-1" != index:
                            gw['hostip'] = gw['hostip'][:index]
                        nodelist.append(gw['hostip'])
                test_vip = self.test_vip_connect(old_vip, nodelist, ha_port)

            if test_vip.has_key('failed_nodes'):
                if len(test_vip['failed_nodes']) == 0:
                    if len(test_vip['connect_node']) != 0:
                        self.addOperationlog(fsid, request, operationlog_name, u'该高可用IP正在使用中')
                        return Response({'success': False, 'error': u'该高可用IP正在使用中'})
                else:
                    for node in test_vip['failed_nodes']:
                        if reasons == '':
                            reasons = node
                        else:
                            reasons += ', ' + node

                    self.addOperationlog(fsid, request, operationlog_name, u'节点“%s”存在网络故障' % reasons)
                    return Response({'success': False, 'error': u'修改高可用IP“%s”相关配置失败，有节点存在网络故障'})

            # 修改主备站点高可用配置
            if disaster_switch == '1':
                if disaster_type:
                    data = {
                        'scheduler_address': current_vip,
                        'secondary_scheduler': seconde_scheduler,
                    }
                    scheduler_request = scheduler.schedulerops.make_request(
                        scheduler.schedulerops.OP_MODIFY_PRIMARY_STATIONS)
                else:
                    data = {
                        'scheduler_address': current_vip,
                        'fsid': fsid,
                    }
                    scheduler_request = scheduler.schedulerops.make_request(
                        scheduler.schedulerops.OP_MODIFY_SECONDARY_STATIONS)

                scheduler_request.data = data
                # 主站点修改与主备连接使用handy到onebackup的同步消息处理，超时时间3小时。
                result_msg = connect.send_to_scheduler(scheduler_request, old_vip, 10800)

                if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
                    self.addOperationlog(fsid, request, operationlog_name, result_msg.result[2])
                    return Response({'success': False, 'error': result_msg.result[2]})
            # 获取已使用的权限值
            used_priority = []
            for node in priority_list:
                used_priority.append(priority_list[node])

            # 删除备用节点
            failed_reasons = {}
            failed_nodes = []
            threads = []
            nloops = range(len(del_slave))
            lock = threading.Lock()
            _service = 'tgt' if '0' == disaster_switch else 'onebackup'
            remove_command = 'timeout 300 /opt/h3c/bin/python %s/close_tgt_ha.py %s %s %s' % (
            HANDY_SHELL_PATH, old_vip, vrid, _service)

            def remove(node):
                result = self.exec_remote_ssh_cmd(node, remove_command)
                try:
                    if result['status'] == 'error':
                        with lock:
                            failed_reasons[node] = 'Host is unreachable'
                            failed_nodes.append(node)
                except IOError:
                    pass
                except:
                    if result.strip() != 'success' and result.find('the specify ip address do not exist') == -1:
                        with lock:
                            failed_reasons[node] = result
                            failed_nodes.append(node)

            for node in del_slave:
                t = threading.Thread(target=remove, args=(node,))
                threads.append(t)

            for i in nloops:
                threads[i].start()

            for i in nloops:
                threads[i].join()

            # 修改原节点vip
            if old_vip != current_vip:
                if (ha_switch != '1') or (disaster_switch != '0'):
                    if balance_switch == '1':
                        switch_arp = 0
                        command = 'timeout 300 /opt/h3c/bin/python %s/config_realserver.py del' % HANDY_SHELL_PATH
                        result = self.command_all_nodes(ha_switch, command, old_vip, vrid, switch_arp)
                        command = 'timeout 300 /opt/h3c/bin/python %s/config_realserver.py add' % HANDY_SHELL_PATH
                        result = self.command_all_nodes(ha_switch, command, current_vip, vrid, switch_arp)

                # 配置主用节点
                _service = 'tgt' if '0' == disaster_switch else 'onebackup'
                modify_command = 'timeout 300 /opt/h3c/bin/python %s/modify_tgt_ha.py %s %s %s' \
                                 % (HANDY_SHELL_PATH, old_vip, current_vip, _service)
                result = self.exec_remote_ssh_cmd(master, modify_command)
                try:
                    if result['status'] == 'error':
                        failed_reasons[master] = 'Host is unreachable'
                        failed_nodes.append(master)
                except IOError:
                    pass
                except:
                    if result.strip() != 'success':
                        failed_reasons[master] = result
                        failed_nodes.append(master)

                # 配置保留的备用节点
                threads = []
                nloops = range(len(keeped_slave))
                lock = threading.Lock()
                modify_command = 'timeout 300 /opt/h3c/bin/python %s/modify_tgt_ha.py %s %s %s' \
                                 % (HANDY_SHELL_PATH, old_vip, current_vip, _service)

                def modify(node):
                    result = self.exec_remote_ssh_cmd(node, modify_command)
                    try:
                        if result['status'] == 'error':
                            with lock:
                                failed_reasons[node] = 'Host is unreachable'
                                failed_nodes.append(node)
                    except IOError:
                        pass
                    except:
                        if result.strip() != 'success':
                            with lock:
                                failed_reasons[node] = result
                                failed_nodes.append(node)

                for node in keeped_slave:
                    t = threading.Thread(target=modify, args=(node,))
                    threads.append(t)

                for i in nloops:
                    threads[i].start()

                for i in nloops:
                    threads[i].join()
            # 修改TGT负载均衡
            if ha_switch == '1' and disaster_switch == '0':
                # 未修改tgt负载均衡设置，只修改了高可用组节点
                if balance_switch == new_balance_switch:
                    if balance_switch == '1':
                        # 删除原来节点的负载均衡配置
                        result_tmp = self.\
                            tgt_lb_config(vrid, current_vip, old_all_nodes, 'del', old_all_nodes)
                        if not result_tmp[0]:
                            msg = "MODIFY Load Balance Group {} failed at {}".format(vrid, result_tmp[1])
                            log.error(msg)
                            return Response({'success': False, 'error': msg})
                        log.info("MODIFY Load Balance Group {} successfully!".format(vrid))
                        # 新增现在节点的负载均衡配置
                        result_tmp = self.\
                            tgt_lb_config(vrid, current_vip, new_all_nodes, 'add', new_all_nodes)
                        if not result_tmp[0]:
                            msg = "MODIFY Load Balance Group {} failed at {}".format(vrid, result_tmp[1])
                            log.error(msg)
                            return Response({'success': False, 'error': msg})
                        log.info("MODIFY Load Balance Group {} successfully!".format(vrid))
                # 修改了负载均衡设置
                else:
                    # 负载均衡状态从开启到关闭
                    if new_balance_switch == '2':
                        result_tmp = self.\
                            tgt_lb_config(vrid, current_vip, old_all_nodes, 'del', old_all_nodes)
                        if not result_tmp[0]:
                            msg = "MODIFY Load Balance Group {} failed at {}".format(vrid, result_tmp[1])
                            log.error(msg)
                            return Response({'success': False, 'error': msg})
                        log.info("MODIFY Load Balance Group {} successfully!".format(vrid))
                    # 负载均衡状态从关闭到开启
                    elif new_balance_switch == '1':
                        result_tmp = self.\
                            tgt_lb_config(vrid, current_vip, new_all_nodes, 'add', new_all_nodes)
                        if not result_tmp[0]:
                            msg = "MODIFY Load Balance Group {} failed at {}".format(vrid, result_tmp[1])
                            log.error(msg)
                            return Response({'success': False, 'error': msg})
                        log.info("MODIFY Load Balance Group {} successfully!".format(vrid))

            # 配置新加入的备用节点
            priority = 240
            threads = []
            nloops = range(len(add_slave))
            lock = threading.Lock()

            def create(node, priority):
                _service = 'tgt' if '0' == disaster_switch else 'onebackup'
                create_command = 'timeout 300 /opt/h3c/bin/python %s/open_tgt_ha.py %s %s %s %s %s %s' \
                                 % (HANDY_SHELL_PATH, current_vip, priority, vrid, ha_switch, balance_switch, _service)
                result = self.exec_remote_ssh_cmd(node, create_command)
                try:
                    if result['status'] == 'error':
                        with lock:
                            failed_reasons[node] = 'Host is unreachable'
                            failed_nodes.append(node)
                except IOError:
                    pass
                except:
                    if result.strip() != 'success':
                        with lock:
                            failed_reasons[node] = result
                            failed_nodes.append(node)

            for node in add_slave:
                priority -= 1
                while priority in used_priority:
                    priority -= 1

                priority_list[node] = priority
                t = threading.Thread(target=create, args=(node, priority))
                threads.append(t)

            for i in nloops:
                threads[i].start()

            for i in nloops:
                threads[i].join()

            # 写入数据库
            if len(failed_nodes) == 0:

                # 修改用于灾备的tgt高可用ip
                if disaster_switch == '0' and backup_exist:
                    onebackup_pool = onebackup.metadata.BackupPool()
                    agent_vip = onebackup_pool.primary.to_json()
                    agent_proxy = agent_vip['agent_proxy']
                    if agent_proxy == old_vip:
                        data = {'proxy': current_vip,}

                        scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_MODIFY_PROXY)
                        scheduler_request.data = data
                        result_msg = connect.send_to_scheduler(scheduler_request)

                        if scheduler_request.req_id == result_msg.req_id:
                            if not result_msg.is_successful():
                                self.ha_rollback(ha_switch, balance_switch, "fault", old_vip, vrid, "del")
                                self.addOperationlog(fsid, request, operationlog_name, result_msg.result[2])
                                return Response({'success': False, 'error': result_msg.result[2]})
                # ADD BY S11435 PN:201607290155 修改完高可用防止保存数据库时挂住
                time.sleep(10)
                if disaster_switch == '0' and ha_switch == '1':
                    balance_switch = new_balance_switch
                params = [current_vip, current_slave, priority_list, disaster_info, balance_switch]
                results = self.onestor_request(fsid, 'database.update_obj', ['highavailableconfig', current_id, params])

                # BEGIN ADD BY S11435 PN:201607290155 如果修改失败，则重试一次
                if results is None or 'error' == results['status']:
                    log.warn('modify highavailableconfig failed, try again...')
                    results = self.onestor_request(
                            fsid, 'database.update_obj', ['highavailableconfig', current_id, params])
                # END ADD BY S11435 PN:201607290155

                if results['status'] != 'error':
                    # BEGIN ADD BY S11435 2016/08/24 PN: 201607290193
                    self._process_get_working_node(current_vip)
                    self.ha_rollback(ha_switch, balance_switch, "success", old_vip, vrid, "del")
                    self.addOperationlog(fsid, request, operationlog_name, 'success')
                    return Response({'success': True})
                else:
                    self.addOperationlog(fsid, request, operationlog_name, results['reason'])

            else:
                reasons = ''
                for node in failed_nodes:
                    if reasons == '':
                        reasons = '“' + node + '”: ' + failed_reasons[node]
                    else:
                        reasons += ', ' + '“' + node + '”: ' + failed_reasons[node]
                self.addOperationlog(fsid, request, operationlog_name, reasons)
                return Response({'success': False, 'error': u'修改高可用IP“%s”相关配置失败' % old_vip})

        except ValueError:
            self.addOperationlog(fsid, request, operationlog_name, u'操作失败，详见后台日志')
            return Response({'success': False, 'error': u'操作失败，详见后台日志'})
        except Exception, e:
            log.exception(e)
            self.addOperationlog(fsid, request, operationlog_name, u'操作失败，详见后台日志')
            return Response({'success': False, 'error': u'操作失败，详见后台日志'})

    def apply(self, request, fqdn):
        try:
            command = request.DATA['command']
        except KeyError:
            raise ParseError("'command' field is required")
        else:
            if not (isinstance(command, basestring)):
                raise ParseError("'command' must be a string")

        try:
            cwd = request.DATA['directory']
        except:
            cwd = '/root/'

        cwd = ''.join(['cwd=', cwd])

        fsid = self.client.list_clusters()[0]['id']

        all_servers = self.client.server_list()
        for server in all_servers:
            if fqdn == server['fqdn']:
                results = self.onestor_request_node(
                        fqdn, 'cmd.run', [cwd, command])
                if None != results:
                    return Response({fqdn: results})

                return Response([])

        results = self.onestor_request(fsid, 'cmd.run', [cwd, command])

        if None != results:
            return Response({fqdn: results})

        return Response([])

    def createRbdCommon(self, onestor_params, db_params, fsid):
        results = self.onestor_request(
                fsid, 'onestor.createRbd', onestor_params)

        if results['status'] == 'success':
            return self.addRbd2DB(fsid, db_params)
        else:
            return results

    @check_cluster_dispace(const.OP_CREATE_RBD)
    def createRbd(self, request, fsid):
        try:
            rbd_name = request.DATA['rbd_name']
            pool_name = request.DATA['pool_name']
            rbd_mode = request.DATA['rbd_mode']
            rbd_type_convert = request.DATA['is_thin']
            diskpool_name = request.DATA.get('diskpool_name', '')
            rbd_size = int(request.DATA['rbd_size'])
            rbd_description = request.DATA.get('rbd_description', '')
        except KeyError:
            return Response({'status': 'error', 'reason': u'输入参数错误', 'errorcode': 'PARAMETER_ERROR'})

        snap_nums = '0'
        is_clone = ''
        baseon_snap_name = ''
        lun_id = '-1'

        clonable = True if '2' == str(rbd_mode) else False
        matadata = '.' + diskpool_name + '.rbd'
        onestor_params = [self.CEPH_CONF_FILE,
                          pool_name, rbd_name, rbd_size, 22, clonable, matadata]
        db_params = [rbd_name, rbd_size, pool_name, rbd_type_convert,
                     snap_nums, is_clone, baseon_snap_name, lun_id, rbd_description, matadata, '']

        result = self.createRbdCommon(onestor_params, db_params, fsid)

        if result['status'] == 'success':
            self.addOperationlog(fsid, request, u'创建块“%s”' %
                                 rbd_name, 'success')

        else:
            self.addOperationlog(fsid, request, u'创建块“%s”' %
                                 rbd_name, result['reason'])
        return Response(result)

    def addRbd2DB(self, fsid, params):

        results = self.onestor_request(
                fsid, 'database.add_obj', ['rbdlist', params])

        if results:
            return results

        return {'status': 'error', 'reason': 'Add RBD to db failed'}

    def resize(self, request, fsid):

        rbd_name = request.DATA['rbd_name']
        new_size = request.DATA['new_size']
        pool_name = request.DATA['pool_name']

        results = self.onestor_request(fsid, 'onestor.resize', [
            self.CEPH_CONF_FILE, pool_name, rbd_name, new_size])

        if None != results:
            return Response(results)

        return Response([])

    def _is_lun_mounted(self, fsid, lun_id):
        if -1 == int(lun_id):
            return 'IDLE'

        # 通过LUN ID获取LUN的详情
        lun_info = self.onestor_request(
                fsid, 'database.find_by_id', ['iscsilun', lun_id])

        if 'NotFound' == lun_info or None == lun_info:
            return 'ERROR_LUN_NOT_EXIST'

        # 先判断LUN所在的target是否被挂载
        result = self.onestor_request_all_node(
                'is_target_used', lun_info['target_id'])

        all_idle = True
        for used in result['error']:
            if used == 'True':
                all_idle = False

        if not all_idle:
            return 'ERROR_TARGET_MOUNTED'

        return 'IDLE'

    def getLunStatus(self, request, fsid):
        try:
            lun_id = request.GET.get('lun_id')
            lun_status = self._is_lun_mounted(fsid, lun_id)

            return Response({'success': True, 'status': lun_status})
        except Exception, e:
            return Response({'success': False, 'reason': str(e)})

    @check_cluster_dispace(const.OP_CREATE_SNAPSHOT)
    @module_required(const.BS_SNAPSHOT)
    def snapshotRbd(self, request, fsid):
        try:
            rbd_name = request.DATA['rbd_name']
            pool_name = request.DATA['pool_name']
            snapshot_name = request.DATA['snapshot_name']
            size = request.DATA['rbd_size']
            status = request.DATA['status']
            snap_type = request.DATA['snap_type']
        except KeyError:
            return Response({'status': 'error', 'reason': u'输入参数错误', 'errorcode': 'PARAMETER_ERROR'})
        # PN: 【BBIT】 集群中创建rbd快照或存储卷快照，可以创建的最大快照的数量超过了256。
        snaps_info = self.onestor_request(fsid, 'onestor.list_snaps', [self.CEPH_CONF_FILE, pool_name, rbd_name])
        if None != snaps_info and list == type(snaps_info):
            if len(snaps_info) >= 256:
                log.error('rbd {0} snapshot numbers over 256'.format(rbd_name))
                self.addOperationlog(
                        fsid, request, u'创建快照“%s”' % snapshot_name, u'单个块设备最多允许创建256个快照')
                return Response({'status': 'error', 'reason': u'单个块设备最多允许创建256个快照'})
        else:
            # 不直接返回记录错误即可
            log.error('get rbd {0} snapshot info error, reason is {1}'.format(rbd_name, snaps_info))
        # end by l11544 2017/4/25

        create_time = self._get_current_time_cst('ms')

        if self.isRBDInDisasterBackup(rbd_name, pool_name, fsid):
            self.addOperationlog(fsid, request, u'创建快照“%s”' %
                                 snapshot_name, u'异地灾备的块设备不支持创建快照')
            return Response({'status': 'error', 'reason': u'异地灾备的块设备不支持创建快照'})

        params = [snapshot_name, size, status,
                  snap_type, rbd_name, pool_name, create_time]
        results = self.onestor_request(fsid, 'onestor.snapshotRbd', [
            self.CEPH_CONF_FILE, pool_name, rbd_name, snapshot_name])

        if results['status'] == 'success':
            ret = self.addSnapshot2DB(fsid, params)
            if ret['status'] == 'success':
                self.addOperationlog(fsid, request, u'创建快照 “%s”' %
                                     snapshot_name, 'success')
            return Response(ret)
        else:
            self.addOperationlog(fsid, request, u'创建快照 “%s”' %
                                 snapshot_name, results['reason'])
            return Response(results)

        return Response([])

    def addSnapshot2DB(self, fsid, params):
        results = self.onestor_request(
                fsid, 'database.add_obj', ['snapshot', params])
        if results:
            return results
        else:
            log.error("Failed to save snapshot")

        return []

    def removeRbdFromDB(self, fsid, current_id):

        results = self.onestor_request(
                fsid, 'database.del_obj', ['rbdlist', current_id])

        if results:
            return results
        else:
            log.error("Failed to remove snapshot from database.")
        return None

    def removeRbd(self, request, fsid):

        rbd_name = request.GET.get('rbd_name')
        pool_name = request.GET.get('pool_name')
        current_id = request.GET.get('rbd_id')

        results = self.onestor_request(fsid, 'onestor.removeRbd', [
            self.CEPH_CONF_FILE, pool_name, rbd_name])

        if results:
            if 'null' != current_id and results['status'] == 'success':
                ret = self.removeRbdFromDB(fsid, current_id)
                return Response(ret)
            else:
                return Response(results)
        else:
            log.info("Failed to remove rbd")

        return Response([])

    @check_cluster_dispace(const.OP_CLONE_RBD)
    @module_required(const.BS_CLONE)
    def cloneRbd(self, request, fsid):
        try:
            rbd_name = request.DATA['rbd_name']
            pool_src = request.DATA['pool_name']
            snap_name = request.DATA['snapshot_name']
            clone_name = request.DATA['clone_name']
            pool_dest = request.DATA['clone_dest']
            diskpool_name = request.DATA.get('diskpool_name', '')
            rbd_size = int(request.DATA['snapshot_size'])
            rbd_type_convert = request.DATA['rbd_type']
        except KeyError:
            return Response({'status': 'error', 'reason': u'输入参数错误', 'errorcode': 'PARAMETER_ERROR'})

        matadata = '.' + diskpool_name + '.rbd'
        snap_nums = '0'
        is_clone = 'True'
        baseon_snap_name = snap_name
        lun_id = -1
        params = [clone_name, rbd_size, pool_dest, rbd_type_convert,
                  snap_nums, is_clone, baseon_snap_name, lun_id, '{0}/{1}的克隆块'.format(pool_src, rbd_name), matadata]
        results = self.onestor_request(fsid, 'onestor.clone_rbd', [
            self.CEPH_CONF_FILE, pool_src, rbd_name, pool_dest, snap_name, clone_name, matadata])

        if results['status'] == 'success':
            ret = self.addRbd2DB(fsid, params)
            if ret['status'] == 'success':
                self.addOperationlog(
                        fsid, request, u'克隆块 “%s”' % clone_name, 'success')
            return Response(ret)

        if 'exist' == results['status'] or -1 != results['reason'].find('rbd image %s already exists' % clone_name):
            self.addOperationlog(fsid, request, u'克隆块 “%s”' %
                                 clone_name, u'克隆块“%s”已经存在' % clone_name)
            return Response({'status': 'error', 'reason': u'克隆块“%s”已经存在' % clone_name, 'errorcode': 'CLONE_RBD_EXIST'})
        else:
            self.addOperationlog(fsid, request, u'克隆块 “%s”' %
                                 clone_name, results)

        return Response(results)

    @check_cluster_dispace(const.OP_BACK_SNAP)
    @module_required(const.BS_SNAPSHOT)
    def roolbackSnap(self, request, fsid):
        try:
            rbd_name = request.DATA['rbd_name']
            pool_name = request.DATA['pool_name']
            snapshot_name = request.DATA['snapshot_name']
            lun_id = request.DATA['lun_id']
        except KeyError:
            return Response({'status': 'error', 'reason': u'输入参数错误', 'errorcode': 'PARAMETER_ERROR'})
        if self.isRBDInDisasterBackup(rbd_name, pool_name, fsid):
            self.addOperationlog(fsid, request, u'恢复快照“%s”' %
                                 snapshot_name, u'异地灾备的块设备不支持恢复快照')
            return Response({'status': 'error', 'reason': u'异地灾备的块设备不支持恢复快照'})

        # 如果是存储卷的访问方式，需要先判断是否被挂载
        if int(lun_id) > 0:
            # 通过LUN ID获取LUN的详情
            lun_info = self.onestor_request(
                    fsid, 'database.find_by_id', ['iscsilun', lun_id])

            if 'NotFound' == lun_info or None == lun_info:
                self.addOperationlog(fsid, request, u'恢复快照“%s”' %
                                     snapshot_name, u'快照所在存储卷不存在')
                return Response({'status': 'error', 'reason': u'恢复快照失败，快照所在存储卷“%s”不存在' \
                                                              % rbd_name, 'errorcode': 'RBD_NOT_FOUND'})

            # 先判断LUN所在的target是否被挂载
            result = self.onestor_request_all_node(
                    'is_target_used', lun_info['target_id'])

            all_idle = True
            for used in result['error']:
                if used == 'True':
                    all_idle = False

            if not all_idle:
                self.addOperationlog(fsid, request, u'恢复快照“%s”' %
                                     snapshot_name, u'快照所在存储卷的Target已经被挂载')
                return Response({'status': 'error', 'reason': u'恢复快照失败，存储卷 “%s” 所在的Target已经被挂载' \
                                                              % rbd_name, 'errorcode': 'TARGET_IS_USED'})

        results = self.onestor_request(fsid, 'onestor.roolbackSnap', [
            self.CEPH_CONF_FILE, pool_name, rbd_name, snapshot_name])

        if None != results:
            if 'success' != results['status']:
                self.addOperationlog(fsid, request, u'恢复快照 “%s”' %
                             snapshot_name, results['reason'])
                return Response(results)
            # BEGIN ADD BY D10039 2016/03/07 PN:201603040460 恢复快照时还原RBD的大小
            rbd_info = self.exec_local_cmd_json('rbd info --image %s -p %s --format json' % (rbd_name, pool_name))
            if None != rbd_info:
                # 通过命令行获取真实的RBD大小
                rbd_size = rbd_info['size']

                # 更新数据库中RBD的大小
                rbds_in_pool = database.find('rbdlist', [{'pool_name': pool_name}])
                for _rbd in rbds_in_pool:
                    if _rbd['rbd_name'] == rbd_name:
                        database.update_obj('rbdlist', _rbd['id'], [
                            _rbd['rbd_name'],
                            rbd_size,
                            _rbd['pool_name'],
                            _rbd['rbd_type_convert'],
                            _rbd['snap_nums'],
                            _rbd['is_clone'],
                            _rbd['baseon_snap_name'],
                            _rbd['lun_id'],
                            _rbd['rbd_description'] if 'rbd_description' in _rbd else '',
                            _rbd['usage_mode'] if 'usage_mode' in _rbd else ''
                        ])
                        break

            # 如果是iSCSI的访问方式，还需要更新各个节点上的存储卷的信息
            if int(lun_id) > 0:
                lun_info = self.onestor_request(fsid, 'database.find_by_id', ['iscsilun', int(lun_id)])

                if 'NotFound' != lun_info and None != lun_info:
                    # 更新存储卷的大小
                    update_lun_size = self.onestor_request_all_node('update_target', lun_info['target_name'])
                    log.info('[ONEStor] [rollback update lun] target is: %s,result is: %s',
                             lun_info['target_name'], update_lun_size)

            # END ADD BY D10039 2016/03/07 PN:201603040460
            self.addOperationlog(fsid, request, u'恢复快照 “%s”' %
                                 snapshot_name, 'success')
            return Response(results)

        self.addOperationlog(fsid, request, u'恢复快照 “%s”' %
                             snapshot_name, results['reason'])
        return Response([])

    @check_cluster_dispace(const.OP_REMOVE_SNAP)
    @module_required(const.BS_SNAPSHOT)
    def removeSnap(self, request, fsid):

        rbd_name = request.GET.get('rbd_name')
        pool_name = request.GET.get('pool_name')
        snapshot_name = request.GET.get('snapshot_name')
        current_id = request.GET.get('snapshot_id')

        if self.isRBDInDisasterBackup(rbd_name, pool_name, fsid):
            self.addOperationlog(fsid, request, u'删除快照“%s”' %
                                 snapshot_name, u'快照所属的块设备正在被异地灾备使用')
            return Response({'status': 'error', 'reason': u'快照所属的块设备正在被异地灾备使用'})

        list_lun_result = self.onestor_request(
                fsid, 'database.list_objs', ['iscsilun'])
        is_lun = False
        for lun in list_lun_result['iscsilun']:
            if '@' in lun['lun_name']:
                lun_rbd, lun_snap = lun['lun_name'].split('@')
                if lun_rbd == rbd_name and lun_snap == snapshot_name:
                    is_lun = True
                    target_id = lun['target_id']
                    lun_id = lun['lun_id']
                    lun_index_id = lun['id']
                    target_name = lun['target_name']
                    break
        if is_lun:
            # 先判断LUN所在的target是否被挂载
            results = self.onestor_request_all_node(
                    'is_target_used', target_id)
            all_idle = True
            for used in results['error']:
                if used == 'True':
                    all_idle = False
            if not all_idle:
                self.addOperationlog(
                        fsid, request, u'删除存储卷“%s”' % rbd_name, u'存储卷所在的Target已经被挂载')
                return Response({'status': 'error', 'reason': u'删除失败，存储卷“%s”所在的Target已经被挂载' \
                                                              % rbd_name, 'errorcode': 'TARGET_IS_USED'})

        results = self.onestor_request(fsid, 'onestor.removeSnap', [
            self.CEPH_CONF_FILE, pool_name, rbd_name, snapshot_name])

        if results['status'] == 'success':
            if is_lun:
                remove_lun_results = self.onestor_request_all_node('remove_lun', target_id,
                                                                   lun_id, pool_name, rbd_name + '@' + snapshot_name,
                                                                   target_name)
                log.debug('[ONEStor remove_lun]', remove_lun_results)
                self.removeLunFromDB(fsid, lun_index_id)
                self.updateLunID2Tgt(fsid, lun_info['target_id'], lun_info['target_name'], 0, 'delete')
            if 'null' != current_id:
                ret = self.removeSnapFromDB(fsid, current_id)
                if ret['status'] == 'success':
                    self.addOperationlog(
                            fsid, request, u'删除快照 “%s”' % snapshot_name, 'success')
                    return Response(ret)
            else:
                return Response(results)
        else:
            self.addOperationlog(fsid, request, u'删除快照 “%s”' %
                                 snapshot_name, results['reason'])
            return Response(results)
        return Response([])

    def removeSnapFromDB(self, fsid, current_id):
        results = self.onestor_request(fsid, 'database.del_obj', [
            'snapshot', current_id])
        if None != results:
            return results
        else:
            log.error("Failed to remove snapshot from database.")
        return None

    @check_cluster_dispace(fun_op=const.LIST_SNAPS, need_operation=False)
    def snapslist(self, request, fsid):
        pool_name = request.GET.get('pool_name')
        rbd_name = request.GET.get('rbd_name')

        results = self.onestor_request(fsid, 'onestor.list_snaps', [
            self.CEPH_CONF_FILE, pool_name, rbd_name])

        if None != results:
            return Response(results)

        return Response([])

    @check_cluster_dispace(fun_op=const.LIST_SNAPS, need_operation=False)
    def getlistsnaps(self, request, fsid):
        pool_name = request.GET.get('pool_name')
        rbd_name = request.GET.get('rbd_name')
        params = [pool_name, rbd_name]

        ret = self.getSnapTimeFromDB(fsid, params)
        results = self.onestor_request(fsid, 'onestor.list_snaps', [
            self.CEPH_CONF_FILE, pool_name, rbd_name])

        if None != results:
            for real in results:
                if ret is None:
                    return Response(results)

                if ret.has_key(real['name']):
                    real['time_diff'] = ret[real['name']]['time_diff']
                    real['create_time'] = ret[real['name']]['create_time']
                    real['database_id'] = ret[real['name']]['id']

            return Response(results)

        return Response([])

    def getSnapTimeFromDB(self, fsid, params):
        time_base = self._get_current_time_cst('ms')

        results = self.onestor_request(
                fsid, 'database.get_obj_byname', ['snapshot', params])

        if None != results:
            diff_snap = {}
            for timep in results:
                print timep
                if 'create_time' in timep.keys():
                    cre = int(timep['create_time'])

                    time_diff = int(time_base) - int(cre)
                    timep['time_diff'] = time_diff
                    diff_snap[timep['snap_name']] = timep
            return diff_snap

        return None

    def isRBDInDisasterBackup(self, rbd_name, pool_name, fsid):
        try:
            disaster_exist = self.disaster_pool_exist()
            if not disaster_exist:
                return False
            is_primary = ''
            disaster_config = self.onestor_request(fsid, 'database.list_objs', ['highavailableconfig'])
            configs = disaster_config['highavailableconfig']
            for config in configs:
                if 'disaster_info' in config and 'disaster_type' in config['disaster_info']:
                    is_primary = config['disaster_info']['disaster_type']
                    break
            backup_pool = onebackup.metadata.BackupPool()
            devicelist = backup_pool.blockdevices.to_json()
            site_info = 'primary_info' if is_primary else 'secondary_info'
            for device in devicelist:
                if device[site_info]['name'].split('/')[0] == pool_name \
                        and device[site_info]['name'].split('/')[1] == rbd_name:
                    return True
            return False
        except Exception, e:
            log.warning(e)
            return False

    # BEGIN ADD BY KF6602 2016/8/10 PN: 201607290499 比较块大小之前进行单位转换
    @staticmethod
    def _convert_rbd_unit(rbd_size):
        unit = 0
        while rbd_size > 1024:
            rbd_size /= 1024.0
            unit += 1
        return float('%.1f' % rbd_size), unit

    # END ADD BY KF6602 2016/8/10 PN: 201607290499 比较块大小之前进行单位转换

    @check_cluster_dispace(const.OP_MODIFY_LUN)
    @assert_tgtd_normal(const.OP_MODIFY_LUN)
    def patchRbd(self, request, fsid):
        try:
            rbd_name = request.DATA['rbd_name_old']
            rbd_name_new = request.DATA['rbd_name_new']
            pool_name = request.DATA['pool_name']
            matadata = request.DATA['matadata']
            old_size = int(request.DATA['old_size'])
            new_size = int(request.DATA['new_size'])
            rbd_type_convert = request.DATA['is_thin']
            lun_current_id = request.DATA['lun_current_id']
            rbd_description = request.DATA.get('rbd_description', '')
        except KeyError:
            return Response({'status': 'error', 'reason': u'输入参数错误', 'errorcode': 'PARAMETER_ERROR'})

        op_log_content = u'修改块 “%s”' % rbd_name if -1 == int(lun_current_id) else u'修改存储卷“%s”' % rbd_name

        if self.isRBDInDisasterBackup(rbd_name, pool_name, fsid):
            is_primary = onebackup.metadata.is_primary()
            if not is_primary:
                self.addOperationlog(fsid, request, op_log_content, u'异地灾备中备站点的块设备不支持修改')
                return Response({'status': 'error', 'reason': u'异地灾备中备站点的块设备不支持修改'})

        # 如果new_size小于old_size，则返回缩容失败
        # BEGIN MODIFY BY KF6602 2016/8/10 PN: 201607290499 比较块大小之前进行单位转换
        new_size_convert, new_size_unit = self._convert_rbd_unit(new_size)
        old_size_convert, old_size_unit = self._convert_rbd_unit(old_size)
        reduce_flag = False
        if new_size_unit < old_size_unit:
            reduce_flag = True
        elif new_size_unit == old_size_unit and new_size_convert < old_size_convert:
            reduce_flag = True
        if reduce_flag:
            self.addOperationlog(fsid, request, op_log_content, u'块设备不支持缩容')
            return Response({'status': 'error', 'reason': u'块设备不支持缩容', 'errorcode': 'RBD_UNSUPPORT_REDUCE'})
        # END MODIFY BY KF6602 2016/8/10 PN: 201607290499 比较块大小之前进行单位转换

        if -1 != lun_current_id:
            # 先测试网络是否都通
            ping_results = self.onestor_request_all_node('ping')
            for state in ping_results['error']:
                if 'Host is unreachable' == state:
                    self.addOperationlog(fsid, request, op_log_content, u'有节点存在网络故障')
                    return Response({'status': 'error', 'reason': u'修改存储卷失败，有节点存在网络故障', 'errorcode': 'NETWORK_FAULT'})

            # 检查LUN所在的target是否被挂载
            lun_status = self._is_lun_mounted(fsid, lun_current_id)
            if 'ERROR_TARGET_MOUNTED' == lun_status:
                self.addOperationlog(fsid, request, op_log_content, u'存储卷所在的Target已经被挂载')
                return Response({'status': 'error', 'reason': u'修改失败，存储卷 “%s” 所在的Target已经被挂载' \
                    % rbd_name, 'errorcode': 'TARGET_IS_USED'})

        current_id = request.DATA['rbd_id']
        snap_nums = '0'
        is_clone = ''
        baseon_snap_name = ''
        params = [rbd_name_new, new_size, pool_name, rbd_type_convert,
                  snap_nums, is_clone, baseon_snap_name, lun_current_id, rbd_description, matadata]

        results = self.onestor_request(fsid, 'onestor.patchRbd', [
                                       self.CEPH_CONF_FILE, pool_name, rbd_name, rbd_name_new, old_size, new_size, matadata])

        if -1 != lun_current_id:
            # 通过LUN ID获取LUN的详情
            lun_info = self.onestor_request(fsid, 'database.find_by_id', [
                                            'iscsilun', lun_current_id])

            if 'NotFound' != lun_info and None != lun_info:
                # 更新存储卷的大小
                update_lun_size = self.onestor_request_all_node(
                    'update_target', lun_info['target_name'])
                log.info('[ONEStor] [update lun] target is: %s,result is: %s',
                    lun_info['target_name'], update_lun_size)

                # ADD BY D10039 2016/04/23 PN:201604180233 同步更新数据库中的存储卷大小
                database.update_one('iscsilun', {'id': lun_current_id, '$set': {'rbd_size': new_size}})

        if results['status'] == 'success':
            if 'null' != current_id:
                ret = self.updateRbd2DB(fsid, current_id, params)
                self.addOperationlog(fsid, request, op_log_content, 'success')
                return Response(ret)
            else:
                return Response(results)
        else:
            self.addOperationlog(fsid, request, op_log_content, results['reason'])
            return Response(results)

        return Response([])

    def updateRbd2DB(self, fsid, current_id, params):

        results = self.onestor_request(fsid, 'database.update_obj', [
                                       'rbdlist', current_id, params])
        if results:
            return results
        else:
            log.error("Failed to update rbd to database.")
        return None

    # end by d11564

    def listTarget(self, request, fsid):
        results = self.onestor_request(
                fsid, 'database.list_objs', ['iscsitarget'])

        # 统计存储卷表中每个Target有多少个存储卷
        lun_count = {}
        for item in database.list_objs('iscsilun')['iscsilun']:
            lun_count[item['target_name']] = lun_count.get(item['target_name'], 0) + 1

        # 更新返回值里的存储卷个数
        for target in results['iscsitarget']:
            target['lun_num'] = lun_count.get(target['target_name'], 0)

        if None != results:
            return Response(results)

        return Response([])

    def addTgt2DB(self, fsid, params):
        results = self.onestor_request(
                fsid, 'database.add_obj', ['iscsitarget', params])

        if None != results:
            return results

        return None

    def getAvaliableTargetID(self, current_max_tid):
        # BEGIN ADD BY D10039 2016/04/24 PN:201604180602 先判断targetID是否存在
        try_counts = 0
        while try_counts < 100:
            current_max_tid += 1
            find_target_by_id = database.find('iscsitarget', [{'target_id': current_max_tid}])

            if 0 == len(find_target_by_id):
                return current_max_tid

            try_counts += 1

        return current_max_tid + 1
        # END ADD BY D10039 2016/04/24

    def createTargetCommon(self, name, iqn_switch, iqns, fsid, usage_mode=''):
        # PN: 201704130211【BBIT】 集群中创建target，可以创建的最大target的数量超过了256。
        target_info = self.exec_local_cmd_json("ceph config-key get iscsitarget")
        if None != target_info and len(target_info['iscsitarget']) >= 256:
            log.error('[createTargetCommon] Target number over 256')
            return {'status': 'error', 'reason': u'集群最多允许创建256个Target', 'errorcode': 'TARGET_OVER'}
        # end by l11544 2017/4/24
        # PN:201511270740 将获取target ID的代码移到后台来，直接到各个节点上获取当前最大的target ID
        current_target_id = self.onestor_request_all_node(
                'get_current_target_id')

        target_id_list = []
        for target_id in current_target_id['error']:
            if 'Host is unreachable' == target_id:
                # MODIFY BY D10039 2016/03/01 PN:201602290515
                return {'status': 'error', 'reason': u'有节点存在网络故障', 'errorcode': 'NETWORK_FAULT'}

            try:
                target_id_list.append(int(target_id))
            except ValueError:
                log.error('[ONEStor] createTargetCommon error, target_id returned is not integer')

        # BEGIN MODIFY BY D10039 2016/04/24 PN:201604180602 结合数据库获取可用的Target ID
        current_max_tid = max(target_id_list)
        tid = self.getAvaliableTargetID(current_max_tid)
        # END MODIFY BY D10039 2016/04/24

        results = self.onestor_request_all_node(
                'create_target', tid, name, iqn_switch, iqns)

        if not results['success']:
            # 只要有一个节点创建target失败，所有的节点都清理掉该target
            self.onestor_request_all_node('remove_target', tid, name)

            # 检查是否为target已经存在的错误
            err_msg = u'在节点 “%s” 上创建Target失败，详情参见日志' % results['nodes']

            for error in results['error']:
                if -1 != error.find('this target already exists'):
                    err_msg = u'在节点 “%s” 上创建Target失败，Target已经存在' % results[
                        'nodes']
                    break

            log.error('[ONEStor] Create target error: %s', results['error'])
            return {'status': 'error', 'reason': err_msg, 'errorcode': 'TARGET_EXIST'}

        result = self.addTgt2DB(fsid, [tid, name, iqn_switch, iqns, 1, 0, usage_mode])
        result['tid'] = tid

        database.update_one(
                'iscsitarget', {'target_name': name, '$set': {'id': tid}})
        return result

    @check_cluster_dispace(const.OP_CREATE_TARGET)
    @assert_tgtd_normal(const.OP_CREATE_TARGET)
    def createTarget(self, request, fsid):
        try:
            name = request.DATA['targetName']
        except KeyError:
            return Response({'status': 'error', 'reason': u'输入参数错误', 'errorcode': 'PARAMETER_ERROR'})

        try:
            # BEGIN ADD BY D10039 2016/04/24 PN:201604180602 阻止同时创建Target的情况发生
            now_time = time.time()
            has_adding = os.path.exists("/tmp/.adding_target")

            if has_adding:
                last_time = float(self.exec_local_cmd('cat /tmp/.adding_target'))

                if now_time - last_time < 5 * 60:
                    self.addOperationlog(
                            fsid, request, u'创建Target“%s”' % name, u'正在创建其它Target，请稍后再试')
                    return Response({'status': 'error', 'reason': u'正在创建其它Target，请稍后再试', \
                                     'errorcode': 'CREATE_TARGET_BUSY'})
                else:
                    has_adding = False

            self.exec_local_cmd('echo %s > /tmp/.adding_target' % now_time)
            # END ADD BY D10039 2016/04/24

            # BEGIN ADD BY D10039 2016/04/23 For UIS Target前缀默认加上iqn
            IQN_PREFIX = 'iqn.2016-01.com.h3c.onestor.'
            if not name.startswith(IQN_PREFIX):
                name = IQN_PREFIX + name
            # END ADD BY D10039 2016/04/23

            # BEGIN ADD BY D10039 2016/03/13 For UIS IQN参数可选
            iqn_switch = request.DATA['iqnSwitch'] \
                if request.DATA.has_key('iqnSwitch') else '0'
            iqns = request.DATA['iqns'] \
                if request.DATA.has_key('iqns') else 'none'
            # END ADD BY D10039 2016/03/13

            ret = self.createTargetCommon(name, iqn_switch, iqns, fsid)
            self.addOperationlog(fsid, request, u'创建Target“%s”' % name, ret)

            # BEGIN ADD BY d10039 2016/03/01 PN:201602290515
            if 'error' == ret['status'] and u'有节点存在网络故障' == ret['reason']:
                ret['reason'] = u'创建Target失败，有节点存在网络故障'
            # END ADD BY d10039 2016/03/01 PN:201602290515
            return Response(ret)
        except ValueError:
            return Response({'status': 'error', 'reason': 'ValueError', 'errorcode': 'VALUE_ERROR'})
        except Exception, e:
            return Response({'status': 'error', 'reason': str(e), 'errorcode': 'INTERNAL_SERVER_ERROR'})
        finally:
            if not has_adding:
                self.exec_local_cmd('rm -f /tmp/.adding_target')

    @check_cluster_dispace(const.OP_MODIFY_TARGET)
    @assert_tgtd_normal(const.OP_MODIFY_TARGET)
    def patchTarget(self, request, fsid):
        try:
            iqn_switch = request.DATA['iqnSwitch']
            target_id = request.DATA['targetID']
            target_name = request.DATA['targetName']
            iqns = request.DATA['iqns']
            lunID = request.DATA['lunID']
            lunNum = request.DATA['lunNum']
            select_disaster = request.DATA.get('selectDisaster', False)

            target_info = self.onestor_request(fsid, 'database.find_one', ['iscsitarget', [{'target_id': target_id}]])
            lun_num = len(database.find('iscsilun', [{'target_name': target_name}]))
            # 当前target若非仅有一个存储卷，且转为容灾使用，需要返回错误
            if select_disaster and 1 != lun_num:
                error_mess = u'当前Target有且仅有一个存储卷时，允许切换为灾备使用'
                self.addOperationlog(fsid, request, u'修改Target“%s”' % target_name, error_mess)
                return Response({'success': False, 'error': error_mess, 'errorcode': 'DISASTER_ERROR'})

            # 对于灾备块转为非灾备需要限制修改
            old_usage_mode = target_info[0]['usage_mode']
            if 'disaster' == old_usage_mode and not select_disaster:
                lun_info = self.onestor_request(
                        fsid, 'database.find_one', ['iscsilun', [{'target_name': target_name}]])[0]
                if self.isRBDInDisasterBackup(
                        lun_info['rbd_name'], lun_info['pool_name'], fsid):
                    self.addOperationlog(fsid, request, u'修改Target“%s”' % target_name, u'该Target下存在灾备的备份策略块')
                    return Response({
                        'status': 'error', 'error': u'该Target下存在灾备的备份策略块', 'errorcode': 'DISASTER_ERROR'})

            if iqn_switch != '-1':
                flag = '0'
                # target页面修改iqn认证
                db_id = request.DATA['id']
                old_iqns = request.DATA['oldIqns']

                added_iqns = 'none'
                del_iqns = 'none'
                if iqn_switch == '1':
                    if old_iqns != 'none':
                        # 获取增加的iqn
                        tmp = iqns.split(',')
                        for iqn in old_iqns.split(','):
                            try:
                                tmp.remove(iqn)
                            except ValueError:
                                pass

                        for iqn in tmp:
                            if added_iqns == 'none':
                                added_iqns = iqn
                            else:
                                added_iqns = added_iqns + ',' + iqn

                        # 获取删除的iqn
                        tmp = old_iqns.split(',')
                        for iqn in iqns.split(','):
                            try:
                                tmp.remove(iqn)
                            except ValueError:
                                pass

                        for iqn in tmp:
                            if del_iqns == 'none':
                                del_iqns = iqn
                            else:
                                del_iqns = del_iqns + ',' + iqn

                    else:
                        added_iqns = iqns

                else:
                    del_iqns = old_iqns

            else:
                flag = '1'
                # 创建rbd时开启target iqn认证
                iqn_switch = '1'
                added_iqns = iqns
                del_iqns = 'none'
                target_info = self.onestor_request(fsid, 'database.find_one', [
                    'iscsitarget', [{'target_id': target_id}]])
                db_id = target_info[0]['id']

            # BEGIN ADD BY D10039 2016/05/26 PN:201605050578 修改Target之前先检查网络是否连通
            ping_results = self.onestor_request_all_node('ping')
            for state in ping_results['error']:
                if 'Host is unreachable' == state:
                    self.addOperationlog(
                            fsid, request, u'修改Target“%s”' % target_name, u'有节点存在网络故障')
                    return Response({'success': False, 'error': u'修改Target失败，有节点存在网络故障',
                                     'errorcode': 'NETWORK_FAULT'})
            # END ADD BY D10039 2016/05/26 PN:201605050578

            results = self.onestor_request_all_node(
                    'modify_target', target_id, target_name, iqn_switch, added_iqns, del_iqns)
            if results['success']:
                # modified by l11544 异地灾备修改Target时将iqn信息保存到metadata中,并修改表容灾状态
                back_utils.DisasterUtils().covert_disaster_target(
                        target_name, iqn_switch, iqns, old_usage_mode, select_disaster)
                usage_mode = 'disaster' if select_disaster else ''
                db_results = self.onestor_request(fsid, 'database.update_obj', ['iscsitarget', db_id, [
                    target_id, target_name, iqn_switch, iqns, lunID, lunNum, usage_mode]])
                log.info('[ONEStor] patchTarget db_results is %s', db_results)

                if flag == '0':
                    self.addOperationlog(
                            fsid, request, u'修改Target“%s”' % target_name, 'success')
                else:
                    self.addOperationlog(
                            fsid, request, u'开启Target“%s”IQN认证' % target_name, 'success')
                return Response({'success': True})
            else:
                for error in results['error']:
                    if 'Host is unreachable' == error:
                        if flag == '0':
                            self.addOperationlog(
                                    fsid, request, u'修改Target“%s”' % target_name, u'有节点存在网络故障')
                            return Response({'success': False, 'error': u'修改Target失败，有节点存在网络故障'})
                        else:
                            self.addOperationlog(
                                    fsid, request, u'开启Target“%s”IQN认证' % target_name, u'有节点存在网络故障')
                            return Response({'success': False, 'error': u'开启Target认证失败，有节点存在网络故障'})

                if flag == '0':
                    log.error('[ONEStor] Modify target error: %s', results['error'])
                    self.addOperationlog(fsid, request, u'修改Target“%s”' %
                                         target_name, u'在节点“%s”上修改Target失败，详情参见日志' % results['nodes'])
                    return Response({'success': False, 'error': u'在节点“%s”上修改Target失败，详情参见日志' % results['nodes']})

                else:
                    log.error('[ONEStor] Open target IQN authentication error: %s', results['error'])
                    self.addOperationlog(fsid, request, u'开启Target“%s”IQN认证' %
                                         target_name, u'在节点“%s”上开启Target IQN认证失败，详情参见日志' % results['nodes'])
                    return Response({'success': False, 'error': u'在节点“%s”上开启认证失败，详情参见日志' % results['nodes']})

        except KeyError:
            return Response({'success': False, 'error': u'参数错误'})
        except Exception, e:
            log.error(e)
            self.addOperationlog(
                    fsid, request, u'配置target“%s”' % target_name, u'操作失败，详见后台日志')
            return Response({'success': False, 'error': u'操作失败，详见后台日志'})

    def removeTargetFromDB(self, fsid, database_id):
        results = self.onestor_request(fsid, 'database.del_obj', [
            'iscsitarget', database_id])

        if None != results:
            return results

        return None

    @check_cluster_dispace(const.OP_REMOVE_TARGET)
    @assert_tgtd_normal(const.OP_REMOVE_TARGET)
    def removeTarget(self, request, fsid):
        database_id = request.GET.get('database_id')
        target_id = request.GET.get('target_id')
        target_name = request.GET.get('target_name')

        # 判断target下是否含有存储卷，如果是则直接返回失败
        luns_in_target = database.find('iscsilun', [{'target_name': target_name}])

        if len(luns_in_target):
            self.addOperationlog(
                    fsid, request, u'删除Target “%s”' % target_name, 'Target存在存储卷')
            return Response({'status': 'error', 'reason': u'删除失败，Target “%s” 存在存储卷' % target_name})

        # 先测试网络是否都通
        ping_results = self.onestor_request_all_node('ping')
        for state in ping_results['error']:
            if 'Host is unreachable' == state:
                self.addOperationlog(
                    fsid, request, u'删除Target “%s”' % target_name, u'有节点存在网络故障')
                return Response({'status': 'error', 'reason': u'删除Target失败，有节点存在网络故障',
                                 'errorcode': 'NETWORK_FAULT'})

        remove_result = self.onestor_request_all_node('remove_target', target_id, target_name)
        log.info('remove_target result is: %s' % remove_result)
        ret = self.removeTargetFromDB(fsid, database_id)
        if None != ret:
            self.addOperationlog(
                    fsid, request, u'删除Target“%s”' % target_name, ret)
            return Response(ret)

        return Response({'status': 'error', 'reason': u'网络错误', 'errorcode': 'INTERNAL_SERVER_ERROR'})

    def listLUN(self, request, fsid):
        results = self.onestor_request(
                fsid, 'database.list_objs', ['iscsilun'])

        if None != results:
            return Response(results)

        return Response([])

    def addLun2DB(self, fsid, params):
        results = self.onestor_request(
                fsid, 'database.add_obj', ['iscsilun', params])

        if None != results:
            return results

        return None

    def updateLunID2Tgt(self, fsid, targetID, targetName, lunID, addOrDel, usage_mode=''):
        lunMessage = database.find_one('iscsitarget', [{'target_name': targetName}])[0]
        # 容灾标识更新 add by l11544 2017/5/26
        usage_mode_use = lunMessage['usage_mode'] if '' == usage_mode else usage_mode

        iqn_switch = lunMessage['iqn_switch']
        iqns = lunMessage['iqns']
        lunNum = int(lunMessage['lun_num'])
        if addOrDel == 'add':
            lunNum += 1
        elif addOrDel == 'delete':
            lunNum -= 1
            lunID = lunMessage['lun_id']
            usage_mode_use = ''
        results = self.onestor_request(fsid, 'database.update_obj', ['iscsitarget', targetID, [
            targetID, targetName, iqn_switch, iqns, lunID, lunNum, usage_mode_use]])

        if None != results:
            return results

        return None

    def _prevent_meantime_action(self, action):
        """
        阻止并发操作
        """
        now_time = time.time()

        if os.path.exists("/tmp/.{0}".format(action)):
            last_time_str = self.exec_local_cmd('cat /tmp/.{0}'.format(action))
            last_time = float(last_time_str) if '' != last_time_str else now_time

            if now_time - last_time < 5 * 60:
                raise IOError('SYSTEM_BUSY')

        self.exec_local_cmd('echo {0} > /tmp/.{1}'.format(now_time, action))

    @check_cluster_dispace(const.OP_CREATE_LUN)
    @assert_tgtd_normal(const.OP_CREATE_LUN)
    def createLUN(self, request, fsid):
        """
        创建存储卷接口
        ADD BY D10039 2016/08/26 PN:201608160171
        增加并发保护
        """
        is_need_prevent = False
        try:
            self._prevent_meantime_action('creating_lun')
            return self.create_lun(request, fsid)
        except IOError, ex:
            log.exception(ex)
            is_need_prevent = True
            error_reason = '正在创建其它存储卷，请稍后再试'
            self.addOperationlog(fsid, request, u'创建存储卷“%s”' % request.DATA['lunName'], error_reason)
            return Response({'status': 'error', 'reason': error_reason, 'errorcode': 'SYSTEM_BUSY'})
        finally:
            if not is_need_prevent:
                self.exec_local_cmd('rm -r /tmp/.creating_lun')

    def create_lun(self, request, fsid):
        lun_name, pool_name, target_name, select_disaster = '', '', '', False
        try:
            create_target_flag = request.DATA['createTarget']
            lun_name = request.DATA['lunName']
            target_name = request.DATA['targetName']
            pool_name = request.DATA['poolName']
            rbd_name = request.DATA['rbdName']
            rbd_size = int(request.DATA['rbdSize'])
            rbd_type_convert = request.DATA['isThin']
            rbd_description = request.DATA.get('rbd_description', '')
            select_disaster = request.DATA['selectDisaster']
            diskpool_name = request.DATA.get('diskpool_name', '')
        except IOError:
            pass
        except Exception:
            self.addOperationlog(fsid, request, u'创建存储卷“%s”' % lun_name, u'无效的参数')
            return Response({'status': 'error', 'reason': u'无效的参数', 'errorcode': 'PARAMETER_ERROR'})
        # 检查集群存储卷数量规格是否超上限
        # PN: 201704130123 集群可以创建的最大存储卷的数量超过了256
        matadata = '.' + diskpool_name + '.rbd'
        restrict_result = self.restrict_lun_num(matadata, target_name)
        if not restrict_result['not_restrict']:
            log.error('lun numbers over restrictions')
            self.addOperationlog(fsid, request, u'创建存储卷“%s”' % lun_name, restrict_result['restrict_reason'])
            return Response(
                    {'status': 'error', 'reason': restrict_result['restrict_reason'], 'errorcode': 'NUM_OVER_ERROR'})
        # End by l11544 2017/5/20

        # 先测试网络是否都通
        ping_results = self.onestor_request_all_node('ping')
        for state in ping_results['error']:
            if 'Host is unreachable' == state:
                self.addOperationlog(
                        fsid, request, u'创建存储卷“%s”' % lun_name, u'有节点存在网络故障')
                return Response({'status': 'error', 'reason': u'创建存储卷失败，有节点存在网络故障', 'errorcode': 'NETWORK_FAULT'})

        # Get LUN table current_id
        try:
            lun_list = self.onestor_request(
                    fsid, 'database.list_objs', ['iscsilun'])
            lun_current_id = int(lun_list['current_id']) + 1
        except IOError:
            pass
        except Exception:
            self.addOperationlog(fsid, request, u'创建存储卷“%s”' %
                                 lun_name, u'获取存储卷ID失败')
            return Response({'status': 'error', 'reason': u'获取存储卷ID失败', 'errorcode': 'INTERNAL_SERVER_ERROR'})

        # Create RBD
        onestor_params = [self.CEPH_CONF_FILE,
                          pool_name, rbd_name, rbd_size, 22, True, matadata]

        # 容灾兼容分区，添加容灾标识 add by l11544 2017/5/25
        usage_mode = 'disaster' if select_disaster else ''

        db_params = [rbd_name, rbd_size, pool_name,
                     rbd_type_convert, '0', '', '', lun_current_id, rbd_description, matadata, usage_mode]

        results = self.onestor_request(
                fsid, 'onestor.createRbd', onestor_params)

        if 'success' != results['status']:
            self.addOperationlog(
                    fsid, request, u'创建存储卷“%s”' % lun_name, results)
            return Response({'status': 'error', 'reason': results['reason'], 'errorcode': 'CREATE_RBD_ERROR'})

        # Create Target
        if 'true' == create_target_flag or True == create_target_flag:
            create_target_result = self.createTargetCommon(target_name, '0', 'none', fsid, usage_mode)

            if 'error' == create_target_result['status']:
                # 删除之前创建的RBD
                self.exec_local_cmd('rbd rm %s/%s' % (matadata, rbd_name))
                self.addOperationlog(fsid, request, u'创建存储卷“%s”' %
                                     lun_name, create_target_result)

                # BEGIN ADD BY d10039 2016/03/01 PN:201602290515
                if u'有节点存在网络故障' == create_target_result['reason']:
                    create_target_result['reason'] = u'创建Target失败，有节点存在网络故障'
                # END ADD BY d10039 2016/03/01 PN:201602290515

                return Response({'status': 'error', 'reason': create_target_result['reason'], \
                                 'errorcode': 'CREATE_TARGET_ERROR'})

            target_id = create_target_result['tid']
            lun_id = 1

        # deleted by l11544 容灾兼容分区 直接标记当前存储卷为灾备使用即可，且一个Target下一个灾备存储卷
        else:
            # PN:201511270740 如果使用已有的target，根据target名称获取target的id
            target_by_name = database.find_one(
                    'iscsitarget', [{'target_name': target_name}])
            target_info = target_by_name[
                0] if 0 < len(target_by_name) else None

            if None == target_info:
                return Response({'status': 'error', 'reason': u'无法查询到当前的Target信息', \
                                 'errorcode': 'INTERNAL_SERVER_ERROR'})

            target_id = target_info['target_id']

            # 获取各个节点上的lun id
            try:
                current_lun_ids = self.onestor_request_all_node(
                        'get_current_lun_id', target_id)
                lun_id_list = []
                for lun_ids in current_lun_ids['error']:
                    if 'Host is unreachable' == lun_ids:
                        self.addOperationlog(
                                fsid, request, u'创建存储卷“%s”' % lun_name, u'有节点存在网络故障')
                        return Response({'status': 'error', 'reason': u'创建存储卷失败，有节点存在网络故障' \
                                                                      % lun_name, 'errorcode': 'NETWORK_FAULT'})

                    lun_id_list.append(int(max(json.loads(lun_ids))))

                lun_id = max(lun_id_list) + 1
            except ValueError:
                log.error('[ONEStor] create lun, get lun_ids error, lun_ids is not integer')
                lun_id = target_info['lun_id'] + 1

                # PN:201511270740 end

        # Create LUN
        log.info('[ONEStor] create lun target_id is %s, lun_id is %s, pool_name is %s, rbd_name is %s, lun type is %s',
            target_id, lun_id, matadata, rbd_name, usage_mode)
        results = self.onestor_request_all_node(
            'create_lun', target_id, lun_id, matadata, rbd_name, target_name, '0', 'none')
        self.updateLunID2Tgt(fsid, target_id, target_name, lun_id, 'add')

        if not results['success']:
            # 只要有一个节点创建LUN失败，所有的节点都清理掉该LUN，并清理掉rbd信息
            self.onestor_request_all_node(
                'remove_lun', target_id, lun_id, matadata, rbd_name, target_name)
            self.exec_local_cmd('rbd rm %s/%s' % (matadata, rbd_name))

            # 如果target是新创建的，还要删除之前创建的target，并废弃当前lunID
            if 'true' == create_target_flag or True == create_target_flag:
                self.onestor_request_all_node(
                        'remove_target', target_id, target_name)
                self.removeTargetFromDB(fsid, target_id)
            else:
                self.updateLunID2Tgt(fsid, target_id, target_name, 0, 'delete')

            self.addOperationlog(fsid, request, u'创建存储卷“%s”' %
                                 lun_name, '在节点“%s”上创建存储卷失败' % results['nodes'])
            return Response({'status': 'error', 'reason': u'在节点“%s”上创建存储卷失败' \
                                                          % results['nodes'], 'errorcode': 'CREATE_LUN_ERROR',
                             'errornodes': results['nodes']})

        log.info('%s %s %s %s %s %s %s %s %s %s', lun_id, lun_name, target_id, target_name, pool_name, rbd_name,
                 rbd_size, rbd_description, matadata, usage_mode)
        # 所有操作都成功后将LUN和RBD保存到数据库
        self.addLun2DB(fsid, [lun_id, lun_name, target_id,
                              target_name, pool_name, rbd_name, rbd_size, rbd_description, matadata, usage_mode])
        self.addRbd2DB(fsid, db_params)

        # 发送消息给scheduler创建灾备存储卷
        if select_disaster:
            try:
                messanger.send_create_onbackup_lun_msg(matadata, rbd_name, target_name, lun_id)
            except ONEBackupError as ex:
                log.error('add lun from backup error, reason is: %s', ex.reason)
            except Exception as e:
                log.error('add lun from backup error, reason is %s', e)

        self.addOperationlog(fsid, request, u'创建存储卷“%s”' % lun_name, 'success')
        target_info = {'lun_id': lun_id,
                       'target_id': target_id, 'target_name': target_name}
        return Response({'status': 'success', 'target_info': target_info})

    def removeLunFromDB(self, fsid, current_id):
        results = self.onestor_request(fsid, 'database.del_obj', [
            'iscsilun', current_id])

        if None != results:
            return results

        return None

    def removeRbdWithLunID(self, fsid, lun_id):
        results = self.onestor_request(
                fsid, 'database.del_rbd_by_lun_id', [lun_id])

        if None != results:
            return results

        return None

    def getLunsByTargetID(self, request, fsid):
        targetID = request.GET.get('targetID')
        luns = self.onestor_request(
                fsid, 'database.find_by_target_id', [targetID])

        return Response(luns) if None != luns else Response([])

    @check_cluster_dispace(const.OP_REMOVE_LUN)
    @assert_tgtd_normal(const.OP_REMOVE_LUN)
    def removeLUN(self, request, fsid):
        """
        删除存储卷接口
        ADD BY z11524 2017/08/11 PN:201707310397
        增加并发保护
        """
        is_need_prevent = False
        try:
            self._prevent_meantime_action('removing_lun')
            return self.remove_lun(request, fsid)
        except IOError, ex:
            log.exception(ex)
            is_need_prevent = True
            error_reason = '正在删除其它存储卷，请稍后再试'
            self.addOperationlog(fsid, request, u'删除存储卷“%s”' % request.GET.get('rbdName'), error_reason)
            return Response({'status': 'error', 'reason': error_reason, 'errorcode': 'SYSTEM_BUSY'})
        finally:
            if not is_need_prevent:
                self.exec_local_cmd('rm -r /tmp/.removing_lun')

    def remove_lun(self, request, fsid):
        pool_name = request.GET.get('poolName')
        rbd_name = request.GET.get('rbdName')
        lun_id = request.GET.get('lunID')
        matadata = request.GET.get('matadata')
        rbdID = request.GET.get('rbdID')

        if self.isRBDInDisasterBackup(rbd_name, matadata, fsid):
            self.addOperationlog(fsid, request, u'删除存储卷“%s”' %
                                 rbd_name, u'异地灾备的块设备不支持删除，请先删除备份策略')
            return Response({'status': 'error', 'reason': u'异地灾备的块设备不支持删除，请先删除备份策略'})

        # 如果是存储卷的访问方式，需要先删除存储卷的信息
        if int(lun_id) > 0:
            # 先测试网络是否都通
            ping_results = self.onestor_request_all_node('ping')
            for state in ping_results['error']:
                if 'Host is unreachable' == state:
                    self.addOperationlog(
                            fsid, request, u'删除存储卷“%s”' % rbd_name, u'有节点存在网络故障')
                    return Response({'status': 'error', 'reason': u'删除存储卷失败，有节点存在网络故障', \
                                     'errorcode': 'NETWORK_FAULT'})

            # 通过LUN ID获取LUN的详情
            lun_info = self.onestor_request(
                    fsid, 'database.find_by_id', ['iscsilun', lun_id])

            if 'NotFound' != lun_info and None != lun_info:
                # 有快照时不允许删除存储卷
                is_snap_exist = self.exec_local_cmd(
                    'rbd snap ls %s/%s 2>/dev/null | wc -l' % (matadata, rbd_name))
                if '0' != is_snap_exist:
                    self.addOperationlog(
                        fsid, request, u'删除存储卷“%s”' % rbd_name, u'存储卷存在快照')
                    return Response({'status': 'error', 'reason': u'删除失败，存储卷“%s”存在快照' \
                        % rbd_name, 'errorcode': 'RBD_HAS_SNAPSHOT'})

                results = self.onestor_request_all_node('remove_lun', lun_info['target_id'], lun_info[
                                                        'lun_id'], matadata, rbd_name, lun_info['target_name'])

                response = self.process_remove_lun_result(request, fsid, results, rbd_name)
                if response:
                    return response

        results = self.onestor_request(fsid, 'onestor.removeRbd', [
            self.CEPH_CONF_FILE, pool_name, rbd_name, matadata])

        if results['status'] == 'success':
            if int(lun_id) > 0:
                # BEGIN MODIFY BY D10039 2016/04/24 PN:201604140479 删除RBD成功后才删除存储卷信息
                self.removeLunFromDB(fsid, lun_id)
                self.updateLunID2Tgt(fsid, lun_info['target_id'], lun_info['target_name'], 0, 'delete')
                # END MODIFY BY D10039 2016/04/24

                self_result = self.removeRbdWithLunID(fsid, lun_id)
                # DELETE BY KF6602 监控项目不需要清除graphite监控数据

                # 发送消息给scheduler删除灾备存储卷
                if 'usage_mode' in lun_info and 'disaster' == lun_info['usage_mode']:
                    try:
                        messanger.send_remove_onbackup_lun_msg(matadata, rbd_name)
                    except Exception, e:
                        log.error('remove lun from backup error, reason is %s', e)

                self.addOperationlog(fsid, request, u'删除存储卷“%s”' % rbd_name, self_result)
                return Response(self_result)
            else:
                self_result = self.removeRbdFromDB(fsid, rbdID)
            self.addOperationlog(fsid, request, u'删除块“%s”' %
                                 rbd_name, self_result)
            return Response(self_result)
        else:
            self.addOperationlog(fsid, request, u'删除块“%s”' %
                                 rbd_name, results['reason'])
            return Response(results)
    # NOTE this function is no longer used, to be deleted
    def check_use_lun(self, tid):
        """
        检查lun所在的tgt是否正在跑业务
        # add by z11524 2017/8/10 PN:201707280462
        """
        nodes = self._get_mon_stor()
        result = self.sub_multi_thread_task(nodes, 'tgtadm -m target -o check --tid %s' % tid)
        for node in result:
            if -1 != result[node]['err'].find('still active'):
                return True
        return False

    @staticmethod
    def __get_mounted_error_disk(mounted_disk, osd_ids):
        """
        获取被挂载但是不在osd tree对应主机下的硬盘
        """
        return [disk['id'] for disk in mounted_disk if int(disk['id']) not in osd_ids]

    def __get_maintain_disk(self, osd_tree):
        """
        获取在维护模式对应主机下的硬盘
        """
        # delete by d11564 2017/05/11 PN:201704150317 获取主机存储节点慢
        maintain, maintain_osd_ids = {}, []
        for node in osd_tree['nodes']:
            if 'maintain' == node['name']:
                maintain = node
                break
        for node in osd_tree['nodes']:
            if 'host' == node['type'] and node['id'] in maintain['children']:
                maintain_osd_ids = node['children']
        return maintain_osd_ids

    def __update_host_status(self, returned, stor_server, osd_ids, osd_tree):
        """
        维护模式增加主机状态
        """
        # 获取已挂载但不在osd tree里的硬盘
        mounted_error_disk = self.__get_mounted_error_disk(
                returned['stor'][stor_server]['disk'], osd_ids)
        for osd_id in mounted_error_disk:
            returned['stor'][stor_server]['osd_status'][osd_id] = False

        returned['stor'][stor_server]['status'] = ''
        progress = self._get_progress('remove_disk')
        if progress is not None and stor_server == progress['hostname']:
            # 增加主机状态
            returned['stor'][stor_server]['status'] = progress['progress']
            if 'disks' in progress and progress['disks'] is not None:
                # 从维护模式文件中读取删除中的硬盘
                maintain_disks = list(set([disk['id'] for disk in progress['disks']]) - set(
                        returned['stor'][stor_server]['osd_status'].keys()))
                for disk_id in maintain_disks:
                    returned['stor'][stor_server]['osd_status'][disk_id] = False
        # BEGIN MODIFY BY KF6602 PN:201706220290 maintain下的硬盘状态均标为异常
        for osd_id in self.__get_maintain_disk(osd_tree):
            if osd_id in osd_ids:
                returned['stor'][stor_server]['osd_status'][osd_id] = False
        # END MODIFY BY KF6602 PN:201706220290
        returned['stor'][stor_server]['osd_count'] = \
            len(returned['stor'][stor_server]['osd_status'])

    def serverInfo(self, request, fsid):
        auto_reload = request.GET.get('auto_reload')
        data = dict()
        data['auto_reload'] = auto_reload
        data['ver'] = '2.0'
        comp_op = plat_leader_router.OP_QUERY_SERVER
        response = ForwardView().send_request_to_leader(comp_op, data, unistor_api=False)
        if 0 == response['result'][0]:
            return Response({'success': True, 'data': response['data']})
        else:
            return Response({'success': False, 'error': response['result'][1], 'errorcode': 'INTERNAL_SERVER_ERROR'})
    def topoInfo(self, request, fsid):
        try:
            returned = {}
            returned['servers'] = {}

            server_info_results = self.onestor_all_topo_info()

            # 获取机架信息
            rack_info = self.exec_local_cmd('timeout 30 ceph osd tree -f json')
            returned['topo'] = json.loads(rack_info)

            for crush_node in returned['topo']['nodes']:
                # 如果OSD为out状态，也将状态标记为down
                if 'osd' == crush_node['type']:
                    if 0 == float(crush_node['reweight']):
                        crush_node['status'] = 'down'

            # BEGIN ADD BY D10039 2016/06/21 PN:201606200375
            try:
                server_arrays = [_server.keys()[0] for _server in server_info_results]
                client = http_request.HttpClient()
                monitoring_data = client.get_server_monitoring_data(server_arrays, server_info_results)
            except KeyError:
                monitoring_data = None
                log.error('[ONEStor] topoInfo monitoring_data is None: KeyError')
            except Exception, e:
                log.error('[ONEStor] topoInfo monitoring_data is None: %s', e)
                monitoring_data = None
            # END ADD BY D10039 2016/06/21 PN:201606200375

            for server in server_info_results:
                single_server_info = {}

                server_name = server.keys()[0]
                server_info = server.values()[0]

                # MODIFY BY D10039 2016/06/21 PN:201606200375
                single_server_info['mem'] = monitoring_data[server_name]['mem'] \
                    if (monitoring_data and monitoring_data[server_name]) else server_info['mem']
                # MODIFY BY D10039 2016/06/21 PN:201606200375
                single_server_info['cpu'] = monitoring_data[server_name]['cpu'] \
                    if (monitoring_data and monitoring_data[server_name]) else server_info['cpu']
                single_server_info['disk'] = server_info['disk']
                single_server_info['lsblk'] = server_info['lsblk']
                single_server_info['ip'] = server_info['ip_addrs'][0]
                single_server_info['sys_version'] = server_info['sys_version']
                single_server_info['sys_uptime'] = server_info['sys_uptime']

                try:
                    # 过滤出业务网段的IP
                    cluster_config = self.get_config_from_conf_file()
                    public_network = cluster_config['public_network']

                    public_ip = ''
                    for ip in server_info['ip_addrs']:
                        if self.subnet_judge(public_network, ip):
                            public_ip = ip
                            break

                    if '' != public_ip:
                        single_server_info['ip'] = public_ip
                except Exception, e:
                    log.error(e)

                returned['servers'][server_name] = single_server_info

            return Response({'success': True, 'rt': returned})
        except Exception, e:
            return Response({'success': False, 'error': u'信息获取失败'})

    def listRack(self, request, fsid):
        results = self.onestor_request(fsid, 'onestor.osd_tree', [])

        if None != results:
            return Response({'success': True, 'data': results['data']})
        else:
            return Response({'success': False})

    def listRackAPI(self, request, fsid):
        try:
            racks = []
            osd_tree = json.loads(self.exec_local_cmd('ceph osd tree -f json'))

            for node in osd_tree['nodes']:
                if 'rack' == node['type'] and (not node['name'].endswith('_ssd')):
                    racks.append({'id': node['id'], 'name': node['name']})

            return Response(racks)

        except Exception, e:
            return Response({'error': e, 'errorcode': 'INTERNAL_SERVER_ERROR'})

    def createRack(self, request, fsid):
        try:
            rack_name = request.DATA['rack_name']
        except Exception:
            return Response({'success': False, 'reason': u'输入参数错误', 'errorcode': 'PARAMETER_ERROR'})

        try:
            # BEGIN ADD BY D10039 2016/09/27 校验bucket是否已经存在
            if not self.handle_validate_bucket(rack_name):
                error = u'机架名称不满足部署要求，详见操作日志'
                op_log = u'机架名称不能为default、maintain，且不能与现有主机名称和机架名称相同'
                self.addOperationlog(fsid, request, u'创建机架 “%s”' % rack_name, op_log)
                return Response({'success': False, 'error': error, 'errorcode': 'RACK_NAME_ERROR'})
            # END ADD BY D10039 2016/09/27 校验bucket是否已经存在

            self.exec_local_cmd('ceph osd crush add-bucket %s rack' % rack_name)
            self.exec_local_cmd('ceph osd crush move %s root=default' % rack_name)
            self.exec_local_cmd('ceph osd crush add-bucket %s_ssd rack' % rack_name)
            self.exec_local_cmd('ceph osd crush move %s_ssd root=ssd_root' % rack_name)

            # 检查机架是否创建成功
            all_racks_str = self.exec_local_cmd('ceph osd tree -f json')
            all_racks_json = json.loads(all_racks_str)

            is_hdd_rack_exist = False
            is_ssd_rack_exist = False
            for node in all_racks_json['nodes']:
                if 'rack' == node['type']:
                    if rack_name == node['name']:
                        is_hdd_rack_exist = True
                    elif '%s_ssd' % rack_name == node['name']:
                        is_ssd_rack_exist = True

            if is_ssd_rack_exist and is_hdd_rack_exist:
                self.addOperationlog(
                        fsid, request, u'创建机架 “%s”' % rack_name, 'success')
                return Response({'success': True})
            else:
                self.addOperationlog(
                        fsid, request, u'创建机架 “%s”' % rack_name, '')
                return Response({'success': False, 'errorcode': 'INTERNAL_SERVER_ERROR'})
        except ValueError:
            return Response({'success': False, 'errorcode': 'INTERNAL_SERVER_ERROR'})
        except Exception, e:
            log.error('[ONEStor] [create_rack] error:%s', e)
            self.addOperationlog(fsid, request, u'创建机架 “%s”' %
                                 rack_name, str(e))
            return Response({'success': False, 'errorcode': 'INTERNAL_SERVER_ERROR'})

    def removeRack(self, request, fsid):
        try:
            rack_name = request.GET.get('rack_name')

            self.exec_local_cmd('ceph osd crush remove %s_ssd' % rack_name)
            self.exec_local_cmd('ceph osd crush remove %s' % rack_name)

            # 检查机架是否删除成功
            all_racks_str = self.exec_local_cmd('ceph osd tree -f json')
            all_racks_json = json.loads(all_racks_str)

            is_hdd_rack_exist = False
            is_ssd_rack_exist = False
            for node in all_racks_json['nodes']:
                if 'rack' == node['type']:
                    if rack_name == node['name']:
                        is_hdd_rack_exist = True
                    elif '%s_ssd' % rack_name == node['name']:
                        is_ssd_rack_exist = True

            if is_ssd_rack_exist or is_hdd_rack_exist:
                self.addOperationlog(
                        fsid, request, u'删除机架 “%s”' % rack_name, '')
                return Response({'success': False, 'errorcode': 'INTERNAL_SERVER_ERROR'})
            else:
                self.addOperationlog(
                        fsid, request, u'删除机架 “%s”' % rack_name, 'success')
                return Response({'success': True})
        except ValueError:
            return Response({'success': False, 'errorcode': 'INTERNAL_SERVER_ERROR'})
        except Exception, e:
            log.error('[ONEStor] [remove_rack] error:%s', e)
            self.addOperationlog(fsid, request, u'删除机架 “%s”' %
                                 rack_name, str(e))
            return Response({'success': False, 'errorcode': 'INTERNAL_SERVER_ERROR'})

    def ClusterConfig(self, request, fsid):
        if self.exec_local_cmd('timeout 5 ceph fsid') == '':
            return Response({'success': True, 'clusterconfig': {}})

        results = self.onestor_request(
                fsid, 'database.list_objs', ['clusterconfig'])

        if None != results:
            return Response({'success': True, 'clusterconfig': results})

        return Response({'success': False})

    def check_cluster_status(self, request, fsid):
        try:
            status = json.loads(self.exec_local_cmd('ceph -s -f json'))
            # MODIFY BY D10039 2017/03/11 PN:201610220299
            cluster_status = [item for item in status['pgmap']['pgs_by_state']
                              if -1 != item['state_name'].find('inconsistent') or
                              not item['state_name'].startswith('active+clean')]

            remove_flag = self.exec_local_cmd(
                    "bash /var/lib/ceph/shell/detect_remove_process.sh")

            if len(cluster_status) > 0:
                return Response({'success': False, 'reason': u'集群状态恢复正常才能执行，否则会造成数据丢失'})
            elif '' != remove_flag:
                return Response({'success': False, 'reason': u'正在操作其它主机或硬盘，请稍后再试'})
            else:
                return Response({'success': True})
        except Exception, e:
            log.error(e)
            return Response({'success': False, 'reason': str(e)})

    # BEGIN ADD BY C13463 PN:201703290552
    def check_host_delete(self, request, fsid):
        try:
            # BEGIN ADD BY C13463 调用onestord 是否可以删除主机
            host_name = request.GET.get('host_name')
            data = {'host_name': host_name}
            log.info('start to check host delete, host is {0}'.format(host_name))
            host_delete_response = send_request_onestord('COMP_CS', 'HOST_delete', data)
            host_delete_result = host_delete_response['response']['result']
            if 0 != host_delete_result[0]:
                log.error('host delete error, response is %s', host_delete_response)
                return Response({'success': False, 'reason': host_delete_result[2], 'errorcode': 'HOST_DELETE'})
            host_delete_data = host_delete_response['response']['data']
            log.info('type %s %s' % (type(host_delete_data), host_delete_data))
            success_reason = None
            if host_delete_data['is_delete']:
                if 'reason' in host_delete_data:
                    success_reason = host_delete_data['reason']
            else:
                return Response({'success': False, 'reason': host_delete_data['reason'], 'errorcode': 'HOST_DELETE'})
            log.info('end to host delete')
            # END ADD BY C13463
            remove_flag = self.exec_local_cmd(
                    "bash /var/lib/ceph/shell/detect_remove_process.sh")
            host_delete_data = host_delete_response['response']['data']
            if not host_delete_data['is_delete']:
                return Response({'success': False, 'reason': host_delete_data['reason']})
            elif '' != remove_flag:
                return Response({'success': False, 'reason': u'正在操作其它主机或硬盘，请稍后再试'})
            elif success_reason != None:
                return Response({'success': True, 'reason': success_reason})
            else:
                return Response({'success': True})
        except Exception, e:
            log.error(e)
            return Response({'success': False, 'reason': str(e)})

    def listDisk(self, request, fsid):
        try:
            HANDY_SHELL_PATH = '/var/lib/ceph/shell'
            fqdn = request.GET['fqdn']
            log.error(fqdn)
            list_disk_command = '/opt/h3c/bin/python %s/list_disk.py' % HANDY_SHELL_PATH
            results = self.exec_remote_ssh_cmd(fqdn, list_disk_command)
            if results.find('available disk -->') != -1:
                return Response({'success': True, 'disks': results})
            else:
                return Response({'success': False, 'error': results})

        except Exception, e:
            return Response({'success': False, 'error': str(e)})

    def remoteScanDisk(self, request, fsid):
        try:
            hostip = request.DATA['hostip']
            user = request.DATA['user']
            passwd = request.DATA['passwd']
            results = self.exec_local_cmd(
                    '/opt/h3c/bin/python /opt/h3c/salt/salt/shell/remote_list_disk.py %s %s %s' % (hostip, user, passwd))
            return Response({'success': True, 'disks': results})

        except Exception, e:
            return Response({'success': False, 'error': str(e)})

    def clusterInfo(self, request, fsid):
        comp_op = plat_leader_router.OP_QUERY_HEALTH
        response = ForwardView().send_request_to_leader(comp_op, unistor_api=False)
        returned = {}
        if 0 == response['result'][0]:
            returned['health_counters'] = response['data']
            return Response({'status': 'success', 'reason': returned})
        else:
            Response({'status': 'error', 'reason': str(response['result'])})

    # BEGIN ADD by l11544 2016/04/28 用于参数配置服务

    # ntp server IP 校验
    # 操作日志记录规则：
    # 直接修改NTP配置失败需要记录，返回成功不需要记录，只是其中的修改过程
    # 创建集群时，不需要记录操作日志
    def ntp_ip_check(self, ntp_servers, cluster_deploy, host_passwd, cluster_hosts, fsid, request):
        test_ip_info, threads = {}, []
        nloops = range(len(ntp_servers))
        # deleted by l11544 2017/2/17 PN: 201701220120

        ntp_check_result = {}
        ntp_check_result_lock = threading.Lock()

        def outer_ntp_check(ntp_ip):
            # deleted by l11544 2017/2/17 PN: 201701220120
            # 不应该限制NTP server IP为业务网IP，部署集群时也不应该判断NTP服务器IP在不在业务网段内
            # 调用公共接口，检查NTP服务器
            ntp_result = self.ntp_network_in_judge(cluster_deploy, ntp_ip, host_passwd, cluster_hosts)
            if 'success' != ntp_result['status']:
                return ntp_result

            # PN:201609180310 配置集群外节点为NTP SERVER，该节点时间早于集群时间50分钟，配置成功后导致集群不健康
            # 检测NTP是否可用
            ntp_result = self.exec_local_cmd('timeout 30 /usr/sbin/ntpdate -q %s' % ntp_ip)
            if not (-1 != ntp_result.find('time server') and -1 != ntp_result.find('offset')):
                return {'status': 'error', 'reason': '主机无法提供ntp时间同步服务'}
            # 获取时间差
            time_result = float(ntp_result.split()[-2])

            # test_time = self.exec_remote_ssh_cmd(test_ip, 'date +%s')
            log.info('handy has time difference {0} with {1}'.format(time_result, ntp_ip))
            # add by l11544 PN:201701020048 NTP同步，不应该判断NTP Server的时间，而应该强制自己与server同步
            if time_result < -1 and 'deploy_cluster' != cluster_deploy:
                return {'status': 'error', 'reason': '主机时间晚于集群系统时间，NTP服务不可用'}

            # end by l11544 2016/9/20
            return {'status': 'success', 'time_differ': time_result}

        # 获取检测结果
        def result_check(ntp_ip):
            result = outer_ntp_check(ntp_ip)
            with ntp_check_result_lock:
                ntp_check_result[ntp_ip] = result

        if isinstance(ntp_servers, list):
            # 异步判断ip是否可用
            for ntp_server in ntp_servers:
                t = threading.Thread(target=result_check, args=(ntp_server,))
                threads.append(t)

            for i in nloops:
                threads[i].start()

            for i in nloops:
                threads[i].join()
            # 检测异步结果，只要有失败即返回，不检测所有结果
            for ntp_server in ntp_check_result:
                if 'success' != ntp_check_result[ntp_server]['status']:
                    message = u'IP地址“' + ntp_server + u'”' + ntp_check_result[ntp_server]['reason']
                    if 'deploy_cluster' != cluster_deploy:
                        self.addOperationlog(fsid, request, u'修改NTP配置', message)
                    return {'status': 'error', 'reason': message}
                else:
                    test_ip_info[ntp_server] = ntp_check_result[ntp_server]['time_differ']
        # add by l11544 PN:201701020048 当server端有和Handy时间偏差大于300秒的情况，需要提示用户
        alert_info, cluster_interval = True, 0
        for skew_value in [value for index, value in test_ip_info.iteritems()]:
            if abs(skew_value) > 300:
                alert_info = False
                # 获取系统默认超时退出时间
                cluster_interval = config.get('calamari_web', 'cluster_interval')
                break

        handy_time = time.time()
        return {'status': 'success', 'server_skew_info': {
            'server_time_skew': test_ip_info, 'alert_judge': alert_info, 'handy_time': handy_time,
            'cluster_interval': cluster_interval}}

    # 部署集群时获取ip信息
    def deploy_ip_check(self, request):
        try:
            ntp_servers = base64.b64decode(request.GET.get('ntp_servers'))
            cluster_deploy = request.GET.get('clusterDeploy')
            # 增加所有主机IP参数 add by l11544 2017/2/17
            all_node_ip = request.GET.get('all_node_ip')
            user = request.GET.get('user')
            passwd = request.GET.get('password')
            ntp_close = request.GET.get('ntp_close')
            local_ip = request.GET.get('local_ip')
            filepath = os.path.split(os.path.realpath(__file__))[0]
            ntp_servers = ntp_servers.split(',') if isinstance(ntp_servers, str) else ntp_servers

            if '0' == ntp_close:
                return Response({'status': 'success'})
            # 给Handy安装必要的软件
            # 执行顺序有问题，可调整
            install_result = os.popen('timeout 1800 /opt/h3c/bin/python %s/handy_common.py install_soft %s %s %s %s %s' % (
                filepath, local_ip, user, passwd, local_ip, ntp_close)).read().rstrip()
            # PN: 201702070041 deleted by l11544 使用本地用户执行命令，不用再配置免密，保留软件安装
            cluster_ips = all_node_ip.split(',') if not isinstance(all_node_ip, list) else all_node_ip
            if local_ip not in cluster_ips:
                cluster_ips.append(local_ip)

            # 添加Handy登录各节点的检测
            ssh_result = self.multi_thread_task(cluster_ips, "echo ok", False, passwd, user)
            err_list = [node for node in ssh_result if 'ok' != ssh_result[node]]
            if len(err_list) > 0:
                log.error('handy login in host {0} failed'.format(err_list))
                return Response({'status': 'error', 'reason': u'IP地址“{0}”主机登录失败'.format(
                        ','.join(str(ip) for ip in err_list))})

            result = self.ntp_ip_check(ntp_servers, cluster_deploy, passwd, cluster_ips, None, None)
            return Response(result)
        except Exception, e:
            log.error(e)
            return Response({'status': 'error', 'reason': str(e)})

    @check_remove_osd_event(const.OP_POST_NTP_INFO)
    def post_ntp_info(self, request, fsid):
        """
        修改ntp服务配置
        :param request:
        :param fsid:
        :return:
        """
        try:
            ntp_servers = base64.b64decode(request.DATA['ntp_servers'])
            # 决定了是否开启配置，是集群内还是不配置
            ntp_status = request.DATA['ntp_status']
            ntp_servers = ntp_servers.split(',') if isinstance(ntp_servers, str) else ntp_servers
            alter_out = False if 'false' == request.DATA['alter_out'] or not request.DATA['alter_out'] else True
            # 获取所有集群节点IP
            host_ip_list = self.get_all_ip()

            def test_ping_inner():
                # 各节点ping连接测试
                test_ping_failed = self.test_ping(host_ip_list)
                if len(test_ping_failed) > 0:
                    message_inner = u'连接到集群内节点“%s”失败，无法修改NTP配置' % ','.join(str(ip) for ip in test_ping_failed)
                    self.addOperationlog(fsid, request, u'修改NTP配置', message_inner)
                    return {'status': 'error', 'reason': message_inner}
                else:
                    return {'status': 'success'}

            result = test_ping_inner()
            if 'success' != result['status']:
                return Response(result)

            # 获取所有监控节点名
            cluster_config = self.get_clusterconfig()
            mon_nodes = cluster_config['mon_fqdns']
            # 写入修改后的ntp_close配置
            cluster_config['ntp_close'] = ntp_status

            # 将所有节点的NTP配置还原为修改前状态
            if '0' == ntp_status:
                multi_result = self.multi_thread_task(
                    host_ip_list, 'timeout 60 ssh $$ /opt/h3c/bin/python /var/lib/ceph/shell/ntp_task.py ntp_return')
                # 修改ntp参数
                add_table_command = "ceph config-key put %s '%s'" % ('clusterconfig', json.dumps(cluster_config))
                result = self.exec_local_cmd(add_table_command)
                self.addOperationlog(fsid, request, u'修改NTP配置', u'success')
                return Response({'status': 'success'})
            # handy的处理
            handy_name = os.popen("hostname").read().strip()
            hosts_info = self.exec_local_cmd('cat /etc/onestor_hosts')
            ips = hosts_info.split('\n')
            local_ip = self._find_ip_by_name(ips, handy_name)

            if '1' == ntp_status:
                # all_node、handy_choose
                all_node = []
                host_all = self._server_list_all()
                for host in host_all:
                    all_node.append(host['fqdn'])
                if handy_name in all_node:
                    handy_choose = 'true'
                else:
                    handy_choose = 'false'
                try:
                    gateway_obj_list = json.loads(os.popen('ceph config-key get gateway').read())['gateway']
                    for gatewayHost in gateway_obj_list:
                        if gatewayHost['hostname'] not in all_node:
                            all_node.append(gatewayHost['hostname'])
                except Exception, e:
                    log.error(e)

                # 加入NAS和MDS节点的主机名, 修改集群内节点时，包含NAS和MDS节点
                # PN:201702070435 
                try:
                    nas_mds_list = self.exec_local_cmd_json('ceph config-key get nas_server_new')
                    for nas_new_info in nas_mds_list['nas_server_new']:
                        if nas_new_info['hostname'] not in all_node:
                            all_node.append(nas_new_info['hostname'])
                except KeyError:
                    pass
                except Exception, e:
                    log.info('get nas or mds server hostname, result is {0}'.format(e))
                # end by l11544 2017/2/10

                # handy_in_mon
                if handy_name in mon_nodes:
                    handy_in_mon = 'true'
                else:
                    handy_in_mon = 'false'
                try:
                    self._create_cluster_config_ntp(
                            str(ntp_status), mon_nodes, local_ip, all_node, handy_choose, handy_in_mon, 'param_write')
                    # 修改ntp参数
                    add_table_command = "ceph config-key put %s '%s'" % ('clusterconfig', json.dumps(cluster_config))
                    result = self.exec_local_cmd(add_table_command)

                    self.addOperationlog(fsid, request, u'修改NTP配置', 'success')
                    return Response({'status': 'success'})
                except ValueError, e:
                    self.addOperationlog(fsid, request, u'修改NTP配置', str(e))
                    return Response({'status': 'error', 'reason': str(e)})

            # 集群外NTP配置，ntp_close值为2
            # 判断IP是否为集群内的IP
            def ntp_in_check(ip_list, ntp_ips):
                """用来判断是否IP已经存在于集群内和用做高可用"""
                check_ips = []
                check_ips = list(set(ip_list) & set(ntp_ips))
                return check_ips

            temp_ip = ntp_in_check(host_ip_list, ntp_servers)
            if len(temp_ip) > 0:
                temp_ip = ','.join(str(ip) for ip in temp_ip)
                cluster_mesage = u'IP地址“%s”与集群已有节点重复，不能再用于提供集群外NTP服务' % temp_ip
                self.addOperationlog(
                        fsid, request, u'修改NTP配置', cluster_mesage)
                return Response(
                        {'status': 'error', 'reason': cluster_mesage})
            try:
                # 配置集群外节点为NTP server输入集群高可用ip没有做判断，配置成功 add by l11544
                # 判断是否为高可用IP，从数据库中获取所有高可用配置
                ha_ips = []
                ha_cfgs = database.list_objs('highavailableconfig')
                handyha_cfgs = self.list_handyha()
                # 获取所有工作节点
                ha_nodes_info = ha_cfgs['highavailableconfig']
                for ha_node_info in ha_nodes_info:
                    ha_ips.append(ha_node_info['vip'])
                for handy_node_info in handyha_cfgs['handyha']:
                    ha_ips.append(handy_node_info['vip'])
                temp_ip = ntp_in_check(ha_ips, ntp_servers)
            except KeyError:
                pass
            except Exception, e:
                log.error(e)
            if len(temp_ip) > 0:
                temp_ip = ','.join(str(ip) for ip in temp_ip)
                high_message = u'IP地址“%s”与集群高可用IP重复，不能再用于提供集群外NTP服务' % temp_ip
                self.addOperationlog(
                        fsid, request, u'修改NTP配置', high_message)
                return Response(
                        {'status': 'error', 'reason': high_message})
            # end by l11544 2016/9/14

            # 判断IP是否可用
            try:
                # add by l11544 PN:201701020048 根据时间偏差判断是否继续向下同步
                if not alter_out:
                    result = self.ntp_ip_check(ntp_servers, 'alter_ntp', None, None, fsid, request)
                    if 'success' != result['status']:
                        return Response(result)
                    # 大于5秒，直接返回，提醒用户
                    alert_judge = result['server_skew_info']['alert_judge']
                    if not alert_judge:
                        log.warning('servers time skew are {0}'.format(result['server_skew_info']))
                        return Response(result)

            except Exception, e:
                log.error(e)
                self.addOperationlog(fsid, request, u'修改NTP配置', str(e))
                return Response({'status': 'error', 'reason': str(e)})
            # 再次检测网络
            result = test_ping_inner()
            if 'success' != result['status']:
                return Response(result)

            # 为所有节点备份NTP配置文件然后添加配置
            result_ntp = self.multi_thread_task(
                host_ip_list, 'timeout 120 ssh $$ /opt/h3c/bin/python /var/lib/ceph/shell/ntp_task.py ntp_write %s'
                              % base64.b64encode(str(ntp_servers)))
            # 判断NTP修改是否完成
            result_ips = []
            for ip in result_ntp:
                if 'ok' != result_ntp[ip]:
                    result_ips.append(ip)
            if len(result_ips) > 0:
                message = u'“%s”修改配置失败' % ','.join(str(ip) for ip in result_ips)
                self.addOperationlog(fsid, request, u'修改NTP配置', message)
                return Response({'status': 'error', 'reason': message})
            # 修改ntp参数
            add_table_command = "ceph config-key put %s '%s'" % ('clusterconfig', json.dumps(cluster_config))
            result = self.exec_local_cmd(add_table_command)

            self.addOperationlog(fsid, request, u'修改NTP配置', 'success')
            return Response({'status': 'success'})
        except Exception, e:
            log.error(e)
            self.addOperationlog(fsid, request, u'修改NTP配置', str(e))
            return Response({'status': 'error', 'reason': str(e)})

    def get_ntp_info(self, request, fsid):
        try:
            result = {}
            # BEGIN ADD by l11544 2016/04/28 用于参数配置服务
            ntp_list = []
            try:
                ntp_in_result = self.ntp_in_judge()
                if 'success' == ntp_in_result['status']:
                    ntp_judge = ntp_in_result['ntp_status']
                else:
                    return Response({'status': 'error', 'reason': u'获取NTP相关配置信息失败'})
                # 集群外
                result['ntp_status'] = ntp_judge
                if '2' == ntp_judge:
                    ntp_list = os.popen(
                            "cat /etc/ntp.conf | grep '^server'| awk '{print $2}'").read().strip().split('\n')
                elif '1' == ntp_judge:
                    # 集群内
                    cluster_info = self.exec_local_cmd_json_v2('ceph config-key get clusterconfig')
                    ntp_list = cluster_info['mon_ip']
                    # 获取优先级最高的节点
                else:
                    log.debug('cluster have not operated')

            except Exception, e:
                log.error('[ONEStor] ntpHost is null or useless %s' % e)
            result['ntp_list'] = ntp_list
            return Response({'status': 'success', 'data': result})
        except Exception, e:
            log.error(e)
            return Response({'status': 'error', 'reason': str(e)})

    # 获取集群基本信息
    def get_ceph_param(self, request, fsid):
        try:
            result = {}
            ceph_config = ONEStorConfig()
            calamari_config = CalamariConfig()

            # PN：201703140363 添加显示管理网段
            section_params = ceph_config.options('global')
            result['manage_network'] = ceph_config.get('global', 'manage_network') if \
                'manage_network' in section_params else ''
            result['disaster_network'] = ceph_config.get('global', 'disaster_network') if \
                'disaster_network' in section_params else ''
            # end by l11544 2017/4/12
            result['fsid'] = ceph_config.get('global', 'fsid')
            #result['osd_journal'] = ceph_config.get('global', 'osd_journal_size')
            #result['osd_flashcache'] = ceph_config.get('global', 'osd_flashcache_size')
            result['public_network'] = ceph_config.get('global', 'public_network')
            result['cluster_network'] = ceph_config.get('global', 'cluster_network')
            result['cluster_time'] = calamari_config.get('calamari_web', 'cluster_interval')
            result['manage_only'] = calamari_config.get('calamari_web', 'manage_only') == 'true'
            if self.exec_local_cmd('timeout 5 ceph fsid') != '':
                get_name_result = send_request_onestord('COMP_HOST', 'NAME_query', {})
                if 'success' == get_name_result['status'] and 0 == get_name_result['response']['result'][0]:
                    result['unistor_cluster_name'] = get_name_result['response']['data']['unistor_cluster_name']
                    result['client_name'] = get_name_result['response']['data']['client_name']
                else:
                    result['unistor_cluster_name'] = ''
                    result['client_name'] = ''
            return Response({'status': 'success', 'data': result})
        except Exception, e:
            log.error(e)
            return Response({'status': 'error', 'reason': str(e)})

    # 修改集群基本配置
    @check_remove_osd_event(const.OP_POST_CEPH_PARAM)
    def post_ceph_param(self, request, fsid):
        try:
            # BEGIN MODIFY BY C13463 20170311 PN:201703030661
            cluster_time = str(request.DATA['clusterTime'])
            manage_only = request.DATA.get('manageOnly', None)
            client_name = request.DATA.get('client_name', None)
            cluster_name = request.DATA.get('unistor_cluster_name', None)
            check_rep = r'^([1-9][0-9]|1[0-1][0-9]|120)$'
            if not re.match(check_rep, cluster_time):
                send_add_oplog_msg(
                    request,
                    ('修改集群服务配置', 'Modify cluster service config'),
                    (-80001, 'This field must be an integer in the range of 10 to 120', '管理平台超时时长只能输入10-120之间的整数')
                )
                return Response({'status': 'error', 'reason': ['This field must be an integer in the range of 10 to 120', u'管理平台超时时长只能输入10-120之间的整数']})
            if manage_only is not None and not isinstance(manage_only, bool):
                send_add_oplog_msg(request, ('修改集群服务配置', 'Modify cluster service config'),
                                   (-6, "Invalid request parameters.", "无效参数"))
                return Response({'status': 'error', 'reason': u'无效参数'})
            # 如果客户名称或者集群名称不为None，则向onestord请求配置
            if None != client_name and '' != client_name:
                post_client_name_result = send_request_onestord('COMP_HOST', 'SET_client_name', {'client_name':client_name})
                if 'success' != post_client_name_result['status'] or 0 != post_client_name_result['response']['result'][0]:
                    send_add_oplog_msg(
                        request,
                        ('修改集群服务配置', 'Modify cluster service config'),
                        (-80000, 'Failed to set the customer name.', '修改客户名称失败')
                    )
                    return Response({'status': 'error', 'reason': ['Failed to set the customer name.', u'修改客户名称失败']})
            if None != cluster_name and '' != cluster_name:
                post_cluster_name_result = send_request_onestord('COMP_HOST', 'SET_cluster_name', {'unistor_cluster_name': cluster_name})
                if 'success' != post_cluster_name_result['status'] or 0 != post_cluster_name_result['response']['result'][0]:
                    send_add_oplog_msg(
                        request,
                        ('修改集群服务配置', 'Modify cluster service config'),
                        (-80000, 'Failed to set the cluster name.', '修改集群名称失败')
                    )
                    return Response({'status': 'error', 'reason': ['Failed to set the cluster name.', u'修改集群名称失败']})
            cluster_time = str(int(cluster_time) * 60)
            calamari_path, message = '/etc/calamari/calamari.conf', ''
            calamari_config = CalamariConfig()
            if os.path.exists("/.dockerenv"):
                self.exec_local_cmd('chmod 777 %s' % calamari_path)
            else:
                self.exec_local_ssh_cmd('chmod 777 %s' % calamari_path)
            self.exec_local_cmd('cp {0} {0}_bak'.format(calamari_path))
            config_update = False
            if manage_only is not None:
                manage_only_str = 'true' if manage_only else 'false'
                calamari_config.set('calamari_web', 'manage_only', manage_only_str)
                config_update = True
            if '' != cluster_time:
                calamari_config.set('calamari_web', 'cluster_interval', cluster_time)
                config_update = True
            if config_update:
                calamari_config.write(open(calamari_path, 'w'))
            # 获取高可用信息，若已经配置高可用，则进行同步
            syn_result = self.syn_calamari_conf()
            if syn_result:
                self.exec_local_cmd('rm -f %s_bak' % calamari_path)
            else:
                self.exec_local_cmd('mv {0}_bak {0}'.format(calamari_path))
                send_add_oplog_msg(
                    request,
                    ('修改集群服务配置', 'Modify cluster service config'),
                    (-80000, 'Fail to sync config to slave node', '同步配置到管理高可用非工作节点失败')
                )
                return Response({'status': 'error', 'reason': ['Fail to sync config to slave node', u'同步配置到管理高可用非工作节点失败']})
            # 改回权限
            if os.path.exists("/.dockerenv"):
                self.exec_local_cmd('chmod 644 %s' % calamari_path)
            else:
                self.exec_local_ssh_cmd('chmod 644 %s' % calamari_path)
            if '' == message:
                message = 'success'
            send_add_oplog_msg(
                request,
                ('修改集群服务配置', 'Modify cluster service config')
            )
            return Response({'status': 'success', 'message': message})
        except Exception, e:
            log.error(e)
            send_add_oplog_msg(
                request,
                ('修改集群服务配置', 'Modify cluster service config'),
                (-80000, str(e), str(e))
            )
            return Response({'status': 'error', 'reason': str(e)})

    # add by l11544 for ntp server
    # 为了解决NTP的IP和新加主机IP重复的情况
    def host_ntp_judge(self, request, fsid):
        # 先判断是否是集群外的NTP配置
        host_ntps = []
        return_type = ''

        try:
            host_ips = request.GET.get('all_node_ip')
            host_ips = host_ips.split(',')
            cluster_deploy = request.GET.get('cluster_deploy')
            host_passwd = request.GET.get('password')
            ntp_in_result = self.ntp_in_judge()

            # 定义错误返回操作日志类型
            if 'add_host_batch' == cluster_deploy:
                return_type = u'批量部署添加主机'
            elif 'add_host_manual' == cluster_deploy:
                return_type = u'单机部署添加主机'
            elif 'add_mon' == cluster_deploy:
                return_type = u'添加监控节点“{0}”'.format(host_ips[0])
            elif 'deploy_gateway' == cluster_deploy:
                return_type = u'添加集群外对象网关'

            if 'success' == ntp_in_result['status']:
                ntp_status = ntp_in_result['ntp_status']
            else:
                self.addOperationlog(fsid, request, return_type, u'获取NTP相关配置信息失败')
                return Response({'status': 'error', 'data': [], 'reason': u'获取NTP相关配置信息失败'})
            if '2' != ntp_status:
                return Response({'status': 'success'})

            # 调用判断主机是否为NTP server端接口判断
            for ip in host_ips:
                host_in_ntp = self.host_in_ntp_out_check(ip, host_passwd, ntp_status)
                if host_in_ntp:
                    host_ntps.append(ip)
        except Exception, e:
            log.error(e)
        if len(host_ntps) > 0:
            str_ips = ','.join(str(ip) for ip in host_ntps)
            test_message = u"IP地址“%s”主机与提供集群外NTP服务主机重复，不能添加到集群内" % str_ips
            self.addOperationlog(fsid, request, return_type, test_message)
            return Response({'status': 'error', 'data': host_ntps})
        return Response({'status': 'success'})

    # END ADD by l11544

    def dashboard(self, request, fsid):
        try:
            returned = {}

            # 获取集群容量信息
            returned['space'] = onestor.space('/etc/ceph/ceph.conf')

            # 获取机架信息
            rack_info = self.exec_local_cmd('timeout 30 ceph osd tree -f json')
            returned['rack_info'] = json.loads(rack_info)

            # 获取环形概览信息
            cluster_health = json.loads(
                    self.exec_local_cmd('timeout 30 ceph -s -f json'))
            try:
                mon_all_count = len(cluster_health['monmap']['mons'])
                mon_ok_count = len(cluster_health['quorum_names'])
            except Exception:
                mon_all_count = 0
                mon_ok_count = 0

            try:
                pg_ok_count = 0
                pg_all_count = cluster_health['pgmap']['num_pgs']
                pg_states = cluster_health['pgmap']['pgs_by_state']

                for pg_state in pg_states:
                    # MODIFY BY D10039 2017/03/11 PN:201610220299
                    if pg_state['state_name'].startswith('active+clean') and \
                                    -1 == pg_state['state_name'].find('inconsistent'):
                        pg_ok_count = pg_state['count']

            except Exception:
                pg_all_count = 0
                pg_ok_count = 0

            try:
                osd_map = json.loads(self.exec_local_cmd(
                        'timeout 30 ceph osd dump -f json'))
                osd_all_count = len(osd_map['osds'])

                osd_ok_count = 0
                for osd in osd_map['osds']:
                    if osd['up'] and osd['in']:
                        osd_ok_count += 1

            except Exception:
                osd_all_count = 0
                osd_ok_count = 0

            returned['health_counters'] = {
                "mon": {
                    "warn": {"count": 0},
                    "critical": {"count": (mon_all_count - mon_ok_count)},
                    "ok": {"count": mon_ok_count}
                },
                "osd": {
                    "warn": {"count": 0},
                    "critical": {"count": (osd_all_count - osd_ok_count)},
                    "ok": {"count": osd_ok_count}
                },
                "pg": {
                    "pgNums": pg_all_count,
                    "warn": {"count": 0},
                    "critical": {"count": (pg_all_count - pg_ok_count)},
                    "ok": {"count": pg_ok_count}
                }
            }

            # 获取主机个数
            cluster_config = self.get_clusterconfig()
            mon_fqdns = cluster_config['mon_fqdns']

            for crush_node in returned['rack_info']['nodes']:
                if 'host' == crush_node['type'] and not crush_node['name'].endswith('_ssd'):
                    if crush_node['name'] not in mon_fqdns:
                        mon_fqdns.append(crush_node['name'])

                # 如果OSD为out状态，也将状态标记为down，集群拓扑页面也要这么处理
                if 'osd' == crush_node['type']:
                    if 0 == float(crush_node['reweight']):
                        crush_node['status'] = 'down'

            returned['servers'] = mon_fqdns

            return Response({'status': 'success', 'reason': returned})
        except Exception, e:
            return Response({'status': 'error', 'reason': str(e)})

    @permit_login
    def health(self, request, fsid):
        """
        获取集群告警信息
        """
        # MODIFY BY KF6602 PN:201804100580
        return Response({
            "report": {'summary': []},
            'alarm_failed': []
        })

    def journalSize(self, request, fsid):
        """
        获取读写分区信息
        """
        try:
            cluster_config = self.get_config_from_conf_file()

            return Response({'status': 'success', 'journal_size': \
                cluster_config['journal_size'], 'flashcache_size': cluster_config['flashcache_size']})

        except Exception:
            return Response({'status': 'error', 'reason': u'获取journal信息失败'})

    def _setOsdStatusById(self, osd_tree, osd):
        try:
            for node in osd_tree['nodes']:
                if int(node['id']) == int(osd['id']):
                    return 'down' if 'down' == node['status'] or 0 == float(node['reweight']) else 'up'

            log.error(
                    '[ONEStor] _setOsdStatusById cannot find osd by id %s', node['id'])
            return 'down'
        except Exception, e:
            log.error('[ONEStor] _setOsdStatusById error: %s', str(e))
            return 'down'

    @staticmethod
    def __get_disk_by_id(disks, disk_id):
        """
        根据硬盘ID获取硬盘信息
        """
        for disk in disks:
            if disk_id == int(disk['id']):
                return disk
        return None

    def serverInfoByFqdn(self, request, fsid):
        """
        获取主机详情
        """
        fqdn = request.GET.get('fqdn')

        ret = self.exec_remote_ssh_cmd(
                fqdn, '/opt/h3c/bin/python /var/lib/ceph/shell/osd-status.py')

        try:
            server_info = json.loads(ret)
        except ValueError:
            log.error('[ONEStor] serverInfoByFqdn result can not json loads')
            return Response({'status': 'error', 'reason': u'主机名称错误', 'errorcode': 'HOSTNAME_ERROR'})
        except Exception, e:
            log.error('[ONEStor] serverInfoByFqdn result can not json loads: %s', e)
            return Response({'status': 'error', 'reason': u'主机名称错误', 'errorcode': 'HOSTNAME_ERROR'})

        try:
            osd_tree = json.loads(self.exec_local_cmd('ceph osd tree -f json'))

            # 从OSD Tree中获取主机的所有OSD ID
            all_osd_id_in_host = []
            for node in osd_tree['nodes']:
                if 'host' == node['type'] and fqdn == node['name'].split('.')[0]:
                    all_osd_id_in_host += node['children']

            # ADD BY D10039 2017/01/14 增加硬盘状态
            progress = self._get_progress('remove_disk')
            mounted_disk = copy.deepcopy(server_info['disk'])

            server_info_id = []
            server_info['disk'] = [osd for osd in server_info['disk']
                                   if int(osd['id']) in all_osd_id_in_host]
            # BEGIN MODIFY BY KF6602 PN:201706220290 maintain下的硬盘状态均标为异常
            maintain_disks = self.__get_maintain_disk(osd_tree)
            for osd in server_info['disk']:
                # DELETE BY D10039 2017/01/17 维护模式
                server_info_id.append(int(osd['id']))
                osd['status'] = self._setOsdStatusById(osd_tree, osd)
                osd['is_mount'] = True if osd['mount'] != '' else False
                if int(osd['id']) in maintain_disks:
                    osd['status'] = 'down'
            # END MODIFY BY KF6602 PN:201706220290

            # 判断是否有umount的硬盘，如果有则显示为暂无数据
            for osd_id in all_osd_id_in_host:
                if osd_id not in server_info_id:
                    server_info['disk'].append({"id": str(osd_id), "is_mount": False, "status": "down"})

            # BEGIN ADD BY D10039 2017/01/14 增加硬盘状态
            server_info['removeHostFlag'] = False
            if progress is not None and fqdn == progress['hostname']:
                if 'disks' in progress and progress['disks'] is not None:
                    for disk in progress['disks']:
                        disk_id = int(disk['id'])
                        if disk_id in server_info_id:
                            osd = self.__get_disk_by_id(server_info['disk'], disk_id)
                            osd['status'] = progress['progress']
                        else:
                            # 处理被移动到maintain下的硬盘
                            maintain_disk = self.__get_disk_by_id(mounted_disk, disk_id)
                            if not maintain_disk:
                                maintain_disk = {
                                    'id': disk['id'],
                                    'is_mount': True,
                                    'mount': '/dev/{0}'.format(disk['name']),
                                    'status': "down"
                                }
                            else:
                                maintain_disk['is_mount'] = True if maintain_disk['mount'] != '' else False
                            maintain_disk['status'] = progress['progress']
                            server_info['disk'].append(maintain_disk)
                else:
                    server_info['removeHostFlag'] = True
                    # ADD BY KF6602 201701230346 删除主机时增加该主机的硬盘状态
                    server_info['disk_status'] = progress['progress']
            # DELETE BY KF6602 PN:201706220290

            # 将df中被移动到maintain下的硬盘标记为down
            all_osd_id_on_page = [int(disk['id']) for disk in server_info['disk']]
            for osd in mounted_disk:
                if int(osd['id']) not in all_osd_id_on_page:
                    osd['status'] = 'down'
                    osd['is_mount'] = True if osd['mount'] != '' else False
                    server_info['disk'].append(osd)
            # END ADD BY D10039 2017/01/14

            # BEGIN ADD BY KF6602 201701230346 删除主机时增加该主机的硬盘状态
            if server_info['removeHostFlag']:
                for disk in server_info['disk']:
                    disk['status'] = server_info['disk_status']
                    # END ADD BY KF6602 201701230346 删除主机时增加该主机的硬盘状态

        except Exception, e:
            log.error('[ONEStor] serverInfoByFqdn get ceph osd tree error: %s', e)

        return Response({'status': 'success', 'data': server_info})

    def _server_list_raw(self):
        nodes = {
            'stor': []
        }

        # 获取存储节点
        try:
            rack_info = json.loads(
                    self.exec_local_cmd('ceph osd tree -f json'))
            for node in rack_info['nodes']:
                if node['type'] == 'host' and (not node['name'].endswith('_ssd')):
                    nodes['stor'].append({'fqdn': node['name']})
        except Exception, e:
            log.error(e)

        return nodes

    def serverList(self, request, fsid):
        """
        获取集群主机列表
        """
        try:
            data_type = request.GET.get('data_type')

            if 'all' == data_type:
                return Response(self._server_list_all())
            # BEGIN ADD BY KF6602 2016/7/25 PN:201607210440 ; 2016/11/11 PN201611050117
            elif 'gateway' == data_type:
                return Response(self._server_list_all(need_handy_self=True, need_handyha=True))
            # END ADD BY KF6602 2016/7/25 PN:201607210440
            elif 'NAS' == data_type or 'MDS' == data_type:
                return Response(self._server_list_all_nas(fsid, data_type))
            # BEGIN ADD BY KF6602 for mr 主机监控需要获取所有主机，包括单独的handy节点和高可用备用节点
            elif 'monitory' == data_type:
                return Response(self._server_list_all_nas(fsid, data_type, need_handy_self=True, need_handyha=True))
            # END ADD BY KF6602 for mr 主机监控需要获取所有主机
            else:
                return Response(self._server_list_raw())

        except Exception:
            return Response({'errorcode': 'INTERNAL_SERVER_ERROR'})

    def _find_ip_by_name(self, ips, host_name):
        for ip in ips:
            ip_pair = ip.split(' ')
            if 2 == len(ip_pair):
                if host_name == ip_pair[1]:
                    return ip_pair[0]
        return None

    def _server_list_all_nas(self, fsid, data_type, need_handy_self=False, need_handyha=False):
        nodes = []
        all_nodes_info = self._server_list_all(need_handy_self, need_handyha)
        for node in all_nodes_info:
            nodes.append(node['fqdn'])
        # # 获取nas表中的主机，添加到列表中
        nas_nodes = self.onestor_request(
                fsid, 'database.list_objs', ['nas_server_new'])
        for nas in nas_nodes['nas_server_new']:
            if nas['hostname'] not in nodes and nas['use'] == data_type:
                all_nodes_info.append({'fqdn': nas['hostname'], 'frontend_addr': nas['hostip']})
        return all_nodes_info

    def updateGatewayPool(self, request, fsid):
        """
        修改对象网关Pool
        """
        try:
            size = request.DATA['size']
        except Exception:
            return Response({'status': 'error', 'reason': u'参数错误'})

        rgw_pools = const.RGW_POOLS.keys()
        try:
            if int(size) > 2:
                pool_min_size = 2
            else:
                pool_min_size = 1

            for pool in rgw_pools:
                self.exec_local_cmd(
                        'ceph osd pool set %s size %s' % (pool, size))
                self.exec_local_cmd(
                        'ceph osd pool set %s min_size %s' % (pool, pool_min_size))

            self.addOperationlog(fsid, request, u'修改Pool “对象网关”', 'success')
            return Response({'status': 'success'})

        except Exception, e:
            self.addOperationlog(fsid, request, u'修改Pool “对象网关”', str(e))
            return Response({'status': 'error', 'reason': e})

    def __check_public_ip(self, public_network, nodes_list):
        """
        nodes_list:节点ip列表
        :return:
        """
        fail_nodes = []
        for node in nodes_list:
            if not self.subnet_judge(public_network, node):
                fail_nodes.append(node)
        return fail_nodes

    def validateNetwork(self, request):
        try:
            # ADD BY D10039 2016/08/16 FOR HANDY HA
            manage_network = request.DATA['manage_network']
            cluster_network = request.DATA['cluster_network']
            public_network = request.DATA['public_network']
            validate_nodes = request.DATA['validate_nodes']
            password = request.DATA['password']
        except Exception:
            return Response({'status': 'error', 'reason': u'参数错误'})

        node_list = validate_nodes.split(',')
        check_reault = self.__check_public_ip(public_network, node_list)
        # 清理掉部署进度信息
        self.exec_local_cmd('rm -rf /tmp/deploy_status')

        filepath = os.path.split(os.path.realpath(__file__))[0]

        try:
            # PN:201512020027 检查Handy自身是否包含业务网段及root密码是否与节点一致
            is_passwd_right_for_handy = self.exec_local_cmd(
                    'timeout 300 /opt/h3c/bin/python %s/handy_common.py scanHost 127.0.0.1 root %s 2>/dev/null' % (
                    filepath, password))
            if '' == is_passwd_right_for_handy or (not json.loads(is_passwd_right_for_handy)['connect']):
                return Response({'status': 'error', 'reason': u'管理平台的root密码不正确，与节点不一致'})

            # BEGIN ADD BY D10039 2016/08/16 FOR HANDY HA
            handy_util = HandyUtil(need_config=False)
            if not handy_util.get_handy_manage_ip(manage_network):
                return Response({'status': 'error', 'reason': u'无法获取管理平台的管理网IP地址'})
            # END ADD BY D10039 2016/08/16 FOR HANDY HA

            is_handy_has_public_network = self.exec_local_cmd(
                    'timeout 300 /opt/h3c/bin/python %s/handy_common.py network_judge 127.0.0.1 root %s %s %s' % (
                        filepath, password, public_network, cluster_network))
            if '' == is_handy_has_public_network or (not json.loads(is_handy_has_public_network)['success']) \
                    or '' == json.loads(is_handy_has_public_network)['public_ip']:
                return Response({'status': 'error', 'reason': u'无法获取管理平台的存储前端网IP地址'})

        except Exception, e:
            log.error('[ONEStor] deploy cluster error, %s', e)

        try:
            threads = []
            results = []
            nodes = validate_nodes.split(',')

            nloops = range(len(nodes))

            def execute(node):
                network_str = self.exec_local_cmd('timeout 300 /opt/h3c/bin/python %s/handy_common.py network_judge'
                                                  ' %s %s %s %s %s None %s' % (
                    filepath, node, 'root', password, public_network, cluster_network, manage_network))
                network_info = json.loads(network_str)
                network_info['ip'] = node
                results.append(network_info)

            for node in nodes:
                t = threading.Thread(target=execute, args=(node,))
                threads.append(t)

            for i in nloops:
                threads[i].start()

            for i in nloops:
                threads[i].join()

            connect_error = []
            manage_network_error = []
            cluster_network_error = []
            public_network_error = []
            manage_mask_error = []
            cluster_mask_error = []
            public_mask_error = []
            disaster_network_error = []
            for node in results:
                if node['success']:
                    # begin add by z11524 PN:201608030094 获取网段ip后再ping下是否连通
                    if '' == node['storage_ip']:
                        cluster_network_error.append(node['ip'])

                    if '' == node['public_ip'] or 0 != len(self.test_ping(node['public_ip'].split(','))):
                        public_network_error.append(node['ip'])
                    # end add by z11524 PN:201608030094 获取网段Ip再ping下是否连通

                    if '' == node['manage_ip']:
                        manage_network_error.append(node['ip'])

                    # 校验掩码
                    if not node['storage_mask_match']:
                        cluster_mask_error.append(node['ip'])
                    if not node['public_mask_match']:
                        public_mask_error.append(node['ip'])
                    if not node['manage_mask_match']:
                        manage_mask_error.append(node['ip'])
                else:
                    connect_error.append(node['ip'])

            return Response({
                'status': 'success',
                'connect_error': connect_error,
                'manage_network_error': manage_network_error,
                'cluster_network_error': cluster_network_error,
                'public_network_error': public_network_error,
                'manage_mask_error': manage_mask_error,
                'public_mask_error': public_mask_error,
                'cluster_mask_error': cluster_mask_error,
                'disaster_network_error': disaster_network_error,
                'network_info': results,
                'check_public_ip_error': check_reault
            })

        except Exception, e:
            return Response({'status': 'error', 'reason': e})

    def bucketInfo(self, request, fsid):
        try:
            uid = request.GET.get('uid')
            radosgw = request.GET.get('radosgw')
            radosgw_client = request.GET.get('radosgw_client')
        except Exception:
            return Response({'status': 'error', 'reason': u'参数错误'})

        try:
            bucket_info = self.onestor_request_node_ssh(
                    radosgw, 'get_gateway_bucket_info', uid, radosgw_client)

            return Response({'status': 'success', 'data': json.loads(bucket_info['reason'])})
        except Exception, e:
            return Response({'status': 'error', 'reason': str(e)})

    def publicNetwork(self, request, fsid):
        try:
            cluster_config = self.get_config_from_conf_file()
            public_network = cluster_config['public_network']

            return Response({'status': 'success', 'public_network': public_network})
        except Exception, e:
            return Response({'status': 'error', 'reason': str(e)})

    def getTimeZone(self, request, fsid):
        try:
            date_info = self.exec_local_ssh_cmd("date -R")
            zone_info = date_info.split(' ')[5]

            where = zone_info[0]
            diff = int(zone_info[1:3])

            ratio = 1 if '+' == where else -1

            diff_hour = diff * ratio - 8
            diff_time = diff_hour * 60 * 60 * 1000

            return Response({'status': 'success', 'diff_hour': diff_hour, 'diff_time': diff_time})
        except Exception, e:
            return Response({'status': 'error', 'reason': str(e)})

    def execteRemoteCmd(self, request, fsid):
        try:
            node = request.DATA['node']
            command = request.DATA['command']
        except Exception:
            return Response({'status': 'error', 'reason': u'参数错误'})

        try:
            result = self.exec_remote_ssh_cmd(node, command)
            return Response({'status': 'success', 'result': result})
        except Exception, e:
            return Response({'status': 'error', 'reason': str(e)})

    def version(self, request):
        # begin modify by d11564 207/1/14 取版本的第一行 PN:201701090016
        ver = self.exec_local_cmd("cat /etc/onestor_external_version 2>/dev/null | awk 'NR==1'")
        # end modify by d11564
        release_date = self.exec_local_cmd("cat /etc/onestor_external_version 2>/dev/null | "
                                           "grep '^Release date\s' | awk '{print $3}'")
        return Response({'version': ver, 'release_date': release_date})

    def keepAlive(self, request):
        return Response([])

    # MODIFY BY KF6602 2016/8/12 PN:201607180087
    def reset_gateway_password(self, request, fsid):
        try:
            name = request.DATA['name']
            passwd_new_b64 = request.DATA['passwd_new']
            # ADD BY KF6602 2016/8/12 PN:201607180087
            user_type = request.DATA['user_type']
        except KeyError:
            self.addOperationlog(
                    # MODIFY BY KF6602 2016/8/12 PN:201607180087
                    fsid, request, u'重置%s用户“%s”的密码' % (user_type, name), u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误'})

        # BEGIN ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关
        gateway_ip, client_name, node = self._get_useful_gateway()
        if gateway_ip is None:
            self.addOperationlog(fsid, request, u'重置%s用户“%s”的密码' % (user_type, name), u'无可用的对象网关')
            return Response({'status': 'error', 'reason': u'无可用的对象网关'})
        # END ADD BY KF6602 2016/8/16 PN:201607300001 寻找并返回可用的对象网关

        # BEGIN ADD BY KF6602 2016/8/6 PN:201607180087
        if user_type == 'S3':
            results = self.onestor_request_node_ssh(
                    node, 'reset_password_s3', name, passwd_new_b64, client_name)
        else:
            results = self.onestor_request_node_ssh(
                    node, 'reset_password_swift', name, passwd_new_b64, client_name)
        if 'success' != results['status']:
            log.error('reset %s type user %s password failed, reason is: %s', user_type, name, results['reason'])
            results = {'status': 'error', 'reason': u'操作失败，详见后台日志'}
        self.addOperationlog(fsid, request, u'重置%s用户“%s”的密码' % (user_type, name), results)
        # END ADD BY KF6602 2016/8/6 PN:201607180087
        return Response(results)

    @check_cluster_dispace(const.OP_RBD_TO_LUN)
    @assert_tgtd_normal(const.OP_CREATE_LUN)
    def convertRBDToLUN(self, request, fsid):
        """
        RBD转化为存储卷接口
        ADD BY D10039 2016/08/26 PN:201608160171
        增加并发保护
        """
        is_need_prevent = False
        try:
            self._prevent_meantime_action('creating_lun')
            return self.convert_rbd_to_lun(request, fsid)
        except IOError, ex:
            log.exception(ex)
            is_need_prevent = True
            error_reason = '正在创建其它存储卷，请稍后再试'
            self.addOperationlog(fsid, request, u'创建存储卷“%s”' % request.DATA['rbd_name'], error_reason)
            return Response({'status': 'error', 'reason': error_reason, 'errorcode': 'SYSTEM_BUSY'})
        finally:
            if not is_need_prevent:
                self.exec_local_cmd('rm -r /tmp/.creating_lun')

    # BEGIN ADD by d10039 2016/02/23 PN:201511070269
    def convert_rbd_to_lun(self, request, fsid):
        try:
            target_name = request.DATA['target_name']
            pool_name = request.DATA['pool_name']
            lun_name = request.DATA['rbd_name']
            rbd_size = request.DATA['rbd_size'] if request.DATA.has_key('rbd_size') else 0
            snap_name = request.DATA.get('snap_name', None)
            matadata = request.DATA['matadata']
            is_disaster = request.DATA.get('is_disaster', None)
        except KeyError:
            return Response({'status': 'error', 'reason': u'输入参数错误'})

        # begin add by z11524 2017/11/6 PN:201711010789
        luns = self.onestor_request(fsid, 'database.list_objs', ['iscsilun'])
        if 'status' not in luns or 'error' == luns['status']:
            for lun in luns['iscsilun']:
                if lun_name == lun['lun_name']:
                    return Response({'status': 'error', 'reason': u'已存在该存储卷，不能重复创建！'})
        # end add by z11524 2017/11/6 PN:201711010789

        # 检查集群存储卷数量规格是否超上限
        # PN: 201704130123 集群可以创建的最大存储卷的数量超过了256
        restrict_result = self.restrict_lun_num(matadata, target_name)
        if not restrict_result['not_restrict']:
            log.error('lun numbers over restrictions')
            self.addOperationlog(fsid, request, u'创建存储卷“%s”' % lun_name, restrict_result['restrict_reason'])
            return Response(
                    {'status': 'error', 'reason': restrict_result['restrict_reason']})
        # End by l11544 2017/5/20

        createArgv = []
        if snap_name is not None:
            lun_name = lun_name + '@' + snap_name
            createArgv.append('readonly=1')

        # 根据target名称获取target的id
        target_by_name = database.find_one(
                'iscsitarget', [{'target_name': target_name}])
        target_info = target_by_name[
            0] if 0 < len(target_by_name) else None

        if None == target_info:
            return Response({'status': 'error', 'reason': u'无法查询到当前的Target信息'})

        target_id = target_info['target_id']

        # 获取各个节点上的lun id
        try:
            current_lun_ids = self.onestor_request_all_node(
                    'get_current_lun_id', target_id)
            lun_id_list = []
            for lun_ids in current_lun_ids['error']:
                if 'Host is unreachable' == lun_ids:
                    self.addOperationlog(
                            fsid, request, u'创建存储卷“%s”' % lun_name, u'有节点存在网络故障')
                    return Response({'status': 'error', 'reason': u'创建存储卷失败，有节点存在网络故障'})

                lun_id_list.append(int(max(json.loads(lun_ids))))

            lun_id = max(lun_id_list) + 1
        except ValueError:
            log.error('[ONEStor] create lun, get lun_ids error, lun_ids is not integer')
            lun_id = target_info['lun_id'] + 1

        # 若选择的是转为灾备卷,需要保证容灾处于开启状态 add by l11544 2017/5/25
        usage_mode = ''
        if is_disaster:
            back_error, usage_mode = '', 'disaster'
            disaster_exist = self.disaster_pool_exist()
            if not disaster_exist:
                back_error = u'容灾处于关闭状态'
            if len(database.find('iscsilun', [{'target_name': target_name}])):
                back_error = u'当前Target已经存在存储卷'
            if '' != back_error:
                self.addOperationlog(fsid, request, u'创建存储卷“%s”' % lun_name, back_error)
                return Response({'status': 'error', 'reason': back_error})

        # 到各个节点上创建存储卷
        log.info('[ONEStor] create lun target_id is %s, lun_id is %s, matadata is %s, rbd_name is %s, rbd use as %s',
                 target_id, lun_id, matadata, lun_name, usage_mode)
        results = self.onestor_request_all_node(
            'create_lun', target_id, lun_id, matadata, lun_name, target_name, '0', 'none', *createArgv)
        self.updateLunID2Tgt(fsid, target_id, target_name, lun_id, 'add', usage_mode)

        if not results['success']:
            # 只要有一个节点创建LUN失败，所有的节点都清理掉该LUN
            self.onestor_request_all_node(
                'remove_lun', target_id, lun_id, pool_name, lun_name, target_name)
            self.updateLunID2Tgt(fsid, target_id, target_name, 0, 'delete')
            self.addOperationlog(fsid, request, u'创建存储卷“%s”' %
                                 lun_name, '在节点“%s”上创建存储卷失败' % results['nodes'])
            return Response({'status': 'error', 'reason': u'在节点“%s”上创建存储卷失败' % results['nodes']})

        # 所有操作都成功后将LUN保存到数据库
        self.addLun2DB(fsid, [lun_id, lun_name, target_id,
                              target_name, pool_name, lun_name, rbd_size,
                              '{0}/{1}转化的存储卷'.format(pool_name, lun_name), matadata, usage_mode])

        # 获取当前lun的数据库ID
        lun_database_id = 0
        luns_in_target = database.find_by_target_id(target_id)
        for _lun in luns_in_target:
            if _lun['lun_id'] == lun_id:
                lun_database_id = _lun['id']
                break

        # 修改RBD的类型为iSCSI Target，即将lun的数据库ID更新到rbd上
        rbds_in_pool = database.find('rbdlist', [{'pool_name': pool_name}])
        for _rbd in rbds_in_pool:
            if _rbd['rbd_name'] == lun_name:
                database.update_obj('rbdlist', _rbd['id'], [
                    _rbd['rbd_name'],
                    _rbd['rbd_size'],
                    _rbd['pool_name'],
                    _rbd['rbd_type_convert'],
                    _rbd['snap_nums'],
                    _rbd['is_clone'],
                    _rbd['baseon_snap_name'],
                    lun_database_id,
                    _rbd['rbd_description'] if 'rbd_description' in _rbd else '',
                    _rbd['matadata'],
                    usage_mode
                ])
                break

        # 发送消息给scheduler创建灾备存储卷
        if is_disaster:
            try:
                messanger.send_create_onbackup_lun_msg(pool_name, lun_name, target_name, lun_id)
            except ONEBackupError as ex:
                log.error('add lun from backup error, reason is: %s', ex.reason)
            except Exception as e:
                log.error('add lun from backup error, reason is %s', e)

        self.addOperationlog(fsid, request, u'创建存储卷“%s”' % lun_name, 'success')
        return Response({'status': 'success', 'luns': luns_in_target})

    # add by w15064 2017/12/27 PN: 201712130381
    def process_remove_lun_result(self, request, fsid, results, rbd_name):
        """处理删除存储卷的逻辑，当有节点上的存储卷上存在读写业务时，提示用户存储卷上正在进行读写业务，并提示用户是否继续删除"""
        if not results['success']:
            log.error('[ONEStor process_remove_lun_result] {}'.format(results))
            error = results.get('error', None)  # get error reasons or get default value None
            # continue_ = False
            if error is not None and isinstance(error, list):
                # tgtadm: can't find the session is thrown,
                # but tgt info within memory and configuration file is cleared, so just ignore the error
                # if all errors on error nodes is tgtadm: can't find the session,
                # just ignore `tgtadm: can't find the session` errors
                session_not_found = "tgtadm: can't find the session"
                continue_ = all(map(lambda err: err == session_not_found, error))
                # WARNING 由于 self.onestor_request_all_node() 是在多线程执行的，
                # 返回的 results['nodes'] 和 results['error'] 不一定是对应的，所以根据返回值无法判断哪个节点是处于active的状态
                # 若返回的错误结果只包含 lun_not_found 和 lun_is_active ，则返回
                error_nodes = results['nodes'].split(',')
                lun_not_found = "tgtadm: can't find the logical unit"
                lun_is_active = 'tgtadm: this logical unit is still active'
                is_deleted = all(map(lambda err: err == lun_not_found, error))
                active = lambda err: err == lun_not_found or err == lun_is_active
                is_active = lun_is_active in error and all(map(active, error))
                other_errors = not(continue_ or is_deleted or is_active)
                if continue_:
                    log.info("error: tgtadm: can't find the session was ignored")
                if is_deleted:
                    log.info('luns on nodes {} was previously deleted'.format(error_nodes))
                if is_active: # 处理删除存储卷时发生的 active 错误
                    log.info('lun is active, try delete again')
                    self.addOperationlog(fsid, request, u'删除存储卷“{}”'.format(rbd_name), u'存储卷“{}”上存在读写业务'.format(rbd_name))
                    return Response({'status': 'error',
                                     'errno' : 'BUSY',
                                     'reason': u'存储卷“{}”上存在读写业务'.format(rbd_name)})
                if other_errors:
                    log.info('unknown error occurred')
                    self.addOperationlog(fsid, request, u'删除存储卷“{}”'.format(rbd_name), u'操作失败，详见后台日志')
                    return Response({'status': 'error','errno': 'UNKNOWN', 'reason': u'操作失败，详见后台日志'})
            else:
                log.error('[ONEStor process_remove_lun_result] {}'.format(error))

    @check_cluster_dispace(const.OP_LUN_TO_RBD)
    @assert_tgtd_normal(const.OP_REMOVE_LUN)
    def convertLUNToRBD(self, request, fsid):
        """
        存储卷转化为RBD接口
        ADD BY z11524 2017/08/11 PN:201707310397
        增加并发保护
        """
        is_need_prevent = False
        try:
            self._prevent_meantime_action('removing_lun')
            return self.convert_lun_to_rbd(request, fsid)
        except IOError, ex:
            log.exception(ex)
            is_need_prevent = True
            error_reason = '正在删除其它存储卷，请稍后再试'
            self.addOperationlog(fsid, request, u'删除存储卷“%s”' % request.GET.get('rbd_name'), error_reason)
            return Response({'status': 'error', 'reason': error_reason, 'errorcode': 'SYSTEM_BUSY'})
        finally:
            if not is_need_prevent:
                self.exec_local_cmd('rm -r /tmp/.removing_lun')

    def convert_lun_to_rbd(self, request, fsid):
        try:
            rbd_name = request.GET.get('rbd_name')
            lun_id = int(request.GET.get('lun_id'))
            pool_name = request.GET.get('pool_name')
            matadata = request.GET.get('matadata')
        except ValueError:
            return Response({'status': 'error', 'reason': u'参数错误'})

        if self.isRBDInDisasterBackup(rbd_name, matadata, fsid):
            self.addOperationlog(fsid, request, u'删除存储卷“%s”' %
                                 rbd_name, u'异地灾备的块设备不支持删除，请先删除备份策略')
            return Response({'status': 'error', 'reason': u'异地灾备的块设备不支持删除，请先删除备份策略'})

        # 先测试网络是否都通
        ping_results = self.onestor_request_all_node('ping')
        for state in ping_results['error']:
            if 'Host is unreachable' == state:
                self.addOperationlog(
                        fsid, request, u'删除存储卷“%s”' % rbd_name, u'有节点存在网络故障')
                return Response({'status': 'error', 'reason': u'删除存储卷失败，有节点存在网络故障'})

        # 通过LUN ID获取LUN的详情
        lun_info = self.onestor_request(
                fsid, 'database.find_by_id', ['iscsilun', lun_id])

        if 'NotFound' == lun_info or None == lun_info:
            self.addOperationlog(
                    fsid, request, u'删除存储卷“%s”' % rbd_name, u'存储卷不存在')
            return Response({'status': 'error', 'reason': u'删除存储卷失败，存储卷“%s”不存在' % rbd_name})

        results = self.onestor_request_all_node('remove_lun', lun_info['target_id'], lun_info['lun_id'],
            matadata, rbd_name, lun_info['target_name'])

        response = self.process_remove_lun_result(request, fsid, results, rbd_name)
        if response:
            return response

        self.removeLunFromDB(fsid, lun_id)
        self.updateLunID2Tgt(fsid, lun_info['target_id'], lun_info['target_name'], 0, 'delete')

        # 根据LUN ID查找rbd
        if '@' not in rbd_name:
            _rbd = database.find('rbdlist', [{'lun_id': lun_id}])[0]

            # 修改块设备的类型为RBD，将rbd的LUN ID修改为-1
            database.update_obj('rbdlist', _rbd['id'], [
                _rbd['rbd_name'],
                _rbd['rbd_size'],
                _rbd['pool_name'],
                _rbd['rbd_type_convert'],
                _rbd['snap_nums'],
                _rbd['is_clone'],
                _rbd['baseon_snap_name'],
                -1,
                _rbd['rbd_description'] if 'rbd_description' in _rbd else '',
                _rbd['matadata'],
                ''
            ])

        # 发送消息给scheduler删除灾备存储卷
        if 'disaster' == lun_info['usage_mode']:
            try:
                messanger.send_remove_onbackup_lun_msg(matadata, rbd_name)
            except Exception, e:
                log.error('remove lun from backup error, reason is %s', e)

        self.addOperationlog(fsid, request, u'删除存储卷“%s”' % rbd_name, 'success')
        return Response({'status': 'success'})
        # END ADD by d10039 2016/02/23 PN:201511070269

    # 函 数 名  :detectNetworkStatus
    # 创建日期  :2016年02月28日
    # 作    者  :戴新春 10039
    # 函数描述  :部署过程中检查各个节点的网络状况
    # 输入参数  :无
    # 输出参数  :无
    # 返 回 值  :成功返回success，失败返回错误码
    # 注意事项  :无
    # ------------------------------------------------------------------
    #   修改历史
    #   日期        姓名             描述
    # --------------------------------------------------------------------
    def detectNetworkStatusWhenDeploy(self, request):
        all_node_ip = request.GET.get('all_node_ip', None)
        # ADD BY D10039 2016/05/28 PN:201605030179 不传参则表示为部署集群
        deploy_type = request.GET.get('deploy_type', 'cluster')
        task_id = request.GET.get('task_id', None)
        current_task = {}

        if None == all_node_ip:
            return Response({'success': False, 'reason': 'all_node_ip is null'})

        # 如果是收集日志，需要先获取到所有的节点
        if '' == all_node_ip and 'collect_log' == deploy_type:
            node_ips = self.get_all_hostIp()
            all_node_ip = ','.join(str(ip) for ip in node_ips)

        failed_nodes = self.test_ping(all_node_ip.split(','))
        deploy_finish = False
        if 0 == len(failed_nodes):
            # 检查到网络没有故障时需要检查当前任务是否已经完成
            tasks_info = self.read_progress(const.ONESTOR_PROGRESS, deploy_type, task_id)
            current_task = tasks_info['current_task']
            # begin add by d11564 2017/05/17 PN:201704140205 部署集群卡在99%，实际已成功
            has_deploy_status = os.path.exists('/tmp/deploy_status')
            has_fsid = self.exec_local_cmd('timeout 30 ceph fsid 2>/dev/null')
            if not has_deploy_status and has_fsid != '':
                deploy_finish = True
            # end add by d11564 2017/05/17 PN:201704140205
            return Response({
                'success': True,
                'failed_nodes': failed_nodes,
                'current_task': current_task,
                'finish': deploy_finish
            })

        # MODIFY BY D10039 2016/05/28 PN:201605030179 部署集群的时候才执行清理操作
        if 'cluster' == deploy_type:
            # 清理各个节点上的配置文件
            log.info('[ONEStor] network fault, clear config on node %s' % all_node_ip)
            self.multi_thread_task(
                    all_node_ip.split(','), "timeout 120 ssh $$ /opt/h3c/bin/python /var/lib/ceph/shell/destroy.py 2>/dev/null")

            # 杀掉Handy上所有正在执行的/opt/h3c/bin/python脚本
            self.exec_local_cmd('pkill /opt/h3c/bin/python')
            self.exec_local_cmd('rm -f /home/ceph-cluster/*')
        elif 'collect_log' == deploy_type:
            log.info('collect_logs process been killed')
            for ip in failed_nodes:
                self.exec_local_cmd(
                        "kill -9 $(ps -ef | grep %s | grep 'collect_log.py' | grep -v 'color=auto' | awk '{print $2}')"
                        % ip)
        else:
            # 操作失败时kill相应的进程
            self._kill_progress(deploy_type, all_node_ip)
            # 获取当前任务状态并返回给页面
            current_task = self.__update_onestor_task(deploy_type, task_id)
        return Response({
            'success': True,
            'failed_nodes': failed_nodes,
            'current_task': current_task,
            'finish': deploy_finish
        })

    def __update_onestor_task(self, op, task_id):
        """
        网络故障时更新任务状态并返回当前任务
        """
        tasks_info = self.read_progress(const.ONESTOR_PROGRESS, op, task_id)
        current_task = tasks_info['current_task']
        for task in tasks_info['tasks']:
            if task_id == task['task_id'] and 'finish' != current_task['status']:
                current_task['errorcode'] = task['errorcode'] = const.NETWORK_FAULT
                current_task['error_reason'] = task['error_reason'] = const.ERR_NETWORK_FAULT
                break
        self.write_progress(const.ONESTOR_PROGRESS, tasks_info['tasks'])
        return current_task

    @staticmethod
    def __set_killed_progress_info(all_node_ip):
        """
        根据当前的操作类型生成需要杀掉的进程列表
        [[xx], [xx, xx]] 表示每一个操作需要kill的进程列表
        [xx]表示匹配 'ps -ef | grep xx'
        [xx1, xx2]表示匹配 'ps -ef | grep xx1 | grep xx2'
        Date: 2017/01/23
        """
        add_disk_list = [
            ['add_disk.py']
        ]
        add_mon_list = [
            ['scp', all_node_ip],
            [all_node_ip, 'add_mon'],
            [all_node_ip, 'mon add'],
            ['ssh {0}'.format(all_node_ip)],
            ['handy_common.py install_soft'],
            ['ssh', 'ntpdate -u {0}'.format(all_node_ip)],
            [all_node_ip, 'handy_common.py network_judge'],
            [all_node_ip, 'handy_common.py exec_remote_cmd']
        ]
        remove_mon_list = [
            ['ssh {0}'.format(all_node_ip)]
        ]
        remove_host_list = [
            ['remove_host.py'],
            ['ssh {0}'.format(all_node_ip)]
        ]
        distro = platform.dist()[0]
        if distro == "centos":
            remove_disk_list = [
                ['&& systemctl stop ceph-osd@{}.service'],
                ['remove_disk.py']
            ]
        else:
            remove_disk_list = [
                ['&& stop ceph-osd id='],
                ['remove_disk.py']
            ]
        add_host_single_list = [
            ['deploy_disk.py'],
            ['scp', all_node_ip],
            ['ssh {0}'.format(all_node_ip)],
            ['handy_common.py install_soft'],
            ['ssh', 'ntpdate -u {0}'.format(all_node_ip)],
            [all_node_ip, 'handy_common.py network_judge'],
            [all_node_ip, 'handy_common.py exec_remote_cmd']
        ]
        create_handy_ha_list = [
            ['scp', all_node_ip],
            ['handy_common.py install_soft'],
            ['handy_common.py exec_remote_cmd'],
            ['ssh {0}'.format(all_node_ip)],
            [all_node_ip, 'handy_common.py network_judge']
        ]
        remove_handy_ha_list = [
            ['close_tgt_ha.py'],
            ['ssh {0}'.format(all_node_ip)]
        ]
        create_rgw_list = [
            ['install_rgw.sh '],
            ['ssh {0}'.format(all_node_ip)],
            ['handy_common.py exec_remote_cmd']
        ]
        remove_rgw_list = [
            ['ssh {0}'.format(all_node_ip)]
        ]
        return {
            'add_disk': add_disk_list,
            'add_mon': add_mon_list,
            'remove_mon': remove_mon_list,
            'remove_stor': remove_host_list,
            'remove_disk': remove_disk_list,
            'add_stor': add_host_single_list,
            'create_handy_ha_cfg': create_handy_ha_list,
            'remove_handy_ha_cfg': remove_handy_ha_list,
            'deploy_gateway': create_rgw_list,
            'remove_gateway': remove_rgw_list
        }

    def _kill_progress(self, deploy_type, all_node_ip):
        """
        操作失败时kill相应的进程
        Date: 2017/01/23
        """
        # 获取需要kill的进程列表
        killed_progress = self.__set_killed_progress_info(all_node_ip)
        if deploy_type not in killed_progress:
            return
        with open('/tmp/.network_error', 'wb') as _file:
            _file.write(deploy_type)
        sleep(1)
        for kill_item in killed_progress[deploy_type]:
            kill_msg_list = "ps -ef"
            for kill_msg in kill_item:
                kill_msg_list += " | grep '" + kill_msg + "'"
            if 1 == len(kill_item):
                kill_msg_list += " | grep -v grep | awk '{print $2}'"
            else:
                kill_msg_list += " | awk '{print $2}'"
            self.exec_local_cmd("kill -9 $({0})".format(kill_msg_list))

    def netdisk_state(self, request, fsid):
        """
        PN:201606150545 增加批量导入用户功能开关 2016/06/16
        :param request:
        :param fsid:
        :return:
        """
        netdisk_switch = config.get('calamari_web', 'netdisk_switch')
        return Response({'status': netdisk_switch})

    def mon_op_switch(self, request, fsid):
        """
        增加MON功能开关 2016/06/23
        :param request:
        :param fsid:
        :return:
        """
        mon_switch = config.get('calamari_web', 'mon_op_switch')

        # begin add by z11524 2017/11/2 PN:201710200205
        public_network = self.get_clusterconfig()['public_network']
        return Response({'status': mon_switch, 'mask': public_network})

    # def partition_is_empty(self, request, fsid):
    #     """
    #     判断root partition下是否有子分区 by h13051 2017/02/21
    #     :param request: 请求体
    #     :param fsid: 集群ID
    #     :return:
    #     """
    #     partition_name = request.DATA['partition_name']
    #     root_empty = is_root_empty(partition_name)
    #     log.info('do function partition_is_empty, partition is {0}, return is {1}'.format(partition_name,
    #                                                                                       root_empty))
    #     if root_empty:
    #         return Response({'success': True, 'is_empty': True})
    #     return Response({'success': True, 'is_empty': False})

    def get_sys_time(self, request, fsid):
        """
        获取系统时间 2017/07/19
        :param request:
        :param fsid:
        :return:
        """
        try:
            date = os.popen("timeout 10 date +%Y-%m-%d").read()
            time = os.popen('timeout 10 date "+%Y-%m-%d %H:%M:%S"').read()
            log.info(u'system-log get systime=%s' % time)
            if '-' in str(time):
                return Response({'status': 'success', 'date': date, 'time': time})
            else:
                return Response({'status': 'error'})
        except Exception, e:
            log.error('[ONEStor] system-log get systime error, %s', e)
            return Response({'status': 'error'})


class PermissionManage(RPCViewSet):
    def create_permission(self, request):
        if request.user.is_superuser:
            try:
                content_type = ContentType.objects.get_for_model(Task)
                permission = Permission.objects.create(codename='cluster', name='cluster',
                                                       content_type=content_type)
                rt = permission.name
                return Response({'success': True, rt: rt})
            except Exception, e:
                raise e

    def permission_list(self, request):
        if request.user.is_superuser:
            try:
                permissions = Permission.objects.all()
                rt = [{'name': permission.name} for permission in permissions]
                return Response({'success': True, 'rt': rt})
            except Exception, e:
                raise e

    def permission_user(self, request):
        if request.user.is_superuser:
            try:
                username = request.DATA['username']
                user = User.objects.get(username=username)
                permissiontemps = request.user.get_group_permissions()
                permissions = {permission[22:]: True for permission in permissiontemps if permission.startswith(
                        'calamari_rest.operate')}
            except Exception, e:
                raise e


# 新增邮件告警特性类和方法
# 类 名 : EmailAlertViewSet
# 创建日期 ：2016年1月15日
# 作 者 ：党妮 d11564
# 函数描述 ：邮件告警特性后台方法
# 输入参数 ：无
# 输出参数 ：无
# 返 回 值 :
# 注意事项 :
# ------------------------------------------------------------------
# 修改历史
# 日期 姓名 描述
# --------------------------------------------------------------------


class EmailAlertViewSet(ONEStorCommon):
    """
    add by d11564 2016/01/10
    """

    def add_mail_servers(self, request, fsid):
        try:
            server_address = request.DATA['serverAddress']
            port_number = int(request.DATA['portNumber'])
            sender_address = request.DATA['senderAddress']
            user_name = request.DATA['userName']
            password = base64.b64decode(request.DATA['passWord'])
            ifemailguide = request.DATA['ifEmailGuide']
            alarm_interval = int(request.DATA['alarmInterval'])
            err_msg = ''
        # except ValueError:
        #     self.addOperationlog(fsid, request, u'配置邮件服务器', u'端口号必须是数字')
        #     err_msg = u'端口号必须是数字'
        except Exception:
            self.addOperationlog(fsid, request, u'配置邮件服务器', u'输入参数错误')
            err_msg = u'输入参数错误'
        if '' != err_msg:
            return Response({'status': 'error', 'reason': err_msg})

        if alarm_interval < 5 or alarm_interval > 60:
            self.addOperationlog(fsid, request, u'配置邮件服务器', u'告警间隔需要在5-60分钟之间')
            return Response({'status': 'error', 'reason': u'告警间隔需要在5-60分钟之间'})

        params = [server_address, port_number,
                  sender_address, user_name, password, alarm_interval]

        try:
            try:
                nowtime = time.strftime('%Y-%m-%d %X', time.localtime())
                # begin add by d11564 PN:201703070092 loading转圈修改
                support_modules = calamari_web.settings.MODULES
                if support_modules['fs']:
                    email_title = 'Unistor'
                else:
                    email_title = 'ONEStor'
                send_mail_results = send_mail(params, [sender_address],
                                              "【{0}】邮件服务器测试邮件".format(email_title),
                                              "[{0}] 本邮件由{1}系统自动发出，请勿直接回复。".format(nowtime, email_title))
                # end by d11564
                self.addOperationlog(
                        fsid, request, u'配置邮件服务器', send_mail_results)

                # BEGIN MODIFY BY D10039 2016/06/19 PN:201606150109 发送成功才记录到数据库中
                if 'success' == send_mail_results['status']:
                    # ADD BY KF6618 2016/08/01 PN:201607270198
                    alarmdb.clear()
                    # begin modify by d11564 2017/04/14 PN:201704110650 密码加密后传入数据库
                    params_db = [server_address, port_number, sender_address, user_name, request.DATA['passWord'],
                                 alarm_interval]
                    mail_server = self.onestor_request(
                            fsid, 'database.list_objs', ['mailServers'])
                    if [] != mail_server['mailServers']:
                        self.onestor_request(fsid, 'database.update_obj', ['mailServers',
                                                                           mail_server['current_id'], params_db])
                    else:
                        self.onestor_request(
                                fsid, 'database.add_obj', ['mailServers', params_db])

                    # PN: 201704140262 集群配置管理高可用后，配置邮件告警服务器，集群osd异常，集群正常发送邮件告警
                    # 检测是否有管理高可用，若存在且网络连通则重启监控
                    handy_util = HandyUtil()
                    handy_util.exec_cmd_on_handy_nodes(cmd.CMD_RESTART_ALARM)
                    # end by l11544 2017/4/22
                    if not ifemailguide:
                        return Response(send_mail_results)
                else:
                    return Response(send_mail_results)
                    # END MODIFY BY D10039 2016/06/19 PN:201606150109
            except ValueError:
                self.addOperationlog(
                        fsid, request, u'配置邮件服务器', u'端口号必须是数字')
                err_msg = u'端口号必须是数字'
            except Exception, ex:
                log.error(ex)
                self.addOperationlog(fsid, request, u'配置邮件服务器', str(ex))
                err_msg = u'配置邮件服务器失败'
            if '' != err_msg:
                return Response({'status': 'error', 'reason': err_msg})
        except KeyError:
            self.addOperationlog(fsid, request, u'配置邮件服务器', u'添加数据失败')
            return Response({'status': 'error', 'reason': u'添加数据失败'})
        except Exception, ex:
            log.error(ex)
            self.addOperationlog(fsid, request, u'配置邮件服务器', str(ex))
            return Response({'status': 'error', 'reason': str(ex)})
        # 创建告警接收人
        try:
            receiver_name = request.DATA['receiverName']
            receiver_phone = request.DATA['receiverPhone']
            receiver_email = request.DATA['receiverEmail']
            alram_type = request.DATA['alramType']
            content = u'创建告警接收人“{receiver}”（邮箱：{email_addr}）'.format(receiver=receiver_name, email_addr=receiver_email)
        except KeyError:
            self.addOperationlog(fsid, request, content, u'参数错误')
            return Response({'status': 'error', 'reason': u'参数错误',
                             'receiver': True})
        except Exception:
            self.addOperationlog(fsid, request, content, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误',
                             'receiver': True})
        params_receiver = [receiver_name, receiver_phone, receiver_email, alram_type]
        alarm_response = self.create_alarm_part(request, fsid, params_receiver)
        alarm_response['receiver'] = True
        self.addOperationlog(fsid, request, content, alarm_response)
        return Response(alarm_response)

    def get_mail_servers(self, request, fsid):
        try:
            results = self.onestor_request(
                    fsid, 'database.list_objs', ['mailServers'])
            return Response(results['mailServers'])
        except KeyError:
            return Response({'status': 'error', 'reason': u'获取数据失败'})
        except Exception, ex:
            log.error(ex)
            self.addOperationlog(fsid, request, u'获取邮件服务器失败', str(ex))
            return Response({'status': 'error', 'reason': str(ex)})

    def reset_email_server(self, request, fsid):
        try:
            mail_server = self.onestor_request(
                    fsid, 'database.list_objs', ['mailServers'])
            if '' != mail_server['mailServers']:
                current_id = mail_server['current_id']
                results = self.onestor_request(fsid, 'database.del_obj', [
                    'mailServers', current_id])
                self.addOperationlog(fsid, request, u'重置邮件服务器', results)
                # BEGIN ADD BY D10039 2016/10/09 重置邮件服务器成功后需要清除邮件服务器故障
                mail_servers = database.list_objs('mailServers')
                if 0 == len(mail_servers['mailServers']):
                    alarmdb.clear()
                # END ADD BY D10039 2016/10/09
                return Response(results)
        except KeyError:
            return Response({'status': 'error', 'reason': u'获取数据失败'})
        except Exception, ex:
            log.error(ex)
            self.addOperationlog(fsid, request, u'重置邮件服务器失败', str(ex))
            return Response({'status': 'error', 'reason': str(ex)})

    def add_alarm_receiver(self, request, fsid):
        receiver_name = request.DATA.get('receiverName')
        receiver_phone = request.DATA.get('receiverPhone')
        receiver_email = request.DATA.get('receiverEmail')
        alram_type = request.DATA.get('alramType')
        content = u'创建告警接收人“{receiver}”（邮箱：{email_addr}）'.format(receiver=receiver_name, email_addr=receiver_email)

        if not receiver_name or not receiver_email:
            self.addOperationlog(fsid, request, content, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'参数错误'})
        params = [receiver_name, receiver_phone, receiver_email, alram_type]

        alarm_response = self.create_alarm_part(request, fsid, params)
        self.addOperationlog(fsid, request, content, alarm_response)
        return Response(alarm_response)

    def create_alarm_part(self, request, fsid, params):
        try:
            # 先判断个数是否达到16个
            receiverlist = self.onestor_request(
                    fsid, 'database.list_objs', ['alarmReceiver'])
            if 16 <= len(receiverlist['alarmReceiver']):
                return {'status': 'error',
                        'reason': u'已达到告警接收人数上限（16）'}
            results = self.onestor_request(fsid, 'database.add_obj', [
                'alarmReceiver', params])
            return results
        except KeyError:
            return {'status': 'error', 'reason': u'获取数据失败'}
        except Exception, ex:
            log.error(ex)
            return {'status': 'error', 'reason': str(ex)}

    def get_alarm_receiver(self, request, fsid):
        try:
            results = self.onestor_request(
                    fsid, 'database.list_objs', ['alarmReceiver'])
            return Response(results['alarmReceiver'])
        except KeyError:
            return Response({'status': 'error', 'reason': u'获取数据失败'})
        except Exception, ex:
            log.error(ex)
            self.addOperationlog(fsid, request, u'获取告警接收人失败 ', str(ex))
            return Response({'status': 'error', 'reason': str(ex)})

    def update_alarm_receiver(self, request, fsid):
        receiver_name = request.DATA.get('receiverName')
        receiver_phone = request.DATA.get('receiverPhone')
        receiver_email = request.DATA.get('receiverEmail')
        alram_type = request.DATA.get('alramType')
        current_id = request.DATA.get('alarmId')
        old_receiver_name = request.DATA.get('oldReceiverName')
        old_receiver_email = request.DATA.get('oldReceiverEmail')

        content = u'修改告警接收人“{old_receiver_model}”（邮箱：{old_email_addr_model}）为“{new_receiver_model}”（邮箱：{new_email_addr_model}）'\
            .format(old_receiver_model=old_receiver_name, old_email_addr_model=old_receiver_email,new_receiver_model=receiver_name,new_email_addr_model=receiver_email)
        if not receiver_name or not receiver_email:
            self.addOperationlog(fsid, request, content, u'输入参数错误')
            return Response({'status': 'error', 'reason': u'输入参数错误'})
        params = [receiver_name, receiver_phone, receiver_email, alram_type]
        try:
            results = self.onestor_request(fsid, 'database.update_obj', [
                                           'alarmReceiver', current_id, params])
            self.addOperationlog(fsid, request, content, results)
            return Response(results)
        except KeyError:
            return Response({'status': 'error', 'reason': u'更新数据失败'})
        except Exception, ex:
            log.error(ex)
            self.addOperationlog(fsid, request, content, str(ex))
            return Response({'status': 'error', 'reason': str(ex)})

    def remove_alarm_receiver(self, request, fsid):
        log_content = u'删除告警接收人“{receiver}”（邮箱：{email}）'
        current_id = request.GET.get('alarmId')
        receiver_name = request.GET.get('ReceiverName')
        email_addr = request.GET.get('email')

        if not receiver_name or not email_addr:
            self.addOperationlog(fsid, request, log_content.format(receiver=receiver_name,email=email_addr), u'输入参数错误')
            return Response({'status': 'error', 'reason': u'参数错误'})
        # except Exception:
        try:
            results = self.onestor_request(fsid, 'database.del_obj', ['alarmReceiver', current_id])
            self.addOperationlog(fsid, request, log_content.format(receiver=receiver_name,email=email_addr), results)
             # BEGIN ADD BY D10039 2016/10/09 删除最后一个告警接收人需要清除邮件服务器故障
            alarm_receivers = database.list_objs('alarmReceiver')
            if 0 == len(alarm_receivers['alarmReceiver']):
                alarmdb.clear()
            # END ADD BY D10039 2016/10/09
            return Response(results)
        except KeyError:
            return Response({'status': 'error', 'reason': u'删除数据失败'})
        except Exception, ex:
            log.error(ex)
            self.addOperationlog(fsid, request, log_content.format(receiver=receiver_name,email=email_addr), str(ex))
            return Response({'status': 'error', 'reason': str(ex)})


@api_view(['POST'])
@permission_classes((AllowAny,))
def change_language(request):
    """
    """
    try:
        language_str = request.DATA['language']
        log.info('start to change language_new =%s', language_str)
        language_conf = LanguageDatabase.list_language()
        language_old = language_conf['language']
        if language_old != '':
            if language_old == language_str:
                log.info('the same as language')
            else:
                LanguageDatabase.update_language(language_old, language_str)
        else:
            LanguageDatabase.update_language(language_old, language_str)
        return Response({'status': 'success'})
    except Exception as ex:
        log.error('failed to change language...')
        log.exception(ex)
        return Response({'status': 'error', 'reason': errno.ERR_CHANGE_LANGUATE})


@api_view(['GET'])
@permission_classes((AllowAny,))
def query_language(request):
    """
    :param request:
    :return:
    """
    try:
        language_conf = LanguageDatabase.list_language()
        current_language = request.GET.get('language')
        if language_conf is None:
            language = ''
            lang_obj = {
                'language': current_language
            }
            LanguageDatabase.create_language(lang_obj)
        else:
            language = language_conf['language']
        return Response({'status': 'success', 'data': language})
    except Exception as ex:
        log.error('failed to query language...')
        log.exception(ex)
        return Response({'status': 'error', 'reason': errno.ERR_QUERY_LANGUATE})
