#!/usr/bin/env python
# coding: utf-8


"""
定义操作成功日志
"""

SUCCESS_MODIFY_HANDY_HA = '修改前管理高可用IP地址为{0}，修改后管理高可用为{1}'