#!/usr/bin/python
# coding:utf-8

import platform

"""
定义命令行
"""

CMD_GET_HA_VRID = 'timeout 300 /opt/h3c/bin/python {0}/getvrid_tgt_ha.py'
CMD_OPEN_HA = 'timeout 300 /opt/h3c/bin/python {0}/open_tgt_ha.py {1} {2} {3} {4} {5} {6}'
CMD_CLOSE_HA = 'timeout 300 /opt/h3c/bin/python {0}/close_tgt_ha.py {1} {2} {3}'
CMD_MODIFY_HA = 'timeout 300 /opt/h3c/bin/python {0}/modify_tgt_ha.py {1} {2} {3}'
CMD_LIST_HA = 'timeout 300 /opt/h3c/bin/python {0}/list_ha.py {1}'
CMD_GET_VIP_CONNECT_STATUS = "timeout 300 ip addr | grep '{vip}/' | wc -l && " \
                             "netstat -apn | grep tgtd | grep '{vip}:3260' | grep ESTABLISHED | wc -l"
# modify by z11524 2017/5/18 PN:201705040683
CMD_GET_HANDY_VIP_CONNECT_STATUS = "timeout 300 ip addr | grep '{vip}/' | wc -l && netstat -apn | " \
                                   "grep httpd | grep '{vip}:80' | grep ESTABLISHED | wc -l"
CMD_IP_ADDR = "ip addr | grep brd | grep inet | grep -v 'lo:' | grep -v secondary"
CMD_LIST_NETWORK_INTERFACES = \
    "ip addr | grep brd | grep inet | grep -v 'lo:' | grep -v secondary | awk '{print $2}' | awk -F '/' '{print $1}'"
# add by l11544 2017/6/24
# 获取集群异常PG存储池ID
CMD_GET_CEPH_PG_POOL_ID = "timeout 30 ceph health detail | grep -w 'pg' | grep -v 'grep' | " \
                          "cut -d '.' -f 1 | awk '{print $2}'"
# 获取灾备池的ID
CMD_GET_BACKUP_POOL_ID = "timeout 30 ceph osd pool ls detail | grep .backup | awk '{print $2}'"
CMD_GET_MASK_BY_IP = 'timeout 60 ip addr | grep "inet {0}/" | cut -d / -f 2 | cut -d " " -f 1'

CMD_GET_FSID = 'timeout 60 ceph fsid'
CMD_LIST_POOLS = 'timeout 300 ceph osd pool ls -f json'
CMD_RUN_REMOTE_CMD = "timeout 1800 /opt/h3c/bin/python {0}/handy_common.py exec_remote_cmd {1} {2} \"{3}\" \"{4}\""
CMD_INSTALL_SOFT = "timeout 1800 /opt/h3c/bin/python {0}/handy_common.py install_soft {1} {2} {3} {4} {5} {6}"
CMD_GET_HANDY_PUBLIC_IP = "/opt/h3c/bin/python {0}/handy_common.py getHandyPublicIP {1}"
CMD_CAT_ONESTOR_HOSTS = "cat /etc/onestor_hosts | awk '{print $1,$2}'"
CMD_DATE = 'date'
CMD_HOSTNAME = 'hostname'
CMD_NTPDATE = 'ntpdate -u {0}'
CMD_BACKUP_NTP_CONFIG = 'mv /etc/ntp.conf /etc/ntp.conf.bak 2>/dev/null'
CMD_CONFIG_NTP_CLIENT = ' && echo server {0} iburst minpoll 4 maxpoll 4 >> /etc/ntp.conf'
CMD_SSH_KEY_COPY = '/opt/h3c/bin/python {0}/ssh_key_copy.py {1} {2} {3}'
CMD_ADD_CRON_TASK = 'bash {0}/crontab_task.sh'

CMD_CHECK_SOFT_INSTALLED = 'ceph -v 2>/dev/null && ls /var/lib/ceph/shell/process_detect.sh 2>/dev/null && cat /var/log/h3c/deploy_ceph.log 2>/dev/null'
CMD_CHECK_MON_MC_SOFT_INSTALLED = "cat /opt/h3c/packages.info | grep 'common\|zookeeper' | cut -d = -f 2"
CMD_CHECK_MC_SOFT_INSTALLED = "cat /opt/h3c/packages.info | grep common | cut -d = -f 2"
CMD_CHECK_ZK_SOFT_INSTALLED = "cat /opt/h3c/packages.info | grep zookeeper | cut -d = -f 2"
CMD_CHECK_SSH = 'timeout 30 ssh {0} hostname 2>/dev/null'
CMD_BACKUP_RGW_KEYRING = 'mv /etc/ceph/ceph.client.radosgw.keyring /etc/ceph/ceph.client.radosgw.bak 2>/dev/null'
CMD_RESTORE_RGW_KEYRING = 'mv /etc/ceph/ceph.client.radosgw.bak /etc/ceph/ceph.client.radosgw.keyring 2>/dev/null'
CMD_COPY_CLUSTER_CONFIG = 'timeout 300 scp -p /etc/ceph/*.keyring /etc/ceph/ceph.conf [{0}]:/etc/ceph/'
# PN: 201612260612 增加写入集群主机的业务网IP配置
CMD_COPY_CLUSTER_CONFIG_NO_CEPH = 'timeout 300 scp -p /etc/ceph/*.keyring [{0}]:/etc/ceph/'
CMD_COPY_CLUSTER_CONFIG_FOR_RGW = \
    'timeout 300 scp /etc/ceph/ceph.conf /etc/ceph/ceph.client.admin.keyring [{0}]:/etc/ceph/'
CMD_COPY_VERSION_FILE = 'timeout 300 scp /etc/onestor_*version [{0}]:/etc/'
CMD_COPY_ONESTOR_HOST_FILE = 'timeout 300 scp /etc/onestor_hosts [{0}]:/etc/'
CMD_MKDIR_CEPH_DIR = 'mkdir -p /var/run/ceph'
CMD_GET_SSH_PUB_KEY = 'cat /root/.ssh/id_rsa.pub 2>/dev/null'
CMD_CREATE_SSH_KEY = '/var/lib/ceph/shell/ssh-key-gen.sh'
CMD_EXEC_SSH_PROTECT = '/opt/h3c/bin/python /var/lib/ceph/shell/ssh_protect.py'
CMD_BACKUP_DIAMOND_CONF = 'ls /etc/diamond/diamond.conf.bak ||' \
                          ' cp /etc/diamond/diamond.conf /etc/diamond/diamond.conf.bak'
# add by r13889 2017/03/24 PN:201703160637
CMD_BACKUP_ONESTOR_HOSTS = 'cp -f /etc/onestor_hosts /etc/onestor_hosts.bak'
CMD_SCP_ONESTOR_HOSTS = 'timeout 30 scp /etc/onestor_hosts [$$]:/etc/onestor_hosts && echo OK'
# add by z11524 2016/11/9 PN:201611040049
CMD_RM_DIAMOND_CONF = 'rm -rf /etc/diamond/diamond.conf.bak'
# end by z11524 2016/11/9 PN:201611040049

# add by z11524 2016/11/23 for HA
CMD_CHECK_MANAGE_NET = '/opt/h3c/bin/python {0}/handyha_upgrade.py {1}'
CMD_CREATE_MANAGE_NET = '/opt/h3c/bin/python {0}/handyha_upgrade.py {1} {2}'
CMD_SCP_CEPH_CONF = 'timeout 30 scp /etc/ceph/ceph.conf [{0}]:/etc/ceph/ceph.conf && echo OK'
CMD_BACKUP_CEPH_CONF = 'cp /etc/ceph/ceph.conf /etc/ceph/ceph.conf.bak'
CMD_RECOVER_CEPH_CONF = 'mv /etc/ceph/ceph.conf.bak /etc/ceph/ceph.conf'
CMD_RM_BACKUP_CEPH_CONF = 'rm -rf /etc/ceph/ceph.conf.bak'
CMD_GET_CEPH_CONF_STATUS = "ls /etc/ceph | grep ^ceph.conf$ | wc -l"
CMD_RM_KEEPALIVED_BK = "rm -rf /etc/keepalived/keepalived.conf.bk"
CMD_RESTORE_DIAMOND_CONF = '/opt/h3c/bin/python /var/lib/ceph/shell/reset_diamond.py remove_handyha {0}'
CMD_SETUP_MULTI_DIAMOND = '/opt/h3c/bin/python /var/lib/ceph/shell/setup_diamond.py {0}'
CMD_COPY_HANDY_DB = 'timeout 300 scp {0} [{1}]:/tmp/ && echo success'
CMD_RM_FILE = 'rm -rf {0}'
CMD_RM_SLAVE_HADNY_DB = 'rm -f /tmp/handy.db'
CMD_UNZIP_PROMETHEUS_DATA = 'tar -xf /tmp/data.tar.gz -C /'
CMD_RM_PROMETHEUS_DATA = 'rm -f /tmp/data.tar.gz'
CMD_SET_ONESTOR_PROGRESS = 'echo {0} > {1}'
CMD_GET_ONESTOR_PROGRESS = 'cat {0}'
CMD_GET_HANDY_VERSION = "cat /opt/h3c/etc/handy/info.txt | grep version | cut -d = -f 2"
CMD_GET_SLAVE_HANDY_VER = "cat /opt/h3c/etc/handy/info.txt | grep version | cut -d = -f 2"
CMD_REMOVE_ONESTOR_HOST = "sed -i '/^{0}/,/{1}$/d' /etc/onestor_hosts"
CMD_SSH_SLAVE_HA = 'timeout 300 /opt/h3c/bin/python {0}/io_file.py {1} {2} append'
CMD_SURE_SSH_HA = "cat /etc/ssh/ssh_config | grep 'StrictHostKeyChecking no'"
# add by z11524 2016/11/9 PN:201611100264
CMD_RESTART_ALARM = 'supervisorctl restart alarm'
# and by z11524 2016/11/9 PN:201611100264

CMD_UPDATE_MON_CFG = '/opt/h3c/bin/python /var/lib/ceph/shell/update_mon.py {0} {1} {2}'

PSQL_CREATE_PASSWD = 'echo localhost:5432:calamari:calamari:{0} > /root/.pgpass'
PSQL_CHMOD_PASSWD = 'chmod 0600 /root/.pgpass'
PSQL_UNSET_PASSWD = 'rm -f /root/.pgpass'
PSQL_DUMP_HANDY_DB = 'pg_dump -f {0} -h localhost -U calamari -p 5432 calamari -o'
PSQL_DROP_HANDY_DB = 'sudo -u postgres dropdb calamari'
PSQL_INIT_HANDY_DB = 'sudo -u postgres createdb calamari'
PSQL_IMPORT_HANDY_DB = 'sudo -u postgres psql -d calamari -f /tmp/handy.db'
PSQL_BECOME_MASTER = '/opt/h3c/bin/python /var/lib/ceph/shell/handyha/keepalived_event.py become_master'
PSQL_BECOME_SLAVE = '/opt/h3c/bin/python /var/lib/ceph/shell/handyha/keepalived_event.py become_slave_pre_check'

SERVICE_RESTART_NTP = 'service ntp restart'
SERVICE_RELOAD_APACHE = 'service apache2 reload'
SERVICE_RESTART_APACHE = 'service apache2 restart'
SERVICE_RESTART_DIAMOND = 'service diamond restart'
SERVICE_START_RADOSGW = '/etc/init.d/radosgw start'
SERVICE_RESTART_ONESTORD = 'supervisorctl restart onestor-peon || echo 1 && supervisorctl restart onestor-leader'
SERVICE_RESTART_PSQL = 'service postgresql restart'
SERVICE_RESTART_CARBON = 'supervisorctl restart carbon-cache'

DB_GET_LAST_OP_TIME = "timeout 300 ceph config-key get last_op_time"
DB_UPDATE_LAST_OP_TIME = "timeout 300 ceph config-key put last_op_time '{0}'"
DB_GET_CLUSTER_CONFIG = 'timeout 300 ceph config-key get clusterconfig'
DB_GET_HANDY_KEY = 'timeout 300 ceph config-key get handy_key'
DB_GET_CLUSTER_HOSTS = 'timeout 300 ceph config-key get cluster_hosts'
DB_SAVE_HANDY_KEY = "timeout 300 ceph config-key put handy_key '{0}'"
DB_SAVE_CLUSTER_HOSTS = "timeout 300 ceph config-key put cluster_hosts '{0}'"
DB_SAVE_CLUSTER_CONFIG = "timeout 300 ceph config-key put clusterconfig '{0}' 1>/dev/null 2>&1 && echo ok"
DB_GET_GATEWAY = "timeout 300 ceph config-key get gateway"
DB_GET_HA = "ceph config-key get highavailableconfig"
DB_GET_MAINTAIN = "timeout 300 ceph config-key get maintain"
DB_SAVE_MAINTAIN = "timeout 300 ceph config-key put maintain '{0}'"
DB_LIST = "timeout 300 ceph config-key list"
# begin add by d11564 多mds项目
DB_GET_NAS_SERVER_NEW = 'timeout 300 ceph config-key get nas_server_new'
DB_SAVE_NAS_SERVER_NEW = "timeout 300 ceph config-key put nas_server_new '{0}'"
# end add by d11564 多mds项目
# ADD BY D10039 2017/01/14 FOR MAINTAIN
CMD_CEPH_OSD_TREE = 'timeout 300 ceph osd tree -f json'
CMD_REMOVE_BUCKET = 'timeout 300 ceph osd crush remove {0}'
CMD_MOVE_OSD_BUCKET = "timeout 300 ceph osd crush move osd.{0} {1}={2}"
CMD_MOVE_OTHER_BUCKET = "timeout 300 ceph osd crush move {0} {1}={2}"
CMD_SET_OSD_UNREADY = "mv /var/lib/ceph/osd/ceph-{osd_id}/ready /var/lib/ceph/osd/ceph-{osd_id}/ready_bak"
distro = platform.dist()[0]
if distro == "centos":
    CMD_STOP_OSD = "systemctl stop ceph-osd@{osd_id}.service"
else:
    CMD_STOP_OSD = "stop ceph-osd id={osd_id}"
CMD_GET_HEALTH_STATUS = 'timeout 300 ceph health -f json'
OPEN_DATA_REBLANCE = "timeout 300 ceph osd unset {0}"
CLOSE_DATA_REBLANCE = "timeout 300 ceph osd set {0}"

# BEGIN ADD BY Z11524 FOR replication postgres
OPEN_HANDY_HA_PSQL = '/opt/h3c/bin/python /var/lib/ceph/shell/handyha/open_handy_ha.py {0} {1} {2}'
# begin add by z11524 2017/5/3 PN:201704190103
UPDATE_CEPH_CONF_HANDY = '/opt/h3c/bin/python /var/lib/ceph/shell/handyha/open_handy_ha.py {0} {1} {2} update'
CLOSE_HANDY_HA_PSQL = '/opt/h3c/bin/python /var/lib/ceph/shell/handyha/close_handy_ha.py'
ROLLBACK_HANDY_HA_PSQL = '/opt/h3c/bin/python /var/lib/ceph/shell/handyha/close_handy_ha.py rollback'
CMD_CHECK_PSQL_STATUS = "pidof postgres | wc -l"
CMD_CHECK_ONESTORD_STATUS = "supervisorctl status onestor-leader 2>/dev/null | grep RUNNING | wc -l"
# END ADD BY Z11524 FOR replication postgres

CMD_CHECK_DISK_MOUNT = \
    "df /var/lib/ceph/osd/ceph-{0} 2>/dev/null | grep /var/lib/ceph/osd/ceph | wc -l"
CMD_GET_MANAGE_NETWORK = '/opt/h3c/bin/python /var/lib/ceph/shell/handyha/upgrade.py get_manage_network'
CMD_UPDATE_MANAGE_NETWORK = '/opt/h3c/bin/python /var/lib/ceph/shell/handyha/upgrade.py create_manage_network {0}'
CMD_COPY_INSTALL_RGW_FILE = 'scp /var/lib/ceph/shell/install_rgw.sh [{0}]:/var/lib/ceph/shell/install_rgw.sh'
CMD_COPY_INSTALL_RGW_SHX_FILE = 'scp /var/lib/ceph/shell/install_rgw.sh.x [{0}]:/var/lib/ceph/shell/install_rgw.sh.x'
CMD_GET_HANDY_PORT = "cat /opt/h3c/conf/httpd.conf| grep 'Listen ' | tail -1 | awk '{print $2}'"
CMD_INSTALL_RGW = 'bash /var/lib/ceph/shell/install_rgw.sh {0} {1}'
CMD_DEPLOY_RGW = '/opt/h3c/bin/python /var/lib/ceph/shell/onestor.py deploy_gateway_config {0} {1} {2}'
CMD_CREATE_RGW_CONF = '/opt/h3c/bin/python /var/lib/ceph/shell/onestor.py create_rgw_ceph_conf {0} {1} {2}'
CMD_REMOVE_RGW_CONF = '/opt/h3c/bin/python /var/lib/ceph/shell/onestor.py remove_gateway {0}'
CMD_REMOVE_RGW_CONF_HANDY = '/opt/h3c/bin/python /var/lib/ceph/shell/onestor.py remove_rgw_ceph_conf {0}'
CMD_REMOVE_RGW_AUTH = 'timeout 60 ceph auth del client.radosgw.{0}'
CMD_REMOVE_RGW_GRAPHITE = '/opt/h3c/bin/python /var/lib/ceph/shell/whisper_cleaner.py remove_radosgws {0}'
CMD_REMOVE_RGW_POOL = '/opt/h3c/bin/python /var/lib/ceph/shell/whisper_cleaner.py remove_pool {0} {1} {2} {3}'
CMD_CHECK_DIAMOND_INSTALLED = 'cat /opt/h3c/packages.info | grep diamond | cut -d = -f 2'
CMD_CHECK_RGW_STATUS = "pidof radosgw | wc -l"
CMD_CHECK_RGW_IS_USED = 'netstat -anp | grep ":{0}" | grep ESTABLISHED | grep radosgw | wc -l'
CMD_CHECK_RGW_AUTH = 'ceph auth list 2>/dev/null | grep "client.radosgw.{0}$" | wc -l'
CMD_CLEAR_GRAPHITE_DATA = 'rm -rf /var/lib/graphite/whisper/servers/{0}'
CMD_CLEAR_GRAPHITE_HOST = '/opt/h3c/bin/python /var/lib/ceph/shell/whisper_cleaner.py remove_host {0} {1}'
# True则仅删除存储节点数据，False则删除除ceph目录下的所有数据
CMD_STOP_RGW_DAEMON = 'touch /var/lib/ceph/shell/radosgw_maintaining && /etc/init.d/radosgw stop ' \
                      '&& timeout 30 dpkg -P radosgw'

# BEGIN ADD BY Z11524 2017/4/21 PN:201704170117
CP_VERSION = 'cp /tmp/onestor_external_version /tmp/onestor_internal_version /etc'
CP_VERSION_BACKUP = 'cp /etc/onestor_external_version /etc/onestor_internal_version /tmp'
RM_VERSION_BACKUP = 'rm -rf /tmp/onestor_external_version /tmp/onestor_internal_version'
# END ADD BY Z11524 2017/4/21 PN:201704170117

# begin by z11524 2017/6/7 PN:201704140832
CMD_HAS_HANDYHA = "cat /etc/ceph/ceph.conf | grep 'slave_addr '"

# BEGIN ADD BY C13463
CMD_SET_MAINTAIN = '/opt/h3c/bin/python /var/lib/ceph/shell/onestor_maintain.py set_maintain'
# END ADD BY C13463

# begin by z11524 2017/6/20 PN:201706120689
CMD_TOUCH_FILE = "touch {0}"

CMD_TEST_PSQL_STATUS = "timeout 1800 /opt/h3c/bin/python /var/lib/ceph/shell/handyha/test_psql_status.py"
CMD_REPAIR_PSQL = "timeout 1800 /opt/h3c/bin/python /var/lib/ceph/shell/handyha/keepalived_event.py become_master_repair"
CMD_CHECK_HANDY_HA_EVENT = \
    "ps -ef | grep /opt/h3c/bin/python | grep -v grep| grep 'keepalived_event.py become_' | wc -l"

CMD_BACKUP_PSQL = "timeout 600 /opt/h3c/bin/python /var/lib/ceph/shell/handyha/backup_psql.py {0}"

# begin add by z11524 2017/7/24 PN:201707190746
CMD_BACKUP_PSQL_MASTER = "timeout 600 sudo -u postgres cp -r /var/lib/postgresql/{0}/main /var/lib/postgresql/{0}/main_bak"
CMD_BACKUP_PSQL_SLAVE = "timeout 600 sudo -u postgres scp -r /var/lib/postgresql/{0}/main [{1}]:/var/lib/postgresql/{0}/main_bak"
CMD_RM_BACKUP_PSQL = "rm -rf /var/lib/postgresql/{0}/main_bak"
CMD_GET_PSQL_VERSION = "cat /opt/h3c/etc/postgresql/info.txt | grep version | cut -d = -f 2"
# end add by z11524 2017/7/24 PN:201707190746
# begin add by h13051
CMD_HOST_INFO_IP = "python /opt/h3c/salt/salt/shell/host_info_ip.py list --nodes={0} --user={1} --passwd={2}"
CMD_GET_PUBLIC_IP = "/opt/h3c/bin/python {0}/handy_common.py getPublicAddress {1} {2} {3} {4}"
CMD_NTP_WRITE = "timeout 25 python /var/lib/ceph/shell/ntp_task.py ntp_write {0}"
CMD_NTP_WRITE_MULTI = "timeout 30 ssh $$ python /var/lib/ceph/shell/ntp_task.py ntp_write {0}"
CMD_CLUSTER_DEPLOY = "bash {0}/cluster-deploy.sh {1} {2} {3} {4} {5} {6} {7} {8} {9} {10} {11}"
CMD_CHMOD_CEPH_CONF = "chmod 644 {0}/*.keyring {1}/ceph.conf"
CMD_COPY_CEPH_CONF = "cp {0}/*.keyring {1}/ceph.conf /etc/ceph/"
CMD_SCP_COPY_CEPH_CONF = "scp -p {0}/*.keyring {1}/ceph.conf [{2}]:/etc/ceph/"
CMD_CHMOD_666_HOSTS_DIR = "chmod 666 /etc/onestor_hosts && chmod 666 /etc/hosts"
CMD_CHMOD_644_HOSTS_DIR = "chmod 644 /etc/onestor_hosts && chmod 644 /etc/hosts"
CMD_MODIFY_ETC_HOST = "cp /etc/hosts /etc/hosts_bk && echo 127.0.0.1 localhost > /etc/onestor_hosts " \
                      "&& echo 127.0.0.1 localhost > /etc/hosts"

# begin add by z14172 2017/12/25
#CMD_IDENTIFY＿X10000 = "ipmitool raw 0x36 0x08"
CMD_IDENTIFY_X10000 = "cat /var/host_type |grep X10000"
# end add by z14172 2017/12/25
CMD_SSH_RESTART_TGT = 'timeout 300 ssh {0} service tgt restart >/dev/null 2>&1 &'
# end add by z14172 2017/12/25

CMD_STOP_NM_SUB = "timeout 30 ssh $$ supervisorctl stop onestor-nm onestor-sub"
CMD_RESTART_NM_SUB = "timeout 30 ssh $$ supervisorctl restart onestor-nm onestor-sub"
