#!/usr/bin/python
# coding:utf-8


"""
定义常量
"""

OP_LIST = 'list'
OP_CREATE = 'create'
OP_UPDATE = 'update'
OP_DELETE = 'delete'
OP_RECOVERY = 'recovery'
OP_HA = 'ha_sync'
OP_SUCCSSFUL = 'success'
OP_FAILED = 'failed'
NOT_FOUND = 'NotFound'
OP_RACK_REMOVE = 'RACK_remove'

COMP_CS = 'COMP_CS'

OP_NODEPOOL_CREATE = 'NODEPOOL_create'
OP_DISKPOOL_CREATE = 'DISKPOOL_create'
OP_PROTECTIONDOMAIN_CREATE = 'PROTECTIONDOMAIN_create'
OP_RACK_CREATE = 'RACK_create'
OP_RACK_MOVE = 'RACK_move'

RESULT_ERROR = 'error'
RESULT_NONE = 'none'
HANDY_SHELL_PATH = '/var/lib/ceph/shell'
HANDY_SHELL_NTP = '/var/lib/ceph/shell/ntp_task.py'
SSH_PATH = '/etc/ssh/ssh_config'
CLUSTER_DEPLOY_DIR = '/home/ceph-cluster'
CONST_HA_MASTER = 'master'
CONST_HA_SLAVE = 'slave'
CONST_HA_VIP = 'vip'
NETWORK_FAULT = 'NETWORK_FAULT'
MANAGE_NETWORK = 'manage_network'
PUBLIC_NETWORK = 'public_network'
DISASTER_NETWORK = 'disaster_network'
CLUSTER_NETWORK = 'cluster_network'
MANAGE_NETWORK_CN = '管理网段'
PUBLIC_NETWORK_CN = '业务网段'
DISASTER_NETWORK_CN = '灾备网段'
CLUSTER_NETWORK_CN = '存储网段'

TABLE_HIGHAVAILABLE = 'highavailableconfig'
TABLE_HANDY_HA = 'handyha'
TABLE_GATEWAY = 'gateway'
# begin add by d11564 多MDS项目
TABLE_NAS_SERVER_NEW = 'nas_server_new'
HOST_USE = "use"
NEED_RESTORE_MDS = 'NEED_RESTORE_MDS'
NEED_DELETE_HOST = 'NEED_DELETE_HOST'
# end add by d11564 多MDS项目
SERVICE_TGT = 'tgt'
SERVICE_ONEBACKUP = 'onebackup'
SERVICE_HANDYHA = 'handyha'

ROLE_HANDY = 'handy'
ROLE_STOR = 'stor'
ROLE_MON = 'mon'
ROLE_RGW = 'rgw'
ROLE_NAS = 'nas'
ROLE_MDS = 'mds'

USER_DEFAULT = 'default'
USER_DEFAULT_PASSWD = 'User@123'
OPERATE = 'operate'
CALAMARI_REST_OPERATE = 'calamari_rest.operate'
PERMISSION_GROUPMANAGE = 'operate_groupmanage'
PERMISSION_USERMANAGE = 'operate_usermanage'
PERMISSION_POOL_POLICY = 'operate_pool_policy'
CHECK_CEPH_CONF = 'check_ceph_conf'
CRRATE_MANAGE_NETWORK = 'create_manage_network'
HA_CREATE_GROUP = 'HA_create_group'  # 创建用户组
HA_REMOVE_GROUP = 'HA_remove_group'  # 删除用户组
HA_MODIFY_GROUP_PERMISSION = 'HA_modify_group_permission'  # 修改用户组权限
HA_CREATE_USER = 'HA_create_user'  # 创建用户
HA_REMOVE_USER = 'HA_remove_user'  # 删除用户
HA_MODIFY_USER_GROUP = 'HA_modify_user_group'  # 修改用户所在组
HA_MODIFY_USER_PASSWD = 'HA_modify_user_passwd'  # 修改用户密码
HA_SSH_SLAVE = '"    StrictHostKeyChecking no\n    UserKnownHostsFile /dev/null"'

OP_GET_LICENSE_INFO = 'HA_get_license_info'  # 获取License信息

CHECK_CEPH_VERSION = 'ceph version'

DATA = 'data'
STEP = 'step'
IDLE = 'idle'
NTP_SWITCH = 'ntp_close'
NTP_CLOSE = '0'
NTP_IN_CLUSTER = '1'
NTP_OUT_CLUSTER = '2'
MON_FQDNS = 'mon_fqdns'
USER_ROOT = 'root'
SSH_PUB_KEY = 'ssh_pub_key'
HOST_IP = 'hostip'
DISASTER_IP = 'disaster_ip'
HOST_NAME = 'hostname'
IS_REGISTER = 'is_register'
BS_MAX_CAPACITY = 'bs_max_capacity'
OS_MAX_CAPACITY = 'os_max_capacity'
FS_MAX_CAPACITY = 'fs_max_capacity'
BS_VERSION_TYPE = 'bs_version_type'
OS_VERSION_TYPE = 'os_version_type'
FS_VERSION_TYPE = 'fs_version_type'
LICENSE_TYPE = 'license_type'
EXPIRE_TIME = 'expire_time'
MACS = 'macs'
CPUID = 'cpuid'

BACKUP_POOL_NAME = ".backup"
LIUNX_VERSION = 'uname -a'
NETWORK_FAULT_TMP_FILE = '/tmp/.network_error'
ONESTOR_PROGRESS_HA_FILE = '/tmp/.progress_onestor_ha'
ONESTOR_PROGRESS = '/tmp/.progress_onestor'
STEP_VALIDATE_NETWORK = 'validate_network'
STEP_VALIDATE_LICENSE = 'validate_license'
STEP_SSH_CONFIG = 'ssh_config'
STEP_INSTALL_SOFT = 'install_soft'
STEP_DEPLOY_OSD = 'deploy_osd'
STEP_SETUP_NTP = 'setup_ntp'
STEP_SYNC_CONFIG = 'sync_config'
STEP_SSH_CONFIG_OTHER = 'ssh_config_other'
STEP_SETUP_DIAMOND = 'setup_diamond'
STEP_SYNC_PSQL = 'sync_psql'
STEP_SYNC_MONITORY = 'sync_monitory'
STEP_CONFIG_HA = 'config_ha'
STEP_ROLLBACK = 'rollback'
STEP_PREPARE_REMOVE = 'prepare_remove'
STEP_WAITING_DATA_BALANCE = 'waiting_data_balance'
STEP_BEGIN_REMOVE = 'begin_remove'
WAIT_FOR_ONESTORD_RESTART = 10
STEP_ADD_MDS = 'add_mds'
HOST_NUM_LIMIT = 33

# 操作状态标记文件，现只用于灾备
ONESTTOR_PROCESS_CONFIG_KEY = 'progress_onestor'

STEP_TIPS_SHOW = {
    '': '',
    STEP_VALIDATE_NETWORK: '正在检查网络信息...',
    STEP_VALIDATE_LICENSE: '正在检查软件信息...',
    STEP_SSH_CONFIG: '正在进行免密配置...',
    STEP_INSTALL_SOFT: '正在安装软件...',
    STEP_SETUP_NTP: '正在配置NTP时间同步...',
    STEP_SYNC_CONFIG: '正在同步集群配置...',
    STEP_SSH_CONFIG_OTHER: '正在对其它节点进行免密...',
    STEP_SETUP_DIAMOND: '正在配置Diamond监控...',
    STEP_SYNC_PSQL: '正在同步本地数据库...',
    STEP_SYNC_MONITORY: '正在同步监控数据...',
    STEP_CONFIG_HA: '正在配置高可用信息...',
    STEP_ROLLBACK: '正在恢复配置...',
    STEP_PREPARE_REMOVE: '正在准备删除...',
    STEP_WAITING_DATA_BALANCE: '数据平衡中，请耐心等待...',
    STEP_BEGIN_REMOVE: '正在删除中，请耐心等待...',
}

MULTI_CMD_INSTALL_SOFT = 'install_soft_multi'
MULTI_CMD_SSH_COPY = 'ssh_copy_multi'
CHECK_HANDY_SHELL = 'process_detect'
CHECK_INSTALL_CEPH = 'install module success'
LOCALHOST = 'localhost'
ONESTOR_HOSTS = '/etc/onestor_hosts'
HA_ROLLBACK_ENTITY = 'ha_rollback_entity'
CHECK_ZOOKEEPER = 'zookeeper'
CHECK_COMMON = 'common'

ALL_CEPH_CONF = '/etc/ceph/*'
CEPH_CONF = '/etc/ceph/ceph.conf'
ALL_ONESTOR_CONF = '/etc/onestor_*'
KEYRING_CLIENT_ADMIN = '/etc/ceph/ceph.client.admin.keyring'
KEYRING_BOOTSTRAP = '/etc/ceph/ceph.bootstrap*.keyring'
KEYRING_MON = '/etc/ceph/ceph.mon.keyring'
KEEPALIVED_CONF = '/etc/keepalived/keepalived.conf'
ZK_MYID_PATH = '/opt/h3c/var/lib/zookeeper/data/myid'
ZK_ZOO_CFG_PATH = '/opt/h3c/zookeeper/conf/zoo.cfg'

CONF_HANDY_DB = '/opt/h3c/handy.db'
CONF_CALAMARI_WEB = 'calamari_web'
CONF_CALAMARI_DB_PASSWD = 'db_password'

STATUS_ACTIVE = u'已启用'
STATUS_STOPPED = u'未启用'
USER_TYPE_COMMON = u'普通'
SLAVE_NODE = '备用节点'

ERR_NETWORK_FAULT = '主机有网络故障'

# response返回格式, type1为{"status": "error", "errorcode": "xxx", "reason": "xxx"}
RETURN_TYPE_1 = 'return_type1'
# response返回格式, type2为{"success": False, "errorcode": "xxx", "error": "xxx"}
RETURN_TYPE_2 = 'return_type2'
# response返回格式, type3为{"success": False, "errorcode": "xxx", "error": "xxx", "nodes": "xxx"}
RETURN_TYPE_3 = 'return_type3'
# 主机管理常量
OFFLINE = 'offline'
HOST_TIME_DIFF = 300
MON_TIME_DIFF = 2
TASK_FREQUENCY_TIME = 30 * 60
FLAG_ADDING_OSD = '/tmp/.adding_osd'
FLAG_OPERATE_MON = '/tmp/.operate_mon'
FLAG_OPERATE_RGW = '/tmp/.operate_rgw'
FLAG_OPERATE_CLUSTER = '/tmp/.operate_cluster'
FLAG_REMOVING_OSD = '/tmp/.removing_osd'
FLAG_DEPLOY_STATUS = '/tmp/deploy_status'
FLAG_SWITCH_HANDY_HA = '/tmp/.operate_handyha_switch'
NEED_RESTORE_ETC_HOSTS = 'NEED_RESTORE_ETC_HOSTS'
NEED_RESTORE_CEPH_CONF = 'NEED_RESTORE_CEPH_CONF'
NEED_RESTORE_RACK = 'NEED_RESTORE_RACK'
NEED_RESTORE_CLUSTER_CONF = 'NEED_RESTORE_CLUSTER_CONF'
NEED_RESTORE_ONEBACKUP = 'NEED_RESTORE_ONEBACKUP'
NEED_RESTORE_NTP = 'NEED_RESTORE_NTP'
NEED_RESTORE_ZK = 'NEED_RESTORE_ZK'
NEED_RESTORE_PSQL = 'NEED_RESTORE_PSQL'
STEP_DEPLOY_ADMIN_NODE = 'deploy_admin_node'
STEP_DEPLOY_DISK = 'deploy_data_node'
STEP_ADD_DISK_BATCH = 'add_disk_batch'
STEP_SYNC_TGT = 'sync_tgt_config'
STEP_RESTART_DIAMOND = 'restart_diamond'
STEP_INITIAL_CRUSH = 'initial_cluster'
STEP_GET_OSD_ID_FOR_ADD_HOST = 'get_osd_id_for_add_host'
STEP_GET_OSD_ID_FOR_ADD_DISK = 'get_osd_id_for_add_disk'
OP_ADD_STOR = 'add_stor'
OP_ADD_MON = 'add_mon'
OP_REMOVE_STOR = 'remove_stor'
OP_REMOVE_MON = 'remove_mon'
OP_REMOVE_STOR_CN = '删除主机'
OP_ADD_DISK = 'add_disk'
OP_REMOVE_DISK = 'remove_disk'
OP_REMOVE_DISK_CN = '删除硬盘'
OP_CREATE_CLUSTER = 'create_cluster'

OP_CREATE_TARGET = 'create_target'
OP_MODIFY_TARGET = 'modify_target'
OP_REMOVE_TARGET = 'remove_target'
OP_CREATE_LUN = 'create_lun'
OP_MODIFY_LUN = 'modify_lun'
OP_REMOVE_LUN = 'remove_lun'
# PN: 201612160639 【BBIT】osd已容量超95%，断开I-T连接
OP_CREATE_RBD = 'create_rbd'
OP_CREATE_SNAPSHOT = 'create_snapshot'
OP_CLONE_RBD = 'clone_rbd'
OP_BACK_SNAP = 'back_snap'
OP_REMOVE_SNAP = 'remove_snap'
OP_RBD_TO_LUN = 'rbd_to_lun'
OP_LUN_TO_RBD = 'lun_to_rbd'
LIST_SNAPS = 'list_snaps'
# end by l11544 2017/4/27

BACKUP_ALL = 'backup_all'
BACKUP_MANAGE = 'backup_manage'

# 规格常量
# HANDY_TOP_CMD_SPACE = 90                                # Ceph集群允许执行相关命令的容量上限，为百分比值
CEPH_TOP_CMD_SPACE = 90                                 # Ceph集群允许执行相关命令的容量上限，为百分比值
LUN_NUM_IN_CLUSTER = 256                                # 集群最多允许的存储卷数量
LUN_NUM_IN_POOL = 256                                   # 存储池最多允许的存储卷数量
LUN_NUM_IN_TARGET = 256                                 # Target最多允许的存储卷数量
BACKUP_POOL_WAIT_TIME = 120                             # 开启容灾创建灾备池，等待池恢复健康的时间
ASTRICT_RBD_DISPACE = 64 * 1024 * 1024 * 1024 * 1024    # 创建块设备所允许的最大大小规格64T
USER_GROUP_LIMIT = 16                                   # 用户组最多允许创建 16 个
USER_LIMIT = 128                                       # 用户最多允许创建 128 个

LOG_COUNT_TO_BROWSER = 500                             # 返回给浏览器的操作日志条数限制为 500 条

# 维护模式常量
BUCKET_POD = 'pod'
HOST_NAME_POD = '{0}_pod'
BUCKET_HOST = 'host'
BUCKET_ROOT = 'root'
BUCKET_MAINTAIN = 'maintain'
PROGRESS_FILE = '/tmp/.progress_{0}'
PROGRESS_PREPARE_RM = 'prepare_remove'
PROGRESS_REBALANCE = 'rebalance'
PROGRESS_ROMOVING = 'removing'
PROGRESS_FINISH = 'finish'
NOBACKFILL = 'nobackfill'
NOREBALANCE = 'norebalance'
NOUP = 'noup'
NOOUT = 'noout'
AUTO_MAINTAIN = 'auto'
MANUAL_MAINTAIN = 'manual'
CLOSE_MAINTAIN = 'close'
DEF_START = 0
DEF_END = 23
NO_MAINTAIN_CONFIG = 'no_maintain_config'
FLAG_NO_HANDYCRON = 'no_handycron'
FLAG_UPGRADE = 'upgrade'

# ceph 12.2.0 分类新增字段
OSDMAP_FLAGS = 'OSDMAP_FLAGS'
POOL_APP_NOT_ENABLED = 'POOL_APP_NOT_ENABLED'
TOO_MANY_PGS = 'TOO_MANY_PGS'

# 对象网关、高可用、参数配置常量
OP_DEPLOY_GATEWAY = 'deploy_gateway'
OP_REMOVE_GATEWAY = 'remove_gateway'
OP_CREATE_HA_CFG = 'create_ha_cfg'
OP_MODIFY_HA_CFG = 'modify_ha_cfg'
OP_REMOVE_HA_CFG = 'remove_ha_cfg'
OP_HA_GROUP_ENABLE = 'enable_ha_cfg'
OP_HA_GROUP_DISABLE = 'disable_ha_cfg'
OP_CREATE_HANDY_HA_CFG = 'create_handy_ha_cfg'
OP_MODIFY_HANDY_HA_CFG = 'modify_handy_ha_cfg'
OP_REMOVE_HANDY_HA_CFG = 'remove_handy_ha_cfg'
OP_POST_NTP_INFO = 'post_ntp_info'
OP_POST_CEPH_PARAM = 'post_ceph_param'
OP_CREATE_MANAGE_NETWORK = 'create_manage_network'
# begin add by z11524 date:2017/06/22 PN:201706120689

D_COMP_CM = 'COMP_CM'
D_OP_ZK_SETUP = 'ZK_setup'
D_OP_ZK_ADD = 'ZK_add'
D_OP_ZK_DELETE = 'ZK_delete'
D_OP_ZK_INIT = 'ZK_init'
D_OP_HOST_SAVE = 'HOST_save'
D_OP_HOST_DELETE = 'HOST_delete'
D_OP_HOST_DELETE_BY_MIP = 'HOST_delete_by_manage_ip'
D_OP_HOST_REWRITE_IP = 'HOST_rewrite_ip'
D_OP_NAS_LIST_GROUPS = 'NAS_list_groups_leader'

RGW_POOLS = {
    "default.rgw.control": 16,
    "default.rgw.log": 8,
    "default.rgw.buckets.index": 16,
    "default.rgw.buckets.data": 64,
    "default.rgw.buckets.non-ec": 128,
    ".rgw.root": 8,
    "default.rgw.meta": 8
}

RGW_POOLS_WITHOUT_BUCKETS = [
    "default.rgw.control",
    "default.rgw.log",
    "default.rgw.buckets.index",
    "default.rgw.buckets.non-ec",
    ".rgw.root",
    "default.rgw.meta"
]
# 配置文件
CALAMARI_CONF = '/etc/calamari/calamari.conf'                    # calamari.conf配置文件
FLAG_HA_FILE = "/tmp/.op_handyha"
READY = 'ready'
UNREADY = 'unready'
TEST = 'test'
# begin add by z11524 2017/8/10 PN:201708090145
CLUSTERCONFIG = 'clusterconfig'
# NAS模块
NAS_PROGRESS = '/tmp/.progress_nas'
OP_ADD_NAS_NODE = 'add_nas_node'
FLAG_ADDING_NAS_NODE = '/tmp/.adding_nas_node'
OP_ADD_NAS_GROUP = 'add_nas_group'
FLAG_ADDING_NAS_GROUP = '/tmp/.adding_nas_group'
OP_DEL_NAS_GROUP = 'del_nas_group'
FLAG_REMOVE_NAS_GROUP = '/tmp/.remove_nas_group'
OP_DEL_NAS_NODE = 'del_nas_node'
FLAG_REMOVE_NAS_NODE = '/tmp/.remove_nas_node'
# 用于限制超时退出的请求
REQUEST_V2_URL = ['addHostManual', 'addHostAuto', 'addMon', 'removeHost', 'removeMon', 'add_rados_gateway',
                  'remove_rados_gateway', 'create_handy_ha_cfg', 'remove_handy_ha_cfg', 'createHighAvailable',
                  'create_disasterha_conf', 'addDisk', 'removeDisk']
ONESTOR_CONF = '/etc/onestor/onestor.conf'
MON_NUM_LIMIT = 7  # 集群mon个数限制
OP_DISKPOOL_QUERY_SHORT = 'DISKPOOL_query_short'
NODEPOOL_NAME_EMPTY_OBJECT = {'nodepool_name': ''}
CEPH_FS_METADATA = 'cephfs-metadata'
OP_HOST_QUERY_BY_HOST_NAME = 'HOST_query_by_host_name'
OP_DISKPOOL_QUERY_SUMMARY = 'DISKPOOL_query_summary'
OP_NODEPOOL_QUERY = 'NODEPOOL_query'
OP_DISK_QUERY = 'DISK_query'
OP_CHECK_HOST_OSD_NUMBER_LIMIT = 'CHECK_host_osd_number_limit'
# License备份路径
LICS_FILE_PATH = '/opt/h3c/webapp/content/temp/lics/'
# 企业版高级特性
FS_WORM = 'fs_worm'
FS_QOS = 'fs_qos'
FS_LOAD_BALANCE = 'fs_load_balance'
FS_SNAPSHOT = 'fs_snapshot'
BS_SNAPSHOT = 'bs_snapshot'
BS_CLONE = 'bs_clone'
BS_SSD_RW = 'bs_ssd_rw'
OP_DISKPOOL_UPDATE_CAPACITY = 'DISKPOOL_update_capacity'
ADD_DISK_FOR_UPDATE_DISKPOOL_CAPACITY = 'add_disk'
DELETE_DISK_FOR_UPDATE_DISKPOOL_CAPACITY = 'delete_disk'
OP_DISKPOOL_LOGICAL_HOST_CAPACITY_QUERY = 'DISKPOOL_logical_host_capacity_query'
