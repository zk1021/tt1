#!/usr/bin/env python
# coding: utf-8


"""
定义错误码
"""
cluster_head_net = u'存储前端网段'
cluster_behind_net = u'存储后端网段'
public_net = u'存储前端网'

ERR_USER_LIMIT_EXCEED = (-97, 'Maximum number of users (128) exceeded.', '用户数量超过限制，最多允许创建128个用户')
ERR_GROUP_LIMIT_EXCEED = (-98, 'Maximum number of user groups (16) exceeded.', '用户数量超过限制，最多允许创建16个用户组')
ERR_CONNECT_SLAVE_FAILED = (-99, 'Cannot connect to a node that is not the current active node.', '无法连接到非当前工作节点')
ERR_GROUP_EXIST = (-100, 'The user group already exists.', '用户组已经存在')
ERR_GROUP_NOT_EXIST = (-101, 'The user group does not exist.', '用户组不存在')
ERR_GROUP_NAME_IS_NONE = (-102, 'Please specify a user group name.', '用户组名称不能为空')
ERR_USER_EXIST = (-103, 'The username already exists.', '用户已经存在')
ERR_USER_NOT_EXIST = (-104, 'The username does not exist.', '用户不存在')
ERR_USER_NAME_IS_NONE = (-105, 'Please specify a username.', '用户名称不能为空')
ERR_PASSWORD_IS_NONE = (-106, 'Please specify a password.', '用户密码不能为空')
ERR_IS_NOT_SUPERUSER = (-107, 'Only the super user (admin) can perform this operation.', '超级管理员才有权限操作')
# ERR_GROUP_EXIST_USER = (-108, 'The user group contains users and cannot be deleted.', '删除失败，用户组中存在用户')
ERR_USER_UNAUTHENTICATED = (-109, 'User authentication failed.', '用户认证失败')
ERR_DELETE_SUPERUSER = (-110, 'Super user cannot be deleted.', '超级管理员不允许删除')
# ERR_OLD_PASSWD_IS_WRONG = (-111, 'Old password is incorrect.', '原密码错误')
# ERR_USER_IS_STOPPED = (-112, 'The user has been blocked.', '用户已经被禁用')
# ERR_PASSWORD_IS_TOO_SIMPLE = (-113, 'The password is too short.', '密码长度不符合要求')
# ERR_RESET_SUPERUSER_PASSWD = (-114, 'Cannot reset the password of the super user.', '超级管理员不能重置密码')
# ERR_MODIFY_SUPERUSER_GROUP = (-115, 'Cannot change the user group of the super user.', '超级管理员不能修改用户组')

ERR_MASTER_AND_SLAVE_IP_REPEAT = (-116, 'The IP addresses of primary and backup nodes must be different.', '主备节点IP不能相同')
ERR_HA_IP_NOT_IN_PUBLIC_NETWORK = (-117, 'HA VIP is not in the %s. ', u'高可用IP不在%s内' % cluster_head_net)
ERR_IP_IS_USED = (-118, 'The IP address is already in use.', 'IP地址“{0}”已经被使用')
ERR_NODE_HAS_NETWORK_FAULT = (-119, 'Some nodes have network failure. Please review the system log.', '有节点存在网络故障，详见系统日志')
ERR_GET_AVAIL_VRID = (-120, 'Failed to obtain VRID .', '无法获取可用的VRID')
ERR_CREATE_HA_CFG = (-121, 'Failed to create the HA VIP. Please review the system log.', '创建高可用IP失败，详见系统日志')
ERR_HA_IP_IS_USED = (-122, 'The HA VIP is already in use.', '该高可用IP正在使用中')
ERR_REMOVE_HA_CFG = (-123, 'Failed to delete the HA VIP. Please review the system log', '删除高可用IP失败，详见系统日志')
ERR_MODIFY_HA_CFG = (-124, 'Failed to change the HA VIP. Please review the system log', '修改高可用IP失败，详见系统日志')
ERR_HA_IP_NOT_IN_MANAGE_NETWORK = (-125, 'The HA VIP is not in the management network.', '高可用IP不在管理网段内')
ERR_SLAVE_IP_NOT_IN_PUBLIC_NETWORK = (-126, 'The IP address of the backup node is not in the %s . ', u'备用节点IP不在%s内' % cluster_head_net)
ERR_SLAVE_IP_NOT_IN_MANAGE_NETWORK = (-127, 'The IP address of the backup node is not in the management network.', '备用节点IP不在管理网段内')
ERR_MASTER_IP_NOT_IN_PUBLIC_NETWORK = (-128, 'The IP address of the primary node is not in the %s.' , u'主用节点IP不在%s内' % cluster_head_net)
ERR_MASTER_IP_NOT_IN_MANAGE_NETWORK = (-129, 'The IP address of the primary node is not in the management network.', '主用节点IP不在管理网段内')
ERR_CONNECT_TO_HOST = (-130, 'Failed to connect to host “{0}”.', '无法连接到主机“{0}”')
ERR_HA_IP_IS_SAME = (-131, 'The HA VIP is not changed.', '高可用IP地址未修改')
ERR_HA_CFG_NOT_FOUND = (-132, 'The HA group is not found.', '该高可用配置不存在')
ERR_SLAVE_EXIST_CLUSTER = (-133, 'The backup node has been added to another cluster.', '备用节点已经存在于其它集群中')
ERR_INSTALL_ONESTOR_SOFT = (-134, 'Failed to install Unistor.', '安装UniStor软件失败')
ERR_AUTH_FAILED = (-135, 'Authentication failed. Please check the IP address and root password for error.', '认证失败，请检查IP地址和root密码是否正确')
ERR_GET_CLUSTER_CONFIG = (-136, 'Failed to obtain basic cluster settings.', '获取集群基础配置失败')
ERR_GET_PUBLIC_IP = (-137, 'Host “{0}”: Failed to obtain the %s IP .', u'无法获取主机“{0}”的%sIP' % public_net)
ERR_SSH_CONFIG = (-138, 'Failed to configure SSH without password.', 'SSH免密配置失败')
ERR_SYNC_CLUSTER_CONFIG = (-139, 'Failed to synchronize the cluster configuration file.', '同步集群配置文件失败')
ERR_CREATE_SSH_KEY = (-140, 'Failed to create the SSH key.', '生成SSH秘钥失败')
ERR_CONFIG_MULTI_DIAMOND = (-141, 'Failed to configure Diamond.', '配置Diamond失败')
ERR_SYNC_PSQL_DB = (-142, 'Failed to synchronize the PostgreSQL database.', '同步Postgresql数据库失败')
ERR_SYNC_MONITORY_DATA = (-143, 'Failed to synchronize monitoring data.', '同步监控数据失败')
ERR_GET_MASTER_LICENSE = (-144, 'Failed to obtain license information from the primary node.', '主用节点的License信息获取失败')
ERR_GET_SLAVE_LICENSE = (-145, 'Failed to obtain license information from the backup node.', '备用节点的License信息获取失败')
ERR_NOT_HA_LICENSE = (-146, 'Please first register the license for HA use.', '请先以双机热备的方式注册License')
ERR_DIFFERENT_LICENSE = (-147, 'The primary and backup nodes have different license specifications.', '主用节点和备用节点的License规格不一致')
ERR_SLAVE_HAS_NO_HANDY = (-148, 'Handy software is not installed in the backup management node.', '备用节点上未安装Handy软件')
ERR_DIFF_SLAVE_VERSION = (-149, 'The primary and backup management nodes run different versions of Handy software.', '主备节点的Handy版本不一致')
ERR_BAD_HOST_NAME = (-150, 'The host has been added to a cluster.', '该主机（名）已存在集群')
ERR_ONLY_ALLOW_ONE_HA_CFG = (-151, 'You can create only one management HA group.', '只允许创建一条管理高可用信息')
ERR_CLUSTER_HAS_NETWORK_FAULT = (-152, 'Some nodes in the cluster have network failure.', '集群内有节点存在网络故障')
ERR_CEPH_CONF_LOSE = (-153, 'Ceph configuration is incomplete on some nodes in the cluster.', '集群内有节点存在ceph配置缺失')
ERR_CONNECT_TO_WORKING_SLAVE = (-154, 'Cannot connect to a Handy node that is not the current active node.', '无法连接到非当前工作Handy节点')
ERR_CONNECT_TO_PUBLIC_NEWORK = (-155, 'Network failure occurred on storage front-end network {0} . ', '集群内节点存储前端网{0}故障')
ERR_GET_DISASTER_IP = (-156, 'Failed to obtain the IP address of the backup site  for host “{0}”.', '无法获取主机“{0}”的灾备网IP')
ERR_TASK_FREQUENCY_TIME = (-157, 'The minimum interval for editing the management HA group settings is 30 minutes.', '操作管理高可用的时间间隔不能小于30分钟')
# begin add by z11524 2017/8/10 PN:201708090145
ERROR_MON_NUM_LIMIT = (-158, 'The cluster can have only a maximum of seven monitor nodes.', '监控节点数量最多7个')
# 为管理高可用掩码内不可用IP校验设置
ERR_HA_IP_IN_MANAGE_MASK_NETWORK = (-159, 'Invalid management HA VIP.', '管理高可用IP为无效的IP地址')
ERR_HA_IP_IN_PUBLIC_MASK_NETWORK = (-159, 'Invalid service HA VIP.', '业务高可用IP为无效的IP地址')
ERR_MASTER_IP_IN_MASK_NETWORK = (-161, 'IP address of the primary node is invalid.', '主用节点IP为无效的IP地址')
ERR_SLAVE_IP_IN_MASK_NETWORK = (-160, 'IP address of the backup node is invalid.', '备用节点IP为无效的IP地址')
ERROR_MON_MIN_MUN_LIMIT = (-162, 'The cluster must have a minimum of three monitor nodes.','监控节点数量最少3个')
ERR_BSN_NOT_EXIST = (-163, 'The Block Service Network does not exist', '块服务网段不存在')
# BEGIN 主机管理错误码
ERROR_GET_MON_STATUS = (-300, 'Failed to obtain monitor node state.', '获取监控节点状态失败')
ERROR_HUGE_TIME_DIFF = (-301, 'A large time gap exists between host “{0}” and the cluster.', '主机“{0}”的时间与集群相差太大')
ERROR_DISK_IS_NULL = (-302, 'No available disks.', '没有可用的硬盘')
ERROR_GET_HOST_INFO = (-303, 'Failed to obtain host information.', '无法获取主机信息')
ERROR_GET_HOST_DISK_INFO = (-304, 'Failed to obtain disk information from host “{0}”.', '无法获取主机“{0}”的硬盘信息')
ERROR_HOST_BUSY = (-305, 'The system is adding a host or disk. Please try again later.', '正在添加主机或硬盘，请稍后再试')
ERROR_HOST_BUSY_REMOVE = (-306, 'The system is deleting a host or disk. Please try again later.', '正在删除主机或硬盘，请稍后再试')
ERROR_DEPLOY_DISK = (-307, 'Failed to deploy disks on host “{0}”.', '主机“{0}”部署硬盘失败')
ERROR_CLUSTER_NOT_CLEAN = (-308, 'To avoid data loss, you can only {0} after the cluster recovers.', '集群状态恢复正常才能{0}，否则会造成数据丢失')
ERROR_NETWORK_FAULT = (-309, 'No network connectivity to host “{0}”.', '主机“{0}”有网络故障')
ERROR_TARGET_MOUNTED = (-310, 'The node contains mounted volumes.', '该节点有存储卷被挂载')
ERROR_REMOVE_HOST = (-311, 'Host deletion failed. Please review the back-end log.', '删除主机失败，详见后台日志')
ERROR_ADD_DISK = (-312, 'Failed to add disks. Please review the back-end log. ', '增加硬盘失败，详见后台日志')
ERROR_ADD_SOME_DISK = (-313, 'Failed to add disk “{0}”. Please verify that the disk is operating correctly and try again.', '硬盘“{0}”增加失败，请检查硬盘后重试')
ERROR_REMOVE_DISK = (-314, 'Disk deletion failed. Please review the back-end log.', '删除硬盘失败，详见后台日志')
ERROR_INSTALL_SOFT_BATCH = (-315, 'Failed to install software on host “{0}”.', '主机“{0}”软件安装失败')
ERROR_CONFIG_SSH_BATCH = (-316, 'Failed to configure SSH without password on host “{0}”.', '主机“{0}”免密配置失败')
ERROR_HOSTNAME_EXIST = (-317, 'Hostname of host “{0}” already exists in the onestor_hosts file.', '主机“{0}”的主机名已经存在于onestor_hosts文件中')
ERROR_HOSTIP_EXIST = (-318, 'Host “{0}”: The %s IP of the host already exists in the onestor_hosts file.', u'主机“{0}”的%sIP已经存在于onestor_hosts文件中' % public_net)
ERROR_SYNC_CONFIG_BATCH = (-319, 'Failed to configure host “{0}” with the cluster settings.', '主机“{0}”同步集群配置失败')
ERROR_SETUP_NTP_BATCH = (-320, 'Failed to configure host “{0}” with the NTP settings.', '主机“{0}”NTP同步配置失败')
ERROR_VENDOR_UNMATCH = (-321, 'Model of server “{0}” is incompatible with Unistor.', '服务器“{0}”的型号不匹配')
ERROR_MON_BUSY = (-322, 'The system is adding or deleting a monitor node. Please try again later.', '正在添加或删除监控节点，请稍后再试')
ERROR_MON_EXIST = (-323, 'The node is already a monitor node for the cluster.', '该节点已作为集群中监控节点')
ERROR_IP_NOT_IN_PUBLIC_NETWORK = (-324, 'The IP address is not in %s.', u'输入的IP地址不在%s内' % cluster_head_net)
ERROR_START_MON_DAEMON = (-325, 'Failed to start the monitor daemon.', '监控节点进程启动失败')
ERROR_UPDATE_MON_CFG = (-326, 'Failed to update the configuration file on node “{0}”.', '更新节点“{0}”上的配置文件失败')
ERROR_LEVELDB_UNAVAILABLE = (-327, 'The leveldb database is not available.', 'leveldb数据库不可用')
ERROR_RM_MON_FROM_QUORUM = (-328, 'Failed to delete the monitor node from the quorum.', '从quorum中删除监控节点失败')
ERROR_GET_NTP_CFG_OUT = (-329, 'Failed to obtain the external NTP server configuration.', '获取集群外NTP配置失败')
ERROR_WRITE_NTP_CFG = (-330, 'Failed to write the NTP configuration.', 'NTP配置写入失败')
ERROR_UNSUPPORT_HOST_NAME = (
-331, 'The hostname must start with a letter and can contain only letters, digits, and hyphens (-). It cannot be “localhost”.', '主机名称必须以字母开头，只包含字母、数字、中划线，且不能为localhost')
ERROR_REPEAT_BUCKET = (
-332, 'The {0} name cannot be “default” or “maintain” or be the same as a hostname or rack name.', '{0}名称不能为default、maintain，且不能与现有主机名称和机架名称相同')
ERROR_ADD_NTP_SERVER_TO_CLUSTER = (
-333, 'The host at IP address “{0}”  has been configured as an external NTP server for the cluster and cannot be added to the cluster.', u"IP地址“{0}”主机与提供集群外NTP服务主机重复，不能添加到集群内")
ERROR_TASK_EXIST = (-334, 'The task already exists.', '操作失败，存在相同的任务')
ERROR_ADD_MON_TO_QUORUM = (-335, 'Failed to add the monitor node to the quorum.', '添加监控节点到quorum失败')
# BEGIN ADD BY D10039 2017/01/14 for 维护模式
ERROR_OPEN_MAINTAIN_MODE = (-336, 'Failed to enable maintenance mode.', '开启维护模式失败')
ERROR_CLOSE_MAINTAIN_MODE = (-337, 'Failed to disable maintenance mode.', '关闭维护模式失败')
ERROR_ALREADY_OPEN_MAINTAIN_MODE = (-338, 'Maintenance mode already enabled.', '不能重复开启维护模式')
ERROR_ALREADY_CLOSE_MAINTAIN_MODE = (-339, 'Maintenance mode already disabled.', '不能重复关闭维护模式')
ERROR_ADD_HOST_IN_MAINTAIN_MODE = (-340, 'Cannot add hosts in maintenance mode.', '维护模式下不允许添加主机')
ERROR_REMOVE_HOST_IN_MAINTAIN_MODE = (-341, 'Cannot delete hosts in maintenance mode', '维护模式下不允许删除主机')
ERROR_ADD_DISK_IN_MAINTAIN_MODE = (-342, 'Cannot add disks in maintenance mode.', '维护模式下不允许增加硬盘')
ERROR_REMOVE_DISK_IN_MAINTAIN_MODE = (-343, 'Cannot delete disks in maintenance mode.', '维护模式下不允许删除硬盘')
ERROR_HOST_NETWORK_FAULT = (-344, 'No network connectivity to the host.', '主机有网络故障')
ERROR_HOST_NOT_EXIST = (-345, 'The selected storage node does not exist.', '所选的存储节点不存在')
# END ADD BY D10039 2017/01/14
ERROR_HOST_IN_OUT_NTP_SERVER = (
-346, 'The host at IP address “{0}” has been configured as an external NTP server for the cluster and cannot be added to the cluster.', u"IP地址“{0}”主机与提供集群外NTP服务主机重复，不能添加到集群内")
ERR_EXECUTE_COMMAND = (-347, 'ERR_EXECUTE_COMMAND', 'Command execution failed. Please review the back-end log.')
ERROR_OPERATE_RGW_BUSY = (-348, 'The system is adding or deleting the object gateway. Please try again later.', '正在添加或删除对象网关，请稍后再试')
ERROR_ADD_RGW_EXIST_HOST_IP = \
(-349, 'The IP address belongs to a host in the cluster. To use the host as an object gateway, select it from the cluster.', 'IP地址与集群已有节点重复，请通过集群已有主机的方式创建对象网关')
ERROR_ADD_RGW_EXIST_HOST_NAME = \
(-350, 'The hostname belongs to a host in the cluster. To use the host as an object gateway, select it from the cluster.', '主机名称与集群已有节点重复，请通过集群已有主机的方式创建对象网关')
ERROR_ADD_RGW_EXIST_CEPH_CONF = \
(-351, 'Cluster configuration file exists on the host. To use the host as an object gateway, select it from the cluster.', '该主机上已经有集群的配置文件，请通过集群已有主机的方式创建对象网关')
ERROR_RGW_EXIST_OTHER_CEPH_CONF = \
(-352, 'The host is in another cluster and cannot act as an object gateway for this cluster.', '该主机已存在于其它集群中，无法再作为本集群的对象网关')
ERROR_INSTALL_RGW_SOFT = (-353, 'Failed to install the object gateway software.', '对象网关软件安装失败')
ERROR_CREATE_RGW_POOL = (-354, 'Failed to create object gateway storage pool  “{0}”.', '创建对象网关Pool“{0}”失败')
ERROR_NO_RGW_PORT = (-355, 'No available object gateway ports.', '无可用的对象网关端口')
ERROR_CREATE_RGW_CONF = (-356, 'Failed to create the object gateway configuration. Please review the back-end log.', '生成对象网关配置失败，详见后台日志')
ERROR_GET_RGW_CONF = (-357, 'Failed to obtain the object gateway configuration.', '获取对象网关配置失败')
ERROR_EXIST_RGW_DAEMON = (-358, 'An object gateway process already exists on the host.', '该主机已经存在对象网关进程')
ERROR_RGW_IS_USED = (-359, 'Object gateway “{0}” is being used.', '对象网关“{0}”正在被使用')
ERROR_REMOVE_RGW_CONF = (-360, 'Failed to delete the object gateway configuration. Please review the back-end log.', '删除对象网关配置失败，详见后台日志')
ERROR_REMOVE_RGW_AUTH = (-361, 'Failed to delete object gateway authentication information.', '删除对象网关认证信息失败')
ERROR_STOP_RGW_DAEMON = (-362, 'Failed to stop the object gateway process.', '停止对象网关进程失败')
ERROR_RGW_POOL_RESIDUAL = (-363, 'Object storage pool “{0}” is not completely deleted.', '对象存储Pool“{0}”残留')
ERROR_LUN_OVER_CLUSTER = (-364, 'The cluster supports a maximum of {0} volumes.', u'集群最多允许创建{0}个存储卷')
ERROR_LUN_OVER_POOL = (-365, 'A storage pool can have a maximum of {0} volumes.', u'单个存储池最多允许创建{0}个存储卷')
ERROR_LUN_OVER_TARGET = (-366, 'A target can have a maximum of {0} volumes.', u'单个Target最多允许创建{0}个存储卷')
ERROR_UPDATE_NAS_CFG = (-367, 'Failed to update the configuration file on NAS node “{0}”.', '更新NAS节点“{0}”上的配置文件失败')
ERROR_CREATE_RACK_OVER = (-368, 'The cluster can have only a maximum of 32 racks.', '集群最多允许创建32个机架')
ERR_CONNECT = (-369, 'Failed to connect to leaderclient.', '连接leaderclient失败')
ERROR_SAVE_CLUSTER_CONFIG_FAULT = (-370, 'Failed to save monitor node data to the database.', '监控节点数据保存至数据库失败')
ERROR_OS_VERSION = (-371, 'System mismatch between the host and the cluster.', '主机的系统与集群系统不匹配')
# ERROR_PARTITION_NOT_CLEAN = (-401, 'To avoid data loss, partition “{0}” allows the {1} operation only after it recovers.', '分区“{0}”状态恢复正常才能{1}，否则会造成数据丢失')
ERROR_DISK_PULL_OUT = (-402, 'Check whether disk “{0}” has been removed from the server.', '请检查硬盘“{0}”是否已经从服务器上拔除')
# begin add by r13889 2017/4/15
ERROR_UPDATE_MANAGE_NET_CFG = (-403, 'Failed to configure the management network on host “{0}”. Please review the back-end log.', '在主机“{0}”上配置管理网段失败，详见后台日志')
ERROR_MANAGE_IP_NOT_FOUND = (-404, 'Host “{0}” does not have an IP address in the management network.', '主机“{0}”没有管理网段内的IP地址')
ERROR_ILLEGAL_PARAMETER = (-405, 'Invalid parameter.', '非法参数')
ERROR_SWITCH_MAINTAIN_MODE = (-406, 'Failed to change maintenance mode status.', '切换维护模式状态失败')
ERROR_SET_MAINTAIN_CONF = (-407, 'Failed to configure maintenance mode.', '配置维护模式参数失败')
ERROR_NO_MAINTAIN_CONF = (-408, 'No maintenance mode configuration is available.', '维护模式配置缺失')
ERROR_NO_HANDYCRON = (-409, 'Maintenance mode configuration related files are missing.', '维护模式配置相关文件缺失')
ERROR_UPGRADING = (-410, 'The cluster is upgrading. Please try again later.', '集群正在进行升级相关操作，请稍后再试')
ERROR_EXIST_HANDY_HA_EVENT = (-411, 'A Handy switchover or recovery task is running. Please try again later.', '已经存在Handy切换或修复任务，请稍后再试')
ERROR_ENSURE_SLAVE_SSH = (-412, 'Failed to configure SSH without password for host “{0}”.', '主机“{0}”免密配置失败')
# ERROR_PARTION_SPACE_OVER = (-416, 'ERROR_PARTION_SPACE_OVER', u'集群分区“{0}”容量不足，请扩容')
# ERROR_BACK_PARTION_SPACE_OVER = (-417, 'ERROR_PARTION_SPACE_OVER', u'异地灾备元数据池所在分区“{0}”容量不足，请扩容')
ERROR_UNMATCH_MASK = (-413, 'The subnet mask of host “{0}” does not match its mask configuration on cluster {1}.', u'主机“{0}”的掩码配置与集群{1}不一致')
ERROR_DUPLICATE_IP = (-414, 'The IP address of host “{0}” has been used on another host.', u'主机“{0}”的网络配置异常，存在重复的IP地址')
# EBGIN ADD BY C13463 FOR SSO
ERROR_SSO_LOGIN_URL = (-415, 'Login URL for SSO is not available.', '单点登录服务的登录URL不可用')
ERROR_SSO_AUTH_URL = (-416, 'Authentication URL for SSO is not available.', '单点登录服务的校验URL不可用')
ERROR_SSO_LOGOUT_URL = (-417, 'Logout URL for SSO is not available.', '单点登录服务的登出URL不可用')
ERROR_SSO_NETWORK = (-418, 'Network error occurred. The management node cannot access SSO service.', '管理节点无法访问单点登录服务，存在网络故障')
ERROR_SSO_MANAGE_NETWORK = (-419, 'The SSO server not in the management network.', '单点登录服务不在管理网段内')
ERROR_NTP_COMMON = (-428, 'NTP time synchronization error occurred.', 'NTP时间同步异常，请检查')
ERROR_GET_NETWORK_INFO = (-420, 'Failed to obtain network information for host “{0}”. Please remove network issues and try again.', u'获取主机“{0}”的网络信息失败，请检查网络后重试')
ERROR_RGW_EXISTED = (-429, 'Please first remove the object gateway role from host “{0}”.', '请先删除与主机“{0}”相关的对象网关角色')
ERROR_DISK_CACHE_ENABLED = (-430, 'Please check if the caches on all disks are disabled.', '请检查主机上所有硬盘的缓存是否关闭')
ERROR_IP_MASK = (-431, 'Invalid IP address.', u'无效的IP地址')             # 主要用于广播地址、组播地址和本地地址的判断
ERROR_LOST_DATA = (-432, 'The cluster might have data loss. Please recover the cluster and then add the disk again.', '集群可能存在数据丢失，请恢复后再添加硬盘')
ERR_GET_NAS_SERVER_NEW = (-421, 'Failed to obtain file storage hosts.', '获取文件存储主机失败')
SUCCESS = (0, "Operation succeeded.", "执行成功")
ERROR_STOR_NUM_LIMIT = (-422, 'The cluster can only have a maximum of 32 storage nodes.', '存储节点数量最多32个')
ERROR_STOR_ADD_MDS_BATCH = (-423, 'Failed to add MDS servers.', '添加元数据服务器失败，{0}')
ERROR_REMOVE_MDS = (-424, 'Failed to delete the MDS server. {0}', '删除元数据服务器失败，{0}')
ERROR_GET_FS = (-425, 'Failed to obtain the file system. {0}', '获取文件系统失败，{0}')
ERROR_DEPLOY_MDS_DISK = (-426, 'Deployment failed. {0}', '部署失败, {0}')
ERROR_ACTIVE_MDS = (-427, 'Failed to activate the metadata server. {0}', '激活元数据服务器失败, {0}')

# BEGIN ADD FOR 集群部署
ERROR_MON_NUM_LIMIT = (-500, 'The cluster can only have a maximum of seven monitor nodes.', '监控节点数量最多7个')
ERROR_CLUSTER_ALREADY_EXIST = (-501, 'The cluster already exists.', '集群已存在')
ERROR_NTP_CONFIG = (-502, 'Failed to configure NTP.', 'NTP配置失败')
ERROR_MANAGE_NTP_CONFIG = (-511, 'Failed to configure NTP on the management node.', '管理节点NTP配置失败')
ERROR_DEPLOY_MON_NODE = (-503, 'Monitor node deployment failed.', '部署监控节点失败')
ERROR_DEPLOY_DATA_NODE = (-504, 'Data node deployment failed.', '部署数据节点失败')
ERROR_COPY_CONF_OTHER_NODE = (-505, 'Failed to copy the configuration file to the destination node.', '拷贝配置文件到其他节点失败')
ERROR_GET_OSD_INFO = (-506, 'Failed to obtain OSD information.', '获取OSD信息失败')
ERROR_INITIALIZE_CLUSTER = (-507, 'Cluster initialization failed.', '初始化集群失败')
ERROR_DEPLOY_THESE_NODES = (-508, 'Error occurred while host “{0}” was being deployed.', '主机“{0}”部署过程出现异常')
ERROR_SOFT_CERTIFICATE = (-509, 'Software authentication failed.', '软件认证失败')
ERROR_LICENSE_CAPACITY_EXCEED = (-510, 'Total disk capacity (%.1f TB) exceeds the maximum capacity ({} TB).', '硬盘总容量（%.1f TB）超过License最大容量（{} TB）')
ERROR_MODIFY_CEPH_CONF = (-512, 'Failed to edit the Ceph configuration.', '修改ceph配置失败')
ERROR_CREATE_NODEPOOL = (-513, 'Failed to create the node pool.', '创建节点池失败')
ERROR_CREATE_DISKPOOL = (-514, 'Failed to create the disk pool.', '创建硬盘池失败')
ERROR_CREATE_RACK = (-515, 'Failed to create the rack.', '创建机架失败')
ERROR_MOVE_RACK = (-516, 'Failed to move the rack.', '移动机架失败')
ERROR_INTERNAL_SERVER = (-517, 'Internal server error.', '服务器内部错误')
ERROR_CREATE_PROTECTION_DOMAIN = (-518, 'Failed to create protection domains.', '创建保护域失败')
ERROR_DEPLOY_ADMIN_NODE = (-519, 'Management node deployment failed.', '部署管理节点失败')
ERROR_HOST_NOT_DELETE = (-520, 'Data balancing is performed on host “{0}”. To avoid data loss, you can perform the {1} operation only after data balancing is completed.', '主机“{0}”数据平衡完成才能{1}，否则会造成数据丢失')
ERROR_INSTALL_SOFT = (-521, 'Failed to install software on the following hosts: {}', '以下主机软件安装失败:{}')
ERROR_CLEAR_ROW_AND_RACK = (-522, 'Failed to remove empty protection domains or racks.', '清除空保护域或机架失败')
ERROR_QUERY_REBALANCE_PROGRESS = (-523, 'Data balancing progress query error.', '查询数据平衡过程进度异常')
ERROR_WAIT_DATA_REBALANCE = (-524, 'Error occurred while waiting for data balancing.', '等待数据数据平衡过程中出现异常')
ERROR_SSH_CONFIG = (-525, 'Failed to configure SSH without password for the following hosts: {}', '以下主机ssh免密配置失败:{}')
ERROR_DEPLOY_OSD = (-526, 'Failed to deploy data nodes on the following hosts: {}', '以下主机部署数据节点失败:{}')
ERROR_CHECK_CRUSH = (-527, 'OSD deployment errors found in the ceph osd tree.', '校验ceph osd tree中osd部署结果存在错误')
ERROR_QUERY_DISKPOOL = (-528, 'Disk pool data query error occurred.', '查询硬盘池数据出现异常')
ERROR_CHECK_CRUSH_OSD = (-529, 'Host “{0}” has disk errors in disk pool “{1}”.', '主机“{0}”部署到硬盘池“{1}”的硬盘存在异常')
ERROR_QUERY_NODEPOOL = (-530, 'Node pool data query error occurred.', '查询节点池数据出现异常')
ERROR_NODEPOOL_MAINTAIN_MODE = (-531, 'The following node pools are in maintenance mode and do not support adding or deleting hosts or disks.', '以下节点池开启维护模式，维护模式下不允许增删主机或硬盘：{}')
ERROR_DISKPOOL_MAINTAIN_MODE = (-532, 'The following disk pools are in maintenance mode and do not support adding or deleting hosts or disks.', '以下硬盘池开启维护模式，维护模式下不允许增删主机或硬盘：{}')
ERROR_QUERY_HOST = (-533, 'ERROR_QUERY_HOST', 'Host data query error occurred.')
ERROR_REMOVE_RACK = (-534, 'Error occurred when deleting the rack.', '删除逻辑机架出现异常')
ERR_SAVE_ZK = (-535, 'Failed to save the cluster management configuration.', '保存集群管理配置数据失败')
ERR_SAVE_HOSTS = (-536, 'Failed to save host data.', '保存主机数据失败')
ERROR_UNCHECK_NETWORK = (-433, 'Network connectivity to host “{0}” is not tested.', u'主机“{0}”未检查网络')
ERROR_SEND_TO_ONESTORD = (-434, 'Failed to send the request to onestord.', u'请求onestord失败')
ERROR_HANDY_MANAGE_IP = (-435, 'Failed to obtain the IP address of the management system on the management network.', u'无法获取管理平台的管理网IP地址')
ERROR_NETWORK_LINK = (-436, 'Failed to connect to host “{0}”.', u'连接主机“{0}”失败')
ERROR_MANAGE_NETWORK_LINK = (-437, 'Failed to obtain the IP address of host “{0}” on the management network.', u'无法获取主机“{0}”的管理网IP地址')
ERROR_PUBLIC_NETWORK_LINK = (-438, 'Failed to obtain the IP address of host “{0}” on the storage front-end network.', u'无法获取主机“{0}”的存储前端网IP地址')
ERROR_CLUSTER_NETWORK_LINK = (-439, 'Failed to obtain the IP address of host “{0}” on the storage back-end network.', u'无法获取主机“{0}”的存储后端网IP地址')
ERROR_ZK_DEPLOY = (-440, 'Network monitor module deployment failed.', u'部署网络监控模块失败')
ERROR_NOT_X10000 = (-441, 'Host “{0}” is not an X10000 server.', u'主机{0}不是一体机设备')
ERR_CHANGE_LANGUATE = (-712, "Changing language failed.", "切换语言失败")
ERR_QUERY_LANGUATE = (-713, "Querying language failed.", "查询语言失败")


def format_error(err, *args):
    """
    格式化错误信息，适用于带参数的错误提示
    """
    return err[0], err[1], err[2].format(*args)


class ONEStorConfigError(Exception):
    """
    请求处理错误
    """

    def __init__(self, error, *args):
        super(ONEStorConfigError, self).__init__()
        self.error_code = error[1]
        self.reason = error[2].format(*args)


class ONEStorError(Exception):
    """
    请求处理错误
    """

    def __init__(self, error, *args):
        super(ONEStorError, self).__init__()
        self.error_code = error[1]
        self.reason = error[2].format(*args)

    def __str__(self):
        return "\r\nerror code: {0}, \r\nreason: {1}".format(self.error_code, self.reason)

    @staticmethod
    def make_error(error_code, reason):
        """
        根据err_code和reason生成error
        """
        return ONEStorError((0, error_code, reason))


class ONEStorHostError(Exception):
    """
    请求处理错误
    """

    def __init__(self, error, nodes, error_step, *args):
        super(ONEStorHostError, self).__init__()
        self.error_code = error[1]
        self.nodes = nodes
        self.error_step = error_step
        self.reason = error[2].format(*args)

    def __str__(self):
        return "\r\nerror code: {0}, \r\nreason: {1}, \r\nnodes: {2}".format(
            self.error_code, self.reason, self.nodes)


class APIError(Exception):
    """
    API接口处理错误
    """
    def __init__(self, error):
        super(APIError, self).__init__()
        self.error = error

    def __str__(self):
        return "\r\nerror: {0}".format(self.error)
