# coding:utf-8


"""
定义校验正则表达式
"""
from onestor import regexp
handy_username_regexp = regexp.check_regexp["handy_user_name"]

checkRegExp = dict()
required_item = dict()

# 校验正则表达式

# 用户组管理 BEGIN

# 用户组管理 END

# 异地灾备 BEGIN
checkRegExp['original_log_block'] = \
    checkRegExp['backup_log_block'] = \
    checkRegExp['block_name'] = \
    checkRegExp['backup_block_name'] = \
    r'(^[A-Za-z0-9][A-Za-z0-9\_\-\.]{0,29})+(/)+([A-Za-z0-9][A-Za-z0-9\_\-\.]{0,29}$)'

checkRegExp['snap_name_log_block'] = \
    r'(_onebackup_)+({[\d]+}_)+({[\d\.]+})+(_{[\s\S]*})+(_{[\s\S]*})+(_{[\s\S]*})'
# 异地灾备 END

checkRegExp['linux_host_name'] = r'^[A-Za-z][A-Za-z0-9\-]*$'

###############################################################################

# 校验非空字段，key为方法名称，value为需要校验的字段

# 用户组管理 BEGIN
required_item['list_group_user'] = ['groupname']


# 用户组管理 END

# 异地灾备 BEGIN
required_item['restore_backup_block'] = ['original_log_block', 'backup_log_block', 'snap_name_log_block']

required_item['clear_backup_task'] = ['block_name']

required_item['manual_backup'] = \
    required_item['stop_backup'] = \
    required_item['get_snap_list'] = \
    required_item['remove_backup_block'] = \
    ['block_name', 'backup_block_name']
# 异地灾备 END
