#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
    Author: dai.xinchun@h3c.com
    Date: 2016/09/07
    Description: UNIStor转发类，用于将前台的消息转发给ONEStord
"""

import os
import json
import logging

from rest_framework import status
from rest_framework.response import Response
from calamari_rest.views.rpc_view import RPCViewSet
from calamari_rest.common import filter_password, do_filter
from calamari_web import add_operation_log
from calamari_web import docker_get_leader_ip, set_leader_ip_in_docker
from django.http.request import QueryDict

import onestor
from onestor import const
from onestor import message
from onestor import errno
from onestor.config import CephConf
from onestor.errno import ONEStorError
from onestor.plat.cm.ha import hamessage as hamsg
from onestor.sys import sysmessage as sysmsg
from onestor.plat.cm.host import hostmessage as hostmsg
from onestor.plat.cm.syslog import logmessage as syslogmsg
from onestor.plat.cm.oplog import logmessage as oplogmsg
from onestor.fs import fsmessage as fsmsg
from onestor.cs import csmessage as csmsg
from onestor.cm import cmmessage as cmmsg
from onestor.obs import obsmessage as obsmsg
from onestor.scrub import scrubmessage as scrubmsg
from onestor.opt import optmessage
from onestor.tgt import tgtmessage
from onestor.dm import dmmessage
from onestor.plat.alarm import alarm_message
from onestor.plat.snmp import snmpmessage as snmpmsg
from onestor.plat.cm.usermanage import ummessage as ummsg
from onestor.plat.tasks import task_message as taskmsg
from onestor.plat.cm.ntp import ntpmessage as ntpmsg
from onestor.plat.cm.patch import patchmessage as patchmsg
from onestor.blk import blkmessage as blkmsg
from onestor.mr import mr_message as mrmsg
from onestor.qos import qosmessage as qosmsg
from onestor.plat.lics import licsmessage as licsmsg
from onestor.plat.emp import empmessage
from onestor.pcs import pcs_message
from onestor.plat.cm.multicluster import multicluster_message as mcmsg
from onestor.plat.cm.auditlog import logmessage as auditlogmsg

log = logging.getLogger('django.request')

"""
    Author: dai.xinchun@h3c.com
    Date: 2016/09/07
    Description: ONEStor转发类，用于将前台的消息转发给ONEStord
"""

CONST_OP = 'op'
CONST_COMP = 'comp'
CONST_DATA = 'data'
CONST_ERROR = 'error'
CONST_SUMMARY = 'summary'
CONST_BATCH = 'is_batch'
# begin add by d11564 增加批量操作op,不需要前台记录操作日志
NOT_SAVE_OP_LOG = ['QUOTA_create', 'QUOTA_modify', 'QUOTA_delete', 'LB_add', 'LB_modify', 'CIFS_remove_authority', 'FTP_anon_enable', 'FTP_anon_disable']
NOT_SAVE_COMP_LOG = ['COMP_ALARM', 'COMP_SNMP']
NOT_SAVE_LOG = ['QUOTA_create', 'QUOTA_modify', 'QUOTA_delete']
# end by d11564
CONST_TIMEOUT = 'timeout'
OPLOG_USER = const.OPLOG_USER
OPLOG_IP = const.OPLOG_IP
LOG_KEY = const.LOG_KEY
COMP_UM = message.COMP_UM
COMP_FS = message.COMP_FS
COMP_PATCH = message.COMP_PATCH
COMP_MULTICLUSTER = message.COMP_MULTICLUSTER
OP_PATCH_UPLOAD = patchmsg.OP_PATCH_UPLOAD
OP_PATCH_DELETE = patchmsg.OP_PATCH_DELETE
OP_LIST_USER_PERMISSION = ummsg.OP_LIST_USER_PERMISSION
OP_USER_CHECK_SAMEUSER = fsmsg.OP_USER_CHECK_SAMEUSER_LEADER
OP_MULTICLUSTER_QUERY = mcmsg.OP_MULTICLUSTER_QUERY
ONLY_SUPERUSER_OPERATE_COMP = [message.COMP_UM]


class ForwardView(RPCViewSet):
    """
    公共转发接口
    """
    def __init__(self, *args, **kwargs):
        """
        初始化
        """
        super(ForwardView, self).__init__(*args, **kwargs)

    @staticmethod
    def make_request(comp, op):
        """
        request生成器
        :param comp: 模块名
        :param op: 操作名
        :return:
        """

        def _make_request(data):
            """
            闭包函数，根据操作码生成对应组件下的request请求
            :param data:
            :return:
            """
            if message.COMP_HA == comp:
                _request = hamsg.make_request(op)
            elif message.COMP_SYS == comp:
                _request = sysmsg.make_request(op)
            elif message.COMP_HOST == comp:
                _request = hostmsg.make_request(op)
            elif message.COMP_LB == comp:
                _request = fsmsg.make_request(op)
            elif message.COMP_FS == comp:
                _request = fsmsg.make_request(op)
            elif message.COMP_SCRUB == comp:
                _request = scrubmsg.make_request(op)
            # begin add by d11564  2017/05/10 PN:201705040287 加预读大小
            elif message.COMP_OPT == comp:
                _request = optmessage.make_request(op)
            elif message.COMP_CS == comp:
                _request = csmsg.make_request(op)
            elif message.COMP_CM == comp:
                _request = cmmsg.make_request(op)
            # end add by d11564  2017/05/10 PN:201705040287 加预读大小
            elif message.COMP_TGT == comp:
                _request = tgtmessage.make_request(op)
            elif message.COMP_DM == comp:
                _request = dmmessage.make_request(op)
            elif message.COMP_ALARM == comp:
                _request = alarm_message.make_request(op)
            elif message.COMP_SNMP == comp:
                _request = snmpmsg.make_request(op)
            elif message.COMP_UM == comp:
                _request = ummsg.make_request(op)
            elif message.COMP_SYSTEM_LOG == comp:
                _request = syslogmsg.make_request(op)
            elif message.COMP_OPERATION_LOG == comp:
                _request = oplogmsg.make_request(op)
            elif message.COMP_TASK == comp:
                _request = taskmsg.make_request(op)
            elif message.COMP_OS == comp:
                _request = obsmsg.make_request(op)
            elif message.COMP_NTP == comp:
                _request = ntpmsg.make_request(op)
            elif message.COMP_BLK == comp:
                _request = blkmsg.make_request(op)
            elif message.COMP_MR == comp:
                _request = mrmsg.make_request(op)
            elif message.COMP_QOS == comp:
                _request = qosmsg.make_request(op)
            elif message.COMP_LICS == comp:
                _request = licsmsg.make_request(op)
            elif message.COMP_EMP == comp:
                _request = empmessage.make_request(op)
            elif message.COMP_DOCKER_SUVE == comp:
                _request = pcs_message.make_request(op)
            elif message.COMP_MULTICLUSTER == comp:
                _request = mcmsg.make_request(op)
            elif message.COMP_PATCH == comp:
                _request = patchmsg.make_request(op)
            elif message.COMP_AUDIT_LOG == comp:
                _request = auditlogmsg.make_request(op)
            else:
                raise ONEStorError(errno.ERR_INVALID_OP)
            _request.data = data
            return _request

        return _make_request

    def get_model_timeout(self, comp, op):
        """

        :return:
        """
        _timeout = 30
        if message.COMP_HA == comp:
            _timeout = hamsg.estimate_time(op)
        elif message.COMP_SYS == comp:
            _timeout = sysmsg.estimate_time(op)
        elif message.COMP_HOST == comp:
            _timeout = hostmsg.estimate_time(op)
        elif message.COMP_LB == comp:
            _timeout = fsmsg.estimate_time(op)
        elif message.COMP_FS == comp:
            _timeout = fsmsg.estimate_time(op)
        elif message.COMP_SCRUB == comp:
            _timeout = scrubmsg.estimate_time(op)
        elif message.COMP_OPT == comp:
            _timeout = optmessage.estimate_time(op)
        elif message.COMP_CS == comp:
            _timeout = csmsg.estimate_time(op)
        elif message.COMP_TGT == comp:
            _timeout = tgtmessage.estimate_time(op)
        elif message.COMP_DM == comp:
            _timeout = dmmessage.estimate_time(op)
        elif message.COMP_CM == comp:
            _timeout = cmmsg.estimate_time(op)
        elif message.COMP_ALARM == comp:
            _timeout = alarm_message.estimate_time(op)
        elif message.COMP_SNMP == comp:
            _timeout = snmpmsg.estimate_time(op)
        # elif message.COMP_UM == comp:
        #     _timeout = ummsg.estimate_time(op)
        elif message.COMP_SYSTEM_LOG == comp:
            _timeout = syslogmsg.estimate_time(op)
        elif message.COMP_OPERATION_LOG == comp:
            _timeout = oplogmsg.estimate_time(op)
        elif message.COMP_TASK == comp:
            _timeout = taskmsg.estimate_time(op)
        elif message.COMP_OS == comp:
            _timeout = obsmsg.estimate_time(op)
        elif message.COMP_NTP == comp:
            _timeout = ntpmsg.estimate_time(op)
        elif message.COMP_BLK == comp:
            _timeout = blkmsg.estimate_time(op)
        elif message.COMP_MR == comp:
            _timeout = mrmsg.estimate_time(op)
        elif message.COMP_QOS == comp:
            _timeout = qosmsg.estimate_time(op)
        elif message.COMP_LICS == comp:
            _timeout = licsmsg.estimate_time(op)
        elif message.COMP_EMP == comp:
            _timeout = empmessage.estimate_time(op)
        elif message.COMP_DOCKER_SUVE == comp:
            _timeout = pcs_message.estimate_time(op)
        elif message.COMP_MULTICLUSTER == comp:
            _timeout = mcmsg.estimate_time(op)
        elif message.COMP_PATCH == comp:
            _timeout = patchmsg.estimate_time(op)
        elif message.COMP_AUDIT_LOG == comp:
            _timeout = auditlogmsg.estimate_time(op)
        return _timeout

    def handle_request_message(self, request, fsid):
        """
        处理Handy Client发送过来的REST请求，并将处理的结果返回
        :param request:
        :param fsid:
        请求格式如下：
        {
            "comp": "COMP_HA",
            "op": "HA_create_user",
            "data": {
                "username": "test01",
                "groupname": "group01"
            },
            "timeout": 200  //指定超时时间
        }
        响应格式如下：
        {
            "data": {
                "license_type": 0,
                "max_capacity": -1,
                "is_register": false,
                "expire_time": 1457122908
            },
            "result": [
                0,
                "success",
                ""
            ],
            "req_id": 2
        }
        如果请求后台超时，响应格式如下：
        TODO
        """
        op = request.DATA.get(CONST_OP)
        comp = request.DATA.get(CONST_COMP)
        summary = request.DATA.get(CONST_SUMMARY)
        data = request.DATA.get(CONST_DATA)

        try:
            upload_file = request.FILES.get('uploadFile', None)
            if upload_file is not None:
                if not isinstance(data, dict):
                    data = json.loads(data)
                op = data.get(CONST_OP)
                comp = data.get(CONST_COMP)
                summary = data.get(CONST_SUMMARY)
                data = data['data']
                data['upload_file'] = upload_file.read()
        except Exception, e:
            log.exception(e)

        is_batch = False

        if not isinstance(data, dict):
            return Response(status=status.HTTP_400_BAD_REQUEST)

        try:
            if comp == 'COMP_HOST' and op == 'CHECK_network_segment':
                set_leader_ip_in_docker(data)

            _timeout = self.get_model_timeout(comp, op)
            if CephConf().multicluster_ip is None:
                client = onestor.message.Messenger.create_leaderclient(
                    host='localhost', timeout=_timeout)
            else:
                if os.path.exists("/.dockerenv"):
                    _host = docker_get_leader_ip()
                else:
                    _host = '127.0.0.1'
                client = onestor.message.Messenger.create_multicluster_client(
                    host=_host, timeout=_timeout)
            if client is None:
                return Response({'result': errno.ERR_CONNECT})

            if summary is not None:
                # 往data中补充IP地址、用户名和操作日志概要
                data[const.OPLOG_USER] = request.user.username
                data[const.OPLOG_IP] = request.META.get('REMOTE_ADDR')
                data[const.OPLOG_SUMMARY] = summary

            # 增加批量操作后台记录操作日志，summary依然会传递，修改为postgres记录操作日志后可删除
            if CONST_BATCH in data and data[CONST_BATCH] is True:
                is_batch = data[CONST_BATCH]
                data[const.OPLOG_IS_BATCH] = is_batch
            # end add by l11544

            request_forward = self.make_request(comp, op)(data)
            filtered_passwd_data = filter_password(data, ["password", "passwd"])
            if summary is not None:
                log.info('begin handle request..(%s,%s)..\n%s\n==============',  comp, op, filtered_passwd_data)
            response = client.send_request(request_forward)
            if summary is not None:
                log.info('finish handle request...\n%s\n==============', response)
        except ONEStorError, err:
            log.exception(err)
            return Response({CONST_ERROR: err.error_code}, status=status.HTTP_400_BAD_REQUEST)
        except Exception, err:
            log.exception(err)
            return Response({CONST_ERROR: str(err)}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
        else:
            return Response(response.to_json())
        finally:
            if summary is not None and not is_batch:
                # begin modify by d11564 判断不是批量操作op,才记录操作日志
                client_addr = request.META.get("REMOTE_ADDR", None)
                username = request.user.username
                if client is not None:
                    if op not in NOT_SAVE_OP_LOG and comp not in NOT_SAVE_COMP_LOG:
                        reason = 'success' if 0 == response.result[0] else response.result[2]
                        add_operation_log(client_addr, username, summary, reason)
                else:
                    if op not in NOT_SAVE_LOG:
                        reason = errno.ERR_CONNECT[2]
                        add_operation_log(client_addr, username, summary, reason)
                    # end by d11564

    def send_request_to_leader(self, comp_op, data={}, request=None, unistor_api=True, is_get=False):
        comp, op = comp_op
        if not isinstance(data, dict):
            return Response(status=status.HTTP_400_BAD_REQUEST)
        try:
            if request and comp in ONLY_SUPERUSER_OPERATE_COMP:
                data[const.MANAGER] = request.user.username

            if isinstance(data, QueryDict):
                data = data.dict()
            if '__async__' in data and 'true' == data['__async__']:
                data['__async__'] = True
            fe_timeout_list = [csmsg.OP_RAID_CREATE]
            if op in fe_timeout_list:
                _timeout = data['timeout']
            else:
                _timeout = self.get_model_timeout(comp, op)
            if CephConf().multicluster_ip is None:
                client = message.Messenger.create_leaderclient(host='localhost', timeout=_timeout)
            else:
                if os.path.exists("/.dockerenv"):
                    _host = docker_get_leader_ip()
                else:
                    _host = '127.0.0.1'
                client = message.Messenger.create_multicluster_client(host=_host, timeout=_timeout)
            request_forward = self.make_request(comp, op)(data)
            filtered_passwd_data = filter_password(data, ["password", "passwd"])
            if is_get:
                log.debug('begin handle request..(%s,%s)..\n%s\n==============', comp, op, filtered_passwd_data)
            else:
                log.info('begin handle request..(%s,%s)..\n%s\n==============',  comp, op, filtered_passwd_data)
            response = client.send_request(request_forward)
            # 返回集群管理节点的IP
            if os.path.exists("/.dockerenv") and comp == message.COMP_MULTICLUSTER and op == 'MULTICLUSTER_QUERY':
                if isinstance(response.data, dict):
                    response.data['manage_node_ip'] = docker_get_leader_ip()
            # ONEStor2.0接口调用需要适配相应参数
            if not unistor_api:
                return response.to_json()
            if is_get:
                log.debug('finish handle request...\n%s\n========================', response)
            else:
                log.info('finish handle request...\n%s\n========================', response)
        except ONEStorError, err:
            log.exception(err)
            return Response({CONST_ERROR: err.error_code}, status=status.HTTP_400_BAD_REQUEST)
        except Exception, err:
            log.exception(err)
            return Response({CONST_ERROR: str(err)}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(response.to_json())
