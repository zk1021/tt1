#!/usr/bin/env python
# coding: utf-8

"""
定义校验正则
"""
import re

EXP_USER_NAME = r'^[A-Za-z0-9_\-\.]{1,30}$'
EXP_PERMISSIONS = r'^\d+(,\d+)*$'


def validate(exp, data):
    """
    校验正则表达式
    :param exp:
    :param data:
    :return:
    """
    re_exp = re.compile(exp)
    return True if re_exp.match(data) else False
