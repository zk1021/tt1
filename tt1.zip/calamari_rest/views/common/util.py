# -*- coding:utf-8 -*-

import re
import os
import time
import json
import base64
import logging
import threading
import functools

import onestor
from rest_framework.response import Response
from django.http.request import QueryDict

from calamari_rest.views.onestor_common import ONEStorCommon
from calamari_rest.views.onestor import database
from calamari_rest.views.common import const, errno, regexp, op_log, cmd
from calamari_rest.views.usermanage import HAUser, HAGroup, HAResponse
from calamari_rest.views.onestor_common import ONEStorResponse, ONEBackupError

# PN: 201612260612 增加写入集群主机的业务网IP配置
# 兼容V1R1版本 for maintain
# end by l11544

log = logging.getLogger('django.request')

"""
    Author: dai.xinchun@h3c.com
    Date: 2016/07/28
    Description: ONEStor工具类
"""


class SlaveResponse(object):
    """
    备用Handy响应
    """

    def __init__(self):
        self.result = const.OP_SUCCSSFUL  # 错误码
        self.data = {}  # 响应数据

    def to_json(self):
        """
        将响应转换为json格式
        """
        ret = {
            "result": self.result,
            "data": self.data,
        }
        return ret

    def is_successful(self):
        """
        检查响应，判断请求是否执行成功
        """
        return self.result == const.OP_SUCCSSFUL


def send_to_slave_handy(op, data, slave_handy_ip=None, is_ha_user=None):
    """
    发送给备Handy，同步数据
    """
    response = SlaveResponse()

    if not slave_handy_ip:
        # 从数据库中获取另一个Handy的地址
        handy_util = HandyUtil()
        slave_handy_ip = handy_util.get_slave_handy_ip()

    # 如果没有返回备用节点的IP地址，则未开启HandyHA功能
    if not slave_handy_ip:
        return response

    client = onestor.message.Messenger.create_peonclient(slave_handy_ip)
    # 无法连接备用Handy时直接返回失败
    if not client:
        response.result = errno.ERR_CONNECT_SLAVE_FAILED
        if is_ha_user:
            response.result = errno.ERR_CONNECT_TO_WORKING_SLAVE
        return response

    request = onestor.ha.hamessage.make_request(op)
    request.data = data
    log.info('send_to_slave_handy request is: %s', request)
    response = client.send_request(request)
    log.info('send_to_slave_handy response is: %s', response)
    return response


def process_validate_params(params, func_name):
    """
    通过正则表达式校验输入参数是否合法
    """
    # 如果是GET或DELETE请求，需要对数据类型进行预处理
    if QueryDict == type(params):
        params = dict(params)
        for key in params:
            params[key] = params[key][0]

    # 先校验必填的参数
    if func_name in regexp.required_item:
        required_param = regexp.required_item[func_name]
        for param in required_param:
            if param not in params:
                raise errno.ONEStorError((-1, 'INVALID_PARAM', op_log.NULL_PARAM.format(param)))

    # 再逐个校验必填参数是否合法
    log.info('[ONEStor] process function "%s", params is: %s', func_name, params)
    for key in params:
        if key not in regexp.checkRegExp:
            continue
        if not re.match(regexp.checkRegExp[key], str(params[key])):
            raise errno.ONEStorError((-2, 'INVALID_PARAM', op_log.INVALID_PARAM.format(key)))


def set_onestor_progress(step):
    """
    设置ONEStor页面的进度
    """
    os.system(cmd.CMD_SET_ONESTOR_PROGRESS.format(step, const.ONESTOR_PROGRESS_HA_FILE))


def get_onestor_progress():
    """
    获取ONEStor页面的进度
    """
    return os.popen(cmd.CMD_GET_ONESTOR_PROGRESS.format(const.ONESTOR_PROGRESS_HA_FILE)).read().strip()


def clear_onestor_task():
    """
    删除ONEStor进度临时文件
    """
    os.system(cmd.CMD_RM_FILE.format(const.ONESTOR_PROGRESS_HA_FILE))


def _process_user_return(ret_type, user_return, error_code, error_reason, nodes, error_step):
    """
    根据返回类型生成返回的数据
    """
    if user_return:
        return user_return

    if const.RETURN_TYPE_2 == ret_type:
        if '' == error_code:
            user_return = {
                'success': True
            }
        else:
            user_return = {
                'success': False,
                'errorcode': str(error_code),
                'error': error_reason
            }
    elif const.RETURN_TYPE_3 == ret_type:
        if '' == error_code:
            user_return = {
                'success': True
            }
        else:
            user_return = {
                'success': False,
                'errorcode': str(error_code),
                'error': error_reason if '' == error_step else error_step,
                'nodes': nodes
            }
    return user_return


def __update_task_progress(_self, op, error_code, error_reason, request):
    """
    当操作结束时在finally方法中标记任务进度为finish
    """
    # 从request中取出task id来
    task_id = None
    if hasattr(request, 'GET') and 'task_id' in request.GET:
        task_id = request.GET.get('task_id')
    elif hasattr(request, 'DATA') and 'task_id' in request.DATA:
        task_id = request.DATA['task_id']
    else:
        log.warn('invalid request when update task progress')

    tasks_info = _self.read_progress(const.ONESTOR_PROGRESS, op)
    has_task = False
    for task in tasks_info['tasks']:
        if task_id == task['task_id']:
            has_task = True
            ftime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
            task['ftime'] = ftime
            task['status'] = 'finish'
            task['errorcode'] = str(error_code)
            task['error_reason'] = str(error_reason)
    # begin add by z11524 date: 2017/11/12 PN:201710180116
    if not has_task and 'ERROR_HOST_BUSY_REMOVE' == str(error_code):
        this_task = {
            'task_id': task_id,
            'op': op,
            'ctime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
            'ftime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
            'status': 'finish',
            'errorcode': str(error_code),
            'error_reason': str(error_reason)
        }
        tasks_info['tasks'].append(this_task)
    # end add by z11524 date: 2017/11/12 PN:201710180116
    if task_id is not None:
        _self.write_progress(const.ONESTOR_PROGRESS, tasks_info['tasks'])
        # delete by z11524 2017/8/3 PN:201707260904
    else:
        log.warn('task id is None when update task progress, op is %s', op)


def reload_apache(_self, op, error_code):
    """
    配置HandyHA操作成功时需要重新加载apache
    add by z11524 2017/8/3 PN:201707260904
    """
    if (const.OP_CREATE_HANDY_HA_CFG == op or const.OP_REMOVE_HANDY_HA_CFG == op) and '' == error_code:
        log.info('update last op time...')
        _self.update_last_op_time(op)
        log.info('reload apache2 when execute {0}...'.format(const.OP_CREATE_HANDY_HA_CFG))
        _self.exec_local_cmd(cmd.SERVICE_RELOAD_APACHE)


def send_response(op=None, ret_type=const.RETURN_TYPE_1):
    """
    请求处理完成后的处理：
    1、如果是增、删、改，记录操作日志并返回HttpResponse给页面
    2、如果是查询，直接返回HttpResponse给页面
    """

    def decorate(func):
        """
        装饰器
        """

        @functools.wraps(func)
        def _decorate(_self, request, fsid=None):
            """
            装饰器
            """
            resp = []
            error_code = ''
            error_step = ''
            error_reason = ''
            operationlog = op_log.DEFAULT_OPERATION_LOG
            user_return = None
            nodes = None
            try:
                if const.OP_LIST == op:
                    # 查询类操作直接返回数据
                    resp = func(_self, request, fsid).next()
                else:
                    # 遍历所有func里的yield，根据不同的数据类型进行相应的处理
                    for result in func(_self, request, fsid):
                        if result is None:
                            continue
                        if isinstance(result, dict) or isinstance(result, QueryDict):
                            # 在此校验参数是否合法，如果不合法，则抛出异常
                            process_validate_params(result, func.__name__)
                        elif isinstance(result, str) or isinstance(result, unicode):
                            # 传过来的字符串作为操作日志
                            operationlog = result
                        elif isinstance(result, HAResponse):
                            # 处理用户组的返回值
                            response = result.to_json()
                            if response['success']:
                                user_return = {'success': True, 'rt': response['rt'], 'type': response['type']}
                            else:
                                # 如果遇到错误的返回值，需要跳出循环，不再继续执行
                                error_code = response['error'][1]
                                error_reason = response['error'][2]
                                user_return = {'success': False, 'error': response['error'][2]}
                                break
            except ONEBackupError as ex:
                log.exception(ex)
                error_code = ex.errorcode
                error_reason = ex.reason
            except errno.ONEStorConfigError as ex:
                log.exception(ex)
                error_code = ex.error_code
                error_reason = ex.reason
                if const.RETURN_TYPE_1 == ret_type:
                    user_return = {
                        "status": "error",
                        "errorcode": error_code,
                        "reason": error_reason
                    }
                else:
                    user_return = {
                        'success': False,
                        'error': error_reason
                    }
            except errno.ONEStorError as ex:
                error_code = ex.error_code
                error_reason = ex.reason
            except errno.ONEStorHostError as ex:
                nodes = ex.nodes
                error_code = ex.error_code
                error_reason = ex.reason
                error_step = ex.error_step
            except Exception as ex:
                log.exception(ex)
                error_code = ex
                error_reason = op_log.DEFAULT_ERROR_REASON
            finally:
                # 查询类的操作不需要记录操作日志
                if const.OP_LIST == op:
                    return Response(resp)
                # 操作类清理文件中的进度
                clear_onestor_task()
                # 网络故障的操作日志
                if os.path.exists(const.NETWORK_FAULT_TMP_FILE):
                    with open(const.NETWORK_FAULT_TMP_FILE, 'rb') as f:
                        if op == f.readline().strip():
                            error_reason = const.ERR_NETWORK_FAULT
                            error_code = 'NETWORK_FAULT'
                            os.system(cmd.CMD_RM_FILE.format(const.NETWORK_FAULT_TMP_FILE))
                # 处理返回类型
                user_return = _process_user_return(
                    ret_type, user_return, error_code, error_reason, nodes, error_step)
                # update by z11524 2017/8/3 PN:201707260904
                result = ONEStorResponse().init(
                    fsid, request, operationlog, str(error_code), error_reason, user_return)
                # 部署集群操作不需要记录操作日志
                if const.OP_CREATE_CLUSTER == op:
                    return result
                # 当任务结束时，更新到进度文件中
                __update_task_progress(_self, op, error_code, error_reason, request)
                reload_apache(_self, op, error_code)
                return result
        return _decorate

    return decorate


def before_return(final=None, roolback=None):
    """
    装饰器 - 请求返回之前要执行的方法
    :author: daixinchun <dai.xinchun@h3c.com>
    :date: 2016/12/09
    """

    def decorate(func):
        """
        装饰器
        """

        @functools.wraps(func)
        def _decorate(*args, **kwargs):
            try:
                result = func(*args, **kwargs)
                for ret in result:
                    yield ret
            except Exception, e:
                log.exception(e)
                if roolback:
                    log.error('execute func <%s> failed, begin rollback...', func.__name__)
                    try:
                        roolback(*args)
                    except Exception, err:
                        log.exception('rollback error, reason is %s', str(err))
                raise e
            finally:
                if final:
                    try:
                        final(*args)
                    except Exception, err:
                        log.exception('do finally error, reason is %s', str(err))

        return _decorate

    return decorate


class HandyUtil(ONEStorCommon):
    def __init__(self, need_config=True, *args, **kwargs):
        super(HandyUtil, self).__init__(*args, **kwargs)
        self.filepath = os.path.split(os.path.realpath(__file__))[0].split('/common')[0]
        if need_config:
            self.cluster_config = self.get_config_from_conf_file()

    def get_slave_handy_ip(self):
        """
        获取另一个Handy的IP地址
        """
        handy_ha_cfg = self.list_handyha()

        handy_cfg = handy_ha_cfg[const.TABLE_HANDY_HA]
        if 0 == len(handy_cfg):
            return None

        master = handy_cfg[0][const.CONST_HA_MASTER]
        slave = handy_cfg[0][const.CONST_HA_SLAVE]

        # 获取当前节点上所有的IP地址
        get_ip_result = self.exec_local_cmd(cmd.CMD_LIST_NETWORK_INTERFACES)
        local_ips = [ip for ip in get_ip_result.split('\n') if '' != ip]

        return slave if master in local_ips else master

    def get_handy_manage_ip(self, manage_network):
        """
        获取Handy自身的管理网段IP地址
        """
        # 从本地获取Handy所有的IP
        get_ip_result = self.exec_local_cmd(cmd.CMD_LIST_NETWORK_INTERFACES)
        local_ips = [ip for ip in get_ip_result.split('\n') if '' != ip]

        # 将管理网段内的IP地址返回，可能会有多个，页面只使用第一个即可
        manage_network_ip = [ip for ip in local_ips if self.subnet_judge(manage_network, ip)]
        if 0 == len(manage_network_ip):
            return None

        return manage_network_ip[0]

    def get_handy_public_ip(self):
        """
        获取Handy自身的业务网段IP地址
        """
        public_network = self.cluster_config[const.PUBLIC_NETWORK]
        return os.popen(cmd.CMD_GET_HANDY_PUBLIC_IP.format(
            self.filepath, public_network)).read().rstrip()

    def cmd_remote(self, host_ip, passwd, command, user=const.USER_ROOT):
        """
        根据用户名和密码到远端执行命令并返回
        """
        log.info('run cmd remote, host is "%s", command is "%s"', host_ip, command)
        result = self.exec_local_cmd(cmd.CMD_RUN_REMOTE_CMD.format(
            self.filepath, host_ip, user, passwd, command))
        log.info('run cmd remote, result is "%s"', result)

        # 检查结果
        if -1 != result.find('e400:'):
            raise errno.ONEStorConfigError(errno.ERR_AUTH_FAILED)
        return result

    def _check_x10000_version(self, host_ip, passwd, user=const.USER_ROOT):
        """
        检测主机是否是一体机设备
        :return:
        """
        from calamari_rest.views.lics.lics_view import LicsViewSet
        return LicsViewSet().check_x10000(host_ip, user, passwd)

    def check_license(self, disk_pool_list, host_list, node_ip, user=None, passwd=None, batch=False, in_cluster=False):
        # BEGIN ADD BY z14172 2017/12/22 容量校验，识别一体机
        from calamari_rest.views.lics.lics_view import LicsViewSet
        lics_view_set = LicsViewSet()
        if lics_view_set.is_soft_version():
            # 软件产品检测容量
            license_check_result = lics_view_set.check_diskpool_capacity(disk_pool_list, host_list)
            if not license_check_result['success']:
                error_code = 'LICENSE_CAPACITY_EXCEED'
                raise errno.ONEStorError.make_error(error_code, license_check_result['reason'])
        else:
            # 一体机产品检测待添加主机是否为一体机设备
            if batch:
                ip_list = node_ip.split(',')
                license_check_result = self._check_x10000_version(ip_list, passwd)
                not_x10000_host = ''
                for host_ip in ip_list:
                    if not license_check_result[host_ip]['is_X10000']:
                        not_x10000_host += str(node_ip) + ','
                if not_x10000_host:
                    raise errno.ONEStorError(errno.ERROR_NOT_X10000, not_x10000_host[:-1])
            else:
                if in_cluster:
                    return
                elif not self._check_x10000_version(node_ip, passwd):
                    raise errno.ONEStorError(errno.ERROR_NOT_X10000, node_ip)

    def multi_thread(self, nodes, command, passwd='', user=const.USER_ROOT, ip_cache_map=None):
        """
        多线程执行任务
        """
        results = {}
        threads = []
        nloops = range(len(nodes))

        log.info("[ONEStor] multi_thread nodes is '%s', command is '%s'", nodes, command)

        # BEGIN ADD BY h13051 PN:201704280428
        ssh_multi_thread_lock = threading.Lock()
        # END ADD BY h13051
        def execute(node):
            node_ip = self.name_to_ip(node)

            # 先检查node节点是否能ping通
            if not self.network_check(node_ip):
                results[node] = const.NETWORK_FAULT
            else:
                result = const.OP_SUCCSSFUL
                try:
                    # 批量安装软件
                    if const.STEP_INSTALL_SOFT == command:
                        result = self.install_soft(node_ip, passwd, user)
                    # 批量进行免密
                    elif const.STEP_SSH_CONFIG == command:
                        with ssh_multi_thread_lock:
                            result = self.ssh_config(node_ip, passwd, user)
                    # 批量同步集群配置
                    elif const.STEP_SYNC_CONFIG == command:
                        # BEGIN ADD BY C13463 修改journal_size，flashcache_size
                        if ip_cache_map is not None and node_ip in ip_cache_map:
                            self.sync_cluster_config(
                                node_ip, ip_cache_map[node_ip]['journal_size'],
                                ip_cache_map[node_ip]['flashcache_size'])
                        # END ADD BY C13463
                        else:
                            self.sync_cluster_config(node_ip)
                    # 批量配置NTP同步
                    elif const.STEP_SETUP_NTP == command:
                        self.setup_ntp_client(node)
                    # begin add by z14172 2017/12/25
                    # 批量检测一体机设备
                    elif const.STEP_VALIDATE_LICENSE == command:
                        result = self._check_x10000_version(node_ip, passwd)
                    # end add  by z14172 2017/12/25
                except Exception, e:
                    log.exception(e)
                    results[node] = e
                else:
                    results[node] = result

        for _node in nodes:
            t = threading.Thread(target=execute, args=(_node,))
            threads.append(t)

        for i in nloops:
            threads[i].start()

        for i in nloops:
            threads[i].join()

        log.info("[ONEStor] multi_thread result: %s", results)

        return results

    def get_node_public_ip(self, host_ip, passwd, user=const.USER_ROOT):
        """
        获取节点的业务网IP
        """
        public_network = self.cluster_config[const.PUBLIC_NETWORK]

        # 获取节点上的所有IP
        ip_addr = self.cmd_remote(host_ip, passwd, cmd.CMD_IP_ADDR, user)
        # begin add by z11524 过滤掉业务高可用的虚ip 2017/2/8
        ha_list = self.exec_local_cmd_json(cmd.DB_GET_HA)
        ha_vip = []
        if ha_list and ha_list['highavailableconfig']:
            for ha in ha_list['highavailableconfig']:
                ha_vip.append(ha['vip'])
        all_ip = [s.strip().split(' ')[1].split('/')[0] for s in ip_addr.split('\n')]
        all_ip = list(set(all_ip) - set(ha_vip))
        # end add by z11524 过滤掉业务高可用的虚ip 2017/2/8
        for ip in all_ip:
            # 获取到了IP，需要实际ping测试一下通不通，否则会有误判
            if self.subnet_judge(public_network, ip) and self.network_check(ip):
                return ip
        raise errno.ONEStorConfigError(errno.format_error(errno.ERR_GET_PUBLIC_IP, host_ip))

    def remote_get_disaster_ip(self, host_ip):
        """
        ssh远程登录获取节点的灾备网IP，当数据库中获取不到时实时获取一次，可以兼容升级
        :param host_ip: 主机的业务网IP地址
        :return: 灾备网IP地址
        """
        disaster_network = self.cluster_config[const.DISASTER_NETWORK]
        # 获取节点上的所有IP
        ip_addr = self.exec_remote_ssh_cmd(host_ip, cmd.CMD_IP_ADDR, raise_exc=True)
        all_ip = [s.strip().split(' ')[1].split('/')[0] for s in ip_addr.split('\n')]
        for ip in all_ip:
            if self.subnet_judge(disaster_network, ip):
                return ip
        raise errno.ONEStorConfigError(errno.format_error(errno.ERR_GET_DISASTER_IP, host_ip))

    def get_node_disaster_ip(self, host_ip, from_db=False):
        """
        获取节点的灾备网IP
        """
        disaster_exist = self.judge_disaster_exist()
        if not disaster_exist:
            return ''
        if from_db:
            # 从cluster_hosts数据库中获取灾备网IP
            cluster_hosts_db = self.exec_local_cmd_json(cmd.DB_GET_CLUSTER_HOSTS)
            if not cluster_hosts_db:
                raise errno.ONEStorConfigError(errno.ERR_GET_CLUSTER_CONFIG)
            disaster_ip = [_host[const.DISASTER_IP] for _host in cluster_hosts_db
                           if const.DISASTER_IP in _host and host_ip == _host[const.HOST_IP]]
            if 0 < len(disaster_ip):
                return disaster_ip[0]

        return self.remote_get_disaster_ip(host_ip)

    def ssh_config(self, host_ip, passwd, user=const.USER_ROOT):
        """
        SSH免密配置
        """
        # 先获取节点的业务网IP
        public_ip = self.get_node_public_ip(host_ip, passwd, user)

        # 获取节点的主机名称
        host_name = self.cmd_remote(host_ip, passwd, cmd.CMD_HOSTNAME, user)

        # 检查节点的主机名是否与集群已有节点冲突
        cluster_hosts = self.get_cluster_hosts_from_config()
        for host in cluster_hosts:
            if host_name == host[const.HOST_NAME] and public_ip != host[const.HOST_IP]:
                raise errno.ONEStorConfigError(errno.ERR_BAD_HOST_NAME)

        # TODO 需要适配部署集群代码
        # BEGIN MODIFY BY D10039 2017/03/15 HandyHA中两个Handy都需要对该节点免密
        handy_keys = self.exec_local_cmd_json(cmd.DB_GET_HANDY_KEY)
        if not handy_keys:
            raise errno.ONEStorConfigError(errno.ERR_GET_CLUSTER_CONFIG)

        for handy in handy_keys[const.SSH_PUB_KEY]:
            handy_name = handy.keys()[0]
            # 下发免密命令
            ssh_key_copy_cmd = cmd.CMD_SSH_KEY_COPY.format(
                const.HANDY_SHELL_PATH, public_ip, user, passwd)
            self.exec_remote_ssh_cmd(handy_name, ssh_key_copy_cmd)
        # END MODIFY BY D10039 2017/03/15

        # 检查SSH免密是否配置成功
        ssh_result = self.exec_local_cmd(cmd.CMD_CHECK_SSH.format(host_ip))
        if '' == ssh_result or -1 == ssh_result.find(host_name):
            raise errno.ONEStorConfigError(errno.ERR_SSH_CONFIG)

        return host_name, public_ip

    def install_soft(self, host_ip, passwd, user=const.USER_ROOT, node_type='stor'):
        """
        根据用户名和密码到远端安装ONEStor软件
        :param node_type stor/mon
        """
        log.info('install soft for host "%s" ...', host_ip)
        handy_ip = self.get_handy_public_ip()
        ntp_close = '2'

        result = os.popen(cmd.CMD_INSTALL_SOFT.format(
            self.filepath, host_ip, user, passwd, handy_ip, ntp_close, node_type)).read().rstrip()
        log.info('install soft for host "%s" result is "%s"', host_ip, result)

        # 检查软件是否已经安装成功
        if 'mon' == node_type:
            # 检测mon节点软件安装命令
            check_soft_cmds = [cmd.CMD_CHECK_SOFT_INSTALLED, cmd.CMD_CHECK_MON_MC_SOFT_INSTALLED]
        else:
            # 检测其他节点软件安装命令
            check_soft_cmds = [cmd.CMD_CHECK_SOFT_INSTALLED, cmd.CMD_CHECK_MC_SOFT_INSTALLED]
        check_result = self.cmd_remote(host_ip, passwd, ' && '.join(check_soft_cmds))
        log.info('Check soft installed for host "{0}" result is: "{1}"'.format(host_ip, check_result))
        if -1 == check_result.find(const.CHECK_CEPH_VERSION) or -1 == check_result.find(const.CHECK_HANDY_SHELL)\
                or -1 == check_result.find(const.CHECK_COMMON) or -1 == check_result.find(const.CHECK_INSTALL_CEPH):
            if -1 == check_result.find(const.CHECK_COMMON):
                log.error('Failed to install soft common for host "{0}".'.format(host_ip))
            raise errno.ONEStorConfigError(errno.ERR_INSTALL_ONESTOR_SOFT)
        if 'mon' == node_type and -1 == check_result.find(const.CHECK_ZOOKEEPER):
            if -1 == check_result.find(const.CHECK_ZOOKEEPER):
                log.error('Failed to install soft zookeeper for host "{0}".'.format(host_ip))
            raise errno.ONEStorConfigError(errno.ERR_INSTALL_ONESTOR_SOFT)

        return result

    def setup_ntp_client(self, node):
        """
        NTP客户端的配置
        Date: 2016/12/26
        """
        # 如果集群外NTP服务器与当前主机IP相同，需要返回错误
        if const.NTP_OUT_CLUSTER == self.get_ntp_type():
            ntp_server_list = self.get_ntp_server_outer()
            public_ip = self.name_to_ip(node)
            if public_ip in ntp_server_list:
                raise errno.ONEStorError(errno.ERROR_ADD_NTP_SERVER_TO_CLUSTER, public_ip)
        setup_ntp_result = self._add_host_config_ntp(node)
        # 检查NTP配置结果
        if const.OP_SUCCSSFUL != setup_ntp_result['status']:
            raise errno.ONEStorError(errno.ERROR_SETUP_NTP_BATCH, public_ip)

    def get_ntp_type(self):
        """
        获取NTP同步类型
        Date: 2016/12/26
        Author: dai.xinchun@h3c.com
        :return 0-关闭 1-集群内 2-集群外
        """
        cluster_config = self.get_clusterconfig()
        return cluster_config[const.NTP_SWITCH]

    def _reconfig_cluster_ntp(self, mon_nodes, exclude_nodes=None):
        """
        重新配置集群所有节点的NTP配置
        """
        handy_in_mon = self.is_handy_in_mon()
        handy_in_mon = 'true' if handy_in_mon else 'false'
        # 获取集群所有的主机
        cluster_hosts = self.get_cluster_hosts_from_config()
        all_node_name = [host[const.HOST_NAME] for host in cluster_hosts]
        if exclude_nodes is not None:
            all_node_name = list(set(all_node_name) - set(exclude_nodes))
        self._create_cluster_config_ntp(
            const.NTP_IN_CLUSTER,
            mon_nodes,
            self.get_handy_public_ip(),
            all_node_name,
            'true',
            handy_in_mon,
            'mon_write'
        )

    def __process_setup_ntp_server(self, node_name, ntp_type):
        """
        开始配置NTP服务端
        Date: 2016/12/26
        Author: dai.xinchun@h3c.com
        """
        # 如果是集群外主机提供NTP服务，对集群其它节点的NTP不作任何修改，只需要将本次增加的节点作为客户端即可
        if const.NTP_OUT_CLUSTER == ntp_type:
            ntp_list = self.get_ntp_server_outer()
            if 1 > len(ntp_list):
                raise errno.ONEStorError(errno.ERROR_GET_NTP_CFG_OUT)
            result_ntp = self.exec_remote_ssh_cmd(
                node_name, 'python /var/lib/ceph/shell/ntp_task.py ntp_write %s true' % base64.b64encode(str(ntp_list)))
            if 'ok' != result_ntp:
                log.info("ntp_type: %s, ntp write error, result is: %s", ntp_type, result_ntp)
                raise errno.ONEStorError(errno.ERROR_WRITE_NTP_CFG)
        else:
            # 如果是集群内的主机提供NTP服务，只需要调用部署集群时的方法重新对所有的节点配置一下NTP即可
            cluster_config = self.get_clusterconfig()
            mon_nodes = cluster_config['mon_fqdns']
            mon_nodes.append(node_name)
            self._reconfig_cluster_ntp(mon_nodes)
        return ntp_type

    def setup_ntp_server(self, node_name):
        """
        NTP服务端的配置
        :param node_name 主机名称
        Date: 2016/12/26
        Author: dai.xinchun@h3c.com
        """
        ntp_type = self.get_ntp_type()
        # 以下两种场景无需配置NTP：
        # 1.没有开启NTP同步
        # 2.集群外的NTP服务器，当前主机是集群内的节点
        roles = self.get_host_roles_by_name(node_name)
        if const.NTP_CLOSE == ntp_type or (const.NTP_OUT_CLUSTER == ntp_type and roles):
            return ntp_type
        # 开始配置NTP
        return self.__process_setup_ntp_server(node_name, ntp_type)

    def get_ntp_server(self, ntp_status):
        """
        获取NTP配置情况下服务端IP
        :param ntp_status: 1或2
        :return: Tuble
        """
        ntp_server = ''
        # 获取主MON节点
        quorum_leader_name = self.get_leader_mon()
        quorum_leader_ip = self.name_to_ip(quorum_leader_name)
        if '2' == ntp_status:
            ntp_server_list = self.get_ntp_server_outer()
            ntp_server = ntp_server_list[0]
        if '2' == ntp_status and not ntp_server:
            log.error("get ntp server info error")
            raise errno.ONEStorError(errno.ERROR_NTP_COMMON)
        return ntp_server, quorum_leader_ip

    def config_ntp_server_offset(self, node_ip, ntp_server, leader_ip, ntp_status):
        """
        获取新加监控节点的时间偏移
        :param node_ip: 新加节点IP
        :param ntp_server: 服务端和leader
        :param ntp_status: 当前NTP状态
        :return: Flost
        """
        if '2' == ntp_status:
            # 集群外配置时,分别获取时间偏移量
            offset_info_all = self.multi_thread_task(
                [node_ip, leader_ip], "timeout 60 /usr/sbin/ntpdate -q {0}".format(ntp_server), ssh=True)
            # 检查是否有获取时间偏移失败情况
            for obj, offset_info in offset_info_all.iteritems():
                if not (-1 != offset_info.find('time server') and -1 != offset_info.find('offset')):
                    log.error("ntp server '%s' status not normal, please check", leader_ip)
                    # raise errno.ONEStorError(errno.ERROR_NTP_COMMON)
                    # 若取不到时间，不再直接抛出异常
                    return {'status': False}
            # 获取时间偏移
            log.info("ntp_status is: %s, config_ntp_server_offset offset_info_all: %s", ntp_status, offset_info_all)
            offset_time = abs(float(offset_info_all[node_ip].split()[-2]) - float(
                offset_info_all[leader_ip].split()[-2]))
        else:
            # 在配置集群内时直接获取时间偏移
            offset_info = self.exec_remote_ssh_cmd(node_ip, "timeout 60 /usr/sbin/ntpdate -q {0}".format(leader_ip))
            log.info("ntp_status is: %s, offset_info: %s", ntp_status, offset_info)
            if not (-1 != offset_info.find('time server') and -1 != offset_info.find('offset')):
                log.error("ntp server '%s' status not normal, please check", leader_ip)
                # 若取不到时间，不再直接抛出异常
                return {'status': False}
                # raise errno.ONEStorError(errno.ERROR_NTP_COMMON)
            else:
                offset_time = abs(float(offset_info.split()[-2]))

        return {'status': True, 'offset_time': offset_time}

    def sync_cluster_config(self, node, journal_size=None, flashcache_size=None, role=None):
        """
        同步集群的配置文件
        """
        # 排除掉Handy上的对象网关keyring
        self.exec_local_cmd(cmd.CMD_BACKUP_RGW_KEYRING)
        # 通过scp同步/etc/ceph目录
        # PN: 201612260612 增加写入集群主机的业务网IP配置
        # 对于对端如果已经存在ceph.conf，则不再拷贝ceph.conf，也不再重写业务网
        ls_result = self.exec_remote_ssh_cmd(node, 'ls /etc/ceph/ceph.conf | wc -l')
        # BEGIN ADD BY C13463 ceph.conf已经存在,也需要修改journal_size，flashcache_size
        cache_change_flag = False
        if journal_size is not None and flashcache_size is not None:
            cache_change_flag = True
        # END ADD BY C13463
        if '0' == ls_result:
            # 如果是对象网关，仅拷贝ceph.conf和client.admin.keyring
            if const.ROLE_RGW == role:
                self.exec_local_cmd(cmd.CMD_COPY_CLUSTER_CONFIG_FOR_RGW.format(node))
            else:
                self.exec_local_cmd(cmd.CMD_COPY_CLUSTER_CONFIG.format(node))
            # TODO BEGIN MODIFY BY D10039 2017/02/09 临时代码，兼容V1R1
            self.exec_local_cmd(
                "timeout 30 scp /etc/onestor_hosts [{0}]:/etc/".format(self.name_to_ip(node)))
            # modified by l11544 PN:201703020278 2017/3/11 使用传递的业务网IP
            config_common = "python /var/lib/ceph/shell/rewrite_config.py ceph_config_fix %s" % self.name_to_ip(node)
            self.exec_remote_ssh_cmd(node, config_common)
            # END MODIFY BY D10039 2017/02/09 
        else:
            self.exec_local_cmd(cmd.CMD_COPY_CLUSTER_CONFIG_NO_CEPH.format(node))
        # end by l11544 2016/12/27
        # BEGIN ADD BY C13463 修改journal_size，flashcache_size
        # if cache_change_flag:
        #     config_common = "python /var/lib/ceph/shell/rewrite_config.py osd_cache_rewrite %d %d" % (
        #         journal_size, flashcache_size)
        #     self.exec_remote_ssh_cmd(node, config_common)
        # else:
        #     pass
        # END ADD BY C13463
        # 还原对象网关keyring
        self.exec_local_cmd(cmd.CMD_RESTORE_RGW_KEYRING)
        # 推送ONEStor版本文件到节点上
        self.exec_local_cmd(cmd.CMD_COPY_VERSION_FILE.format(node))
        # 创建出/var/run/ceph目录，防止命令行告警
        self.exec_remote_ssh_cmd(node, cmd.CMD_MKDIR_CEPH_DIR)

        # 检查集群文件是否同步成功
        target_fsid = self.exec_remote_ssh_cmd(node, cmd.CMD_GET_FSID)
        self_fsid = self.exec_local_cmd(cmd.CMD_GET_FSID)
        if target_fsid != self_fsid:
            raise errno.ONEStorConfigError(errno.ERR_SYNC_CLUSTER_CONFIG)

        # 增加定时任务
        self.exec_remote_ssh_cmd(node, cmd.CMD_ADD_CRON_TASK.format(const.HANDY_SHELL_PATH))

    def add_handy_key_to_db(self, node_name, ssh_pub_key):
        """
        将ssh公钥保存到handy_key表
        """
        # 从数据库中获取公钥
        handy_keys = self.exec_local_cmd_json(cmd.DB_GET_HANDY_KEY)
        if not handy_keys:
            raise errno.ONEStorConfigError(errno.ERR_GET_CLUSTER_CONFIG)

        if not (node_name in (s.keys()[0] for s in handy_keys[const.SSH_PUB_KEY])):
            handy_keys[const.SSH_PUB_KEY].append({
                node_name: ssh_pub_key
            })
            # 将该公钥保存到数据库handy_key表中
            self.exec_local_cmd(cmd.DB_SAVE_HANDY_KEY.format(json.dumps(handy_keys)))

    def remove_handy_key_from_db(self, node_name):
        """
        将主机从handy_key表中删除
        """
        # 从数据库中获取公钥
        handy_keys = self.exec_local_cmd_json(cmd.DB_GET_HANDY_KEY)
        if not handy_keys:
            raise errno.ONEStorConfigError(errno.ERR_GET_CLUSTER_CONFIG)

        for pub_key in handy_keys[const.SSH_PUB_KEY]:
            if node_name == pub_key.keys()[0]:
                handy_keys[const.SSH_PUB_KEY].remove(pub_key)
                break

        self.exec_local_cmd(cmd.DB_SAVE_HANDY_KEY.format(json.dumps(handy_keys)))

    def add_mon_to_ldb(self, node_ip, node_name):
        """
        将MON保存到clusterconfig表
        Date: 2016/12/27
        """
        cluster_config_db = self.exec_local_cmd_json(cmd.DB_GET_CLUSTER_CONFIG)
        if not cluster_config_db:
            raise errno.ONEStorConfigError(errno.ERR_GET_CLUSTER_CONFIG)
        if node_name not in cluster_config_db['mon_fqdns']:
            cluster_config_db['mon_fqdns'].append(node_name)
        if node_ip not in cluster_config_db['mon_ip']:
            cluster_config_db['mon_ip'].append(node_ip)
        save_result = self.exec_local_cmd(cmd.DB_SAVE_CLUSTER_CONFIG.format(json.dumps(cluster_config_db)))

        if save_result != 'ok':
            log.error('mon save to db error')
            raise errno.ONEStorError(errno.ERROR_SAVE_CLUSTER_CONFIG_FAULT, node_ip)

    @staticmethod
    def __is_network_fault_once(op, node_ip):
        """
        PN:201704140732 检查操作过程中是否曾经出现过网络故障，通过.network_error文件来判断
        :param op: 当前操作的OP
        :param node_ip: 当前操作的主机IP
        """
        if os.path.exists(const.NETWORK_FAULT_TMP_FILE):
            with open(const.NETWORK_FAULT_TMP_FILE, 'rb') as f:
                if op == f.readline().strip():
                    raise errno.ONEStorError(errno.ERROR_NETWORK_FAULT, node_ip)

    def remove_mon_from_ldb(self, node_ip, node_name):
        """
        将MON从clusterconfig表中删除
        Date: 2016/12/27
        """
        cluster_config_db = self.exec_local_cmd_json(cmd.DB_GET_CLUSTER_CONFIG)
        if not cluster_config_db:
            raise errno.ONEStorConfigError(errno.ERR_GET_CLUSTER_CONFIG)
        if node_name in cluster_config_db['mon_fqdns']:
            cluster_config_db['mon_fqdns'].remove(node_name)
        if node_ip in cluster_config_db['mon_ip']:
            cluster_config_db['mon_ip'].remove(node_ip)
        # PN:201704140732 检查是否有过网络故障，如果是则不再删除数据库中的mon
        self.__is_network_fault_once(const.OP_REMOVE_MON, node_ip)
        # 开始从数据库中删除
        self.exec_local_cmd(cmd.DB_SAVE_CLUSTER_CONFIG.format(json.dumps(cluster_config_db)))

    def add_rgw_to_ldb(self, node_ip, node_name, rgw_port, ssl, diskpool_name):
        """
        将对象网关保存到clusterconfig表
        Date: 2017/04/22
        """
        log.info('begin add rgw to db...')
        gateway_db = self.exec_local_cmd_json(cmd.DB_GET_GATEWAY)
        # 如果数据库中没有该主机的名称（或者没有gateway表），则保存进去
        if not gateway_db or not (True in (node_name == _gateway[
                const.HOST_NAME] for _gateway in gateway_db[const.TABLE_GATEWAY])):
            database.add_obj(const.TABLE_GATEWAY, [
                '{0}:{1}'.format(node_ip, rgw_port),
                node_name,
                ssl,
                'OK',
                diskpool_name
            ])
        else:
            log.error('add rgw to ldb, but host name already exist.')

    @staticmethod
    def remove_rgw_from_ldb(gateway_id):
        """
        将对象网关从clusterconfig表中删除
        Date: 2017/04/22
        """
        log.info('begin remove rgw from db...')
        result = database.del_obj(const.TABLE_GATEWAY, gateway_id)
        log.info('remove rgw from ldb result: %s', result)

    def add_host_to_db(self, node_ip, node_name, disaster_ip=''):
        """
        将主机保存到cluster_hosts表
        """
        cluster_hosts_db = self.exec_local_cmd_json(cmd.DB_GET_CLUSTER_HOSTS)
        if not cluster_hosts_db:
            raise errno.ONEStorConfigError(errno.ERR_GET_CLUSTER_CONFIG)

        # 如果数据库中没有该主机IP，则保存进去
        if not (True in (node_ip == _host_info[const.HOST_IP] for _host_info in cluster_hosts_db)):
            cluster_hosts_db.append({
                const.HOST_IP: node_ip,
                const.HOST_NAME: node_name,
                const.DISASTER_IP: disaster_ip
            })
            self.exec_local_cmd(cmd.DB_SAVE_CLUSTER_HOSTS.format(json.dumps(cluster_hosts_db)))
        elif disaster_ip:
            for _host_info in cluster_hosts_db:
                if node_ip == _host_info[const.HOST_IP]:
                    _host_info[const.DISASTER_IP] = disaster_ip
                    break
            self.exec_local_cmd(cmd.DB_SAVE_CLUSTER_HOSTS.format(json.dumps(cluster_hosts_db)))

    def _remove_disaster_ip(self, node_ip):
        """
        删除主机时从cluster_hosts表中删除灾备的IP地址
        :param node_ip: 主机的业务网IP地址
        :return:
        """
        cluster_hosts_db = self.exec_local_cmd_json(cmd.DB_GET_CLUSTER_HOSTS)
        if not cluster_hosts_db:
            raise errno.ONEStorConfigError(errno.ERR_GET_CLUSTER_CONFIG)
        for _host_info in cluster_hosts_db:
            if node_ip == _host_info[const.HOST_IP]:
                _host_info[const.DISASTER_IP] = ''
                break
        self.exec_local_cmd(cmd.DB_SAVE_CLUSTER_HOSTS.format(json.dumps(cluster_hosts_db)))

    def remove_host_from_db(self, node_ip, node_name):
        """
        将主机从cluster_hosts表中删除
        """
        cluster_hosts_db = self.exec_local_cmd_json(cmd.DB_GET_CLUSTER_HOSTS)
        if not cluster_hosts_db:
            raise errno.ONEStorConfigError(errno.ERR_GET_CLUSTER_CONFIG)

        # 遍历数据库进行删除操作
        for _host in cluster_hosts_db:
            if node_ip == _host[const.HOST_IP] and node_name == _host[const.HOST_NAME]:
                cluster_hosts_db.remove(_host)
                break

        self.exec_local_cmd(cmd.DB_SAVE_CLUSTER_HOSTS.format(json.dumps(cluster_hosts_db)))

    def remove_host_from_file(self, node_ip, node_name):
        """
        将主机从/etc/onestor_hosts中删除
        """
        with open(const.ONESTOR_HOSTS, 'rb') as fr:
            with open('/tmp/.onestor_hosts', 'wb') as fw:
                new_lines = [line for line in fr.readlines() if '{0} {1}'.format(
                    node_ip, node_name) != line.strip()]
                fw.writelines(new_lines)
        # Apache用户没有权限操作/etc/hosts文件，改用exec_local_cmd
        self.exec_local_cmd('mv /tmp/.onestor_hosts {0}'.format(const.ONESTOR_HOSTS))

    def ssh_config_server(self, node, node_name):
        """
        当前节点对集群所有节点进行SSH免密配置
        """
        # 判断当前节点上是否已经有ssh秘钥对
        ssh_pub_key = self.exec_remote_ssh_cmd(node, cmd.CMD_GET_SSH_PUB_KEY)

        if '' == ssh_pub_key:
            # 如果没有公钥，则调用脚本生成
            self.exec_remote_ssh_cmd(node, cmd.CMD_CREATE_SSH_KEY)
            # 检查秘钥是否已经生成，如果没有则抛出异常
            ssh_pub_key = self.exec_remote_ssh_cmd(node, cmd.CMD_GET_SSH_PUB_KEY)
            if '' == ssh_pub_key:
                raise errno.ONEStorConfigError(errno.ERR_CREATE_SSH_KEY)

        # 将ssh公钥保存到handy_key表
        self.add_handy_key_to_db(node_name, ssh_pub_key)

        # 获取集群中的所有主机
        cluster_hosts = self.get_cluster_hosts_from_config()
        nodes = [host[const.HOST_IP] for host in cluster_hosts]

        # 主动触发ssh_protect.py脚本，将免密信息同步到各个节点上
        self.multi_thread_task(nodes, cmd.CMD_EXEC_SSH_PROTECT, ssh=True)

        # 将当前主机保存到cluster_hosts表中
        self.add_host_to_db(node, node_name)

        # 推送onestor_hosts文件到节点上
        self.exec_local_cmd(cmd.CMD_COPY_ONESTOR_HOST_FILE.format(node))

    def __clear_all_config(self, node_ip, node_name, offline=False):
        """
        清空所有Ceph相关配置
        """
        if not offline:
            self.exec_remote_ssh_cmd(
                node_ip, cmd.CMD_RM_FILE.format(const.ALL_CEPH_CONF), raise_exc=True)
            # BEGIN ADD BY Z11524 2017/4/21 PN:201704170117
            self.exec_remote_ssh_cmd(
                node_ip, cmd.CP_VERSION_BACKUP, raise_exc=True)
            self.exec_remote_ssh_cmd(
                node_ip, cmd.CMD_RM_FILE.format(const.ALL_ONESTOR_CONF), raise_exc=True)
            # BEGIN ADD BY Z11524 2017/4/21 PN:201704170117
            self.exec_remote_ssh_cmd(
                node_ip, cmd.CP_VERSION, raise_exc=True)
            self.exec_remote_ssh_cmd(
                node_ip, cmd.RM_VERSION_BACKUP, raise_exc=True)
            # END ADD BY Z11524 2017/4/21 PN:201704170117
            # 删除onestor_hosts中的主机
            self.exec_remote_ssh_cmd(
                node_ip, cmd.CMD_RM_FILE.format(const.ONESTOR_HOSTS), raise_exc=True)
        # 删除cluster_hosts中的主机
        self.remove_host_from_db(node_ip, node_name)
        # modify by z11524 2017/5/11 PN:201705040359
        self.remove_host_from_file(node_ip, node_name)

    def process_remove_handy_ha(self, is_slave_cluster_node, node_ip, node_name, offline=False, roles=None):
        """
        增加管理高可用失败时进行配置回滚
        """
        # 获取集群所有的主机
        cluster_hosts = self.get_cluster_hosts_from_config()
        nodes = [host[const.HOST_IP] for host in cluster_hosts]
        # add by z11524 2016/11/9 PN:201611040049
        failed_nodes = self.test_ping(nodes)
        nodes = list(set(nodes) - set(failed_nodes))
        # end by z11524 2016/11/9 PN:201611040049
        # DELETE BY KF6602 监控项目不需要修改diamond配置
        if not is_slave_cluster_node:
            if not roles:
                self.__clear_all_config(node_ip, node_name, offline)
            # update by z11524 date:2017/9/19 PN:201709180487
            if roles is not None and not(roles['mds'] or roles['nas'] or roles['rgw']):
                # DELETE BY KF6602 监控项目不需要修改diamond配置
                self.__clear_all_config(node_ip, node_name, offline)
            else:
                pass

        # DELETE BY KF6602 PN:201611030043
        # 删除handy_key中的记录
        self.remove_handy_key_from_db(node_name)
        # DELETE BY KF6602 监控项目不需要修改diamond配置

    def _service_restart(self, node_ip, service_name):
        """
        重启service进程
        Date: 2016/12/07
        """
        self.exec_remote_ssh_cmd(node_ip, 'service %s restart' % service_name)

    def check_concurrent_event2(self, flag, interval, _type='check_prevent'):
        """
        检查并发事件，阻止同时操作，非继承时使用
        :param flag: 文件标识
        :param interval: 时间间隔
        """
        return self._check_cocurrent_event(flag, interval, _type)

    def _check_cocurrent_event(self, flag, interval=60 * 60 * 24, _type='check_prevent'):
        """
        检查并发事件，阻止同时操作
        :param flag: 文件标识
        Date: 2016/12/07
        """
        now_time = time.time()
        has_adding = os.path.exists(flag)
        if has_adding:
            with open(flag, 'rb') as fb:
                last_time = float(fb.readline())
            if now_time - last_time < interval:
                has_adding = True
                return has_adding
            else:
                has_adding = False
        # begin add by z11524 date:2017/12/27 PN:201710160741
        if 'check_prevent' != _type:
            self.exec_local_cmd('rm -rf %s' % flag)
            return has_adding
            # end add by z11524 date:2017/12/27 PN:201710160741
        with open(flag, 'wb') as fb:
            fb.write(str(now_time))
        return has_adding

    def get_leader_mon(self):
        """
        获取集群当前的主MON
        """
        # 获取集群的quorum信息
        quorum_status = self.exec_local_cmd_json('timeout 60 ceph quorum_status -f json')
        if not quorum_status:
            raise errno.ONEStorError(errno.ERROR_GET_MON_STATUS)
        # 返回主MON节点
        return quorum_status['quorum_leader_name']

    def ntp_roll_return(self, osd_node, need_check_role=False):
        """
        ADD BY l11544 PN:201612070395
        在删除主机时判断角色是否需要还原，添加失败时直接还原
        :param osd_node: 需要检查角色时为主机名，否则也可为IP
        :param need_check_role:
        :return: None
        """
        if need_check_role:
            role = self.get_host_roles_by_name(osd_node)
            if role is not None:
                return
        self.exec_remote_ssh_cmd(
            osd_node, 'python {0} ntp_return'.format(const.HANDY_SHELL_NTP))

    def get_handy_nodes(self):
        """
        获取集群中的Handy节点，如果开启了HandyHA，会有2个Handy
        """
        handys = self.exec_local_cmd_json(cmd.DB_GET_HANDY_KEY)
        if not handys:
            raise errno.ONEStorError(errno.ERR_GET_CLUSTER_CONFIG)
        # 返回Handy节点的主机名
        return [_handy.keys()[0] for _handy in handys['ssh_pub_key']]

    def exec_cmd_on_handy_nodes(self, command):
        """
        在Handy节点上执行命令，如果开启了HandyHA，会有2个Handy
        """
        handy_nodes = self.get_handy_nodes()
        return self.multi_thread_task(handy_nodes, command, ssh=True)

    def add_host_to_nas_db(self, node_ip, node_name, use):
        """
        将主机保存到nas_server_new表，多MDS项目
        :author: dangni <dang.ni@h3c.com>
        :date: 2017/10/20
        """
        nas_server_new_db = self.exec_local_cmd_json(cmd.DB_GET_NAS_SERVER_NEW)

        # 如果数据库中没有该主机IP，则保存进去
        if not nas_server_new_db \
                or not (True in (node_ip == _nas_server[const.HOST_IP]
                                 and use == _nas_server[const.HOST_USE]
                                 for _nas_server in nas_server_new_db[const.TABLE_NAS_SERVER_NEW])):
            database.add_obj(const.TABLE_NAS_SERVER_NEW, [
                node_name,
                node_ip,
                use
            ])
        else:
            log.error('add mds to ldb, but host already exist.')
