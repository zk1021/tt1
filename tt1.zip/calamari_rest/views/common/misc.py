#!/usr/bin/env python
# coding: utf-8

"""
通用工具
"""

import logging

from calamari_rest.views.onestor import database

LOG = logging.getLogger('django.request')


def query_ceph_leveldb(db_name):
    """
    通过ceph config-key 获取leveldb中的数据
    """
    LOG.debug('begin query ceph level db...')
    db_data = database.list_objs(db_name)
    LOG.debug('query db data is: %s', db_data)
    return db_data
