#!/usr/bin/python
# -*- coding: utf-8 -*-


"""
定义操作日志
"""

SLAVE_NODE = '在非当前工作Handy节点上操作失败：'
DEFAULT_OPERATION_LOG = '未知操作'
DEFAULT_ERROR_REASON = '操作失败，详见系统日志'
NULL_PARAM = '输入参数“{0}”为空'
INVALID_PARAM = '输入参数“{0}”的格式不合法'

# 用户管理
OP_CREATE_GROUP = '创建用户组“{0}”'
OP_REMOVE_GROUP = '删除用户组“{0}”'
OP_MPDOFY_GROUP_PERMISSION = '修改用户组“{0}”的权限'
OP_CREATE_HANDY_USER = '创建Handy用户“{0}”'
OP_MODIFY_HANDY_USER_GROUP = '修改Handy用户“{0}”的用户组'
OP_RESET_HANDY_USER_PASSWD = '重置Handy用户“{0}”的密码'
OP_MODIFY_HANDY_USER_PASSWD = '用户修改密码'
OP_REMOVE_HANDY_USER = '删除Handy用户“{0}”'

# 高可用
OP_CREATE_HA_CFG = '创建业务高可用IP“{0}”'
OP_REMOVE_HA_CFG = '删除业务高可用IP“{0}”'
OP_MODIFY_HA_CFG = '修改业务高可用IP“{0}”'
OP_CREATE_HANDY_HA_CFG = '创建管理高可用IP“{0}”'
OP_REMOVE_HANDY_HA_CFG = '删除管理高可用IP“{0}”'
OP_MODIFY_HANDY_HA_CFG = '修改管理高可用IP“{0}”'
OP_CREATE_MANAGE_NETWORK = '配置管理网段“{0}”'
OP_HA_GROUP_ENABLE = '启用业务高可用IP“{0}”'
OP_HA_GROUP_DISABLE = '禁用业务高可用IP“{0}”'

# 异地灾备
OP_RESTORE_SNAP = '对块设备“{0}”恢复快照'
OP_SYNC_ALL_SNAP = '同步主备站点所有块设备的快照'
OP_CLEAR_TASK = '清空块设备“{0}”的所有任务'
OP_MANUAL_BACKUP = '对块设备“{0}”执行手动备份'
OP_STOP_BACKUP = '停止块设备“{0}”的备份任务'
OP_CREATE_BACKUP_BLOCK = '创建备份块“{0}”'
OP_UPDATE_BACKUP_BLOCK = '修改备份块“{0}”的备份策略'
OP_REMOVE_BACKUP_BLOCK = '删除备份块“{0}”'

OP_DISCONNECT_STATION = '断开{0}的连接'
OP_SWITCH_STATION = '切换为{0}'

# 部署集群
OP_CREATE_CLUSTER = '部署集群'

# 主机管理
OP_ADD_HOST_SINGLE = '添加主机“{0}”'
OP_ADD_HOST_BATCH = '添加主机“{0}”'
OP_REMOVE_HOST = '删除主机“{0}”'
OP_REMOVE_OFFLINE_HOST = '删除离线主机“{0}”'
OP_ADD_DISK = '增加硬盘“{0}”到主机“{1}”'
OP_ADD_DISK_FOR_DISKPOOL = '硬盘池“{0}”增加硬盘“{1}”'
OP_REMOVE_DISK = '删除主机“{0}”上的硬盘“{1}”'

# MON管理
OP_ADD_MON = '添加监控节点“{0}”'
OP_REMOVE_MON = '删除监控节点“{0}”'
OP_REMOVE_OFFLINE_MON = '删除离线监控节点“{0}”'

# 维护模式
OP_OPEN_MAINTAIN_MODE = '开启维护模式'
OP_CLOSE_MAINTAIN_MODE = '关闭维护模式'
OP_CLOSE_MAINTAIN_MODE = '切换维护模式为“关闭”状态'
OP_MANUAL_MAINTAIN_MODE = '切换维护模式为“开启”状态'
OP_AUTO_MAINTAIN_MODE = '切换维护模式为“开启”状态，定时切换周期（{0}）'
OP_AUTO_DAY = '{0}:00至{1}:00'
OP_AUTO_NEXT_DAY = '{0}:00至次日{1}:00'

# 块存储
OP_CREATE_TARGET = '创建Target“{0}”'
OP_MODIFY_TARGET = '修改Target“{0}”'
OP_REMOVE_TARGET = '删除Target“{0}”'
OP_CREATE_LUN = OP_RBD_TO_LUN = '创建存储卷“{0}”'
OP_MODIFY_LUN = '修改存储卷“{0}”'
OP_REMOVE_LUN = OP_LUN_TO_RBD = '删除存储卷“{0}”'
# PN: 201612160639 【BBIT】osd已容量超95%，断开I-T连接，重启所有节点,tgt挂起，
# 再点击target页面删除卷，删除失败，后给集群扩容后重新和客户端建不了连接
OP_CREATE_RBD = '创建块“{0}”'
OP_CREATE_SNAPSHOT = '创建快照“{0}”'
OP_CLONE_RBD = '克隆块“{0}”'
OP_BACK_SNAP = '恢复快照“{0}”'
OP_REMOVE_SNAP = '删除快照“{0}”'
# end by l11544 2017/4/27

# 对象网关和参数配置
OP_DEPLOY_GATEWAY = '创建对象网关“{0}”'
OP_REMOVE_GATEWAY = '删除对象网关“{0}”'
OP_REMOVE_OFFLINE_GATEWAY = '删除离线对象网关“{0}”'
OP_POST_NTP_INFO = '修改NTP配置'
OP_POST_CEPH_PARAM = '修改集群服务配置'

# SSO配置
OP_OPEN_SSO = '开启单点登录服务'
OP_CLOSE_SSO = '关闭单点登录服务'

# license
OP_EXPORT_AUTHCODE = u'收集授权条码'
OP_BACKUP_LICENSE = u'收集License文件'
OP_ACTIVATE_LICENSE = u'激活License'

OP_BS_ALL = {
    'create_target': OP_CREATE_TARGET,
    'modify_target': OP_MODIFY_TARGET,
    'remove_target': OP_REMOVE_TARGET,
    'create_lun': OP_CREATE_LUN,
    'modify_lun': OP_MODIFY_LUN,
    'remove_lun': OP_REMOVE_LUN,
    # PN: 201612160639 【BBIT】osd已容量超95%，断开I-T连接
    'create_rbd': OP_CREATE_RBD,
    'create_snapshot': OP_CREATE_SNAPSHOT,
    'clone_rbd': OP_CLONE_RBD,
    'back_snap': OP_BACK_SNAP,
    'remove_snap': OP_REMOVE_SNAP,
    'rbd_to_lun': OP_RBD_TO_LUN,
    'lun_to_rbd': OP_LUN_TO_RBD,
    # end by l11544 2017/4/27
    'deploy_gateway': OP_DEPLOY_GATEWAY,
    'remove_gateway': OP_REMOVE_GATEWAY,
    'add_mon': OP_ADD_MON,
    'remove_mon': OP_REMOVE_MON,
    'remove_mon_offline': OP_REMOVE_OFFLINE_MON,
    'create_ha_cfg': OP_CREATE_HA_CFG,
    'modify_ha_cfg': OP_MODIFY_HA_CFG,
    'remove_ha_cfg': OP_REMOVE_HA_CFG,
    'create_handy_ha_cfg': OP_CREATE_HANDY_HA_CFG,
    'modify_handy_ha_cfg': OP_MODIFY_HANDY_HA_CFG,
    'remove_handy_ha_cfg': OP_REMOVE_HANDY_HA_CFG,
    'post_ntp_info': OP_POST_NTP_INFO,
    'post_ceph_param': OP_POST_CEPH_PARAM,
    'disable_ha_cfg': OP_HA_GROUP_DISABLE,
    'enable_ha_cfg': OP_HA_GROUP_ENABLE,
}
