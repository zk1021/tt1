#!/usr/bin/env python
# coding: utf-8

"""
集群部署工具类
"""

import os
import json
import time
import base64
import onestor
import datetime
import logging
import threading
import traceback
import platform
from calamari_rest.views.common import const
from calamari_rest.views.common import cmd
from calamari_rest.views.common import errno
from calamari_rest.views.host.host_util import HostUtil
from calamari_rest.views.common.util import HandyUtil
from calamari_rest.common import send_request_onestord

LOG = logging.getLogger('django.request')


class DeployUtil(HostUtil):
    """
    主机管理工具类
    """
    def __init__(self, *args, **kwargs):
        super(DeployUtil, self).__init__(need_config=False, *args, **kwargs)
        self.filepath = os.path.split(os.path.realpath(__file__))[0].split('/deploy')[0]

    @staticmethod
    def _do_deploy_first():
        LOG.info('begin deploy:::::::::::::::::::::::::::::::')
        os.system('echo {0} > {1}'.format(time.time(), const.FLAG_OPERATE_CLUSTER))

    @staticmethod
    def _check_param_data(request):
        """
        检查并组织请求参数
        :param request: 请求数据
        :return:
        """
        try:
            LOG.info('start to check param data, data is {}'.format(request.DATA))
            data = {
                'default_user': request.DATA['default_user'],
                'default_passwd': request.DATA['default_passwd'],
                'all_node_ip': request.DATA['all_node_ip'],
                'local_ip': request.DATA['local_ip'],
                'cluster_name': request.DATA['cluster_name'],
                'osd_nodes': request.DATA['osd_nodes'],
                'mon_nodes': request.DATA['mon_nodes'],
                'all_node_name': request.DATA['all_node_name'],
                # ADD BY D10039 2016/08/16 FOR HANDY HA
                'manage_network': request.DATA['manage_network'],
                'cluster_network': request.DATA['cluster_network'],
                'public_network': request.DATA['public_network'],
                'ntp_close': request.DATA['ntp_close'],
                'rack_list': request.DATA['rack_list'],
                'install_type': request.DATA['install_type']
            }
            ntp_servers = base64.b64decode(request.DATA['ntp_servers'])
            data['ntp_servers'] = ntp_servers.split(',') if isinstance(ntp_servers, str) else ntp_servers

            data['nodepool_list'] = json.loads(request.DATA['nodepool_list'])  # 节点池列表
            data['diskpool_list'] = json.loads(request.DATA['diskpool_list'])  # 硬盘池列表
            data['domain_list'] = json.loads(request.DATA['domain_list'])  # 保护域列表
            data['rack_list'] = json.loads(request.DATA['rack_list'])  # 物理机架列表
            data['host_list'] = json.loads(request.DATA['host_list'])  # 主机列表
            data['logic_rack_list'] = json.loads(request.DATA['logic_rack_list'])  # 逻辑机架列表

            host_rack_map = {}
            host_ip_map = {}
            ip_node_map = {}
            host_journal_map = {}
            host_disk_map = {}
            host_flash_map = {}
            host_diskpool_map = {}
            host_nodepool_map = {}

            if 'host_rack_map_str' not in request.DATA:
                # BEGIN ADD BY D10039 2016/03/14 FOR UIS 兼容D007版本接口
                if 'hosts' in request.DATA:
                    hosts_list = request.DATA['hosts']
                    for _host in hosts_list:
                        _host_name = _host['hostname']
                        host_rack_map[_host_name] = _host['rack']
                        host_ip_map[_host_name] = _host['hostip']
                        ip_node_map[_host['hostip']] = _host_name
                        host_journal_map[_host_name] = ','.join(_host['journal_disk'])
                        host_flash_map[_host_name] = ','.join(_host['flash_cache_disk'])
                else:
                    all_node_rack = request.DATA['all_node_rack'].split(',')
                    all_node_ip_array = data['all_node_ip'].split(',')
                    # 如果不传入hosts参数，则所有的缓存都不开启
                    for i, name in enumerate(data['all_node_name'].split(',')):
                        host_rack_map[name] = all_node_rack[i]
                        host_ip_map[name] = all_node_ip_array[i]
                        ip_node_map[all_node_ip_array[i]] = name
                        host_journal_map[name] = u'-1'
                        host_flash_map[name] = u'-1'
                # END ADD BY D10039 2016/03/14
            else:
                host_diskpool_map_str = request.DATA['host_diskpool_map_str']
                host_diskpool_map_json = json.loads(host_diskpool_map_str)
                for host_diskpool in host_diskpool_map_json['elements']:
                    host_diskpool_map[host_diskpool['key']] = host_diskpool['value']
                data['host_diskpool_map'] = host_diskpool_map

                host_nodepool_map_str = request.DATA['host_nodepool_map_str']
                host_nodepool_map_json = json.loads(host_nodepool_map_str)
                for host_nodepool in host_nodepool_map_json['elements']:
                    host_nodepool_map[host_nodepool['key']] = host_nodepool['value']
                data['host_nodepool_map'] = host_nodepool_map

                for host_data in data['host_list']:
                    host_disk_map[host_data['name']] = []
                    host_journal_map[host_data['name']] = []
                    host_flash_map[host_data['name']] = []
                    for diskpool_name in data['host_diskpool_map'][host_data['name']]:
                        for diskpool in data['diskpool_list']:
                            if diskpool['diskpool_name'] == diskpool_name:
                                journal_size = diskpool['journal_size']
                                flashcache_size = diskpool['flashcache_size']
                                break
                        # ['sdb:journal_size:flashcache_size'] 数据盘
                        host_disk_map[host_data['name']].extend(
                            [disk.split(':')[0] + ':' + str(journal_size) + ':'
                             + str(flashcache_size) + ':' + diskpool_name
                             for disk in host_data[diskpool_name]['data']])
                        # ['sdb:journal_size:flashcache_size'] 写缓存盘
                        host_journal_map[host_data['name']].extend(
                            [disk.split(':')[0] + ':' + str(journal_size) + ':'
                             + str(flashcache_size) + ':' + diskpool_name
                             for disk in host_data[diskpool_name]['journal']])
                        # ['sdb:journal_size:flashcache_size'] 读缓存盘
                        host_flash_map[host_data['name']].extend(
                            [disk.split(':')[0] + ':' + str(journal_size) + ':'
                             + str(flashcache_size) + ':' + diskpool_name
                             for disk in host_data[diskpool_name]['flash']])
                    host_data['diskpool_list'] = data['host_diskpool_map'][host_data['name']]
                    host_data['nodepool_name'] = data['host_nodepool_map'][host_data['name']]
                data['host_disk_map'] = host_disk_map
                data['host_journal_map'] = host_journal_map
                data['host_flash_map'] = host_flash_map

                host_rack_map_str = request.DATA['host_rack_map_str']
                host_rack_map_json = json.loads(host_rack_map_str)
                for host_rack in host_rack_map_json['elements']:
                    host_rack_map[host_rack['key']] = host_rack['value']
                data['host_rack_map'] = host_rack_map

                host_ip_map_str = request.DATA['host_ip_map_str']
                host_ip_map_json = json.loads(host_ip_map_str)
                for host_ip_pair in host_ip_map_json['elements']:
                    host_ip_map[host_ip_pair['key']] = host_ip_pair['value']
                    ip_node_map[host_ip_pair['value']] = host_ip_pair['key']
                data['host_ip_map'] = host_ip_map
                data['ip_node_map'] = ip_node_map

            handy_name = os.popen('hostname').read().rstrip()
            data['handy_name'] = handy_name
            all_node = data['all_node_name'].split(',')
            if handy_name in all_node:
                data['handy_choose'] = True
            else:
                data['handy_choose'] = False
            if handy_name in data['mon_nodes'].split(','):
                data['handy_in_mon'] = True
            else:
                data['handy_in_mon'] = False
            LOG.info('end to check param data, data is {}'.format(data))
            return data
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_ILLEGAL_PARAMETER)

    def calc_disk_size(self, data):
        """
        计算硬盘大小
        :param data: 部署数据
        :return:
        """
        all_disk_byte = 0
        if '' != data['osd_nodes']:
            osd_node_ip = [data['host_ip_map'][host_name] for host_name in data['osd_nodes'].split(',')]
            hosts = self.exec_local_cmd(cmd.CMD_HOST_INFO_IP.format(','.join(osd_node_ip), data['default_user'],
                                                                    data['default_passwd']))
            try:
                hosts = json.loads(hosts)
            except ValueError:
                raise errno.ONEStorError(errno.ERROR_GET_HOST_INFO)
            for host_ip, host in hosts.items():
                if not host['connect']:
                    raise errno.ONEStorError(errno.ERROR_GET_HOST_DISK_INFO, host_ip)
                # 获取当前主机的待添加的硬盘
                _deploy_disks = [disk.split(':')[0] for disk in
                                 data['deploy_disk_map'][host['hostname']].split(';')]
                LOG.info('host %s need deploy disks: %s', host_ip, _deploy_disks)
                for disk_name, disk_detail in host['disks'].items():
                    if disk_name.split('/dev/')[1] not in _deploy_disks:
                        continue
                    else:
                        all_disk_byte += int(disk_detail['size_byte'])
        return all_disk_byte

    @staticmethod
    def check_license(data):
        disk_pool_list = data['diskpool_list']
        host_list = data['host_list']
        all_node_ip = data['all_node_ip']
        handy_util = HandyUtil(need_config=False)
        handy_util.check_license(disk_pool_list, host_list, all_node_ip, passwd=data['default_passwd'], batch=True)

    def _before_deploy_check(self, data):
        """
        部署前基本检查
        :param data: 部署数据
        :return:
        """
        is_match_os = self.check_os_version(data['all_node_ip'].split(','), data['default_passwd'])
        if not is_match_os:
            LOG.error('error os version')
            raise errno.ONEStorError(errno.ERROR_OS_VERSION)
        # 监控节点数量最多7个
        if const.MON_NUM_LIMIT < len(data['mon_nodes'].split(',')):
            LOG.error('the number of mon exceeds the limit')
            raise errno.ONEStorError(errno.ERROR_MON_NUM_LIMIT)
        # add by l11544 PN: 201709080309 2017/3/1 检测deploy_status文件判断是否处于部署状态
        # 特定条件下创建集群时, handy两次写ceph.conf导致集群的fsid与系统运行记录的fsid不一致
        if os.path.exists('/tmp/deploy_status'):
            LOG.error('[next_create_cluster] the file of record deploy cluster status named deploy_status is existed')
            raise errno.ONEStorError(errno.ERROR_CLUSTER_ALREADY_EXIST)
        # end by l11544
        # 判断主机和硬盘规格是否超限(集群最大节点、硬盘数量，单节点池最大节点数量，单硬盘池最大硬盘数量)
        self.check_host_disk_num_limit(data['host_list'], True, True)

    def _network_check(self, data):
        handy_util = HandyUtil(need_config=False)
        handy_manage_ip = handy_util.get_handy_manage_ip(data['manage_network'])
        if not handy_manage_ip:
            raise errno.ONEStorError(errno.ERROR_HANDY_MANAGE_IP)

        all_node_ip_list = data['all_node_ip'].split(',')
        ip_node_map = data['ip_node_map']
        host_ip_map = data['host_ip_map']
        mon_nodes = data['mon_nodes']
        osd_nodes = data['osd_nodes']
        host_manage_ip_map = {}
        host_cluster_ip_map = {}
        nodes_ips_ret = self.get_node_ips(nodes=all_node_ip_list, password=data['default_passwd'],
                                          cluster_network=data['cluster_network'],
                                          public_network=data['public_network'],
                                          manage_network=data['manage_network'])
        LOG.info('get nodes ips : "{0}"'.format(nodes_ips_ret))
        if nodes_ips_ret['success']:
            for public_ip, manage_ip in nodes_ips_ret['manage_ips'].items():
                node = ip_node_map[public_ip]
                host_manage_ip_map[node] = manage_ip
            for public_ip, cluster_ip in nodes_ips_ret['cluster_ips'].items():
                node = ip_node_map[public_ip]
                host_cluster_ip_map[node] = cluster_ip
        elif 0 < len(nodes_ips_ret['connect_error']):
            err_nodes = [ip_node_map[ip] for ip in nodes_ips_ret['connect_error']]
            raise errno.ONEStorError(errno.ERROR_NETWORK_LINK, '，'.join(err_nodes))
        elif 0 < len(nodes_ips_ret['manage_network_error']):
            err_nodes = [ip_node_map[ip] for ip in nodes_ips_ret['manage_network_error']]
            raise errno.ONEStorError(errno.ERROR_MANAGE_NETWORK_LINK, '，'.join(err_nodes))
        elif 0 < len(nodes_ips_ret['public_network_error']):
            err_nodes = [ip_node_map[ip] for ip in nodes_ips_ret['public_network_error']]
            raise errno.ONEStorError(errno.ERROR_PUBLIC_NETWORK_LINK, '，'.join(err_nodes))
        elif 0 < len(nodes_ips_ret['cluster_network_error']):
            err_nodes = [ip_node_map[ip] for ip in nodes_ips_ret['cluster_network_error']]
            raise errno.ONEStorError(errno.ERROR_CLUSTER_NETWORK_LINK, '，'.join(err_nodes))

        # get osd ip
        osd_public_ips =[]
        if '' != osd_nodes:
            osd_public_ips = [host_ip_map[host_name] for host_name in osd_nodes.split(',')]

        # get mon ip
        mon_public_ips = []
        mon_manage_ips = []
        mon_cluster_ips = []
        if '' != mon_nodes:
            mon_public_ips = [host_ip_map[host_name] for host_name in mon_nodes.split(',')]
            mon_manage_ips = [host_manage_ip_map[host_name] for host_name in mon_nodes.split(',')]
            mon_cluster_ips = [host_cluster_ip_map[host_name] for host_name in mon_nodes.split(',')]
        LOG.info('mon hosts public_ip: "{0}"'.format(mon_public_ips))
        LOG.info('mon hosts manage_ip: "{0}"'.format(mon_manage_ips))
        LOG.info('mon hosts cluster_ip: "{0}"'.format(mon_cluster_ips))
        data['mon_public_ips'] = mon_public_ips
        data['mon_manage_ips'] = mon_manage_ips
        data['mon_cluster_ips'] = mon_cluster_ips
        data['host_manage_ip_map'] = host_manage_ip_map
        data['host_cluster_ip_map'] = host_cluster_ip_map
        data['handy_manage_ip'] = handy_manage_ip
        data['osd_public_ips'] = osd_public_ips
        mon_ips_zip = zip(mon_manage_ips, mon_public_ips, mon_cluster_ips)
        mon_ips = list()
        for index, ip in enumerate(mon_ips_zip):
            ips = dict(my_id=index+1, server=ip[0], manage_ip=ip[0], public_ip=ip[1], cluster_ip=ip[2])
            mon_ips.append(ips)
        data['mon_ips'] = mon_ips
        return data

    def get_node_ips(self, nodes=None, user='root', password='',
                     cluster_network=None, public_network=None, manage_network=None):
        """
        获取集群节点ip地址
        :param nodes:
        :param user:
        :param password:
        :param cluster_network:
        :param public_network:
        :param manage_network:
        :return:
        """
        if cluster_network is None and public_network is None and manage_network is None:
            return {'success': False, 'error': 'Params Error!'}
        filepath = self.filepath

        try:
            threads = []
            results = []
            result = {}

            nloops = range(len(nodes))

            def execute(node):
                network_str = self.exec_local_cmd('timeout 300 /opt/h3c/bin/python %s/handy_common.py network_judge'
                                                  ' %s %s %s %s %s None %s' % (
                                                      filepath, node, user, password, public_network, cluster_network,
                                                      manage_network))
                network_info = json.loads(network_str)
                network_info['ip'] = node
                results.append(network_info)

            for node in nodes:
                t = threading.Thread(target=execute, args=(node,))
                threads.append(t)

            for i in nloops:
                threads[i].start()

            for i in nloops:
                threads[i].join()

            result = {
                'success': True,
                'connect_error': [],
                'manage_network_error': [],
                'cluster_network_error': [],
                'public_network_error': [],
                'manage_ips': {},
                'public_ips': {},
                'cluster_ips': {},
                'nodes': {}
            }

            for node in results:
                ip = node['ip']
                if node['success']:
                    host_name = node.get('hostname')
                    result['nodes'][host_name] = dict()
                    if cluster_network is not None:
                        if '' == node['storage_ip']:
                            result['cluster_network_error'].append(node['ip'])
                            result['success'] = False
                        else:
                            result['nodes'][host_name].update(cluster_ip=node['storage_ip'])
                            result['cluster_ips'][ip] = node['storage_ip']
                    if public_network is not None:
                        if '' == node['public_ip']:
                            result['public_network_error'].append(node['ip'])
                            result['success'] = False
                        else:
                            result['nodes'][host_name].update(public_ip=node['public_ip'])
                            result['public_ips'][ip] = node['public_ip']
                    if manage_network is not None:
                        if '' == node['manage_ip']:
                            result['manage_network_error'].append(node['ip'])
                            result['success'] = False
                        else:
                            result['nodes'][host_name].update(manage_ip=node['manage_ip'])
                            result['manage_ips'][ip] = node['manage_ip']
                else:
                    result['connect_error'].append(node['ip'])
                    result['success'] = False
            LOG.debug('get_node_ips info : "{0}"'.format(result))
            return result
        except Exception as e:
            LOG.exception('[ONEStor] get nodes ips error, {}'.format(e))

    def _install_soft(self, data):
        """
        安装软件步骤
        :param data: 部署数据
        :return:
        """
        try:
            LOG.info('start to install soft :::::::')
            os.system('echo install_soft > /tmp/deploy_status')
            if not data['handy_choose']:
                os.popen(cmd.CMD_INSTALL_SOFT.format(
                    self.filepath, data['local_ip'], data['default_user'],
                    data['default_passwd'], data['local_ip'], data['ntp_close'], 'handy')).read().rstrip()
            self.multi_thread_function(data['all_node_ip'].split(','), self._do_install, data)
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERR_INSTALL_ONESTOR_SOFT)
        else:
            self._check_installed_soft(data)  # 检查软件是否已经安装
            LOG.error('end to install soft :::::::')

    def _do_install(self, node, data, lock=None):
        """
        安装软件，多线程调用函数
        :param node: 节点
        :param data: 部署数据
        :param lock: 线程锁
        :return:
        """
        try:
            LOG.info('start to do install for node {} ########'.format(node))
            node_type = 'stor'
            if node in data['mon_public_ips']:
                node_type = 'mon'
            if node in data['osd_public_ips'] and node_type == 'mon':
                node_type = 'mon_osd'
            install_soft_cmd = cmd.CMD_INSTALL_SOFT.format(self.filepath, node, data['default_user'],
                                                           data['default_passwd'], data['local_ip'],
                                                           data['ntp_close'], node_type)
            LOG.info('do install for node {0} , cmd is {1} ########'.format(node, install_soft_cmd))
            self.exec_local_cmd(install_soft_cmd)
            LOG.info('end to do install for node {0} ########'.format(node))
            # BEGIN ADD BY D10039 2016/03/14 FOR UIS 兼容D007版本接口
            # if ('host_rack_map_str' not in data['request_data']) and ('hosts' not in data['request_data']):
            #     host_info = json.loads(install_result)
            #     data['deploy_disk_map'][host_info['hostname']] = host_info['disks']
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERR_INSTALL_ONESTOR_SOFT)

    def _check_installed_soft(self, data):
        """
        检查已安装软件
        :param data: 部署数据
        :return:
        """
        LOG.info('start to check installed soft ########')
        check_stor_soft_cmd = " && ".join([cmd.CMD_CHECK_SOFT_INSTALLED, cmd.CMD_CHECK_MC_SOFT_INSTALLED])
        check_command = cmd.CMD_RUN_REMOTE_CMD.format(
            self.filepath, '$$', data['default_user'], data['default_passwd'], check_stor_soft_cmd)
        install_result = self.multi_thread_task(data['all_node_ip'].split(','), check_command)
        install_error_nodes = []
        for host, version in install_result.iteritems():
            if -1 == version.find('ceph version') or -1 == version.find('process_detect') \
                    or -1 == version.find(const.CHECK_COMMON) or -1 == version.find('install module success'):
                install_error_nodes.append(host)
        if 0 != len(install_error_nodes):
            raise errno.ONEStorHostError(
                errno.ERROR_INSTALL_SOFT,
                ', '.join(install_error_nodes),
                const.STEP_INSTALL_SOFT,
                ', '.join(install_error_nodes))
        mon_public_ips = data['mon_public_ips']
        mon_check_command = cmd.CMD_RUN_REMOTE_CMD.format(
            self.filepath, '$$', data['default_user'], data['default_passwd'], cmd.CMD_CHECK_ZK_SOFT_INSTALLED)
        mon_install_result = self.multi_thread_task(mon_public_ips, mon_check_command)
        LOG.info('Check mon soft installed for host "{0}" result is: "{1}"'.format(mon_public_ips, mon_install_result))
        mon_install_error_nodes = []
        for host, version in mon_install_result.iteritems():
            if -1 == version.find(const.CHECK_ZOOKEEPER):
                mon_install_error_nodes.append(host)
                LOG.error('Failed to install soft zookeeper for host "{0}".'.format(host))
        if 0 != len(install_error_nodes):
            raise errno.ONEStorHostError(
                errno.ERROR_INSTALL_SOFT,
                ', '.join(install_error_nodes),
                const.STEP_INSTALL_SOFT,
                ', '.join(install_error_nodes))
        LOG.info('end to check installed soft ########')

    def _deploy_admin_node(self, data):
        """
        部署管理节点步骤
        :param data: 部署数据
        :return:
        """
        try:
            LOG.info('start to deploy admin node ::::::')
            os.system('echo deploy_admin_node > /tmp/deploy_status')
            self._modify_host_file(data)
            self.exec_local_cmd(cmd.CMD_SSH_KEY_COPY.format(const.HANDY_SHELL_PATH, data['local_ip'],
                                                            data['default_user'], data['default_passwd']))
            # end by l11544
            data['node_net_info'] = {}
            data['cluster_hosts'] = []  # ADD BY D10039 2016/03/24 将主机名对应的业务网IP保存到数据库中
            # 如果没有选中Handy，将Handy自身的信息也保存进去
            if not data['handy_choose']:
                data['cluster_hosts'].append({
                    'hostip': data['local_ip'],
                    'hostname': data['handy_name'],
                    const.DISASTER_IP: ''
                })
            ssh_mutex_lock = threading.Lock()
            self.multi_thread_function(data['all_node_ip'].split(','), self._ssh_key_copy,
                                       data, ssh_mutex_lock)
            LOG.info('end to deploy admin node ::::::')
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_DEPLOY_ADMIN_NODE)

    def _modify_host_file(self, data):
        """
        修改拷贝主机相关文件
        :param data: 部署数据
        :return:
        """
        for mon_node in data['mon_nodes'].split(','):
            self.exec_remote_cmd(
                self.filepath, data['host_ip_map'][mon_node], data['default_user'], data['default_passwd'],
                cmd.CMD_MODIFY_ETC_HOST)
        # handy config ssh self
        self.exec_local_cmd(cmd.CMD_CHMOD_666_HOSTS_DIR)
        # self.exec_local_cmd(
        #     'echo 127.0.0.1 localhost > /etc/onestor_hosts && echo 127.0.0.1 localhost > /etc/hosts')
        if not data['handy_in_mon']:
            self.exec_remote_cmd(
                self.filepath, data['local_ip'], data['default_user'], data['default_passwd'], cmd.CMD_MODIFY_ETC_HOST)
        self.exec_local_cmd(cmd.CMD_CHMOD_644_HOSTS_DIR)

    def _ssh_key_copy(self, node, data, lock):
        """
        配置ssh，多线程调用函数
        :param node: 节点
        :param data: 部署数据
        :param lock: 线程锁
        :return:
        """
        try:
            LOG.info('start to copy ssh key, node is {}'.format(node))
            # Begin add by d10039 2015/08/16
            net_info = os.popen(cmd.CMD_GET_PUBLIC_IP.format(
                self.filepath, node, data['default_user'], data['default_passwd'], data['public_network'])
            ).read().rstrip()
            net_info_list = json.loads(net_info)
            ssh_ip = net_info_list['node_ip']
            osd_node = data['ip_node_map'][node]
            # BEGIN ADD BY D10039 2016/03/24 将主机名对应的业务网IP保存到数据库中
            data['cluster_hosts'].append({
                'hostip': ssh_ip,
                'hostname': osd_node,
                const.DISASTER_IP: ''
            })
            # END ADD BY D10039 2016/03/24 将主机名对应的业务网IP保存到数据库中
            data['node_net_info'][osd_node] = net_info_list
            config_ssh_command = cmd.CMD_SSH_KEY_COPY.format(const.HANDY_SHELL_PATH, ssh_ip,
                                                             data['default_user'], data['default_passwd'])
            for mon_node in data['mon_nodes'].split(','):
                with lock:
                    self.exec_remote_cmd(self.filepath, data['host_ip_map'][mon_node],
                                         data['default_user'], data['default_passwd'], config_ssh_command)
            if not data['handy_in_mon']:
                self.exec_local_cmd(cmd.CMD_SSH_KEY_COPY.format(const.HANDY_SHELL_PATH, ssh_ip,
                                                                data['default_user'], data['default_passwd']))
            LOG.info('end to copy ssh key, node is {}'.format(node))
            # End add by d10039 2015/08/16
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERR_SSH_CONFIG)

    def _check_ssh_config(self, data):
        """
        校验ssh配置
        :param data: 部署数据
        :return:
        """
        ssh_config_result = self.multi_thread_task(data['all_node_ip'].split(','),
                                                   'timeout 30 ssh $$ hostname 2>/dev/null')
        ssh_error_nodes = []
        for host, name in ssh_config_result.iteritems():
            if '' == name or -1 == data['all_node_name'].find(name):
                ssh_error_nodes.append(host)
        if 0 != len(ssh_error_nodes):
            raise errno.ONEStorHostError(
                errno.ERROR_SSH_CONFIG,
                ', '.join(ssh_error_nodes),
                const.STEP_SSH_CONFIG,
                ', '.join(ssh_error_nodes))

    def _set_ntp_config(self, data):
        """
        NTP配置
        :param data: 部署数据
        :return:
        """
        try:
            # Modified by l11544 2016/5/5
            if '1' == str(data['ntp_close']):
                self._create_cluster_config_ntp(data['ntp_close'], data['mon_nodes'], data['local_ip'], data['all_node_name'].split(','),
                                                data['handy_choose'], data['handy_in_mon'], 'deploy_cluster')
            elif '2' == str(data['ntp_close']):
                # 修改并判断NTP修改是否完成
                result_ntp = []
                # Handy节点本地备份和重写NTP配置
                if not data['handy_choose']:
                    # self.exec_local_ssh_cmd('timeout 15 python /var/lib/ceph/shell/ntp_task.py ntp_backup')
                    handy_result = self.exec_local_ssh_cmd(
                        cmd.CMD_NTP_WRITE.format(base64.b64encode(str(data['ntp_servers']))))
                    if 'ok' != handy_result:
                        raise errno.ONEStorError(errno.ERROR_MANAGE_NTP_CONFIG)
                # 先对各节点NTP文件进行备份
                # self.multi_thread_task(
                #     all_node_ip.split(','), 'timeout 15 ssh $$ python /var/lib/ceph/shell/ntp_task.py ntp_backup')
                # 先对各节点NTP文件进行备份然后重写配置
                multi_ntp_rewrite = self.multi_thread_task(
                    data['all_node_ip'].split(','),
                    cmd.CMD_NTP_WRITE_MULTI.format(base64.b64encode(str(data['ntp_servers']))))
                for node in multi_ntp_rewrite:
                    if 'ok' != multi_ntp_rewrite[node]:
                        result_ntp.append(node)
                if len(result_ntp) > 0:
                    raise errno.ONEStorError(errno.ERROR_NTP_CONFIG)
        except ValueError:
            raise errno.ONEStorError(errno.ERROR_NTP_CONFIG)
        except Exception, e:
            LOG.error('NTP config error, %s', e)
            raise errno.ONEStorError(errno.ERROR_NTP_CONFIG)

    def _clean_mon_nodes(self, mon_nodes):
        """
        部署新的集群之前清理mon节点上的目录
        :param mon_nodes:
        :return:
        """
        try:
            self.exec_local_cmd('rm -f /home/ceph-cluster/*')
            self.multi_thread_task(
                mon_nodes, 'rm -rf /var/lib/ceph/mon/*', ssh=True)
            self.multi_thread_task(
                mon_nodes, 'rm -rf /etc/ceph/*', ssh=True)
            self.multi_thread_task(
                mon_nodes, 'rm -rf /var/run/ceph/*', ssh=True)
            distro = platform.dist()[0]
            if distro == "centos":
                self.multi_thread_task(
                    mon_nodes, 'systemctl stop ceph-mon.target && systemctl start ceph-mon.target', ssh=True)
            else:
                self.multi_thread_task(
                    mon_nodes, 'stop ceph-mon-all && start ceph-mon-all', ssh=True)
        except KeyError:
            LOG.error('clean mon nodes error')
        except Exception, e:
            LOG.error(e)

    def _copy_conf_other_node(self, data):
        """
        拷贝配置文件到其他节点
        :param data: 部署数据
        :return:
        """
        # copy keyring to node
        try:
            self.exec_local_cmd(cmd.CMD_CHMOD_CEPH_CONF.format(const.CLUSTER_DEPLOY_DIR, const.CLUSTER_DEPLOY_DIR))
            # copy config to handy /etc/ceph
            self.exec_local_cmd(cmd.CMD_COPY_CEPH_CONF.format(const.CLUSTER_DEPLOY_DIR, const.CLUSTER_DEPLOY_DIR))
            self.multi_thread_function(data['all_node_name'].split(','), self._do_copy_keyring)
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_COPY_CONF_OTHER_NODE)

    def _deploy_mon_node(self, data):
        """
        部署监控节点步骤
        :param data: 部署数据
        :return:
        """
        try:
            LOG.info('start to deploy mon node ::::::')
            os.system('echo deploy_mon_node > /tmp/deploy_status')
            self._clean_mon_nodes(data['mon_nodes'].split(','))
            # MODIFY BY D10039 2016/08/16 FOR HANDY HA
            # Modified by l11544 部署时去除写入灾备网网段
            deploy_mon_command = cmd.CMD_CLUSTER_DEPLOY.format(
                const.HANDY_SHELL_PATH, data['cluster_name'], data['mon_nodes'],
                data['all_node_name'], data['manage_network'], data['cluster_network'],
                data['public_network'], 'around', data['install_type'], ','.join(data['mon_manage_ips']),
                ','.join(data['mon_public_ips']), ','.join(data['mon_cluster_ips']))
            self.exec_local_cmd(deploy_mon_command)
            # 拷贝配置文件到其他节点
            self._copy_conf_other_node(data)
            # 检查监控节点是否部署成功
            deploy_mon_result = self.exec_local_cmd('timeout 30 ceph fsid 2>/dev/null')
            if '' == deploy_mon_result:
                raise errno.ONEStorError(errno.ERROR_DEPLOY_MON_NODE)
            # 需要保证免密已经配置成功，ceph.conf已经拷贝过去
            self.multi_thread_task(data['all_node_ip'].split(','), "timeout 30 scp /etc/onestor_hosts [$$]:/etc/")
            # self._rewrite_config(data)
            LOG.info('end to deploy mon node ::::::')
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_DEPLOY_MON_NODE)

    def _deploy_zk_node(self, data):
        self._rewrite_config(data)
        mon_manage_ips = data['mon_manage_ips']
        mon_public_ips = data['mon_public_ips']

        try:
            cmd_setup_zk = "timeout 30 ssh $$ /opt/h3c/bin/python /var/lib/ceph/shell/zk/zk_task.py set_zk {0}"\
                .format(','.join(mon_manage_ips))
            LOG.info('cmd_setup_zk: {}'.format(cmd_setup_zk))
            zks_result = self.multi_thread_task(mon_public_ips, cmd_setup_zk)
            LOG.info('zks_result: {}'.format(zks_result))
            for host in zks_result:
                if 'success' != zks_result[host]:
                    raise errno.ONEStorError(errno.ERROR_ZK_DEPLOY)
        except Exception:
            raise errno.ONEStorError(errno.ERROR_ZK_DEPLOY)
        # 重启leader和所有节点peon
        peon_list = data['all_node_ip'].split(',')
        if not data['handy_choose']:
            peon_list.append(data['handy_manage_ip'])
        self.restart_leader_pub_sub_nm(peon_list)

    def _do_copy_keyring(self, node, data=None, lock=None):
        """
        拷贝认证文件，多线程调用函数
        :param node: 节点
        :param data: 部署数据
        :param lock: 线程锁
        :return:
        """
        self.exec_local_cmd(cmd.CMD_SCP_COPY_CEPH_CONF.format(
            const.CLUSTER_DEPLOY_DIR, const.CLUSTER_DEPLOY_DIR, node))

    def _rewrite_config(self, data):
        """
        覆写配置文件
        :param data: 部署数据
        :return:
        """
        result_hosts_config = self.multi_thread_task(
            data['all_node_ip'].split(','),
            'timeout 30 ssh $$ /opt/h3c/bin/python /var/lib/ceph/shell/rewrite_config.py ceph_config_fix')
        if not data['handy_choose']:
            self.exec_local_cmd('/opt/h3c/bin/python /var/lib/ceph/shell/rewrite_config.py ceph_config_fix')
        # END ADD BY C13463
        for result_host in result_hosts_config:
            if 'success' != result_hosts_config[result_host]:
                raise errno.ONEStorError(errno.ERROR_MODIFY_CEPH_CONF)

    def _deploy_data_node(self, data):
        """
        部署数据节点步骤
        :param data: 部署数据
        :return:
        """
        LOG.info('start to deploy data node ::::::')
        os.system('echo deploy_data_node > /tmp/deploy_status')
        self.multi_thread_function(data['osd_nodes'].split(','), self._do_deploy_osd, data)
        # 查看下ceph osd tree 结果
        LOG.info('deploy data node, ceph osd tree is {}'.format(
            self.exec_local_cmd('timeout 30 ceph osd tree -f json 2>/dev/null')))
        # 检查数据节点是否部署成功
        self._check_deployed_data_node(data)
        LOG.info('end to deploy data node ::::::')

    def _do_deploy_osd(self, node, data, lock=None):
        """
        部署节点osd，多线程调用函数
        :param node: 节点
        :param data: 部署数据
        :param lock: 线程锁
        :return:
        """
        if not data['host_flash_map'][node]:
            flash_disks = '-1'
            flash_switch = 'close'
        else:
            flash_disks = ','.join(data['host_flash_map'][node])
            flash_switch = 'open'
        if not data['host_journal_map'][node]:
            journal_disks = '-1'
        else:
            journal_disks = ','.join(data['host_journal_map'][node])
        deploy_osd_command = "/opt/h3c/bin/python %s/deploy_disk.py '%s' '%s' '%s' '%s' '%s' '%s' 2>/dev/null" \
                             % (const.HANDY_SHELL_PATH, node, ','.join(data['host_disk_map'][node]),
                                journal_disks, flash_switch, flash_disks, data['install_type'])
        # BEGIN MODIFY BY D10039 2016/04/06 PN:201602260480 改为SSH的方式增加硬盘
        LOG.info('[ONEStor] begin add host when create cluster, node is {0}, '
                 'command is {1}'.format(node, deploy_osd_command))
        self.exec_remote_ssh_cmd(data['host_ip_map'][node], deploy_osd_command)
        LOG.info('[ONEStor] end add host when create cluster')
        # END MODIFY BY D10039 2016/04/06 PN:201602260480

    def _check_deployed_data_node(self, data):
        """
        检查数据节点是否部署成功
        :param data: 部署数据
        :return:
        """
        LOG.info('start to check deployed data node ########')
        deploy_osd_result = self.exec_local_cmd('timeout 30 ceph osd tree -f json 2>/dev/null')
        deploy_osd_error_nodes = []
        if '' != data['osd_nodes'] and '' != deploy_osd_result:
            crush_map_nodes = json.loads(deploy_osd_result)
            for crush_node in crush_map_nodes['nodes']:
                if 'host' == crush_node['type']:
                    if len(data['host_disk_map'][crush_node['name']]) != len(crush_node['children']):
                        deploy_osd_error_nodes.append(crush_node['name'])
        if len(deploy_osd_error_nodes):
            raise errno.ONEStorHostError(
                errno.ERROR_DEPLOY_OSD,
                ', '.join(deploy_osd_error_nodes),
                const.STEP_DEPLOY_OSD,
                ', '.join(deploy_osd_error_nodes))
        LOG.info('end to check deployed data node ########')

    @staticmethod
    def _create_nodepool(data):
        """
        创建节点池
        :param data: 部署数据
        :return:
        """
        try:
            LOG.info('start to create nodepool, nodepool list is {0}'.format(data['nodepool_list']))
            os.system('echo create_nodepool > /tmp/deploy_status')
            data = {'nodepool_list': data['nodepool_list']}
            nodepool_create_response = send_request_onestord(const.COMP_CS, const.OP_NODEPOOL_CREATE, data)
            nodepool_create_result = nodepool_create_response['response']['result']
            if 0 != nodepool_create_result[0]:
                LOG.info('nodepool create error, response is %s', nodepool_create_response)
                raise errno.ONEStorError(errno.ERROR_CREATE_NODEPOOL)
            LOG.info('end to create nodepool ::::::')
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_CREATE_NODEPOOL)

    @staticmethod
    def _create_diskpool(data):
        """
        创建硬盘池
        :param data: 部署数据
        :return:
        """
        try:
            LOG.info('start to create diskpool , diskpool list is {0}'.format(data['diskpool_list']))
            os.system('echo create_diskpool > /tmp/deploy_status')
            data = {'diskpool_list': data['diskpool_list']}
            diskpool_create_response = send_request_onestord(const.COMP_CS, const.OP_DISKPOOL_CREATE, data)
            diskpool_create_result = diskpool_create_response['response']['result']
            if 0 != diskpool_create_result[0]:
                LOG.info('diskpool create error, response is %s', diskpool_create_response)
                raise errno.ONEStorError(errno.ERROR_CREATE_NODEPOOL)
            os.system('ceph osd crush add-bucket maintain root')
            LOG.info('end to create diskpool ::::::')
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_CREATE_DISKPOOL)

    @staticmethod
    def _create_protection_domain(data):
        """
        创建保护域
        :param data: 部署数据
        :return:
        """
        try:
            if data['domain_list']:
                LOG.info('start to create protection domain , protection domain list is {0}'.
                         format(data['domain_list']))
                data = {'nodepool_list': data['domain_list']}
                domain_create_response = send_request_onestord(const.COMP_CS, const.OP_PROTECTIONDOMAIN_CREATE, data)
                domain_create_result = domain_create_response['response']['result']
                if 0 != domain_create_result[0]:
                    LOG.info('protection domain create error, response is %s', domain_create_response)
                    raise errno.ONEStorError(errno.ERROR_CREATE_PROTECTION_DOMAIN)
                LOG.info('end to create protection domain')
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_CREATE_PROTECTION_DOMAIN)

    def _create_rack(self, data):
        """
        创建机架
        :param data: 部署数据
        :return:
        """
        try:
            LOG.info('start to create rack, rack is {0}'.format(data['rack_list']))
            os.system('echo create_rack > /tmp/deploy_status')
            rack_data = {'rack_info': data['rack_list']}
            rack_create_response = send_request_onestord(const.COMP_CS, const.OP_RACK_CREATE, rack_data)
            rack_create_result = rack_create_response['response']['result']
            if 0 != rack_create_result[0]:
                LOG.info('rack create error, response is %s', rack_create_response)
                raise errno.ONEStorError(errno.ERROR_CREATE_RACK)
            LOG.info('end to create rack')
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_CREATE_RACK)

    @staticmethod
    def _move_rack(data):
        """
        移动机架
        :param data: 部署数据
        :return:
        """
        try:
            LOG.info('start to move rack, rack is {0}'.format(data['logic_rack_list']))
            rack_data = {'diskpool_list': data['logic_rack_list']}
            rack_move_response = send_request_onestord(const.COMP_CS, const.OP_RACK_MOVE, rack_data)
            rack_move_result = rack_move_response['response']['result']
            if 0 != rack_move_result[0]:
                LOG.info('rack move error, response is %s', rack_move_response)
                raise errno.ONEStorError(errno.ERROR_MOVE_RACK)
            LOG.info('end to move rack')
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_MOVE_RACK)

    def _initialize_cluster(self, data):
        """
        初始化集群步骤
        :param data: 部署数据
        :return:
        """
        try:
            LOG.info('start to initialize cluster ::::::')
            os.system('echo initial_cluster > /tmp/deploy_status')
            self._init_host_info(data)  # 组织主机信息数据
            self._init_ceph_osd_tree(data)  # 改变ceph osd tree分布，主机记录postgres表
            # self._create_pool()  # 创建默认pool
            self._push_keyring_to_node(data)
            self._add_config_to_database(data)
            self._set_cron_task(data)
            self._rewrite_config(data)  # 重写ceph.conf部分配置
            self._check_initialize_crush_result(data)  # 校验初始化结果
            self._record_deploy_time()
            # 更新硬盘池容量大小
            self.update_diskpool_capacity(data['host_list'], const.ADD_DISK_FOR_UPDATE_DISKPOOL_CAPACITY)
            # 保存主机和zookeeper配置信息
            self._save_host_info(data)
            LOG.info('end to initialize cluster ::::::')
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_INITIALIZE_CLUSTER)

    @staticmethod
    def _save_host_info(data):
        """
        保存主机和zookeeper配置信息
        :param data:
        :return:
        """

        host_ip_map = data['host_ip_map']
        host_manage_ip_map = data['host_manage_ip_map']
        host_cluster_ip_map = data['host_cluster_ip_map']

        # 保存节点ip信息
        mon_ips = data['mon_ips']
        send_data = dict(zks=mon_ips)
        rep = send_request_onestord(const.D_COMP_CM, const.D_OP_ZK_INIT, send_data, need_log=True)
        LOG.info('init zk rep: {}'.format(rep))
        rep_status = rep['status']
        if 'success' != rep_status:
            raise errno.ONEStorError(errno.ERR_SAVE_ZK)
        rep_result = rep['response']['result']
        if 0 != rep_result[0]:
            raise errno.ONEStorError(errno.ERR_SAVE_ZK)
        hosts_dict = dict()
        for host in host_ip_map:
            host_dict = dict(name=host, public_ip=host_ip_map[host])
            hosts_dict[host] = host_dict
        for host in host_manage_ip_map:
            hosts_dict[host].update(manage_ip=host_manage_ip_map[host])
        for host in host_cluster_ip_map:
            hosts_dict[host].update(cluster_ip=host_cluster_ip_map[host])
        # Handy不在集群内，增加Handy节点信息
        if not data['handy_choose']:
            handy_name = data['handy_name']
            host_dict = dict(name=handy_name, public_ip=data['local_ip'],
                             manage_ip=data['handy_manage_ip'])
            hosts_dict[handy_name] = host_dict
        send_data = dict(hosts=hosts_dict.values())
        rep = send_request_onestord(const.D_COMP_CM, const.D_OP_HOST_SAVE, send_data, need_log=True)
        rep_status = rep['status']
        if 'success' != rep_status:
            raise errno.ONEStorError(errno.ERR_SAVE_HOSTS)
        rep_result = rep['response']['result']
        if 0 != rep_result[0]:
            raise errno.ONEStorError(errno.ERR_SAVE_HOSTS)

    def _init_host_info(self, data):
        """
        组织主机信息数据
        :param data: 部署数据
        :return:
        """
        try:
            ssh_mutex_lock = threading.Lock()
            self.multi_thread_function(data['osd_nodes'].split(','), self._do_init_host_info, data, ssh_mutex_lock)
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_GET_OSD_INFO)

    def _do_init_host_info(self, node, data, lock=None):
        """
        组织主机信息数据，多线程调用函数
        :param node: 节点
        :param data: 部署数据
        :param lock: 线程锁
        :return:
        """
        LOG.info('start to get osd info for node:{} , host list is {}'.format(node, data['host_list']))
        osd_id_command = 'df /var/lib/ceph/osd/ceph-* | grep osd/ceph- 2>/dev/null'
        osd_id_result = self.exec_remote_cmd(self.filepath, node, data['default_user'],
                                             data['default_passwd'], osd_id_command).split('\n')
        LOG.info('node {} get osd id, result is {}'.format(node, osd_id_result))
        with lock:
            for host in data['host_list']:
                if host['name'] == node:
                    host['diskpool_list'] = data['host_diskpool_map'][node]
                    host['nodepool_name'] = data['host_nodepool_map'][node]
                    host['public_ip'] = data['host_ip_map'][node]
                    host['rack'] = data['host_rack_map'][node]
                    for disk_pool in data['host_diskpool_map'][node]:
                        data_disk = host[disk_pool]['data']
                        tmp = []
                        for disk in data_disk:
                            disk_name = disk.split(':')[0]
                            for osd in osd_id_result:
                                osd_mount = osd.split()[0]
                                osd_id = osd.split()[5].split('ceph-')[1]
                                if 'loop' in osd_mount or 'cciss' in osd_mount or 'nvme' in osd_mount:
                                    if osd_mount.split('/')[-1][:-2] == disk_name:
                                        tmp.append(disk + ':' + osd_id)
                                else:
                                    if osd_mount.split('/')[-1][:-1] == disk_name:
                                        tmp.append(disk + ':' + osd_id)
                        host[disk_pool]['data'] = tmp
        LOG.info('end to get osd info for node:{} , host list is {}'.format(node, data['host_list']))

    def _init_ceph_osd_tree(self, data):
        """
        组织 ceph osd tree 分布
        :param data: 部署数据
        :return:
        """
        try:
            LOG.info('start init host crush, host is {0}'.format(data['host_list']))
            os.system('echo "init crush..." > /home/ceph-cluster/ceph.result')
            self.initialize_host_crush(data['host_list'], data['diskpool_list'])
            os.system('echo "success" > /home/ceph-cluster/ceph.result')
            LOG.info('end init host crush')
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_INITIALIZE_CLUSTER)

    def _create_pool(self):
        """
        创建默认pool
        :return:
        """
        self.exec_local_cmd('ceph osd pool delete rbd rbd --yes-i-really-really-mean-it')
        self.create_default_pool()

    def _push_keyring_to_node(self, data):
        """
        push keyring 到某节点
        :param data: 部署数据
        :return:
        """
        try:
            self.exec_local_cmd('chmod 644 %s/ceph.conf' % const.CLUSTER_DEPLOY_DIR)
            # copy config to handy /etc/ceph
            self.exec_local_cmd('cp %s/ceph.conf /etc/ceph/' % const.CLUSTER_DEPLOY_DIR)
            self.multi_thread_function(data['all_node_name'].split(','), self._do_push_keyring)
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_COPY_CONF_OTHER_NODE)

    def _do_push_keyring(self, node, data=None, lock=None):
        """
        push keyring 到某节点，多线程调用函数
        :param node: 节点
        :param data: 部署数据
        :param lock: 线程锁
        :return:
        """
        LOG.info('start to do push keyring to node {} ::::::'.format(node))
        push_keyring_command = 'scp -p %s/ceph.conf [%s]:/etc/ceph/' % (const.CLUSTER_DEPLOY_DIR, node)
        self.exec_local_cmd(push_keyring_command)
        # PN:201601180459 将ONEStor版本文件推送到节点上
        LOG.info('[ONEStor] push version to node: %s' % node)
        self.exec_local_cmd('scp /etc/onestor_*version [%s]:/etc/' % node)
        LOG.info('end to do push keyring to node {} ::::::'.format(node))

    def _set_cron_task(self, data):
        """
        设置cron任务
        :param data: 部署数据
        :return:
        """
        LOG.info('start to set cron task :::::::')
        # deleted by l11544 部署时去除创建灾备元数据池 2017/5/22
        # modify by z12001 20160809
        LOG.info('start to restart diamond :::::::')
        os.popen('service diamond restart')
        LOG.info('end to restart diamond :::::::')
        LOG.info('start to rewrite config :::::::')
        self.exec_local_cmd('timeout 30 /opt/h3c/bin/python /var/lib/ceph/shell/rewrite_config.py ceph_config_fix')
        LOG.info('end to rewrite config :::::::')
        # PN: 201608180321 【NTPOpt第一轮验收】handy节点上没有NTP保护进程，handy时间不同步时影响license使用
        if data['local_ip'] not in data['all_node_ip'].split(','):
            crontab_cmd = 'bash {0}/crontab_task.sh'.format(const.HANDY_SHELL_PATH)
            LOG.info('start to bash crontab task , cmd is {} :::::::'.format(crontab_cmd))
            self.exec_local_cmd(crontab_cmd)
            LOG.info('end to bash crontab task :::::::')
        # end by l11544 2017/3/10
        self.multi_thread_function(data['all_node_ip'].split(','), self._do_push_keyring, data)
        self._rewrite_config(data)
        self.multi_thread_function(data['all_node_ip'].split(','), self.add_cron, data)
        LOG.info('end to set cron task :::::::')

    def _add_config_to_database(self, data):
        """
        添加配置信息到数据库
        :param data: 部署数据
        :return:
        """
        mon_ip = []
        for mon_node in data['mon_nodes'].split(','):
            # MODIFY BY Z1524 2017/03/21 PN: 201702200161
            mon_ip.append(self.name_to_ip(mon_node))
        new_obj = {}
        # ADD BY D10039 2016/08/16 FOR HANDY HA
        new_obj['manage_network'] = data['manage_network']
        new_obj['cluster_network'] = data['cluster_network']
        new_obj['public_network'] = data['public_network']
        new_obj['mon_fqdns'] = data['mon_nodes'].split(',')
        new_obj['mon_ip'] = mon_ip
        # ADD BY D10039 2016/03/01 PN:201602180530 修改NTP配置
        new_obj['ntp_close'] = data['ntp_close']
        add_table_command = "ceph config-key put %s '%s'" % ('clusterconfig', json.dumps(new_obj))
        self.exec_local_cmd(add_table_command)
        # PN:201512260085 将Handy的id_rsa.pub保存到数据库中
        pub_key = self.exec_local_cmd('cat /root/.ssh/id_rsa.pub')
        self.exec_local_cmd("ceph config-key put handy_key '{\"ssh_pub_key\": [{\"%s\": \"%s\"}]}'"
                            % (data['handy_name'], pub_key))
        # BEGIN ADD BY D10039 2016/03/24 将主机名对应的业务网IP保存到数据库中
        self.exec_local_cmd("ceph config-key put cluster_hosts '%s'" % json.dumps(data['cluster_hosts']))

    def add_cron(self, node, data=None, lock=None):
        """
        添加cron任务
        :param node: 节点
        :param data: 部署数据
        :return:
        """
        # modify by z12001 to restart diamond 20160809
        LOG.info('start to add cron for node {} ::::'.format(node))
        add_cron_command = 'bash %s/crontab_task.sh && service diamond restart && service tgt restart'\
                           % const.HANDY_SHELL_PATH
        self.exec_remote_cmd(self.filepath, node, data['default_user'], data['default_passwd'], add_cron_command)
        LOG.info('end to add cron for node {}, cmd is {}::::'.format(node, add_cron_command))

    def _check_initialize_crush_result(self, data):
        """
        检查initialize 移动 osd 是否全部成功
        :param data: 部署数据
        :return:
        """
        LOG.info('start to check initialize crush result ########')
        deploy_osd_result = self.exec_local_cmd('timeout 30 ceph osd tree -f json 2>/dev/null')
        total_osd = []  # 全部加到ceph osd tree 中的osd
        total_disk = []  # request 全部需要部署的硬盘
        if '' != data['osd_nodes'] and '' != deploy_osd_result:
            crush_map_nodes = json.loads(deploy_osd_result)
            for crush_node in crush_map_nodes['nodes']:
                if 'root' == crush_node['type'] and 'maintain' != crush_node['name']\
                        and 'default' != crush_node['name']:
                    self.deep_search_crush(crush_node, crush_map_nodes['nodes'], total_osd)
            LOG.info('total osd num in ceph osd tree is {}'.format(len(total_osd)))
            for node in data['osd_nodes'].split(','):
                total_disk.extend(data['host_disk_map'][node])
            LOG.info('total need deploy disk num is {}'.format(len(total_disk)))
        if len(total_osd) != len(total_disk):
            LOG.error('check initialize crush result happens error, deploy osd result is {0}'.format(deploy_osd_result))
            raise errno.ONEStorError(errno.ERROR_CHECK_CRUSH)
        LOG.info('end to check initialize crush result ########')

    def _record_deploy_time(self):
        """
        记录部署时间
        :return:
        """
        # /etc/ceph下写入time.txt文件 #系统日志, PN:201606220206 add by l11544
        system_time = time.time()
        path_time = '/etc/ceph/time.txt'
        self.exec_local_ssh_cmd(
            'echo initTime: %s > %s && echo endJudge: true >> %s && echo startTime: %s >> %s'
            % (system_time, path_time, path_time, system_time, path_time))

    def _clear_cluster_config_batch(self, osd_nodes):
        """
        批量清理集群配置
        :param osd_nodes: 各个节点
        :return:
        """
        try:
            threads = []
            nloops = range(len(osd_nodes.split(',')))
            def clear_config(node):
                self._clear_cluster_config(node)
            for node in osd_nodes.split(','):
                t = threading.Thread(target=clear_config, args=(node,))
                threads.append(t)
            for i in nloops:
                threads[i].start()
            for i in nloops:
                threads[i].join()
        except Exception, e:
            LOG.error('_clear_cluster_config_batch error: %s', e)

    def _do_deploy_last(self, request):
        """
        部署扫尾工作
        :param request: 请求数据
        :return:
        """
        try:
            host_ip_map = {}
            if 'host_rack_map_str' not in request.DATA:
                if 'hosts' in request.DATA:
                    hosts_list = request.DATA['hosts']
                    for _host in hosts_list:
                        _host_name = _host['hostname']
                        host_ip_map[_host_name] = _host['hostip']
                else:
                    all_node_ip = request.DATA['all_node_ip']
                    all_node_name = request.DATA['all_node_name']
                    all_node_ip_array = all_node_ip.split(',')
                    # 如果不传入hosts参数，则所有的缓存都不开启
                    for i, name in enumerate(all_node_name.split(',')):
                        host_ip_map[name] = all_node_ip_array[i]
            else:
                host_ip_map_str = request.DATA['host_ip_map_str']
                host_ip_map_json = json.loads(host_ip_map_str)
                for host_ip_pair in host_ip_map_json['elements']:
                    host_ip_map[host_ip_pair['key']] = host_ip_pair['value']
            default_user = request.DATA['default_user']
            default_passwd = request.DATA['default_passwd']
            mon_nodes = request.DATA['mon_nodes']
            local_ip = request.DATA['local_ip']
            command = 'mv /etc/hosts_bk /etc/hosts 2>/dev/null && echo ok'
            handy_name = self.exec_local_cmd('hostname')
            if handy_name not in mon_nodes.split(','):
                handy_result = self.exec_remote_cmd(self.filepath, local_ip, default_user, default_passwd, command)
                if 'ok' != handy_result:
                    LOG.warning('[create_cluster] get back %s hosts file failed', handy_name)
            for mon_node in mon_nodes.split(','):
                mon_result = self.exec_remote_cmd(
                    self.filepath, host_ip_map[mon_node], default_user, default_passwd, command)
                if 'ok' != mon_result:
                    LOG.warning('[create_cluster] get back %s hosts file failed', mon_node)
            # PN: 201706200613 【凝思移植系统测试】handy节点/etc/hosts文件里有其他节点ip和主机名残留，
            # 避免对其他操作有影响，建议删除干净
            clear_result = self.exec_local_cmd("timeout 30 sed -i '/# ONEStor$/d' /etc/hosts && echo ok")
            if "ok" != clear_result:
                LOG.warning("clear '# ONEStor' info in /etc/hosts failed")
            # end by l11544 2017/7/5
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_INTERNAL_SERVER)

    @staticmethod
    def multi_thread_function(nodes, func, deploy_data=None, lock=None):
        """
        多线程任务函数
        :param nodes: 任务下发的各个节点
        :param func: 任务函数
        :param deploy_data: 部署相关数据
        :param lock: 线程锁
        :return:
        """
        threads = []
        nloops = range(len(nodes))
        for node in nodes:
            t = threading.Thread(target=func, args=(node, deploy_data, lock))
            threads.append(t)
        for i in nloops:
            threads[i].start()
        for i in nloops:
            threads[i].join()

    def create_default_pool(self):
        """
        给所有分区创建pool，只有下面存在osd，才会成功创建
        :return:
        """
        r = self.execute_cmd("ceph osd crush tree -f json")
        # fix for ceph-12.2.0. stdout endswith []
        if str(r['out']).strip().endswith('[]'):
            stdout = str(r['out']).strip().rstrip(']').rstrip('[')
        else:
            stdout = str(r['out']).strip()
        osd_map = json.loads(stdout)
        for root in osd_map:
            if root['type'] != "root" or root['name'] == "default" or root['name'] == "maintain":
                continue
            pool = {
                'pool_name': root['name'], 'diskpool_name': root['name'],
                'redundancy': 'replicated', 'replicate_num': 2,
            }
            LOG.info("Start to create pool: {0}".format(pool))
            send_request_onestord('COMP_CS', 'POOL_create', pool)
            # fix: 每个分区下创建一个存放rbd元数据的池，业务逻辑后台处理
            # LOG.info("Start to create pool: {0}".format(pool1))
            # send_request_onestord('COMP_CS', 'POOL_create', pool1)
            # deleted by l11544 容灾兼容分区，删除backup池默认创建
        return
