#!/usr/bin/env python
# coding: utf-8

"""
主机管理回滚
"""

import logging

from calamari_rest.views.common import const
from calamari_rest.views.common import errno
from calamari_rest.views.deploy.deploy_util import DeployUtil
from rest_framework.request import Request

LOG = logging.getLogger('django.request')


class DeployFinalRollback(DeployUtil):
    """
    集群部署管理finally和回滚方法类
    """
    def __init__(self, *args, **kwargs):
        super(DeployFinalRollback, self).__init__(*args, **kwargs)

    def deploy_finally(self, *args):
        """
        部署finally操作
        :param data: 请求内容 {
            "args": {}
        }
        :type data: dict
        :returns: dict
        """
        LOG.info('start to do deploy finally ::::::')
        self.exec_local_cmd('rm -f /tmp/deploy_status')
        self.exec_local_cmd('rm -f {0}'.format(const.FLAG_OPERATE_CLUSTER))
        LOG.info('end to do deploy finally ::::::')

    def deploy_rollback(self, *args):
        """
        回退
        :param data: 请求内容 {
             "args": {}
        }
        :type data: dict
        :returns: dict
        """
        LOG.info('start to do deploy rollback ::::::')
        self.exec_local_cmd('rm -f /etc/ceph/ceph.conf.bak 2>/dev/null')
        self.exec_local_cmd('mv /etc/ceph/ceph.conf /etc/ceph/ceph.conf.bak 2>/dev/null')
        LOG.info('end to do deploy rollback ::::::')
