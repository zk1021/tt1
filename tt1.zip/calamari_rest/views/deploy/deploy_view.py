#!/usr/bin/env python
# coding: utf-8

"""
集群部署模块
"""

import logging

from calamari_rest.views.common import util
from calamari_rest.views.common import const
from calamari_rest.views.common import errno
from calamari_rest.views.common import op_log
from calamari_rest.views.deploy.final_rollback import DeployFinalRollback
from rest_framework.response import Response

LOG = logging.getLogger('django.request')


class DeployViewSet(DeployFinalRollback):
    """
    集群部署视图
    """
    @util.send_response(
        op=const.OP_CREATE_CLUSTER,
        ret_type=const.RETURN_TYPE_3
    )
    @util.before_return(
        final=DeployFinalRollback.deploy_finally,
        roolback=DeployFinalRollback.deploy_rollback
    )
    def create_cluster(self, request, fsid=''):
        """
        部署集群
        :param data: 请求内容 {
             "request": {}
        }
        :type data: dict
        :returns: dict
        :raises: :class:`errno.ONEStorError`
        """
        # 部署前
        self._do_deploy_first()
        # 返回操作日志内容
        yield op_log.OP_CREATE_CLUSTER
        # 校验且重新组织请求数据
        deploy_data = self._check_param_data(request)
        # 校验License
        self.check_license(deploy_data)
        # 部署前一些基本检查
        self._before_deploy_check(deploy_data)
        # 网络检查
        deploy_data = self._network_check(deploy_data)
        # 安装软件
        self._install_soft(deploy_data)
        # 部署管理节点
        self._deploy_admin_node(deploy_data)
        # 检查SSH免密是否配置成功
        self._check_ssh_config(deploy_data)
        # NTP配置
        self._set_ntp_config(deploy_data)
        # 部署监控节点
        self._deploy_mon_node(deploy_data)
        self._deploy_zk_node(deploy_data)
        # 部署数据节点
        self._deploy_data_node(deploy_data)
        # 创建节点池
        self._create_nodepool(deploy_data)
        # 创建硬盘池
        self._create_diskpool(deploy_data)
        # 创建保护域
        self._create_protection_domain(deploy_data)
        # 创建机架（物理：写入数据库）
        self._create_rack(deploy_data)
        # 移动机架（逻辑：ceph osd tree）
        self._move_rack(deploy_data)
        # 初始化集群
        self._initialize_cluster(deploy_data)
        # 扫尾工作，又不需要放到finally
        self._do_deploy_last(request)
