#!/usr/bin/env python
# coding: utf-8

"""
language数据库操作实例
"""

import json
import logging

from calamari_rest.models import Language

LOG = logging.getLogger('django.request')


class LanguageDatabase(object):
    """
    Language数据库操作实例
    """

    @staticmethod
    def create_language(language_info):
        """
        创建Languae
        """
        LOG.info('add language info to db: %s', language_info)
        Language.objects.create(
            language=language_info['language'],

        )

    @staticmethod
    def delete_language():
        """
        删除language
        """
        LOG.info('remove language info from db...')
        language_db = Language.objects.all()
        if 0 < len(language_db):
            language_db[0].delete()
            return True

    @staticmethod
    def update_language(old_language, new_language):
        """
        修改language
        """
        LOG.info('update language info to db: %s -> %s', old_language, new_language)
        language_db = Language.objects.all()
        if 0 < len(language_db):
            obj = Language.objects.get(language=old_language)
            obj.language = new_language
            obj.save()

    @staticmethod
    def list_language():
        """
        查询language
        """
        language_db = Language.objects.all()
        data = None
        if 0 < len(language_db):
            data = {
                "language": language_db[0].language
            }
        return data
