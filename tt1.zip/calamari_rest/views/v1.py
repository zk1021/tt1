#!/usr/bin/env python
# -*- coding:utf-8 -*-

import re
import os
from collections import defaultdict
import logging
import socket
import time
import json
import base64
import configobj
from dateutil.parser import parse as dateutil_parse

from django.core.exceptions import ValidationError, PermissionDenied
from django.core.urlresolvers import reverse
from django.http import Http404
import pytz
from rest_framework import viewsets
from rest_framework.exceptions import AuthenticationFailed
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.decorators import permission_classes
from rest_framework.permissions import AllowAny
from rest_framework import status
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import ensure_csrf_cookie
from django.shortcuts import redirect
from django.contrib.auth.models import User, Group, Permission
from rest_framework.views import APIView
from onestor import onestor
from onestor import database
from calamari_common import cmdprocess
from calamari_common import casauth
from calamari_rest.models import Session
from calamari_rest.decorator import permit_login
from calamari_common.cluster_api import cluster_size_kb
import rados
# PN: 201704140690 修改集群服务配置中的闲置超时时长没有生效
from calamari_common.config import CalamariConfig
import datetime
# end by l11544 2017/4/19
# modified by l11544 PN: 201703110304
from calamari_rest.views.lics import lics_view
# end by l11544 2017/3/27 重新读取配置文件保证超时退出生效
from pyDes import *

# Suppress warning from graphite's use of old django API
import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning,
                        message="django.conf.urls.defaults is deprecated")

try:
    import graphite
except ImportError:
    graphite = None
else:
    from graphite.render.attime import parseATTime
    from graphite.render.datalib import fetchData

from calamari_rest.views import sso
from calamari_rest.views.rpc_view import RPCView, DataObject, RPCViewSet
from calamari_common.types import POOL, OSD, ServiceId, OsdMap, PgSummary, MdsMap, MonStatus
from calamari_rest.views.server_metadata import get_local_grains
from calamari_rest.views.onestor_common import ONEStorCommon
from calamari_common.radosgw_swift_api import getTempUrl

try:
    from calamari_rest.version import VERSION
except ImportError:
    # could create version here if we wanted to be fancier
    VERSION = 'dev'

from calamari_rest.serializers.v1 import ClusterSpaceSerializer, ClusterHealthSerializer, UserSerializer, \
    ClusterSerializer, OSDDetailSerializer, OSDListSerializer, ClusterHealthCountersSerializer, \
    PoolSerializer, ServerSerializer, InfoSerializer
from calamari_common.config import CalamariConfig
from calamari_web import send_add_oplog_msg

from sso.sso_db import SsoConfigDatabase
from sso.sso_view import SsoViewSet

from calamari_rest.views.login_view import LoginPermit
from calamari_rest.views.common import regexp

config = CalamariConfig()
onestor_common = ONEStorCommon()

log = logging.getLogger('django.request')

ENCRYPT_CONCATE_STR = 'J0Inin1n'  # 加解密拼接字符串
CEPH_PATH = '/opt/h3c/bin/ceph'

@api_view(['GET', 'POST'])
@permission_classes((AllowAny,))
def casserver(request):
    """
    获得sso登出url
    :param request:
    :return:
    """
    sso_config = SsoConfigDatabase.list_sso_config()
    if sso_config is not None:
        return Response({'casserver': sso_config['login_url']})
    else:
        raise Http404("casserver not found")


def _get_latest_graphite(metric):
    """
    Get the latest value of a named graphite metric
    """

    tzinfo = pytz.timezone("UTC")
    until_time = parseATTime('now', tzinfo)

    def _get(from_time):
        series = fetchData({
            'startTime': from_time,
            'endTime': until_time,
            'now': until_time,
            'localOnly': False},
            metric
        )
        try:
            return [k for k in series[0] if k is not None][-1]
        except IndexError:
            return None

    # In case the cluster has been offline for some time, try looking progressively
    # further back in time for data.  This would not be necessary if graphite simply
    # let us ask for the latest value (Calamari issue #6876)
    for trange in ['-1min', '-10min', '-60min', '-1d', '-7d']:
        val = _get(parseATTime(trange, tzinfo))
        if val is not None:
            return val

    log.warn("No graphite data for %s" % metric)


def get_latest_graphite(metric):
    """
    Wrapper to hide the case where graphite is unavailable
    """
    if graphite is not None:
        return _get_latest_graphite(metric)
    else:
        return None


class Space(RPCView):
    serializer_class = ClusterSpaceSerializer

    def get(self, request, fsid):
        def to_bytes(kb):
            if kb is not None:
                return kb * 1024
            else:
                return None

        df_path = lambda stat_name: "ceph.cluster.{0}.df.{1}".format(fsid, stat_name)
        space = {
            'used_bytes': to_bytes(get_latest_graphite(df_path('total_used'))),
            'capacity_bytes': to_bytes(get_latest_graphite(df_path('total_space'))),
            'free_bytes': to_bytes(get_latest_graphite(df_path('total_avail')))
        }

        return Response(ClusterSpaceSerializer(DataObject({
            'space': space
        })).data)


class Health(RPCView):
    serializer_class = ClusterHealthSerializer

    def get(self, request, fsid):
        health = self.client.get_sync_object(fsid, 'health')
        return Response(ClusterHealthSerializer(DataObject({
            'report': health,
            'cluster_update_time': self.client.get_cluster(fsid)['update_time'],
            'cluster_update_time_unix': self.client.get_cluster(fsid)['update_time'],
        })).data)


class HealthCounters(RPCView):
    serializer_class = ClusterHealthCountersSerializer

    PG_FIELDS = ['pgid', 'acting', 'up', 'state']

    CRIT_STATES = set(['stale', 'down', 'peering', 'inconsistent', 'incomplete', 'inactive'])
    WARN_STATES = set(['creating', 'recovery_wait', 'recovering', 'replay',
                       'splitting', 'degraded', 'remapped', 'scrubbing', 'repair',
                       'wait_backfill', 'backfilling', 'backfill_toofull'])
    OKAY_STATES = set(['active', 'clean'])

    @classmethod
    def generate(cls, osd_map, mds_map, mon_status, pg_summary):
        return {
            'osd': cls._calculate_osd_counters(osd_map),
            'mds': cls._calculate_mds_counters(mds_map),
            'mon': cls._calculate_mon_counters(mon_status),
            'pg': cls._calculate_pg_counters(pg_summary),
        }

    @classmethod
    def _calculate_mon_counters(cls, mon_status):
        mons = mon_status['monmap']['mons']
        quorum = mon_status['quorum']
        ok, warn, crit = 0, 0, 0
        for mon in mons:
            rank = mon['rank']
            if rank in quorum:
                ok += 1
            # TODO: use 'have we had a salt heartbeat recently' here instead
            # elif self.try_mon_connect(mon):
            #    warn += 1
            else:
                crit += 1
        return {
            'ok': {
                'count': ok,
                'states': {} if ok == 0 else {'in': ok},
            },
            'warn': {
                'count': warn,
                'states': {} if warn == 0 else {'up': warn},
            },
            'critical': {
                'count': crit,
                'states': {} if crit == 0 else {'out': crit},
            }
        }

    @classmethod
    def _pg_counter_helper(cls, states, classifier, count, stats):
        matched_states = classifier.intersection(states)
        if len(matched_states) > 0:
            stats[0] += count
            for state in matched_states:
                stats[1][state] += count
            return True
        return False

    @classmethod
    def _calculate_pg_counters(cls, pg_summary):
        # Although the mon already has a copy of this (in 'status' output),
        # it's such a simple thing to recalculate here and simplifies our
        # sync protocol.

        all_states = cls.CRIT_STATES | cls.WARN_STATES | cls.OKAY_STATES

        pgs_by_state = pg_summary['all']
        ok, warn, crit = [[0, defaultdict(int)] for _ in range(3)]
        for state_name, count in pgs_by_state.items():
            states = map(lambda s: s.lower(), state_name.split("+"))
            if cls._pg_counter_helper(states, cls.CRIT_STATES, count, crit):
                pass
            elif cls._pg_counter_helper(states, cls.WARN_STATES, count, warn):
                pass
            elif cls._pg_counter_helper(states, cls.OKAY_STATES, count, ok):
                pass
            else:
                # Uncategorised state, assume it's critical.  This shouldn't usually
                # happen, but want to avoid breaking if ceph adds a state.
                crit[0] += count
                for state in states:
                    if state not in all_states or state in cls.CRIT_STATES:
                        crit[1][state] += count

        return {
            'ok': {
                'count': ok[0],
                'states': dict(ok[1]),
            },
            'warn': {
                'count': warn[0],
                'states': dict(warn[1]),
            },
            'critical': {
                'count': crit[0],
                'states': dict(crit[1]),
            },
        }

    @classmethod
    def _calculate_osd_counters(cls, osd_map):
        osds = osd_map['osds']
        counters = {
            'total': len(osds),
            'not_up_not_in': 0,
            'not_up_in': 0,
            'up_not_in': 0,
            'up_in': 0
        }
        for osd in osds:
            up, inn = osd['up'], osd['in']
            if not up and not inn:
                counters['not_up_not_in'] += 1
            elif not up and inn:
                counters['not_up_in'] += 1
            elif up and not inn:
                counters['up_not_in'] += 1
            elif up and inn:
                counters['up_in'] += 1
        warn_count = counters['up_not_in'] + counters['not_up_in']
        warn_states = {}
        if counters['up_not_in'] > 0:
            warn_states['up/out'] = counters['up_not_in']
        if counters['not_up_in'] > 0:
            warn_states['down/in'] = counters['not_up_in']
        return {
            'ok': {
                'count': counters['up_in'],
                'states': {} if counters['up_in'] == 0 else {'up/in': counters['up_in']},
            },
            'warn': {
                'count': warn_count,
                'states': {} if warn_count == 0 else warn_states,
            },
            'critical': {
                'count': counters['not_up_not_in'],
                'states': {} if counters['not_up_not_in'] == 0 else {'down/out': counters['not_up_not_in']},
            },
        }

    @classmethod
    def _calculate_mds_counters(cls, mds_map):
        up = len(mds_map['up'])
        inn = len(mds_map['in'])
        total = len(mds_map['info'])
        return {
            'total': total,
            'up_in': inn,
            'up_not_in': up - inn,
            'not_up_not_in': total - up,
        }

    def get(self, request, fsid):
        osd_data = self.client.get_sync_object(fsid, OsdMap.str, async=True)
        mds_data = self.client.get_sync_object(fsid, MdsMap.str, async=True)
        pg_summary = self.client.get_sync_object(fsid, PgSummary.str, async=True)
        mon_status = self.client.get_sync_object(fsid, MonStatus.str, async=True)
        mds_data = mds_data.get()
        osd_data = osd_data.get()
        pg_summary = pg_summary.get()
        mon_status = mon_status.get()

        counters = self.generate(osd_data, mds_data, mon_status, pg_summary)

        return Response(ClusterHealthCountersSerializer(DataObject({
            'counters': counters,
            'cluster_update_time': self.client.get_cluster(fsid)['update_time']
        })).data)


class OSDList(RPCView):
    """
    Provides an object which includes a list of all OSDs, and
    some summary counters (pg_state_counts)
    """
    serializer_class = OSDListSerializer

    OSD_FIELDS = ['uuid', 'up', 'in', 'up_from', 'public_addr',
                  'cluster_addr', 'heartbeat_back_addr', 'heartbeat_front_addr']

    def _filter_by_pg_state(self, osds, pg_states, osds_by_pg_state):
        """Filter the cluster OSDs by PG states.
`
        Note that we can't do any nice DB querying here because we aren't
        normalizing out our data to fit the relational model. Thus, this is a
        bit hacky.

        We are modifying the OSD field of this instance of a cluster based on
        the filtering, and passing the result to the serializer. Do not do
        anything like a .save() on this instance; it's just a vehicle for the
        filtered OSDs.
        """
        pg_states = set(map(lambda s: s.lower(), pg_states.split(",")))
        target_osds = set([])
        for state, state_osds in osds_by_pg_state.iteritems():
            if state in pg_states:
                target_osds |= set(state_osds)
        return [o for o in osds if o['id'] in target_osds]

    def generate(self, pg_summary, osd_map, service_to_server, servers):
        fqdn_to_server = dict([(s['fqdn'], s) for s in servers])

        # map osd id to pg states
        pg_states_by_osd = defaultdict(lambda: defaultdict(lambda: 0))
        # map osd id to set of pools
        pools_by_osd = defaultdict(lambda: set([]))
        # map pg state to osd ids
        osds_by_pg_state = defaultdict(lambda: set([]))

        # get the list of pools
        pools_by_id = dict((p_id, p['pool_name']) for (p_id, p) in osd_map.pools_by_id.items())

        for pool_id, osds in osd_map.osds_by_pool.items():
            for osd_id in osds:
                pools_by_osd[osd_id].add(pools_by_id[pool_id])

        for osd_id, osd_pg_summary in pg_summary['by_osd'].items():
            for state_tuple, count in osd_pg_summary.items():
                for state in state_tuple.split("+"):
                    osds_by_pg_state[state].add(osd_id)
                    pg_states_by_osd[osd_id][state] += count

        # convert set() to list to make JSON happy
        osds_by_pg_state = dict((k, list(v)) for k, v in
                                osds_by_pg_state.iteritems())

        # Merge the PgSummary data into the OsdMap data
        def fixup_osd(osd):
            osd_id = osd['osd']
            data = dict((k, osd[k]) for k in self.OSD_FIELDS)
            data.update({'id': osd_id})
            data.update({'osd': osd_id})
            data.update({'pg_states': dict(pg_states_by_osd[osd_id])})
            data.update({'pools': list(pools_by_osd[osd_id])})

            return data

        osds = map(fixup_osd, osd_map.osds_by_id.values())

        # Apply the ServerMonitor data
        for o, (service_id, fqdn) in zip(osds, service_to_server):
            o['fqdn'] = fqdn
            if fqdn is not None:
                o['host'] = fqdn_to_server[fqdn]['hostname']
            else:
                o['host'] = None

        return osds, osds_by_pg_state

    def get(self, request, fsid):
        servers = self.client.server_list_cluster(fsid, async=True)
        osd_data = self.client.get_sync_object(fsid, OsdMap.str, async=True)
        osds = self.client.list(fsid, OSD, {}, async=True)
        pg_summary = self.client.get_sync_object(fsid, PgSummary.str, async=True)
        osds = osds.get()
        servers = servers.get()
        osd_data = osd_data.get()
        pg_summary = pg_summary.get()

        osd_map = OsdMap(None, osd_data)

        server_info = self.client.server_by_service([ServiceId(fsid, OSD, str(osd['osd'])) for osd in osds], async=True)
        server_info = server_info.get()

        osds, osds_by_pg_state = self.generate(pg_summary, osd_map, server_info, servers)

        if not osds or not osds_by_pg_state:
            return Response([], status.HTTP_202_ACCEPTED)

        pg_states = request.QUERY_PARAMS.get('pg_states', None)
        if pg_states:
            osds = self._filter_by_pg_state(osds, pg_states, osds_by_pg_state)

        osd_list = DataObject({
            # 'osds': [DataObject({'osd': o}) for o in osds],
            'osds': osds,
            'osds_by_pg_state': osds_by_pg_state
        })

        return Response(OSDListSerializer(osd_list).data)


class OSDDetail(RPCView):
    """
    This is the same data that is provided in the OSD list, but for
    a single OSD, and not including the pg_state_counts.
    """
    serializer_class = OSDDetailSerializer

    def get(self, request, fsid, osd_id):
        data = self.client.get(fsid, 'osd', int(osd_id))
        osd = DataObject({'osd': data})
        return Response(OSDDetailSerializer(osd).data)


class UserViewSet(viewsets.ModelViewSet):
    """
    The Calamari UI/API user account information.

    You may pass 'me' as the user ID to refer to the currently logged in user,
    otherwise the user ID is a numeric ID.

    Because all users are superusers, everybody can see each others accounts
    using this resource.  However, users can only modify their own account (i.e.
    the user being modified must be the user associated with the current login session).
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer

    def _get_user(self, request, user_id):
        if user_id == "me":
            if request.user.is_authenticated():
                return request.user
            else:
                raise AuthenticationFailed()
        else:
            try:
                user = self.queryset.get(pk=user_id)
            except User.DoesNotExist:
                raise Http404("User not found")
            else:
                return user

    def update(self, request, *args, **kwargs):
        # Note that unlike the parent update() we do not support
        # creating users with PUT.
        partial = kwargs.pop('partial', False)
        user = self.get_object()

        if user.id != self.request.user.id:
            raise PermissionDenied("May not change another user's password")

        serializer = self.get_serializer(user, data=request.DATA, partial=partial)

        if serializer.is_valid():
            try:
                self.pre_save(serializer.object)
            except ValidationError as err:
                # full_clean on model instance may be called in pre_save, so we
                # have to handle eventual errors.
                return Response(err.message_dict, status=status.HTTP_400_BAD_REQUEST)
            user = serializer.save(force_update=True)
            log.debug("saved user %s" % user)
            # self.post_save(user, created=False)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def get_object(self, queryset=None):
        user = self._get_user(self.request, self.kwargs['pk'])
        if self.kwargs['pk'] == 'me':
            self.kwargs['pk'] = user.id
        return user


def _get_user_permissions(username, permissionname):
    """
    判断用户权限是否存在
    """
    _user = User.objects.get(username=username)
    _usergroup = _user.groups.all()[0]
    permissionlist = _usergroup.permissions.all()
    permissions_alive = False
    for permis in permissionlist:
        if permis.name == permissionname:
            permissions_alive = True
    return permissions_alive


def __check_permission():
    """检查Handy登录权限"""
    __permit_login__ = True
    fsid = onestor_common.exec_local_cmd('timeout 3 ceph fsid 2>/dev/null')
    if '' != fsid:
        # 从数据库中获取当前所有的Handy节点
        handys = onestor_common.exec_local_cmd_json('ceph config-key get handy_key')
        if handys is None:
            return __permit_login__
        handys_name = [handy.keys()[0] for handy in handys['ssh_pub_key']]
        handys_key = [handy.values()[0] for handy in handys['ssh_pub_key']]
        # 获取本地的主机名
        local_name = onestor_common.exec_local_cmd('hostname')
        # 获取本地的秘钥
        local_pub_key = onestor_common.exec_local_cmd('cat /root/.ssh/id_rsa.pub')
        if local_name not in handys_name or local_pub_key not in handys_key:
            log.error('[ERROR] no permission to login')
            __permit_login__ = False
    return __permit_login__


def check_lice(request):
    """
    license 检测
    """
    result = {
        'success': False,
        'data': {},
        'status': status.HTTP_405_METHOD_NOT_ALLOWED
    }
    # 检查当前Handy是否有权限管理集群
    if not __check_permission():
        result['data'] = {
            'message': u'当前节点无管理集群的权限',
            'message_en': 'The current node does not have permission to manage the cluster.',
            'errorcode': 'ERROR_INVALID_HANDY'
        }
        result['status'] = status.HTTP_401_UNAUTHORIZED
        return result
 
    # 检查当前Handy是否被其它集群管理
    try:
        _conf = configobj.ConfigObj('/etc/ceph/ceph.conf')
        # 适配3.0监控数据获取，需要强制认证
        force = request.DATA.get('force',None)
        if 'handy' in _conf and 'multicluster_ip' in _conf['handy'] and not force:
            multicluster_ip = _conf['handy']['multicluster_ip']
            cmd = "ip addr | grep inet | grep '{}/' | wc -l".format(multicluster_ip)
            if '0' == onestor_common.exec_local_cmd(cmd):
                result['data'] = {
                    'message': u'当前集群已被“{}”管理'.format(multicluster_ip),
                    'message_en': 'The current cluster has been managed by "{}".'.format(multicluster_ip),
                    'errorcode': 'ERROR_INVALID_HANDY'
                }
                result['status'] = status.HTTP_401_UNAUTHORIZED
                return result
    except Exception, e:
        log.exception(e)

    try:
        license_result = lics_view.LicsViewSet().check_license()
    except ValueError:
        result['data'] = {
            'message': u'License错误',
            'message_en': 'Login attempt denied because of license error.',
            'errorcode': 'INTERNAL_SERVER_ERROR'
        }
        result['status'] = status.HTTP_500_INTERNAL_SERVER_ERROR
        return result
    except Exception:
        result['data'] = {
            'message': u'License错误',
            'message_en': 'Login attempt denied because of license error.',
            'errorcode': 'INTERNAL_SERVER_ERROR'
        }
        result['status'] = status.HTTP_500_INTERNAL_SERVER_ERROR
        return result
    if not license_result['success']:
        result['data'] = {
            'message': license_result['reason'][2],
            'message_en': license_result['reason'][1],
            'errorcode': 'LICENSE_VALIDATE_ERROR'
        }
        return result
    result['success'] = True
    return result


@api_view(['GET', 'POST'])
@permission_classes((AllowAny,))
@ensure_csrf_cookie
@never_cache
def caslogin(request):
    """
    单点登录
    """
    if request.method == 'POST':

        ticket = request.DATA.get('ticket', None)
        service = request.DATA.get('service', None)
        login_type = request.DATA.get('type', None)

        sso_config = SsoViewSet.get_config()
        # lice 相关检测
        lice_result = check_lice(request)
        if not lice_result['success']:
            lice_result['data']['sso_config'] = sso_config
            return Response(lice_result['data'], status=lice_result['status'])

        if not ticket:
            return Response('ticket is require', status=status.HTTP_400_BAD_REQUEST)
        if not service:
            return Response('service is require', status=status.HTTP_400_BAD_REQUEST)

        try:
            user = authenticate(ticket=ticket, service=service)
        except casauth.CasAuthenticationError as e:
            log.info(str(e))
            return Response({
                'message': u'单点登录认证失败',
                'message_en': 'SSO authentication failed.',
                'errorcode': 'SSO_AUTH_ERROR',
                'sso_config': sso_config
            }, status=status.HTTP_403_FORBIDDEN)
        except casauth.NoCasServer as e:
            return Response(str(e), status=status.HTTP_405_METHOD_NOT_ALLOWED)
        except casauth.CurlNeTError:
            return Response({
                'message': u'管理节点无法访问单点登录服务，存在网络故障',
                'message_en': 'Network error occurred. The management node cannot access SSO service.',
                'errorcode': 'ERROR_SSO_NETWORK',
                'sso_config': sso_config
            }, status=status.HTTP_405_METHOD_NOT_ALLOWED)
        except casauth.CurlError:
            return Response({
                'message': u'单点登录服务的校验URL不可用',
                'message_en': 'The SSO authentication URL is not reachable.',
                'errorcode': 'ERROR_SSO_NETWORK',
                'sso_config': sso_config
            }, status=status.HTTP_405_METHOD_NOT_ALLOWED)
        except User.DoesNotExist:
            return Response({
                'message': u'用户不存在',
                'message_en': 'The user does not exist.',
                'errorcode': 'ERR_USER_NOT_EXIST',
                'sso_config': sso_config
            }, status=status.HTTP_405_METHOD_NOT_ALLOWED)
        else:
            auth_login(request, user)

            # 操作日志
            username = user.username
            ip = request.META.get("REMOTE_ADDR", None)
            try:
                if not os.path.exists("/.dockerenv"):
                    cmdprocess.command([CEPH_PATH, 'fsid'], 20)
            except cmdprocess.TimeoutExpired:
                log.error('[ONEStor] login Error')
            else:
                # 记录登录的操作日志
                if 'netdisk' != login_type:
                    send_add_oplog_msg(request, ('用户单点登录', 'User single sign in'))

            user_type = 'normal'
            if user.is_superuser:
                user_type = 'admin'

            try:
                session_id = service.split('sessionid=')[1]
                session_key = request.session._session_key
            except ValueError as e:
                log.exception(e)
            except Exception as e:
                log.exception(e)
            else:
                _session = Session(session_id=session_id, session_key=session_key)
                _session.save()

            result = {
                'user_type': user_type,
                'sso_config': sso_config,
                'user_name': username
            }

            return Response(result)
    else:
        pass

    request.session.set_test_cookie()
    return Response({})


@api_view(['GET', 'POST', 'PUT'])
@permission_classes((AllowAny,))
@ensure_csrf_cookie
@never_cache
def login(request):
    """
This resource is used to authenticate with the REST API by POSTing a message
as follows:

::

    {
        "username": "<username>",
        "password": "<password>"
    }

If authentication is successful, 200 is returned, if it is unsuccessful
then 401 is returend.
    """
    if request.method == 'POST':
        # 登录之前，先判断是否符合登录规则
        login_object = LoginPermit(request)
        check_result = login_object.check_before_login()
        if not check_result["login_permit"]:
            return Response(check_result['error_status'], status=status.HTTP_403_FORBIDDEN)
        # add by l11544 2018/9/18
        username = request.DATA.get('username', None)
        passwd = request.DATA.get('password', None)
        try:
            password = base64.b64decode(passwd)
        except Exception:
            password = passwd
        login_type = request.DATA.get('type', None)
        ip = request.META.get("REMOTE_ADDR", None)
        msg = {}
        if not username:
            msg['username'] = 'This field is required'
        if not password:
            msg['password'] = 'This field is required'
        if len(msg) > 0:
            return Response(msg, status=status.HTTP_400_BAD_REQUEST)

        if SsoConfigDatabase.list_sso_config() is not None and \
                username != 'admin' and username != 'YWRtaW4=':
            return Response({
                'message': u'请使用单点登录服务',
                'message_en': 'Please use SSO service to login.',
                'errorcode': 'SSO_NOT_ADMIN_ERROR'
            }, status=status.HTTP_401_UNAUTHORIZED)

        user, username = user_authenticate(username, password)
        # lice 相关检测
        lice_result = check_lice(request)
        if not lice_result['success']:
            return Response(lice_result['data'], status=lice_result['status'])

        if not user:
            user = authenticate(username=username, password=passwd)
            if not user:
                # 登录失败后，处理提示用户规则
                fail_result = login_object.login_failed_record()
                # add by l11544 2018/9/18
                return Response(fail_result, status=status.HTTP_401_UNAUTHORIZED)
        password_check_result = check_password(user)
        if not password_check_result['success']:
            return Response({
                'message': password_check_result['reason'][0],
                'message_en': password_check_result['reason'][1],
                'errorcode': password_check_result['errorcode'],
            }, status=status.HTTP_401_UNAUTHORIZED)
        auth_login(request, user)
        if request.session.test_cookie_worked():
            request.session.delete_test_cookie()

        user_type = 'normal'
        if user.is_superuser:
            user_type = 'admin'

        # 记录登录的操作日志
        if 'netdisk' != login_type:
            send_add_oplog_msg(request, ('用户登录', 'User login'))
        # 登录成功后，重置登录次数
        login_object.login_succeed_reset()
        # add by l11544 2018/9/18
        try:
            redirect_token = sso.rsa_encrypt(username, password)
        except Exception, e:
            log.exception(e)
            redirect_token = ''
        # end add by w15818 2017/11/18 PN:201711080279

        return Response({'user_type': user_type, 'redirect_token': redirect_token, 'password_expired_warn': password_check_result['expired_warn']})

    elif request.method == 'GET':

        token = request.GET.get('token', None)
        to_url = request.GET.get('to_url', '/manage/#/dashboard')
        if token is not None:
            try:
                log.info('sso login, token is: %s ,to url is %s', token, to_url)
                username, password = sso.rsa_decrypt(token)
                user = authenticate(username=username, password=password)
                if not user:
                    return Response({
                        'message': u'用户名或密码错误',
                        'message_en': 'Incorrect username or password.',
                        'errorcode': 'USERNAME_OR_PASSWORD_ERROR'
                    }, status=status.HTTP_401_UNAUTHORIZED)
                auth_login(request, user)
                return redirect(to_url)
            except Exception, e:
                log.exception(e)
                return redirect('/manage/404.html')

    elif request.method == 'PUT':
        # Currently only available for multi-cluster management.
        username = request.DATA.get('username', None)
        password = request.DATA.get('password', None)
        user = authenticate(username=username, password=password)
        if user:
            return Response({"authenticate": True})
        return Response({"authenticate": False})

    else:
        pass
    request.session.set_test_cookie()
    return Response({})


def check_password(user):
    check_calamari_config()
    result = {}
    calamari_config = CalamariConfig()
    expire_time = int(calamari_config.get('password_param', 'expire_time'))
    lose_efficacy_time = int(calamari_config.get('password_param', 'lose_efficacy_time'))
    start_datetime = user.date_joined
    expire_warn_datetime = start_datetime + datetime.timedelta(days=(expire_time - lose_efficacy_time))
    expire_datetime = start_datetime + datetime.timedelta(days=expire_time)
    now_datetime = datetime.datetime.now()
    if now_datetime < expire_warn_datetime or expire_time == 0:
        result['success'] = True
        result['reason'] = ['正常', 'ok']
        result['expired_warn'] = False
    elif expire_warn_datetime <= now_datetime < expire_datetime:
        result['success'] = True
        result['reason'] = ['密码即将过期', 'The password will be expired']
        result['expired_warn'] = True
    else:
        result['success'] = False
        result['reason'] = ['密码已过期', 'The password is expired']
        result['errorcode'] = "PASSWORD_EXPIRED_ERROR"
    return result


def check_calamari_config():
    from configobj import ConfigObj
    calamari_path = "/etc/calamari/calamari.conf"
    config = ConfigObj(calamari_path, encoding='UTF8')
    if config.get('password_param', None):
        return
    else:
        if os.path.exists("/.dockerenv"):
            onestor_common.exec_local_cmd('chmod 777 %s' % calamari_path)
        else:
            onestor_common.exec_local_ssh_cmd('chmod 777 %s' % calamari_path)
        config['password_param'] = {}
        config['password_param']['expire_time'] = '0'
        config['password_param']['lose_efficacy_time'] = '0'
        config['password_param']['duplicate_limit'] = '3'
        config['password_param']['password_str'] = ''
        config.write()
        if os.path.exists("/.dockerenv"):
            onestor_common.exec_local_cmd('chmod 644 %s' % calamari_path)
        else:
            onestor_common.exec_local_ssh_cmd('chmod 644 %s' % calamari_path)
        return


def user_authenticate(username, password):
    user = authenticate(username=username, password=password)
    if not user:
        try:
            name = base64.b64decode(username)
            if check_regexp_user(name):
                user = authenticate(username=name, password=password)
                username = name
        except Exception:
            user = None
    return user, username


def check_regexp_user(username):
    regexp_username = regexp.handy_username_regexp
    return re.match(regexp_username, username)


@api_view(['GET', 'POST'])
@permission_classes((AllowAny,))
def logout(request):
    """
The resource is used to terminate an authenticated session by POSTing an
empty request.
    """
    # 记录登出的操作日志
    username = request.GET.get('username', None)
    timeout = request.GET.get('isTimeout', None)

    if username is not None:
        msg = ('用户超时退出', 'User session timeout') \
            if timeout is not None and timeout == 'true' else ('用户注销', 'User logout')
        send_add_oplog_msg(request, msg)

    auth_logout(request)
    return Response({'message': 'Logged out'})


@api_view(['GET', 'POST'])
@permission_classes((AllowAny,))
def caslogout(request):

    service = request.GET['service']
    try:
        logout_url = casauth.logout_url(service)
    except casauth.NoCasLogoutServerExist:
        log.warning('caslogout error logout by Handy')
        return logout(request)
    else:
        username = request.user.username
        ip = request.META.get("REMOTE_ADDR", None)
        try:
            if not os.path.exists("/.dockerenv"):
                cmdprocess.command([CEPH_PATH, 'fsid'], 20)
        except cmdprocess.TimeoutExpired:
            log.error('[ONEStor] logout TimeoutExpired')
        else:
            if username is not None:
                send_add_oplog_msg(request, ('用户单点注销', 'User single sign out'))
        auth_logout(request)
        return Response({
            'message': 'Logged out',
            'logout_url': logout_url
        })


class Info(APIView):
    """
Provides metadata about the installation of Calamari server in use
    """
    permission_classes = (AllowAny,)
    serializer_class = InfoSerializer

    def get(self, request):
        grains = get_local_grains()

        try:
            ipaddr = socket.gethostbyname(grains['fqdn'])
        except socket.gaierror:
            # It is annoying, but not rare, to have a host
            # that cannot resolve its own name.
            # From a dict of interface name to list of addresses,
            # we pick the first address from the first interface
            # which has some addresses and isn't a loopback.
            ipaddr = [addrs for name, addrs in grains['ip_interfaces'].items() if
                      name not in ['lo', 'lo0'] and addrs][0][0]

        proto = "https" if request.is_secure() else "http"
        bootstrap_url = "{0}://{1}{2}".format(proto, request.META['HTTP_HOST'], reverse('bootstrap'))
        bootstrap_ubuntu = "wget -O - {url} | sudo python"
        bootstrap_rhel = "curl {url} | sudo python"

        return Response(self.serializer_class(DataObject({
            "version": str(VERSION),
            "license": "N/A",
            "registered": "N/A",
            "hostname": grains['host'],
            "fqdn": grains['fqdn'],
            "ipaddr": ipaddr,
            "bootstrap_url": bootstrap_url,
            "bootstrap_ubuntu": bootstrap_ubuntu.format(url=bootstrap_url),
            "bootstrap_rhel": bootstrap_rhel.format(url=bootstrap_url),
        })).data)


# add by d10039 start
class ShareView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        radosgw = request.GET.get('radosgw')
        user = request.GET.get('user')
        path = request.GET.get('path')
        passwd = request.GET.get('passwd')
        res = getTempUrl(radosgw, user, path, passwd)
        return Response({'result': res})


class InstallView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        filepath = os.path.split(os.path.realpath(__file__))[0]
        hostip = request.GET.get('hostip')
        user = request.GET.get('user')
        passwd = request.GET.get('passwd')
        command = request.GET.get('command')
        _result = os.popen("python %s/handy_common.py exec_remote_cmd %s %s %s \"%s\"" % (
            filepath, hostip, user, passwd, command)).read().rstrip()
        return Response({'result': _result})


class ClusterViewSet(RPCViewSet):
    serializer_class = ClusterSerializer

    def list(self, request):
        clusters = [DataObject(c) for c in self.client.list_clusters()]

        return Response(ClusterSerializer(clusters, many=True).data)

    def retrieve(self, request, pk):
        cluster_data = self.client.get_cluster(pk)
        if not cluster_data:
            return Response(status=status.HTTP_404_NOT_FOUND)
        else:
            cluster = DataObject(cluster_data)
            return Response(ClusterSerializer(cluster).data)


class ServerViewSet(RPCViewSet):
    serializer_class = ServerSerializer

    def retrieve(self, request, pk):
        return Response(
            self.serializer_class(DataObject(self.client.server_get(pk))).data
        )

    def list(self, request, fsid):
        return Response(
            self.serializer_class([DataObject(s) for s in self.client.server_list_cluster(fsid)], many=True).data)


class PoolViewSet(RPCViewSet):
    serializer_class = PoolSerializer

    def pool_object(self, pool_data, cluster):
        return DataObject({
            'id': pool_data['pool'],
            'cluster': cluster['id'],
            'pool_id': pool_data['pool'],
            'name': pool_data['pool_name'],
            'quota_max_objects': pool_data['quota_max_objects'],
            'quota_max_bytes': pool_data['quota_max_bytes'],
            'used_objects': get_latest_graphite(
                "ceph.cluster.%s.pool.%s.num_objects" % (cluster['id'], pool_data['pool'])),
            'used_bytes': get_latest_graphite("ceph.cluster.%s.pool.%s.num_bytes" % (cluster['id'], pool_data['pool']))
        })

    def list(self, request, fsid):
        cluster = self.client.get_cluster(fsid)
        pools = [self.pool_object(p, cluster) for p in self.client.list(fsid, POOL, {})]

        return Response(PoolSerializer(pools, many=True).data)

    def retrieve(self, request, fsid, pool_id):
        cluster = self.client.get_cluster(fsid)
        pool = self.pool_object(self.client.get(fsid, POOL, int(pool_id)), cluster)
        return Response(PoolSerializer(pool).data)


class DashboardView(RPCViewSet, HealthCounters):
    CEPH_CONF_FILE = '/etc/ceph/ceph.conf'

    def _onestor_request_result(self, _request):
        count = 0
        max_times = 600
        result = {'status': 'error', 'error_message': 'timeout'}
        while count < max_times:
            time.sleep(0.05)
            count += 1
            results = self.client.get_request(_request['request_id'])
            if results['result'] is not None:
                if not results['error']:
                    result = {'status': 'success', 'data': results['result']}
                else:
                    result = {'status': 'error', 'error_message': results['error_message']}
                break
        return result

    def onestor_request_node(self, fqdn, command, params):
        _request = self.client.run_onestor_request(fqdn, command, params)

        results = self._onestor_request_result(_request)

        if 'success' == results['status']:
            log.debug("[ONEStor] [Request Node] Request from %s, %s, %s, %s" % (fqdn, command, params, results['data']))
            return {fqdn: results['data']}
        else:
            log.error("[ONEStor] [Request Node] Failed to request from %s, %s, %s, %s" % (
                fqdn, command, params, results['error_message']))

        return None

    def get_all_job_result(self, jid, minions):
        count = 0
        max_count = 10
        result = 'timeout'
        while count < max_count:
            time.sleep(0.1)
            count += 1

            result = self.client.get_job_status(jid, minions)
            if result is None or len(result) != len(minions):
                pass
            else:
                break
        return result

    def topo_info(self):
        # 先测试连通性，再获取连接成功的主机的信息
        test_ping_job = self.client.run_onestor_job('*', 'test.ping', [])
        server_info_job = self.client.run_onestor_job('*', 'server.all', [])

        test_ping_results = self.get_all_job_result(test_ping_job['jid'], test_ping_job['minions'])
        live_minions = []
        for minion in test_ping_job['minions']:
            if test_ping_results and test_ping_results.has_key(minion):
                live_minions.append(minion)

        server_info_results = self.get_all_job_result(server_info_job['jid'], live_minions)
        if server_info_results:
            returned = {}
            returned['servers'] = {}

            for server in server_info_results:
                single_server_info = {}
                single_server_info['mem'] = server_info_results[server]['ret']['mem']
                single_server_info['cpu'] = server_info_results[server]['ret']['cpu']
                single_server_info['disk'] = server_info_results[server]['ret']['disk']
                single_server_info['lsblk'] = server_info_results[server]['ret']['lsblk']
                single_server_info['ip'] = server_info_results[server]['ret']['ip']
                single_server_info['sys_version'] = server_info_results[server]['ret']['sys_version']
                single_server_info['sys_uptime'] = server_info_results[server]['ret']['sys_uptime']
                returned['servers'][server] = single_server_info

            return {'success': True, 'rt': returned}
        else:
            return {'success': False, 'error': u'机架信息获取失败'}

    def exec_local_cmd(self, command):
        filepath = '/opt/h3c/cmd/'
        _result = os.popen('%s./run %s' % (filepath, command)).read().rstrip()
        return _result

    def dashboard(self, request, fsid):
        servers = self.client.server_list_cluster(fsid)

        servers = [s for s in servers if s['last_contact']]
        servers = sorted(servers,
                         key=lambda t: dateutil_parse(t['last_contact']),
                         reverse=True)

        returned = {}

        # Get space info
        returned['space'] = onestor.space('/etc/ceph/ceph.conf')

        # Get rack info
        rack_info = self.exec_local_cmd('ceph osd tree -f json')
        returned['rack_info'] = json.loads(rack_info)

        # returned['rack_info'] = self.topo_info()

        # Get servers
        returned['servers'] = ServerSerializer([DataObject(s) for s in servers], many=True).data

        # Get health counters
        osd_data = self.client.get_sync_object(fsid, OsdMap.str, async=True)
        mds_data = self.client.get_sync_object(fsid, MdsMap.str, async=True)
        pg_summary = self.client.get_sync_object(fsid, PgSummary.str, async=True)
        mon_status = self.client.get_sync_object(fsid, MonStatus.str, async=True)
        mds_data = mds_data.get()
        osd_data = osd_data.get()
        pg_summary = pg_summary.get()
        mon_status = mon_status.get()

        counters = self.generate(osd_data, mds_data, mon_status, pg_summary)

        returned['health_counters'] = ClusterHealthCountersSerializer(DataObject({
            'counters': counters,
            'cluster_update_time': self.client.get_cluster(fsid)['update_time']
        })).data

        return Response(returned)


class AuthModule(RPCViewSet):
    """
    获取当前版本支持的模块信息
    """

    @staticmethod
    def get(request):
        """
        获取模块信息
        :return {
            'bs': True,
            'os': True,
            'ec': False,
            'dr': False,
            'cs': False
        }
        """
        return Response(lics_view.LicsViewSet().get_license_features())
