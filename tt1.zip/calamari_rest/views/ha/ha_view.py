# -*- coding:utf-8 -*-
import os
import logging
import threading
import configobj
import time
import re

from rest_framework.decorators import api_view
from rest_framework.decorators import permission_classes
from rest_framework.permissions import AllowAny

from calamari_rest.views.ha.handy_config import HandyConfigTool
from calamari_rest.views.onestor import database
from calamari_rest.views.usermanage import HAResponse
from calamari_rest.views.ha import HARollbackEntity
from calamari_rest.views.common import util, const, errno, op_log, cmd, success_log
from calamari_rest.views.common.util import set_onestor_progress
# BEGIN MODIFY BY D10039 2017/04/03 FOR POSTGRES HA
from calamari_rest.views.ha.final_rollback import HAFinalRollback
# END MODIFY BY D10039 2017/04/03 FOR POSTGRES HA
from rest_framework.response import Response
from calamari_rest.views.common.util import HandyUtil
from calamari_rest.decorator import check_remove_osd_event
from onestor import message
from onestor.mr import mr_message
log = logging.getLogger('django.request')

"""
    Author: dai.xinchun@h3c.com
    Date: 2016/06/30
    Description: ONEStor高可用管理类
"""


class HaViewSet(HAFinalRollback):
    def __init__(self, *args, **kwargs):
        super(HaViewSet, self).__init__(*args, **kwargs)

    def _get_working_nodes(self, ha_cfgs):
        """
        获取所有工作节点
        """
        all_nodes, ha_ip_list, ha_ips = [], {}, ''

        if not ha_cfgs:
            return ha_ip_list

        for ha in ha_cfgs:
            all_nodes = all_nodes + [ha[const.CONST_HA_MASTER]] + ha[const.CONST_HA_SLAVE].split(',')
            ha_ips = ha_ips + ha[const.CONST_HA_VIP] + ','

        # 去掉重复的节点
        all_nodes = set(all_nodes)

        list_ha_command = cmd.CMD_LIST_HA.format(const.HANDY_SHELL_PATH, ha_ips.rstrip(','))

        # 远程登录到每个高可用节点上获取当前工作节点
        list_ha_results = self.multi_thread_task(all_nodes, list_ha_command, ssh=True)

        for node, result in list_ha_results.items():
            # BEGIN ADD BY D10039 2017/04/25 PN: 201703220079
            if '' == result or 'LOST_CONF' == result:
                ha_ip_list['LOST_CONF'] = node
                continue
            # END ADD BY D10039 2017/04/25 PN: 201703220079
            if const.RESULT_ERROR != result and const.RESULT_NONE != result:
                for ha_ip in result.split(','):
                    ha_ip_list[ha_ip] = node

        return ha_ip_list

    @util.send_response(const.OP_LIST)
    def list_ha_cfg(self, request, fsid):
        """
        获取业务高可用列表
        """
        # 从数据库中获取所有高可用配置
        ha_cfgs = database.list_objs(const.TABLE_HIGHAVAILABLE)
        # 获取所有工作节点
        ha_working_nodes = self._get_working_nodes(ha_cfgs[const.TABLE_HIGHAVAILABLE])
        # 将工作节点更新到结果中
        ha_cfgs['ha_ip_list'] = ha_working_nodes
        # 返回数据给页面
        yield {'success': True, 'data': ha_cfgs}

    def _process_ha_cfg(self, all_nodes, command, failed_nodes=None, failed_reasons=None):
        """
        多线程进行HA配置，修改和删除共用
        """
        results = self.multi_thread_task(all_nodes, command, ssh=True)
        log.info('process ha cfg results: %s', results)

        if not failed_nodes:
            failed_nodes = []

        if not failed_reasons:
            failed_reasons = {}

        for node, result in results.items():
            if const.NETWORK_FAULT == result:
                failed_reasons[node] = 'Host is unreachable'
                failed_nodes.append(node)
                continue
            if const.OP_SUCCSSFUL != result.strip() and -1 == \
                    result.find('the specify ip address do not exist'):
                failed_reasons[node] = result
                failed_nodes.append(node)

        return failed_nodes, failed_reasons

    def _process_remove_ha_cfg(self, vip, vrid, all_nodes, service):
        """
        删除HA配置
        """
        remove_command = cmd.CMD_CLOSE_HA.format(const.HANDY_SHELL_PATH, vip, vrid, service)
        return self._process_ha_cfg(all_nodes, remove_command)

    def _process_create_slave_ha(self, priority, slaves, vip, vrid, service, failed_nodes, failed_reasons,
                                 priority_list, used_priority=list(), useto=1):
        """
        创建与修改可以共用的创建备用节点方法
        """
        threads = []
        nloops = range(len(slaves))

        def create(_node, _priority):
            slave_ha_command = cmd.CMD_OPEN_HA.format(const.HANDY_SHELL_PATH, vip, _priority, vrid, useto, 2, service)
            slave_result = self.exec_remote_ssh_cmd(_node, slave_ha_command)

            if isinstance(slave_result, dict):
                failed_reasons[_node] = slave_result['reason']
                failed_nodes.append(_node)
            elif const.OP_SUCCSSFUL != slave_result:
                failed_reasons[_node] = slave_result
                failed_nodes.append(_node)

        for node in slaves:
            priority -= 1
            # 排除已经被使用的优先级
            while priority in used_priority:
                priority -= 1

            priority_list[node] = priority
            t = threading.Thread(target=create, args=(node, priority))
            threads.append(t)

        for i in nloops:
            threads[i].start()

        for i in nloops:
            threads[i].join()

        return priority_list, failed_nodes, failed_reasons

    def _process_create_ha_cfg(self, vip, master, slave, vrid, useto, switch_lvs, service):
        """
        开始下发HA的配置命令到主备节点
        """
        failed_reasons, failed_nodes, priority_list, priority = {}, [], {}, 240

        # 配置主用节点
        priority_list[master] = priority
        master_ha_command = cmd.CMD_OPEN_HA.format(const.HANDY_SHELL_PATH, vip, priority,
                                                   vrid, useto, switch_lvs, service)
        result = self.exec_remote_ssh_cmd(master, master_ha_command)

        if isinstance(result, dict):
            failed_reasons[master] = result['reason']
            failed_nodes.append(master)
        elif const.OP_SUCCSSFUL != result:
            failed_reasons[master] = result
            failed_nodes.append(master)

        # 配置备用节点
        priority_list, failed_nodes, failed_reasons = self._process_create_slave_ha(
            priority=priority,
            slaves=slave.split(','),
            vip=vip,
            vrid=vrid,
            service=service,
            failed_nodes=failed_nodes,
            failed_reasons=failed_reasons,
            priority_list=priority_list,
            useto=useto
        )

        return priority_list, failed_nodes, failed_reasons

    def _process_validate_ha_nodes(self, vip, master, slave, all_nodes, network=const.PUBLIC_NETWORK):
        """
        检查HA主备节点的网络状态、HA IP是否为业务网段等
        """
        # 主备节点的IP不能相同
        if master in slave.split(','):
            return HAResponse(is_success=False, error=errno.ERR_MASTER_AND_SLAVE_IP_REPEAT)

        # 从集群中获取网段信息
        cluster_config = self.get_config_from_conf_file()
        judge_network = cluster_config[network]

        # 高可用IP必须在对应的网段内
        if not self.subnet_judge(judge_network, vip):
            return HAResponse(
                is_success=False,
                error=errno.ERR_HA_IP_NOT_IN_PUBLIC_NETWORK
                if const.PUBLIC_NETWORK == network else errno.ERR_HA_IP_NOT_IN_MANAGE_NETWORK
            )

        # 主用节点IP必须在对应的网段内
        if not self.subnet_judge(judge_network, master):
            return HAResponse(
                is_success=False,
                error=errno.ERR_MASTER_IP_NOT_IN_PUBLIC_NETWORK
                if const.PUBLIC_NETWORK == network else errno.ERR_MASTER_IP_NOT_IN_MANAGE_NETWORK
            )

        # 检查输入IP是否为掩码内不可用IP
        mask = int(judge_network.split('/')[1])
        # 检查高可用IP
        if not self.check_ip_used_correct(vip, mask):
            return HAResponse(
                is_success=False,
                error=errno.ERR_HA_IP_IN_PUBLIC_MASK_NETWORK
                if const.PUBLIC_NETWORK == network else errno.ERR_HA_IP_IN_MANAGE_MASK_NETWORK
            )
        # 检查主用节点IP
        if not self.check_ip_used_correct(master, mask):
            return HAResponse(
                is_success=False,
                error=errno.ERR_MASTER_IP_IN_MASK_NETWORK
            )
        # end add by l11544 2017/12/24 PN: 201712220650

        # 备用节点IP必须在对应的网段内
        for _slave in slave.split(','):
            if not self.subnet_judge(judge_network, _slave):
                return HAResponse(
                    is_success=False,
                    error=errno.ERR_SLAVE_IP_NOT_IN_PUBLIC_NETWORK
                    if const.PUBLIC_NETWORK == network else errno.ERR_SLAVE_IP_NOT_IN_MANAGE_NETWORK
                )
            # 检查备用节点IP是否可用
            if not self.check_ip_used_correct(_slave, mask):
                return HAResponse(
                    is_success=False,
                    error=errno.ERR_SLAVE_IP_IN_MASK_NETWORK
                )

        # 检查主备节点是否有网络故障
        failed_nodes = self.test_ping(all_nodes)
        if 0 != len(failed_nodes):
            log.error('Network fault nodes: %s', ', '.join(failed_nodes))
            # 如果是创建Handy高可用，则提示无法连接到备用节点
            if const.MANAGE_NETWORK == network:
                # MODIFY ADD BY Z11524 2017/06/02 PN:201704150391
                return HAResponse(is_success=False, error=errno.format_error(errno.ERR_CONNECT_TO_HOST, ', '.join(failed_nodes)))
            return HAResponse(is_success=False, error=errno.ERR_NODE_HAS_NETWORK_FAULT)

        return const.OP_SUCCSSFUL

    def __ensure_ssh_config(self, slave):
        """

        :param slave:
        :return:
        """
        ensure_ssh_command = cmd.CMD_SSH_SLAVE_HA.format(
            const.HANDY_SHELL_PATH, const.SSH_PATH, const.HA_SSH_SLAVE)
        result = self.exec_remote_ssh_cmd(slave, ensure_ssh_command)
        if -1 == result.find(const.OP_SUCCSSFUL):
            log.error(result)
            raise errno.ONEStorError(errno.ERROR_ENSURE_SLAVE_SSH, slave)

    def _process_create_ha_common(
            self, vip, master, slave, service, useto=1, switch_lvs=2,
            network=const.PUBLIC_NETWORK, passwd='', session=None):
        """
        创建业务高可用与管理高可用共用的代码
        """
        all_nodes = [master] + slave.split(',')

        # 校验HA IP是否为业务网和主备节点的连通性等
        validate_result = self._process_validate_ha_nodes(vip, master, slave, all_nodes, network)
        if const.OP_SUCCSSFUL != validate_result:
            return validate_result

        # 检查IP地址是否已经被使用
        if 1 != len(self.test_ping(vip.split(','))):
            return HAResponse(is_success=False, error=errno.format_error(errno.ERR_IP_IS_USED, vip))

        # 获取可用的VRID
        get_vrid_ret = self.exec_local_ssh_cmd(cmd.CMD_GET_HA_VRID.format(const.HANDY_SHELL_PATH))
        if -1 == get_vrid_ret.find('success'):
            log.error('get vrid failed: %s', get_vrid_ret)
            return HAResponse(is_success=False, error=errno.ERR_GET_AVAIL_VRID)

        vrid = get_vrid_ret.split('::')[1]

        # 如果是创建Handy的高可用IP，需要额外安装软件、配置NTP等等
        if const.MANAGE_NETWORK == network:
            self._process_handy_config(vip, master, slave, passwd, session)
            set_onestor_progress(const.STEP_CONFIG_HA)

        # 下发HA的配置命令到主备节点
        priority_list, failed_nodes, failed_reasons = \
            self._process_create_ha_cfg(vip, master, slave, vrid, useto, switch_lvs, service)

        # 如果创建不成功，则回滚HA配置
        if 0 != len(failed_nodes):
            self._process_remove_ha_cfg(vip, vrid, all_nodes, service)
            log.error('create ha cfg error, failed_reasons: %s', failed_reasons)
            return HAResponse(is_success=False, error=errno.ERR_CREATE_HA_CFG)

        return vrid, priority_list

    @check_remove_osd_event(const.OP_CREATE_HA_CFG)
    @util.send_response()
    def create_ha_cfg(self, request, fsid):
        """
        创建业务高可用
        """
        vip = request.DATA.get('vip', None)
        master = request.DATA.get('master', None)
        slave = request.DATA.get('slave', None)
        tgt_switch = request.DATA.get('tgtSwitch', None)
        object_switch = '0'

        # 将操作日志的内容返回
        yield op_log.OP_CREATE_HA_CFG.format(vip)

        # TODO 校验入参是否合法
        yield request.DATA

        # 调用创建高可用的公共方法
        result = self._process_create_ha_common(vip, master, slave, const.SERVICE_TGT)
        if isinstance(result, HAResponse):
            yield result

        vrid, priority_list = result

        # 创建成功则记录到数据库中
        database.add_obj(const.TABLE_HIGHAVAILABLE, [
            vip, master, slave, vrid, priority_list, tgt_switch, object_switch])

        # 返回成功给页面
        yield HAResponse(is_success=True)

    def check_vip_connect(self, vip, nodes_ip, service):
        """
        检查VIP是否正在被使用
        """
        failed_nodes, connect_node = [], []

        query_status_cmd = cmd.CMD_GET_VIP_CONNECT_STATUS.format(vip=vip) if \
            const.SERVICE_TGT == service else cmd.CMD_GET_HANDY_VIP_CONNECT_STATUS.format(vip=vip)

        results = self.multi_thread_task(nodes_ip, query_status_cmd, ssh=True)

        log.info(results)
        for node, result in results.items():
            if const.NETWORK_FAULT == result or '' == result:
                failed_nodes.append(node)
                continue
            # BEGIN ADD BY KF6602 2016/11/22 PN:201611220025
            if not isinstance(result, str):
                result = const.NETWORK_FAULT
            # END ADD BY KF6602 2016/11/22 PN:201611220025
            test_result = result.rstrip().split('\n')
            if test_result[0] != '0' and test_result[1] != '0':
                connect_node.append(node)

        return {'failed_nodes': failed_nodes, 'connect_node': connect_node}

    # begin add by z11524 PN:201701070165 
    def check_nodes_ceph_conf(self, nodes_ip):
        """
        检查节点ceph.conf是否完整
        """
        ceph_conf = True
        results = self.multi_thread_task(nodes_ip, cmd.CMD_GET_CEPH_CONF_STATUS, ssh=True)
        for key, item in results.items():
            if 0 == int(item):
                ceph_conf = False
                break
        return ceph_conf
        # end add by z11524 PN:201701070165

    def _process_remove_ha_common(self, vip, master, slave, vrid, service, offline_node=list()):
        """
        删除业务高可用与管理高可用共用的代码
        """
        # 排除掉离线的主机
        all_nodes = list(set([master] + slave.split(',')) - set(offline_node))

        # 检测VIP是否能连通
        test_vip = self.check_vip_connect(vip, all_nodes, service)
        if 0 != len(test_vip['failed_nodes']):
            log.error('Network fault nodes: %s', test_vip['failed_nodes'])
            return HAResponse(is_success=False, error=errno.ERR_NODE_HAS_NETWORK_FAULT)

        # 检测高可用IP是否正在使用
        if 0 != len(test_vip['connect_node']):
            return HAResponse(is_success=False, error=errno.ERR_HA_IP_IS_USED)

        # 检测配置的节点是否可以Ping通
        failed_nodes = self.test_ping(all_nodes)
        if 0 != len(failed_nodes):
            log.error('Network fault nodes: %s', failed_nodes)
            return HAResponse(is_success=False, error=errno.ERR_NODE_HAS_NETWORK_FAULT)

        # 检测集群ceph配置是否完整 begin add by z11524 for handyha PN:201701070165 
        if not self.check_nodes_ceph_conf(all_nodes):
            return HAResponse(is_success=False, error=errno.ERR_CEPH_CONF_LOSE)
        # end add by z11524 for handyha PN:201701070165 

        # 开始删除高可用配置
        failed_nodes, failed_reasons = self._process_remove_ha_cfg(vip, vrid, all_nodes, service)

        if 0 != len(failed_nodes):
            log.error('remove ha cfg error, failed_reasons: %s', failed_reasons)
            return HAResponse(is_success=False, error=errno.ERR_REMOVE_HA_CFG)

        return const.OP_SUCCSSFUL

    @check_remove_osd_event(const.OP_REMOVE_HA_CFG)
    @util.send_response()
    def remove_ha_cfg(self, request, fsid):
        """
        删除业务高可用
        """
        database_id = request.GET.get('database_id', None)
        vip = request.GET.get('vip', None)
        vrid = request.GET.get('vrid', None)
        master = request.GET.get('master', None)
        slave = request.GET.get('slave', None)

        # 将操作日志的内容返回
        yield op_log.OP_REMOVE_HA_CFG.format(vip)

        # TODO 校验入参是否合法
        yield request.GET

        # 调用删除高可用的公共方法
        result = self._process_remove_ha_common(vip, master, slave, vrid, const.SERVICE_TGT)

        if isinstance(result, HAResponse):
            yield result

        # 删除成功则从数据库中移除
        database.del_obj(const.TABLE_HIGHAVAILABLE, database_id)

        # 返回成功给页面
        yield HAResponse(is_success=True)

    def _process_modify_ha_cfg(
            self, master, old_vip, current_vip, failed_nodes, failed_reasons, keeped_slave, service):
        """
        当高可用IP被修改过时，进入此处理流程
        """
        modify_ha_command = cmd.CMD_MODIFY_HA.format(const.HANDY_SHELL_PATH, old_vip, current_vip, service)

        # 配置主用节点
        result = self.exec_remote_ssh_cmd(master, modify_ha_command)

        if isinstance(result, dict):
            failed_reasons[master] = result['reason']
            failed_nodes.append(master)
        elif const.OP_SUCCSSFUL != result:
            failed_reasons[master] = result
            failed_nodes.append(master)

        # 配置未变更的备用节点
        return self._process_ha_cfg(keeped_slave, modify_ha_command, failed_nodes, failed_reasons)

    @check_remove_osd_event(const.OP_MODIFY_HA_CFG)
    @util.send_response()
    def modify_ha_cfg(self, request, fsid):
        """
        修改业务高可用
        """
        current_id = request.DATA.get('id', None)
        old_vip = request.DATA.get('oldVip', None)
        current_vip = request.DATA.get('currentVip', None)
        master = request.DATA.get('master', None)
        old_slave = request.DATA.get('oldSlave', None)
        current_slave = request.DATA.get('currentSlave', None)
        priority_list = request.DATA.get('priorityList', None)
        vrid = request.DATA.get('vrid', None)

        # 将操作日志的内容返回
        yield op_log.OP_MODIFY_HA_CFG.format(old_vip)

        # TODO 校验入参是否合法
        yield request.DATA

        all_nodes = set(old_slave.split(',') + current_slave.split(',') + [master])

        # 校验HA IP是否为业务网和主备节点的连通性等
        validate_result = self._process_validate_ha_nodes(current_vip, master, current_slave, all_nodes)
        if const.OP_SUCCSSFUL != validate_result:
            yield validate_result

        # 获取新加入的备用节点
        add_slave = list(set(current_slave.split(',')) - set(old_slave.split(',')))

        # 获取被删除的备用节点
        del_slave = list(set(old_slave.split(',')) - set(current_slave.split(',')))

        # 获取当前已用的优先级
        for node in del_slave:
            if node in priority_list:
                del priority_list[node]

        # 获取未变更的备用节点
        keeped_slave = list(set(old_slave.split(',')) - set(del_slave))

        # 检查待删除的高可用节点是否正在使用
        detect_nodes = del_slave if old_vip == current_vip else all_nodes
        test_vip = self.check_vip_connect(old_vip, detect_nodes, const.SERVICE_TGT)

        if 0 != len(test_vip['failed_nodes']):
            log.error('Network fault nodes: %s', test_vip['failed_nodes'])
            yield HAResponse(is_success=False, error=errno.format_error(errno.ERR_CONNECT_TO_HOST, ', '.join(test_vip['failed_nodes'])))

        if 0 != len(test_vip['connect_node']):
            yield HAResponse(is_success=False, error=errno.ERR_HA_IP_IS_USED)

        # 获取已使用的权值
        used_priority = [priority_list[node] for node in priority_list]

        # 配置被删除的备用节点
        failed_nodes, failed_reasons = \
            self._process_remove_ha_cfg(old_vip, vrid, del_slave, const.SERVICE_TGT)

        # 高可用VIP被修改过的处理流程
        if old_vip != current_vip:
            failed_nodes, failed_reasons = self._process_modify_ha_cfg(
                master, old_vip, current_vip, failed_nodes, failed_reasons, keeped_slave, const.SERVICE_TGT)

        # 配置新加入的备用节点
        priority_list, failed_nodes, failed_reasons = self._process_create_slave_ha(
            priority=240,
            slaves=add_slave,
            vip=current_vip,
            vrid=vrid,
            service=const.SERVICE_TGT,
            failed_nodes=failed_nodes,
            failed_reasons=failed_reasons,
            priority_list=priority_list,
            used_priority=used_priority
        )

        if 0 != len(failed_nodes):
            log.error('modify ha cfg error, failed_reasons: %s', failed_reasons)
            yield HAResponse(is_success=False, error=errno.ERR_MODIFY_HA_CFG)

        # 更新数据库中的高可用配置
        database.update_obj(const.TABLE_HIGHAVAILABLE, current_id, [current_vip, current_slave, priority_list])

        # 返回成功给页面
        yield HAResponse(is_success=True)

    @util.send_response(op=const.OP_LIST)
    def get_self_manage_ip(self, request, fsid):
        """
        获取Handy的管理网IP
        """
        # 从集群中获取管理网段
        cluster_config = self.get_config_from_conf_file()
        manage_network = cluster_config['manage_network']

        # 从本地获取Handy所有的IP
        get_ip_result = self.exec_local_cmd(cmd.CMD_LIST_NETWORK_INTERFACES)
        public_has_info = self.exec_local_cmd_json(cmd.DB_GET_HA)
        public_has = []
        if public_has_info and 'highavailableconfig' in public_has_info:
            for public_ha in public_has_info['highavailableconfig']:
                public_has.append(public_ha['vip'])

        local_ips = [ip for ip in get_ip_result.split('\n') if '' != ip]
        local_ips = list(set(local_ips) - set(public_has))

        # 将管理网段内的IP地址返回，可能会有多个，页面只使用第一个即可
        yield [ip for ip in local_ips if self.subnet_judge(manage_network, ip)]

    @util.send_response(
        op=const.OP_CREATE_MANAGE_NETWORK,
        ret_type=const.RETURN_TYPE_2
    )
    @util.before_return(
        final=HAFinalRollback.create_manage_network_finally,
        roolback=HAFinalRollback.create_manage_network_rollback
    )
    def create_manage_network(self, request, fsid):
        """
        升级到HandyHA版本后要在所有节点上插入manage_network网段
        """
        manage_network = request.DATA.get('manage_network', None)
        # 返回操作日志内容
        yield op_log.OP_CREATE_MANAGE_NETWORK.format(manage_network)
        # 从onestor_hosts中获取集群中所有的节点
        cluster_hosts = self.get_cluster_hosts_from_config()
        hosts_ip = [host[const.HOST_IP] for host in cluster_hosts]
        # 登录到各个节点上更新管理网段
        update_result = self.multi_thread_task(
            hosts_ip, cmd.CMD_UPDATE_MANAGE_NETWORK.format(manage_network), ssh=True)
        log.info('create manage network result: %s', update_result)
        failed_nodes = []
        manage_ip_error_nodes = []
        for host_ip in update_result:
            if -1 == update_result[host_ip].find(const.OP_SUCCSSFUL):
                if 'MANAGE_IP_NOT_FOUND_EXCEPTION' == update_result[host_ip]:
                    manage_ip_error_nodes.append(host_ip)
                else:
                    failed_nodes.append(host_ip)
        if 0 != len(manage_ip_error_nodes):
            raise errno.ONEStorError(errno.ERROR_MANAGE_IP_NOT_FOUND, ', '.join(manage_ip_error_nodes))
        # 其它原因返回查看后台日志
        if 0 != len(failed_nodes):
            raise errno.ONEStorError(errno.ERROR_UPDATE_MANAGE_NET_CFG, ', '.join(failed_nodes))
        # 将管理网段信息添加到clusterconfig内 add by l11544 PN:201712120457
        config_info = database.retry_get_database("clusterconfig")
        config_info['manage_network'] = manage_network
        database.retry_put_database("clusterconfig", config_info)

    @util.send_response(op=const.OP_LIST)
    def list_handy_ha_cfg(self, request, fsid):
        """
        获取管理高可用列表
        """
        has_manage_net, manage_network = False, ''
        if 'UNFOUND' == self.exec_local_cmd(cmd.CMD_GET_MANAGE_NETWORK):
            yield {'success': True, 'has_manage_net': has_manage_net, 'mask': manage_network}
        # 从数据库中获取所有高可用配置
        ha_cfgs = self.list_handyha()
        # 获取所有工作节点
        ha_working_nodes = self._get_working_nodes(ha_cfgs[const.TABLE_HANDY_HA])
        # 将工作节点更新到结果中
        ha_cfgs['ha_ip_list'] = ha_working_nodes
        # begin add by z11524 2017/11/2 PN:201710200205
        ceph_conf_info = self.get_clusterconfig()
        manage_network = ceph_conf_info.get('manage_network', '')
        has_manage_net = True if manage_network else False
        # 返回数据给页面
        yield {'success': True, 'data': ha_cfgs, 'has_manage_net': has_manage_net, 'mask': manage_network}

    def _process_handy_config(self, vip, master, slave, passwd, session):
        """
        处理创建Handy高可用时在Handy节点上的操作，包括：
        # 0、校验License规格是否一致
        1、在备用节点上安装ONEStor软件
        2、同步时间和NTP配置
        3、同步集群的配置文件
        4、增加定时任务
        5、对集群所有节点和自身进行免密设置
        6、修改数据库中的handy_key/cluster_hosts表
        7、同步监控数据
        8、同步本地postgres数据库和用户（组）的数据
        """
        config_tool = HandyConfigTool()

        # 校验License规格是否一致
        log.info('[Handy HA] begin validate license info...')
        config_tool.assert_network_ok()
        set_onestor_progress(const.STEP_VALIDATE_LICENSE)
        config_tool.license_check(slave, passwd)

        # update by z11524 2017/10/18 PN:201710120437
        # 先获取节点的业务网IP
        slave_public_ip = self.get_node_public_ip(slave, passwd, const.USER_ROOT)

        # 获取节点的主机名称
        slave_name = self.cmd_remote(slave, passwd, cmd.CMD_HOSTNAME, const.USER_ROOT)

        # 如果备用节点不是集群内的节点，需要安装软件、同步时间和集群配置文件
        is_slave_cluster_node = config_tool.is_cluster_node(slave_public_ip, passwd)

        # 当前Handy对该备用节点进行一次免密
        log.info('[Handy HA] begin ssh config...')
        config_tool.assert_network_ok()
        set_onestor_progress(const.STEP_SSH_CONFIG)
        config_tool.ssh_config(slave, passwd)

        # 将失败回滚的参数记录到session中
        session[const.HA_ROLLBACK_ENTITY] = \
            HARollbackEntity(is_slave_cluster_node, slave_public_ip, slave_name).to_json()

        # 检查主备节点的掩码是否正确
        unmatch_mask_nodes = self.check_node_mask(
            [master] + slave.split(','), const.MANAGE_NETWORK)
        if unmatch_mask_nodes:
            raise errno.ONEStorError(
                errno.ERROR_UNMATCH_MASK,
                ','.join(unmatch_mask_nodes),
                const.MANAGE_NETWORK_CN
            )

        # 去掉备用handy不作MON时ssh到其他节点要输入确定
        if '' == self.exec_remote_ssh_cmd(
                slave, cmd.CMD_SURE_SSH_HA, use_string=False, raise_exc=True):
            self.__ensure_ssh_config(slave)

        if not is_slave_cluster_node:
            # PN: 201703130633 不应该限制NTP server IP为业务网IP
            # 检查主用节点IP和备用节点IP是否已经配做集群外NTP服务端
            host_in_ntp = self.host_in_ntp_out_check(slave_public_ip, passwd)
            if host_in_ntp:
                raise errno.ONEStorConfigError(errno.ERROR_HOST_IN_OUT_NTP_SERVER, slave_public_ip)
            # end by l11544 2017/3/16

            # 安装ONEStor软件
            log.info('[Handy HA] begin install soft...')
            config_tool.assert_network_ok()
            set_onestor_progress(const.STEP_INSTALL_SOFT)
            config_tool.install_soft(slave_public_ip, passwd)

            # 与MON的时间进行同步
            log.info('[Handy HA] begin setup ntp...')
            config_tool.assert_network_ok()
            set_onestor_progress(const.STEP_SETUP_NTP)
            config_tool.setup_ntp(slave_name)

            # 同步集群的配置文件
            log.info('[Handy HA] begin push cluster config...')
            config_tool.assert_network_ok()
            set_onestor_progress(const.STEP_SYNC_CONFIG)
            config_tool.push_cluster_config(slave_public_ip)

        # 对自身和集群其它节点进行免密配置并修改handy_key和cluster_hosts表
        log.info('[Handy HA] begin ssh config to other nodes...')
        config_tool.assert_network_ok()
        set_onestor_progress(const.STEP_SSH_CONFIG_OTHER)
        config_tool.ssh_config_to_cluster_nodes(slave_public_ip, slave_name)

        # postgresql数据库启动流复制HA
        log.info('[Handy HA] begin setup postgresql...')
        config_tool.assert_network_ok()
        set_onestor_progress(const.STEP_SYNC_PSQL)
        config_tool.open_handy_ha_psql(vip, master, slave)
        session[const.NEED_RESTORE_PSQL] = True

        # 同步监控数据给备用Handy
        log.info('[Handy HA] begin sync monitory data...')
        config_tool.assert_network_ok()
        set_onestor_progress(const.STEP_SYNC_MONITORY)
        config_tool.sync_monitory_data(slave_public_ip)

        # 同步calamari conf文件到备用节点 PN:201707200215
        self.syn_calamari_conf(slave_public_ip)

        self.exec_remote_ssh_cmd(slave_public_ip, 'supervisorctl restart onestor-pub')
        self.exec_remote_ssh_cmd(slave_public_ip, 'supervisorctl restart onestor-sub')
        self.exec_remote_ssh_cmd(slave_public_ip, 'supervisorctl restart onestor-nm')

    @util.send_response(op=const.OP_LIST)
    def get_current_progress(self, request, fsid):
        """
        从文件中获取当前操作的具体步骤
        """
        yield {const.STEP: const.STEP_TIPS_SHOW[self.get_onestor_progress()]}

    def check_cluster_nodes_public_network(self):
        """
        检查集群内所有主机的业务网是否正常
        """

        handy_util = util.HandyUtil()
        cluster_hosts = handy_util.get_cluster_hosts_from_config()
        nodes = [host[const.HOST_IP] for host in cluster_hosts]
        failed_nodes = self.test_ping(nodes)
        if 0 != len(failed_nodes):
            # update by z11524 PN:201702170315 2017/2/20
            raise errno.ONEStorConfigError(errno.ERR_CONNECT_TO_PUBLIC_NEWORK, ','.join(failed_nodes))

    @check_remove_osd_event(const.OP_CREATE_HANDY_HA_CFG)
    @util.send_response(
        op=const.OP_CREATE_HANDY_HA_CFG,
        ret_type=const.RETURN_TYPE_2
    )
    @util.before_return(
        final=HAFinalRollback.create_handy_ha_finally,
        roolback=HAFinalRollback.create_handy_ha_rollback
    )
    def create_handy_ha_cfg(self, request, fsid):
        """
        创建管理高可用
        """
        task_id = request.DATA['task_id']
        vip = request.DATA.get('vip', None)
        master = request.DATA.get('master', None)
        slave = request.DATA.get('slave', None)
        passwd = request.DATA.get('passwd', None)
        # 将操作日志的内容返回
        yield op_log.OP_CREATE_HANDY_HA_CFG.format(vip)

        # TODO 校验入参是否合法
        yield request.DATA

        # 将当前任务记录到文件中
        self.add_onestor_task(
            const.ONESTOR_PROGRESS, const.OP_CREATE_HANDY_HA_CFG, task_id)
        self._check_host_network([slave], 'root', passwd,
                                 check_cluster_network=False, check_public_network=False)
        self.check_cluster_nodes_public_network()

        # 从数据库中获取高可用配置，只允许创建一条管理高可用信息
        ha_cfgs = self.list_handyha()
        if 0 < len(ha_cfgs[const.TABLE_HANDY_HA]):
            raise errno.ONEStorConfigError(errno.ERR_ONLY_ALLOW_ONE_HA_CFG)

        # 记录当前操作步骤
        set_onestor_progress(const.STEP_VALIDATE_NETWORK)

        # 清除.network_error文件 ADD BY KF6602 2016/11/22 PN:201611160439
        self.exec_local_cmd(cmd.CMD_RM_FILE.format(const.NETWORK_FAULT_TMP_FILE))

        # 调用创建高可用的公共方法
        result = self._process_create_ha_common(
            vip, master, slave, service=const.SERVICE_HANDYHA, useto=3, switch_lvs=2,
            network=const.MANAGE_NETWORK, passwd=passwd, session=request.session)
        if isinstance(result, HAResponse):
            yield result

        vrid, priority_list = result
        self.exec_local_cmd('timeout 120 ssh %s mkdir -p /home/ceph-cluster' % slave)
        self.exec_local_cmd('timeout 120 scp /home/ceph-cluster/*.keyring [%s]:/home/ceph-cluster/' % slave)
        # 创建成功则记录到数据库中
        # begin modify by z11524 增加业务网
        master_name = self.exec_remote_ssh_cmd(master, 'hostname', raise_exc=True)
        slave_name = self.exec_remote_ssh_cmd(slave, 'hostname', raise_exc=True)
        master_public_ip = self.name_to_ip(master_name)
        slave_public_ip = self.name_to_ip(slave_name)
        if not os.path.exists(const.NETWORK_FAULT_TMP_FILE):
            handyha_info = {
                'vip': vip,
                'master': master,
                'master_public_ip': master_public_ip,
                'slave': slave,
                'slave_public_ip': slave_public_ip,
                'vrid': vrid,
                'priority_list': priority_list
            }
            self.create_handyha(handyha_info)

        # 配置完Psql高可用之后需要重启进程来生效
        time.sleep(30)
        util.clear_onestor_task()
        log.info('running cmd %s', cmd.PSQL_BECOME_MASTER)
        self.exec_local_cmd(cmd.PSQL_BECOME_MASTER)
        # 远程登录主动成为备节点并重启leader进程
        self.exec_remote_ssh_cmd(slave, cmd.PSQL_BECOME_SLAVE, raise_exc=True)
        self.exec_remote_ssh_cmd(slave, cmd.SERVICE_RESTART_ONESTORD, raise_exc=True)

        # ADD BY KF6602 PN:201611070173
        time.sleep(30)

        # add by z11524 2016/11/9 PN:201611100264 重启告警
        self.exec_remote_ssh_cmd(slave, cmd.CMD_RESTART_ALARM, raise_exc=True)
        # begin add by z11524 2017/02/14 移除keepalived.conf.bk
        self.exec_local_cmd(cmd.CMD_RM_KEEPALIVED_BK)
        self.exec_remote_ssh_cmd(slave, cmd.CMD_RM_KEEPALIVED_BK, raise_exc=True)

        # begin add by z11524 2017/7/24 PN:201707190746
        self.psql_backup(master, slave)

        # begin add by z11524 PN:201707170213
        self.set_onestor_host()
        self.save_hosts_base_info([slave])
        self.notify_slave_mr(slave)

    def notify_slave_mr(self, ip_address):
        """
        当创建handy ha成功的时候, 给备handy下的MR进程发送一个消息来启动定时全量备份数据的任务
        :param ip_address:
        :return:
        """
        request = mr_message.make_request(mr_message.OP_MR_HANDLE_CONFIG_HA_SUCCEED_EVENT_SLAVE)
        try:
            client = message.Messenger.create_mr_peon_tcp_client(ip_address)
            client.send_request(request)
            client.close()
            log.info("Send request to slave mr succeed...")
        except Exception as e:
            log.error("Send request to slave mr failed, reason: %s", e)

    def _process_remove_handy_cfg(self, node_ip):
        """
        删除HA配置
        """
        handy_util = HandyUtil()

        # 根据管理网IP获取主机名
        node_name = self.exec_remote_ssh_cmd(node_ip, cmd.CMD_HOSTNAME, raise_exc=True)

        # 根据主机名获取主机业务网IP
        cluster_hosts = handy_util.get_cluster_hosts_from_config()
        node_ip = [host[const.HOST_IP] for host in cluster_hosts if node_name == host[const.HOST_NAME]][0]

        # 判断节点是否为集群内的节点（不含对象网关）
        role = self.get_host_roles_by_name(node_name, handy_util.cluster_config)
        is_cluster_node = False if not role else (
            False if not role['mon'] and not role['stor'] else True)
        log.info('is_cluster_node = %s', is_cluster_node)
        handy_util.process_remove_handy_ha(is_cluster_node, node_ip, node_name, roles=role)
        # 删除handyHA后重新获取角色信息，为集群外节点时停止目标主机nm进程
        role = self.get_host_roles_by_name(node_name, handy_util.cluster_config)
        log.info('Removed HandyHA role is "{0}"'.format(role))
        # 集群外节点，停止nm，sub进程
        if not role:
            log.info('Node "{0}" is not cluster node, stop process nm sub.'.format(node_ip))
            self.stop_nm_sub([node_ip])

    def _process_remove_handy_cfg_offline(self, offline_node):
        """
        离线时删除HA配置
        """
        ceph_conf = configobj.ConfigObj(const.CEPH_CONF)
        if 'handy' not in ceph_conf:
            raise errno.ONEStorError(errno.ERR_GET_CLUSTER_CONFIG)

        slave_addr = ceph_conf['handy']['slave_addr']
        offline_node_name = ceph_conf['handy']['slave'] if \
            offline_node == slave_addr else ceph_conf['handy']['master']
        offline_public_ip = self.name_to_ip(offline_node_name)

        # 判断节点是否为集群内的节点（不含对象网关）
        role = self.get_host_roles_by_name(offline_node_name, self.cluster_config)
        is_cluster_node = False if not role else (False if not role['mon'] and not role['stor'] else True)
        self.process_remove_handy_ha(
            is_cluster_node, offline_public_ip, offline_node_name, offline=True, roles=role)

    @check_remove_osd_event(const.OP_REMOVE_HANDY_HA_CFG)
    @util.send_response(
        op=const.OP_REMOVE_HANDY_HA_CFG,
        ret_type=const.RETURN_TYPE_2
    )
    def remove_handy_ha_cfg(self, request, fsid):
        """
        删除管理高可用
        """
        task_id = request.GET.get('task_id', None)
        vip = request.GET.get('vip', None)
        vrid = request.GET.get('vrid', None)
        master = request.GET.get('master', None)
        slave = request.GET.get('slave', None)
        offline_node = request.GET.get('offline_node', '')

        # 将操作日志的内容返回
        yield op_log.OP_REMOVE_HANDY_HA_CFG.format(vip)

        # TODO 校验入参是否合法
        yield request.GET

        # 将当前任务记录到文件中
        self.add_onestor_task(
            const.ONESTOR_PROGRESS, const.OP_REMOVE_HANDY_HA_CFG, task_id)

        # 检查节点是否存在不允许删除的角色情况(现主要为集群外对象网关角色)
        if '' == offline_node:
            self.remove_ha_before()

        # 清除.network_error文件 ADD BY KF6602 2016/11/22 PN:201611160439
        self.exec_local_cmd(cmd.CMD_RM_FILE.format(const.NETWORK_FAULT_TMP_FILE))

        # 调用删除高可用的公共方法
        result = self._process_remove_ha_common(
            vip, master, slave, vrid, const.SERVICE_HANDYHA, offline_node=[offline_node])

        if isinstance(result, HAResponse):
            yield result

        ceph_conf = configobj.ConfigObj(const.CEPH_CONF)
        if 'handy' not in ceph_conf:
            raise errno.ONEStorError(errno.ERR_GET_CLUSTER_CONFIG)
        local_name = self.exec_local_cmd(const.HOST_NAME)
        handy_names = list()
        handy_names.append(ceph_conf['handy']['slave'])
        handy_names.append(ceph_conf['handy']['master'])
        removed_name = (set(handy_names) - {local_name}).pop()
        log.info('Removed HandyHA name：%s', removed_name)
        removed_roles = self.get_host_roles_by_name(removed_name, self.cluster_config)
        log.info('Removed HandyHA roles：%s', removed_roles)
        # 删除HA配置
        if '' == offline_node:
            # 登录到master节点获取主机名，判断当前登录的是哪个节点
            master_name = self.exec_remote_ssh_cmd(master, const.HOST_NAME, raise_exc=True)
            local_name = self.exec_local_cmd(const.HOST_NAME)
            # 获取另一个Handy的IP地址
            another_handy_ip = slave if master_name == local_name else master
            self._process_remove_handy_cfg(another_handy_ip)
            # 删除数据库之前先检查一下网络是否正常
            self._assert_network_ok(another_handy_ip)
        else:
            # 删除离线的节点
            self._process_remove_handy_cfg_offline(offline_node)
        # 删除成功则从数据库中移除
        self.delete_handyha()

        # 还原postgres数据库的配置
        self.close_handy_ha_psql(master, slave, offline_node)

        # begin add by z11524 2017/7/24 PN:201707190746
        self.psql_backup(master, slave)

        # begin add by z11524 PN:201707170213
        self.set_onestor_host()
        if removed_roles is None or removed_roles['role_num'] < 2:
            self.delete_host_base_info(removed_name)

        # 返回成功给页面
        yield HAResponse(is_success=True)

    @check_remove_osd_event(const.OP_MODIFY_HANDY_HA_CFG)
    @util.send_response()
    def modify_handy_ha_cfg(self, request, fsid):
        """
        修改管理高可用
        """
        current_vip = request.DATA.get('vip', None)
        master = request.DATA.get('master', None)
        slave = request.DATA.get('slave', None)

        # 清除.network_error文件 ADD BY KF6602 2016/11/22 PN:201611160439
        self.exec_local_cmd(cmd.CMD_RM_FILE.format(const.NETWORK_FAULT_TMP_FILE))

        # 根据vip从数据库中查询待修改的项
        ha_cfgs = self.list_handyha()['handyha']
        if 0 == len(ha_cfgs):
            yield HAResponse(is_success=False, error=errno.ERR_HA_CFG_NOT_FOUND)

        ha_cfg = ha_cfgs[0]

        old_vip = ha_cfg['vip']

        # 将操作日志的内容返回
        yield op_log.OP_MODIFY_HANDY_HA_CFG.format(old_vip)

        # TODO 校验入参是否合法
        yield request.DATA

        all_nodes = set([slave] + [master])

        # 检查VIP是否被修改了，目前Handy HA只允许修改VIP
        if old_vip == current_vip:
            yield HAResponse(is_success=False, error=errno.ERR_HA_IP_IS_SAME)

        # 检查新的VIP是否已经被使用
        if 1 != len(self.test_ping(current_vip.split(','))):
            yield HAResponse(is_success=False, error=errno.format_error(errno.ERR_IP_IS_USED, current_vip))

        # 校验HA IP是否为管理网和主备节点的连通性等
        validate_result = self._process_validate_ha_nodes(
            current_vip, master, slave, all_nodes, network=const.MANAGE_NETWORK)
        if const.OP_SUCCSSFUL != validate_result:
            yield validate_result

        # 检查原来的VIP是否正在使用
        test_vip = self.check_vip_connect(old_vip, all_nodes, const.SERVICE_HANDYHA)

        if 0 != len(test_vip['failed_nodes']):
            log.error('Network fault nodes: %s', test_vip['failed_nodes'])
            yield HAResponse(is_success=False, error=errno.ERR_NODE_HAS_NETWORK_FAULT)

        if 0 != len(test_vip['connect_node']):
            yield HAResponse(is_success=False, error=errno.ERR_HA_IP_IS_USED)

        # 高可用VIP被修改过的处理流程
        failed_nodes, failed_reasons = self._process_modify_ha_cfg(
            master, old_vip, current_vip, [], {}, [slave], const.SERVICE_HANDYHA)

        if 0 != len(failed_nodes):
            log.error('modify ha cfg error, failed_reasons: %s', failed_reasons)
            yield HAResponse(is_success=False, error=errno.ERR_MODIFY_HA_CFG)

        # 更新数据库中的高可用配置
        self.update_handyha(old_vip, current_vip)

        # begin add by z11524 2017/5/3 PN:201704190103
        self.exec_remote_ssh_cmd(master, cmd.UPDATE_CEPH_CONF_HANDY.format(current_vip, master, slave))
        self.exec_remote_ssh_cmd(slave, cmd.UPDATE_CEPH_CONF_HANDY.format(current_vip, master, slave))
        # end add by z11524 2017/5/3 PN:201704190103

        # 返回成功给页面
        yield HAResponse(is_success=True, rt=success_log.SUCCESS_MODIFY_HANDY_HA.format(old_vip, current_vip),
                         type=const.TABLE_HANDY_HA)

    def psql_backup(self, master, slave):
        """
        备份数据库方法
        add by z11524 2017/7/24 PN:201707190746
        """
        log.info('begin backup psql')
        self.multi_thread_task([master, slave], cmd.CMD_BACKUP_PSQL.format(const.RESULT_NONE), ssh=True)
        log.info('end backup psql')

    def auto_backup_psql(self, request):
        """
        定时备份数据库
        """
        log.info('begin auto backup psql')
        self.exec_local_cmd(cmd.CMD_BACKUP_PSQL.format(const.TEST))
        log.info('end auto backup psql')
        return Response({'success': True})


def test_psql_db():
    """
    测试数据库是否正常
    """
    handy_util = HandyUtil()
    # update add by z11524 date:2017/12/27 PN:201710160741
    result = handy_util.check_concurrent_event2(const.FLAG_SWITCH_HANDY_HA, 1800, 'check')
    if result:
        return const.UNREADY
    # 检查是否存在切换的进程，如果是则返回unready
    if '0' != handy_util.exec_local_cmd(cmd.CMD_CHECK_HANDY_HA_EVENT):
        return const.UNREADY
    # 往数据库中测试表中增删数据
    test_result = handy_util.exec_local_cmd(cmd.CMD_TEST_PSQL_STATUS)
    if -1 != test_result.find('PSQL_READY'):
        return const.READY
    else:
        return const.UNREADY


def repair_psql_db():
    """
    修复Postgres数据库
    1、检查PSQL的进程是否存在，如果不存在则重启PSQL的进程
    2、检查进程是否被成功重启，如果成功则测试能否写入数据
    3、如果进程未成功启动或者进程在但是无法写入测试数据，则从main_bak中还原数据库
    4、最后再测试能否写入数据
    5、如果是则返回成功，如果否则返回修复失败
    """
    handy_util = HandyUtil()
    # 检查是否已经有HandyHA切换的进程
    if '0' != handy_util.exec_local_cmd(cmd.CMD_CHECK_HANDY_HA_EVENT):
        return 'EXIST_TASK'
    # 调用脚本进行修复
    log.info('begin repair postgres...')
    return handy_util.exec_local_cmd(cmd.CMD_REPAIR_PSQL)


def switch_to_master():
    """
    将当前节点切换为主用节点
    """
    handy_util = HandyUtil()
    result = const.OP_SUCCSSFUL
    has_flag = False
    try:
        log.info('begin handle become master event...')
        # 并发保护，一分钟后失效
        has_flag = handy_util.check_concurrent_event2(
            const.FLAG_SWITCH_HANDY_HA, interval=60)
        if has_flag:
            raise errno.ONEStorError(errno.ERROR_EXIST_HANDY_HA_EVENT)
        # 检查是否已经有HandyHA切换的进程
        if '0' != handy_util.exec_local_cmd(cmd.CMD_CHECK_HANDY_HA_EVENT):
            raise errno.ONEStorError(errno.ERROR_EXIST_HANDY_HA_EVENT)
        # 调用become_master脚本
        handy_util.exec_local_cmd(cmd.PSQL_BECOME_MASTER)
        # 同步MON数据库到sqlite数据库
        log.info('please see logs in /var/log/calamari/handyha.log')
    except errno.ONEStorError as ex:
        log.exception(ex)
        result = ex.reason
    except Exception, e:
        log.exception(e)
        result = '系统错误，详见后台日志'
    finally:
        # 删除并发保护的标识
        if not has_flag:
            if os.path.exists(const.FLAG_SWITCH_HANDY_HA):
                os.remove(const.FLAG_SWITCH_HANDY_HA)
        log.info('finish handle become master event')
        # 记录完操作日志再重启apache完成整个切换
        if const.OP_SUCCSSFUL == result:
            log.info('begin restart apache2 to finish switch...')
            handy_util.exec_local_cmd(cmd.SERVICE_RESTART_APACHE)
        return result
