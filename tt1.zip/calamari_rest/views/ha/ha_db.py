#!/usr/bin/env python
# coding: utf-8

"""
HandyHA数据库操作实例
"""

import json
import logging

from calamari_rest.models import HandyHA

LOG = logging.getLogger('django.request')


class HandyHADatabase(object):
    """
    HandyHA数据库操作实例
    """

    @staticmethod
    def create_handyha(handyha_info):
        """
        创建HandyHA
        """
        LOG.info('add handyha info to db: %s', handyha_info)
        HandyHA.objects.create(
            vip=handyha_info['vip'],
            master=handyha_info['master'],
            master_public_ip=handyha_info['master_public_ip'],
            slave=handyha_info['slave'],
            slave_public_ip=handyha_info['slave_public_ip'],
            vrid=handyha_info['vrid'],
            priority_list=json.dumps(handyha_info['priority_list'])
        )

    @staticmethod
    def delete_handyha():
        """
        删除HandyHA
        """
        LOG.info('remove handyha info from db...')
        handyha_db = HandyHA.objects.all()
        if 0 < len(handyha_db):
            handyha_db[0].delete()
            return True

    @staticmethod
    def update_handyha(old_vip, new_vip):
        """
        修改HandyHA
        """
        LOG.info('update handyha info to db: %s -> %s', old_vip, new_vip)
        handyha_db = HandyHA.objects.all()
        if 0 < len(handyha_db):
            obj = HandyHA.objects.get(vip=old_vip)
            obj.vip = new_vip
            obj.save()

    @staticmethod
    def list_handyha():
        """
        查询HandyHA
        """
        handyha_db = HandyHA.objects.all()
        data = {'handyha': []}
        if 0 < len(handyha_db):
            data = {
                'handyha': [{
                    "id": 1,
                    "vip": handyha_db[0].vip,
                    "master": handyha_db[0].master,
                    "master_public_ip": handyha_db[0].master_public_ip,
                    "slave": handyha_db[0].slave,
                    "slave_public_ip": handyha_db[0].slave_public_ip,
                    "priority_list": json.loads(handyha_db[0].priority_list),
                    "vrid": handyha_db[0].vrid
                }]
            }
        return data
