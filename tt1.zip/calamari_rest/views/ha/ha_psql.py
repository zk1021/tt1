# -*- coding:utf-8 -*-

"""
postgres流复制配置类
"""

import logging

from calamari_rest.views.common import const, cmd, errno
from calamari_rest.views.host.host_util import HostUtil

LOG = logging.getLogger('django.request')


class PostgresHA(HostUtil):
    """
    postgres HA配置类
    """

    def __init__(self, *args, **kwargs):
        super(PostgresHA, self).__init__(*args, **kwargs)

    def __exec_cmd_check_result(self, command, node=None):
        """
        检查命令执行的结果是否为success，如果不是则抛出异常
        """
        if node is None:
            result = self.exec_local_cmd(command)
        else:
            result = self.exec_remote_ssh_cmd(node, command)
        # 检查结果
        if const.OP_SUCCSSFUL != result:
            LOG.exception(result)
            raise errno.ONEStorConfigError(errno.ERR_EXECUTE_COMMAND)

    def open_handy_ha_psql(self, vip, master, slave):
        """
        基于流复制来配置Postgresql实现数据库HA
        """
        # update by z11524 2017/5/3 PN:201704190103
        open_handy_ha_cmd = cmd.OPEN_HANDY_HA_PSQL.format(vip, master, slave)
        self.__exec_cmd_check_result(open_handy_ha_cmd, master)
        self.__exec_cmd_check_result(open_handy_ha_cmd, slave)

    def close_handy_ha_psql(self, master, slave, offline_node):
        """
        删除Handy高可用时重置postgres的配置信息，包括：
        1、还原pg_hba.conf和postgresql.conf文件
        2、删除recovery.conf文件
        3、删除ceph.conf中handyha的区块
        4、重启数据库和apache2
        """
        if offline_node != slave:
            self.__exec_cmd_check_result(cmd.CLOSE_HANDY_HA_PSQL, slave)
        if offline_node != master:
            self.__exec_cmd_check_result(cmd.CLOSE_HANDY_HA_PSQL, master)
