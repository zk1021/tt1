#!/usr/bin/env python
# coding: utf-8

"""
高可用管理回滚处理
"""

import logging

from rest_framework.request import Request

from calamari_rest.views.common.cmd import *
from calamari_rest.views.common import const, cmd
from calamari_rest.views.common.util import set_onestor_progress
from calamari_rest.views.ha.ha_psql import PostgresHA

LOG = logging.getLogger('django.request')


class HAFinalRollback(PostgresHA):
    """
    HA管理finally和回滚方法类
    """

    def create_handy_ha_finally(self, *args):
        """
        创建HandyHA finally执行函数
        Date: 2017/04/03
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session

        # 获取集群所有的主机
        cluster_hosts = self.get_cluster_hosts_from_config()
        nodes = [host[const.HOST_IP] for host in cluster_hosts]
        failed_nodes = self.test_ping(nodes)
        nodes = list(set(nodes) - set(failed_nodes))

        # 删除Diamond备份配置文件
        self.multi_thread_task(nodes, CMD_RM_DIAMOND_CONF, ssh=True)

        # 检查主备两个节点的postgres数据库和onestord进程是否正常
        LOG.info('checking postgres and onestord status...')
        if '0' == self.exec_local_cmd(CMD_CHECK_PSQL_STATUS):
            LOG.info('[master] postgres status is unnormal, try to restart...')
            self.exec_local_cmd(SERVICE_RESTART_PSQL)
        else:
            LOG.info('[master] postgres status is ok.')

        if '0' == self.exec_local_cmd(CMD_CHECK_ONESTORD_STATUS):
            LOG.info('[master] onestord status is unnormal, try to restart...')
            self.exec_local_cmd(SERVICE_RESTART_ONESTORD)
        else:
            LOG.info('[master] onestord status is ok.')

        if const.HA_ROLLBACK_ENTITY in session:
            slave_ip = session[const.HA_ROLLBACK_ENTITY]['node_ip']
            if '0' == self.exec_remote_ssh_cmd(slave_ip, CMD_CHECK_PSQL_STATUS):
                LOG.info('[slave] postgres status is unnormal, try to restart...')
                self.exec_remote_ssh_cmd(slave_ip, SERVICE_RESTART_PSQL)
            else:
                LOG.info('[slave] postgres status is ok.')

            if '0' == self.exec_remote_ssh_cmd(slave_ip, CMD_CHECK_ONESTORD_STATUS):
                LOG.info('[slave] onestord status is unnormal, try to restart...')
                self.exec_remote_ssh_cmd(slave_ip, SERVICE_RESTART_ONESTORD)
            else:
                LOG.info('[slave] onestord status is ok.')
            del session[const.HA_ROLLBACK_ENTITY]

        if const.NEED_RESTORE_PSQL in session:
            del session[const.NEED_RESTORE_PSQL]

    def create_handy_ha_rollback(self, *args):
        """
        创建HandyHA 回滚处理函数
        Date: 2017/04/03
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        set_onestor_progress(const.STEP_ROLLBACK)

        if const.HA_ROLLBACK_ENTITY in session:
            rollback_entity = session[const.HA_ROLLBACK_ENTITY]
            LOG.info('begin rollback handy ha cfg, %s', rollback_entity)

            _node_ip = rollback_entity['node_ip']
            node_name = self.ip_to_name(_node_ip)
            role = self.get_host_roles_by_name(node_name)
            self.process_remove_handy_ha(
                is_slave_cluster_node=rollback_entity['is_cluster_node'],
                node_ip=_node_ip,
                node_name=rollback_entity['node_name'],
                roles=role
            )

            if const.NEED_RESTORE_PSQL in session:
                # 调用close_handy_ha.py进行回滚，包括ceph.conf和psql配置等
                LOG.info('execute close_handy_ha.py when rollback handy ha')
                self.exec_remote_ssh_cmd(_node_ip, ROLLBACK_HANDY_HA_PSQL)
                self.exec_local_cmd(ROLLBACK_HANDY_HA_PSQL)
        LOG.info('finish rollback when create handy ha.')

    def create_manage_network_finally(self, *args):
        """
        创建管理网段 finally执行函数
        Date: 2017/04/20
        """
        # 获取集群所有的主机
        cluster_hosts = self.get_cluster_hosts_from_config()
        nodes = [host[const.HOST_IP] for host in cluster_hosts]
        failed_nodes = self.test_ping(nodes)
        nodes = list(set(nodes) - set(failed_nodes))
        # 不管操作成功或失败都去删除ceph.conf.bak文件
        self.multi_thread_task(nodes, CMD_RM_BACKUP_CEPH_CONF, ssh=True)

    def create_manage_network_rollback(self, *args):
        """
        创建管理网段 回滚处理函数
        Date: 2017/04/20
        """
        # 获取集群所有的主机
        cluster_hosts = self.get_cluster_hosts_from_config()
        nodes = [host[const.HOST_IP] for host in cluster_hosts]
        failed_nodes = self.test_ping(nodes)
        nodes = list(set(nodes) - set(failed_nodes))
        # 回滚时还原ceph.conf.bak文件
        self.multi_thread_task(nodes, CMD_RECOVER_CEPH_CONF, ssh=True)
        LOG.info('finish rollback when create manage network.')
