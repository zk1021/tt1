# -*- coding:utf-8 -*-


class HARollbackEntity:
    """
    HA回滚实体类
    """

    def __init__(self, is_cluster_node, node_ip, node_name):
        """
        初始化
        """
        self.node_ip = node_ip
        self.node_name = node_name
        self.is_cluster_node = is_cluster_node

    def to_json(self):
        return {
            'node_ip': self.node_ip,
            'node_name': self.node_name,
            'is_cluster_node': self.is_cluster_node
        }
