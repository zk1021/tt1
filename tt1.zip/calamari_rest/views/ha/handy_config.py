# -*- coding:utf-8 -*-

import os
import time
import base64
import logging

from calamari_common.config import CalamariConfig
from calamari_rest.views.common import errno, cmd, const
from calamari_rest.views.common.util import HandyUtil, send_to_slave_handy
from calamari_rest.views.ha.ha_psql import PostgresHA

log = logging.getLogger('django.request')

config = CalamariConfig()

"""
    Author: dai.xinchun@h3c.com
    Date: 2016/06/30
    Description: ONEStor配置Handy高可用类
"""


class HandyConfigTool(PostgresHA):
    def __init__(self, *args, **kwargs):
        super(HandyConfigTool, self).__init__(*args, **kwargs)
        self.handy_util = HandyUtil()

    def is_cluster_node(self, node, passwd):
        """
        判断当前节点是否已经为集群已有的节点
        """
        # 判断备用节点是否已经为集群的已有节点
        slave_fsid = self.handy_util.cmd_remote(node, passwd, cmd.CMD_GET_FSID)

        # 获取当前Handy的fsid
        self_fsid = self.exec_local_cmd(cmd.CMD_GET_FSID)

        # 如果fsid与当前Handy的fsid不一致，则不允许加入集群，如果一致则不再重复安装软件
        if '' != slave_fsid and slave_fsid != self_fsid:
            raise errno.ONEStorConfigError(errno.ERR_SLAVE_EXIST_CLUSTER)

        # 集群fsid相同，则为集群已有节点
        if slave_fsid == self_fsid:
            return True

        return False

    @staticmethod
    def assert_network_ok():
        """
        检查是否出现过网络故障，如果是则抛出异常
        """
        if os.path.exists(const.NETWORK_FAULT_TMP_FILE):
            raise errno.ONEStorConfigError(errno.ERR_NODE_HAS_NETWORK_FAULT)

    def license_check(self, node_ip, passwd):
        """
        校验License信息是否一致
        """
        pass

    def ssh_config(self, node_ip, passwd):
        """
        配置SSH免密
        """
        return self.handy_util.ssh_config(node_ip, passwd)

    def install_soft(self, node_ip, passwd):
        """
        在备用节点上安装ONEStor软件
        """
        self.handy_util.install_soft(node_ip, passwd)

    def setup_ntp(self, node_name):
        """
        在备用节点上配置NTP
        """
        self.handy_util.setup_ntp_client(node_name)

    def push_cluster_config(self, node_ip):
        """
        同步集群配置
        """
        self.handy_util.sync_cluster_config(node_ip)

    def ssh_config_to_cluster_nodes(self, node_ip, node_name):
        """
        对集群其它节点进行免密
        """
        self.handy_util.ssh_config_server(node_ip, node_name)

    def sync_monitory_data(self, node_ip):
        """
        同步监控数据到备用Handy
        """
        pass
