# -*- coding:utf-8 -*-
import os
import sys
import platform
import json
import base64
import paramiko
import logging
import time
from common import cmd

DEBUG_LEVEL = logging.INFO
SCAN_RESULT_FILE = 'scan_result'
LOG_FILE = '/var/log/calamari/ONEStor_{0}.log'
INSTALL_SHELL = '/opt/h3c/salt/salt/shell/install_ceph.sh'
LISD_DISK_SHELL = '/opt/h3c/salt/salt/shell/remote_list_disk.py'


def log(target, msg, exc_info=False):
    try:
        logging.basicConfig(
            level=DEBUG_LEVEL,
            filename=LOG_FILE.format(target),
            format='%(asctime)s [%(levelname)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        _log = logging.getLogger('main')
        if exc_info:
            _log.exception(msg)
        else:
            _log.info(msg)
    except Exception, e:
        print e


def subnet_judge(subnet, ip):
    try:
        subnet_len = int(subnet.split('/')[1])
        all_sub_single_ip = subnet.split('/')[0].split('.')
        first_sub_ip_bin = str(bin(int(all_sub_single_ip[0]))).split('0b')[1].zfill(8)
        second_sub_ip_bin = str(bin(int(all_sub_single_ip[1]))).split('0b')[1].zfill(8)
        third_sub_ip_bin = str(bin(int(all_sub_single_ip[2]))).split('0b')[1].zfill(8)
        fourth_sub_ip_bin = str(bin(int(all_sub_single_ip[3]))).split('0b')[1].zfill(8)

        all_single_ip = ip.split('.')
        first_ip_bin = str(bin(int(all_single_ip[0]))).split('0b')[1].zfill(8)
        second_ip_bin = str(bin(int(all_single_ip[1]))).split('0b')[1].zfill(8)
        third_ip_bin = str(bin(int(all_single_ip[2]))).split('0b')[1].zfill(8)
        fourth_ip_bin = str(bin(int(all_single_ip[3]))).split('0b')[1].zfill(8)

        bin_subnet = first_sub_ip_bin + second_sub_ip_bin + third_sub_ip_bin + fourth_sub_ip_bin
        bin_ip = first_ip_bin + second_ip_bin + third_ip_bin + fourth_ip_bin

        subnet_mask = bin_subnet[0:subnet_len]
        if bin_ip[0:subnet_len] == subnet_mask:
            return True
        else:
            return False
    except Exception:
        return False


def connectHost(hostip, username, password, master):
    reload(sys)
    sys.setdefaultencoding("utf8")

    # BEGIN ADD BY D10039 2016/06/02 PN:201606020047
    try:
        passwd_decode = base64.b64decode(password)
    except:
        passwd_decode = password
    # END ADD BY D10039 2016/06/02

    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostip, 22, username, passwd_decode)

        client.exec_command("echo 'master: %s' > /etc/salt/minion" % master)
        client.exec_command("service salt-minion restart")
        stdin, stdout, stderr = client.exec_command("hostname")
        hostname = stdout.read().rstrip()

        stdin, stdout, stderr = client.exec_command("bash /var/lib/ceph/shell/list_disk.sh")
        disks = stdout.read().rstrip()

        client.close()

        print '%s,disks->%s' % (hostname, disks)
    except Exception, e:
        print '400'


def exec_remote_cmd(host, port, user, passwd, command):
    # BEGIN ADD BY D10039 2016/06/02 PN:201606020047
    try:
        passwd_decode = base64.b64decode(passwd)
    except:
        passwd_decode = passwd
    # END ADD BY D10039 2016/06/02

    try:
        log(host, '%s' % command)
        s = paramiko.SSHClient()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        s.connect(host, port, user, passwd_decode)

        stdin, stdout, stderr = s.exec_command(command)
        ret = stdout.read().rstrip()
        log(host, '%s;%s' % (ret, stderr.read().rstrip()))

        s.close()
        print ret
        return ret
    except Exception, e:
        import traceback
        traceback.print_exc()
        print 'e400:%s' % e
        try:
            s.close()
        except:
            pass

def push_soft_pkg(s, sftp, module_name, component):
    component_dir = "/opt/h3c/package/" + component + "/"
    cmd = "ls " + component_dir + " | grep " + module_name + "_"
    module_tar_name = os.popen(cmd).read().strip()
    pkg_dir = component_dir + module_tar_name
    remote_pkg_dir="/opt/h3c/package/" + module_tar_name
    sftp.put(pkg_dir, remote_pkg_dir)
    s.exec_command("echo '%s' >> /tmp/module_tar_name.txt" % (module_tar_name))


def install_soft(host, port, user, passwd, master, ntp_close, node_type):
    # BEGIN ADD BY D10039 2016/06/02 PN:201606020047
    try:
        passwd_decode = base64.b64decode(passwd)
    except:
        passwd_decode = passwd
    # END ADD BY D10039 2016/06/02

    try:
        s = paramiko.SSHClient()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        s.connect(host, port, user, passwd_decode)

        t = paramiko.Transport((host, port))
        t.connect(username=user, password=passwd_decode)
        sftp = paramiko.SFTPClient.from_transport(t)

        log(host, 'push module package......')
        s.exec_command("rm /tmp/module_tar_name.txt >/dev/null")
        s.exec_command("mkdir -p /opt/h3c/package && chmod 777 /opt/h3c/package")
        time.sleep(2)

        if master != host:
            push_soft_pkg(s, sftp, 'common', 'platform')
            push_soft_pkg(s, sftp, 'base', 'platform')
            push_soft_pkg(s, sftp, 'ntp', 'platform')
            push_soft_pkg(s, sftp, 'supervisor', 'platform')
            push_soft_pkg(s, sftp, 'publog', 'platform')
            push_soft_pkg(s, sftp, 'ceph', 'platform')
            push_soft_pkg(s, sftp, 'handy-osd-shell', 'platform')
            push_soft_pkg(s, sftp, 'onestor-cli', 'platform')
            push_soft_pkg(s, sftp, "prometheus", "platform")
            push_soft_pkg(s, sftp, 'onestord', 'platform')

        if node_type == 'nas':
            push_soft_pkg(s, sftp, 'nfs', 'nas')
            push_soft_pkg(s, sftp, 'nscd', 'nas')
            push_soft_pkg(s, sftp, 'krb5', 'nas')
            push_soft_pkg(s, sftp, 'vsftpd', 'nas')
            push_soft_pkg(s, sftp, 'dnsmasq', 'nas')
            push_soft_pkg(s, sftp, 'samba', 'nas')
            push_soft_pkg(s, sftp, "prometheus", "platform")
            push_soft_pkg(s, sftp, 'ldapd', 'nas')
            push_soft_pkg(s, sftp, 'onestord', 'platform')
        elif node_type == 'mds':
            pass
        elif node_type == 'mon' or node_type == 'mon_osd': 
            push_soft_pkg(s, sftp, 'open-iscsi', 'platform')
            push_soft_pkg(s, sftp, 'ipvsadm', 'platform')
            #push_soft_pkg(sftp, 'flashcache', 'platform')
            push_soft_pkg(s, sftp, 'tgt', 'block')
            push_soft_pkg(s, sftp, 'vae', 'block')
            push_soft_pkg(s, sftp, 'themis', 'block') 
            push_soft_pkg(s, sftp, 'zookeeper', 'platform')
        else:
            push_soft_pkg(s, sftp, 'open-iscsi', 'platform')
            push_soft_pkg(s, sftp, 'ipvsadm', 'platform')
            #push_soft_pkg(s, sftp, 'flashcache', 'platform')
            push_soft_pkg(s, sftp, 'tgt', 'block')
            push_soft_pkg(s, sftp, 'themis', 'block')
            push_soft_pkg(s, sftp, 'vae', 'block')

        push_soft_pkg(s, sftp, 'keepalived', 'platform')
        push_soft_pkg(s, sftp, 'USupd', 'platform')
        push_soft_pkg(s, sftp, 'diamond', 'platform')
        log(host, 'push module package sucess.')

        log(host, 'upload install_ceph.sh......')
        sftp.put(INSTALL_SHELL, '/tmp/install_ceph.sh')

        stdin, stdout, stderr = s.exec_command('chmod 777 /tmp/install_ceph.sh')
        # BEGIN ADD BY D10039 2016/03/05 ONEStor for UIS, support port modify
        handy_port = os.popen(
            "cat /opt/h3c/conf/httpd.conf| grep 'Listen ' | tail -1 | awk '{print $2}'").read().strip()
        stdin, stdout, stderr = s.exec_command(
            "bash /tmp/install_ceph.sh %s %s %s %s %s %s" % (master, host, passwd_decode, node_type, handy_port, ntp_close))
        # END ADD BY D10039 2016/03/05 ONEStor for UIS, support port modify
        log(host, '%s;%s' % (stdout.read().rstrip(), stderr.read().rstrip()))

        stdin, stdout, stderr = s.exec_command('hostname')
        hostname = stdout.read().rstrip()
        log(host, 'hostname is %s' % hostname)

        stdin, stdout, stderr = s.exec_command('cat /tmp/disk_%s' % host)
        disks = stdout.read().rstrip()

        s.exec_command('rm -rf /tmp/install_ceph.sh /tmp/disk_*')

        s.close()
        t.close()

        return_obj = {'hostname': hostname, 'disks': disks}
        print json.dumps(return_obj)
        return return_obj
    except Exception, e:
        import traceback
        traceback.print_exc()
        try:
            s.close()
            t.close()
        except:
            pass


def getHandyPublicIP(public_network):
    try:
        all_ip = os.popen(
            "ip addr|grep 'inet ' |grep -v ' lo' |awk  '{print $2}' |cut -d / -f 1").read().rstrip()
        # 获取onestor_hosts内的ip列表进行过滤，进行对比保证Handy业务网IP唯一性 PN:201612160546
        if os.path.exists('/etc/onestor_hosts'):
            need_check = True
            ip_list_str = os.popen("cat /etc/onestor_hosts | awk '{print $1}'").read().strip()
            onestor_hosts = [ip.strip() for ip in ip_list_str.split('\n')]
        else:
            need_check = False

        for ip in all_ip.split('\n'):
            if subnet_judge(public_network, ip):
                if need_check and ip not in onestor_hosts:
                    continue
                # end by l11544 2017/3/22 保证获取的不是虚IP
                return ip

    except Exception, e:
        return str(e)


def getPublicAddress(host, port, user, passwd, public_network):
    # BEGIN ADD BY D10039 2016/06/02 PN:201606020047
    try:
        passwd_decode = base64.b64decode(passwd)
    except:
        passwd_decode = passwd
    # END ADD BY D10039 2016/06/02

    try:
        s = paramiko.SSHClient()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        s.connect(host, port, user, passwd_decode)

        list_node_ip_command = "ip addr|grep 'inet ' |grep -v ' lo' |awk  '{print $2}' |cut -d / -f 1"

        stdin, stdout, stderr = s.exec_command(list_node_ip_command)
        list_node_ip_ret = stdout.read().rstrip()

        net_info = list_node_ip_ret.split('\n')
        num_ip = len(net_info)

        net_info_list = {}

        for i in range(num_ip):
            if subnet_judge(public_network, net_info[i]):
                net_info_list['node_ip'] = net_info[i]
                net_info_list['interface'] = 'eth0'
                break

        net_info_list['success'] = True

        s.close()
        print json.dumps(net_info_list)
        return json.dumps(net_info_list)
    except Exception, e:
        print json.dumps({'success': False, 'error': str(e)})
        try:
            s.close()
        except:
            pass


def scanHost(host, port, user, passwd):
    # BEGIN ADD BY D10039 2016/06/02 PN:201606020047
    try:
        passwd_decode = base64.b64decode(passwd)
    except:
        passwd_decode = passwd
    # END ADD BY D10039 2016/06/02

    try:
        s = paramiko.SSHClient()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        s.connect(host, port, user, passwd_decode)

        host_info = {}
        
        disks = []
        detail = []        

        disk_ret = os.popen('/opt/h3c/bin/python %s %s %s "%s"' % (LISD_DISK_SHELL, host, user, passwd)).read().rstrip()
        host_info['disk_cache'] = (-1 != disk_ret.find('DISK_CACHE_ENABLED'))
        host_info['disk_info'] = disk_ret
        disk_info = disk_ret.split('available disk -->')[1]
        if disk_info == '':
            host_info['disks'] = []
            host_info['detail'] = []
        else:
            for disk in disk_info.split(';'):
                disks.append(disk.split('Disk ')[1].split(',')[0] + '::' + disk.split(',')[2])
                detail.append(disk)
            host_info['disks'] = disks
            host_info['detail'] = detail


        scan_host_command = 'hostname && lsb_release -d && ls /etc/ceph/ceph.conf'

        stdin, stdout, stderr = s.exec_command(scan_host_command)
        scan_host_ret = stdout.read().rstrip()

        scan_ret_array = scan_host_ret.split('\n')
        host_info['connect'] = True
        host_info['hostname'] = scan_ret_array[0]
        host_info['linux_version'] = scan_ret_array[1].split('Description:')[1].strip()

        # BEGIN MODIFY FOR HANDY HA 2017/03/09
        host_info['cluster_exist'] = host_info['cluster_same'] = False
        # 获取目标主机的集群ID
        get_fsid_cmd = "cat /etc/ceph/ceph.conf | grep 'fsid'"
        stdin, stdout, stderr = s.exec_command(get_fsid_cmd)
        ssh_fsid = stdout.read().rstrip()
        if '' != ssh_fsid:
            host_info['cluster_exist'] = True
            ssh_fsid = ssh_fsid.split('=')[1].strip()
            # 获取Handy本地的集群ID
            local_fsid = os.popen(get_fsid_cmd).read().strip()
            if '' != local_fsid:
                local_fsid = local_fsid.split('=')[1].strip()
            if local_fsid == ssh_fsid:
                host_info['cluster_same'] = True
        # END MODIFY FOR HANDY HA 2017/03/09

        # BEGIN ADD by d10039 2016/02/24 PN:201602170609 modify by d11564 PN:201703060657 过滤NAS虚ip
        distro = platform.dist()[0]
        if distro == "centos":
            list_node_ip_command = "ifconfig |grep 'inet ' | grep -v '127.0.0.1' | awk '{print $2}'"
        else:
            list_node_ip_command = "ifconfig | grep Bcast | grep inet | grep -v ' lo'|awk  '{print $2}' |cut -d : -f 2"
        # END MODIFY BY D11564 2017/03/14 PN:201703060657
        stdin, stdout, stderr = s.exec_command(list_node_ip_command)
        list_node_ip_ret = stdout.read().rstrip()

        net_info = list_node_ip_ret.split('\n')
        host_info['net_info'] = net_info

        s.close()
        # END ADD by d10039 2016/02/24 PN:201602170609
        print json.dumps(host_info)

    except Exception, e:
        log(SCAN_RESULT_FILE, '{0} >> {1}'.format(host, e), exc_info=True)
        import traceback
        traceback.print_exc()
        host_info = {'connect': False}
        print json.dumps(host_info)
        try:
            s.close()
        except:
            pass


def mask_judge(network, mask):
    """
    检查掩码是否与网段一致
    :param network: 待检查的网段
    :param mask: 待检查的掩码
    :return: True: 掩码一致 False: 掩码不一致
    """
    return int(mask) == int(network.split('/')[1])


def network_judge(host, user, passwd, public_network, cluster_network, disaster_network=None, manage_network=None):
    # BEGIN ADD BY D10039 2016/06/02 PN:201606020047
    try:
        passwd_decode = base64.b64decode(passwd)
    except:
        passwd_decode = passwd
    # END ADD BY D10039 2016/06/02

    try:
        s = paramiko.SSHClient()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        s.connect(host, 22, user, passwd_decode)

        list_node_ip_command = "ip addr|grep 'inet ' |grep -v ' lo' |awk  '{print $2}' && cat /etc/hostname"
        stdin, stdout, stderr = s.exec_command(list_node_ip_command)
        list_node_ip_ret = stdout.read().rstrip()

        net_info = list_node_ip_ret.split('\n')
        num_ip = len(net_info)
        net_info_list = {
            'success': True,
            'manage_ip': '',
            'public_ip': '',
            'storage_ip': '',
            'disaster_ip': '',
            'manage_mask_match': False,
            'public_mask_match': False,
            'storage_mask_match': False,
            'disaster_mask_match': False,
            'hostname': ''
        }

        for i in range(num_ip):
            if i == num_ip-1:
                net_info_list['hostname'] = net_info[i]
                break
            _nic = net_info[i]
            _nic_ip = _nic.split('/')[0]
            _nic_mask = _nic.split('/')[1]
            if subnet_judge(public_network, _nic_ip):
                if not net_info_list['public_ip']:
                    net_info_list['public_ip'] = _nic_ip
                    net_info_list['public_mask_match'] = mask_judge(public_network, _nic_mask)

            if subnet_judge(cluster_network, _nic_ip):
                if not net_info_list['storage_ip']:
                    net_info_list['storage_ip'] = _nic_ip
                    net_info_list['storage_mask_match'] = mask_judge(cluster_network, _nic_mask)

            if disaster_network is not None and subnet_judge(disaster_network, _nic_ip):
                if not net_info_list['disaster_ip']:
                    net_info_list['disaster_ip'] = _nic_ip
                    net_info_list['disaster_mask_match'] = mask_judge(disaster_network, _nic_mask)
            # check manage_network
            if manage_network is not None and subnet_judge(manage_network, _nic_ip):
                if not net_info_list['manage_ip']:
                    net_info_list['manage_ip'] = _nic_ip
                    net_info_list['manage_mask_match'] = mask_judge(manage_network, _nic_mask)

        return json.dumps(net_info_list)
    except Exception, e:
        return json.dumps({
            'success': False,
            'error': str(e)
        })
    finally:
        try:
            s.close()
        except:
            pass


def get_host_performance(host, port, user, passwd):
    # BEGIN ADD BY D10039 2016/06/02 PN:201606020047
    # noinspection PyBroadException
    try:
        passwd_decode = base64.b64decode(passwd)
    except:
        passwd_decode = passwd
    # END ADD BY D10039 2016/06/02
    try:
        s = paramiko.SSHClient()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        s.connect(host, port, user, passwd_decode)
        host_info = {}
        # 获取cpu分值
        get_cpu_score_command = "unixbench -i 1 -c 1 dhry2reg whetstone-double syscall"
        stdin, stdout, stderr = s.exec_command(get_cpu_score_command)
        cup_score = stdout.read().rstrip()
        host_info['cpu_score'] = int(cup_score)
        # 获取memory分值
        get_memory_size_command = "cat /proc/meminfo | grep MemTotal | awk '{print $2}'"
        stdin, stdout, stderr = s.exec_command(get_memory_size_command)
        memory_size = stdout.read().rstrip()
        host_info['mem_size'] = int(memory_size)
        print json.dumps(host_info)
    except Exception, e:
        log(host, '{0} >> {1}'.format(host, e), exc_info=True)
        import traceback
        traceback.print_exc()
        host_info = {'connect': False}
        print json.dumps(host_info)
    finally:
        try:
            s.close()
        except:
            pass

if __name__ == "__main__":
    if 'connect_host' == sys.argv[1]:
        connectHost(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
    elif 'exec_remote_cmd' == sys.argv[1]:
        exec_remote_cmd(sys.argv[2], 22, sys.argv[3], sys.argv[4], sys.argv[5])
    elif 'install_soft' == sys.argv[1]:
        if len(sys.argv) == 8:
            install_soft(sys.argv[2], 22, sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7])
        else:
            install_soft(sys.argv[2], 22, sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], 'other')
    elif 'getPublicAddress' == sys.argv[1]:
        getPublicAddress(sys.argv[2], 22, sys.argv[3], sys.argv[4], sys.argv[5])
    elif 'scanHost' == sys.argv[1]:
        scanHost(sys.argv[2], 22, sys.argv[3], sys.argv[4])
    elif 'getHandyPublicIP' == sys.argv[1]:
        print getHandyPublicIP(sys.argv[2])
    elif 'get_host_performance' == sys.argv[1]:
        get_host_performance(sys.argv[2], 22, sys.argv[3], sys.argv[4])
    elif 'network_judge' == sys.argv[1]:
        disaster_net = None
        manage_net = None
        if len(sys.argv) > 7 and str.lower(sys.argv[7]) != 'none':
            disaster_net = sys.argv[7]
        if len(sys.argv) > 8:
            manage_net = sys.argv[8]
        print network_judge(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], disaster_net, manage_net)
