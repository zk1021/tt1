#!/usr/bin/python
# encoding:utf-8

import os
import time
import json
import logging
import functools

LOG = logging.getLogger('django.request')


class CephCommandError(Exception):
    pass


def retry(times=5):
    """
    装饰器
    对被装饰的对象，重试给定次数
    如果times为None，则无限次重复
    :param times 重试次数
    """

    def decorate(func):
        """
        装饰器
        :param func 被装饰的方法
        """

        @functools.wraps(func)
        def _decorate(*args, **kwargs):
            """
            装饰器
            """
            if not os.path.exists('/etc/ceph/ceph.conf'):
                return func(*args, **kwargs)
            count = 0
            while True:
                try:
                    return func(*args, **kwargs)
                except Exception as error:
                    count += 1
                    time.sleep(count * 2)
                    if times and count >= times:
                        LOG.error('execute function %s failed with retry %s times.', func.__name__, times)
                        LOG.exception(error)
                        raise error
                    LOG.info('execute function %s failed, try again %s', func.__name__, count)

        return _decorate

    return decorate


def local_cmd(cmd):
    """
    执行Linux本地命令
    :param cmd: 待执行的命令
    :return: 命令执行结果，如果错误会返回空值
    """
    return os.popen(cmd).read().rstrip()


@retry(times=3)
def is_table_exist(table_name):
    """
    判断数据库表是否存在于leveldb中
    :param table_name: 数据库表名称
    :return: True-存在， False-不存在，如果得不到结果则抛出异常
    """
    LOG.info('check table %s exist or not when insert.', table_name)
    tables = local_cmd('timeout 60 ceph config-key list')
    if '' == tables:
        raise CephCommandError(
            'Failed to list leveldb table when check table {0}'.format(table_name))
    return table_name in json.loads(tables)
