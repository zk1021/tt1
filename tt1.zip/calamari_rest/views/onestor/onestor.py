# -*- coding:utf-8 -*- 
import os
import json
import time
import rbd
import rados
import math
import logging
import subprocess
import platform
from database import add_obj

LOG_FILE = '/var/log/ceph/ONEStor_RPC.log'
log = logging.getLogger('django.request')


def execute_cmd(command_args):
    p = subprocess.Popen(command_args.split(' '), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    status = p.returncode
    return {
        'out': stdout,
        'err': stderr,
        'status': status
    }


def log_info(module, msg):
    _now = time.strftime('%Y-%m-%d %H:%M:%S')
    all_info = '[%s] %s: %s' % (_now, module, msg)
    os.system('echo %s >> %s' % (all_info, LOG_FILE))


def space(conf_file):
    try:
        cluster = rados.Rados(conffile=conf_file)
        cluster.connect()
        cluster_stats = cluster.get_cluster_stats()
        return cluster_stats
    except Exception, e:

        return {'status': 'error', 'reason': str(e)}


def poolspace(conf_file, pool_name):
    try:
        space = json.loads(os.popen('ceph df --format json').read())
        if 'pools' in space:
            for p in space['pools']:
                if p['name'] == pool_name:
                    return p['stats']['max_avail']

        return 0
    except Exception, e:
        return {'status': 'error', 'reason': e}


def getPoolSpaceByName(spaces, pool_name):
    try:
        if 'pools' in spaces:
            for p in spaces['pools']:
                if p['name'] == pool_name:
                    return p['stats']['max_avail']

        return 0
    except Exception, e:
        return 0


def createRbd(conf_file, pool_name, rbd_name, size, order, clonable, matadata):
    try:
        with rados.Rados(conffile=conf_file) as cluster:
            with cluster.open_ioctx(matadata) as ioctx:
                rbd_inst = rbd.RBD()
                log.info('[ONEStor] create rbd before, rbd_name is %s/%s', pool_name, rbd_name)
                # API: create(ioctx, name, size, order=None, old_format=True, features=0, stripe_unit=0, stripe_count=0)
                if clonable:
                    rbd_inst.create(ioctx, str(rbd_name), int(size), order, False, 15, data_pool=pool_name)
                else:
                    rbd_inst.create(ioctx, str(rbd_name), int(size), order, data_pool=pool_name)

                log.info('[ONEStor] create rbd after, rbd_name is %s/%s', pool_name, rbd_name)

        return {'status': 'success'}
    except rbd.ImageExists, e:

        return {'status': 'error', 'reason': u'块 “%s” 已经存在' % rbd_name, 'errorcode': 'RBD_EXIST'}
    except rbd.InvalidArgument, e:

        return {'status': 'error', 'reason': u'参数错误', 'errorcode': 'PARAMETER_ERROR'}
    except Exception, e:
        log.exception(e)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'INTERNAL_SERVER_ERROR'}


def removeRbd(conf_file, pool_name, rbd_name, matadata):
    try:
        with rados.Rados(conffile=conf_file) as cluster:
            with cluster.open_ioctx(matadata) as ioctx:
                rbd_inst = rbd.RBD()
                log.info('[ONEStor] remove rbd before, rbd_name is %s/%s', matadata, rbd_name)
                rbd_inst.remove(ioctx, str(rbd_name))
                log.info('[ONEStor] remove rbd after, rbd_name is %s/%s', matadata, rbd_name)

        return {'status': 'success'}
    except rbd.ImageNotFound, e:

        return {'status': 'error', 'reason': u'块 “%s” 不存在' % rbd_name, 'errorcode': 'RBD_NOT_FOUND'}
    except rbd.ImageBusy, e:

        return {'status': 'error', 'reason': u'块 “%s” 正在被使用' % rbd_name, 'errorcode': 'RBD_BUSY'}
    except rbd.ImageHasSnapshots, e:

        return {'status': 'error', 'reason': u'块 “%s” 存在快照' % rbd_name, 'errorcode': 'RBD_HAS_SNAPSHOT'}
    except Exception, e:
        log.exception(e)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'INTERNAL_SERVER_ERROR'}


def list(conf_file, pool_name):
    try:
        rbd_arry = []
        with rados.Rados(conffile=conf_file) as cluster:
            with cluster.open_ioctx(pool_name) as ioctx:
                rbd_inst = rbd.RBD()
                rbds = rbd_inst.list(ioctx)
                # fill rbd infos
                for _rbd in rbds:
                    with rbd.Image(ioctx, _rbd) as image:
                        this_rbd = image.stat()
                        this_rbd['name'] = _rbd
                        this_rbd['old_format'] = image.old_format()
                        this_rbd['snap_nums'] = image.list_snaps().num_snaps
                        try:
                            temp = image.parent_info()
                        except Exception, e:
                            this_rbd['parent_snap'] = ''
                        else:
                            this_rbd['parent_snap'] = temp
                        rbd_arry.append(this_rbd)

        return rbd_arry
    except Exception, e:

        return {'status': 'error', 'reason': str(e), 'errorcode': 'INTERNAL_SERVER_ERROR'}


def list_snaps(conf_file, pool_name, rbd_name):
    try:
        snap_arry = []
        with rados.Rados(conffile=conf_file) as cluster:
            with cluster.open_ioctx(pool_name) as ioctx:
                with rbd.Image(ioctx, str(rbd_name)) as image:
                    for snap in image.list_snaps():
                        snap_arry.append(snap)
        return snap_arry
    except Exception, e:

        return {'status': 'error', 'reason': str(e), 'errorcode': 'INTERNAL_SERVER_ERROR'}


def clone_rbd(conf_file, pool_src, rbd_name, pool_dest, snap_name, clone_name, matadata):
    try:
        log.info('rbd -p %s snap protect --image %s --snap %s' % (matadata, rbd_name, snap_name))
        ret_snap = os.popen('rbd -p %s snap protect --image %s --snap %s' % (matadata, rbd_name, snap_name)).read()
        log.info('rbd cmd: rbd -p %s clone --image %s --snap %s --dest %s --dest-pool %s --data-pool %s' % (
            matadata, rbd_name, snap_name, clone_name, matadata, pool_dest))
        ret_str = execute_cmd('rbd -p %s clone --image %s --snap %s --dest %s --dest-pool %s --data-pool %s' % (
            matadata, rbd_name, snap_name, clone_name, matadata, pool_dest))
        if 0 == ret_str['status']:
            return {'status': 'success'}
        else:
            return {'status': 'exist', 'reason': ret_str['err'][ret_str['err'].find('librbd') + 8:-1]}
    except Exception, e:
        log.exception(e)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'INTERNAL_SERVER_ERROR'}


def snapshotRbd(conf_file, pool_name, rbd_name, snapshot_name):
    try:
        with rados.Rados(conffile=conf_file) as cluster:
            with cluster.open_ioctx(pool_name) as ioctx:
                with rbd.Image(ioctx, str(rbd_name)) as image:
                    image.create_snap(str(snapshot_name))

        return {'status': 'success'}
    except rbd.ImageExists, e:
        return {'status': 'error', 'reason': u'快照 “%s” 已经存在' % snapshot_name, 'errorcode': 'SNAPSHOT_EXIST'}
    except Exception, e:
        log.exception(e)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'INTERNAL_SERVER_ERROR'}


def updatePool(pool_name, pool_uname, size, kind):
    try:
        if int(size) > 2:
            pool_min_size = 2
        else:
            pool_min_size = 1

        if int(kind) == 1:
            result = execute_cmd('ceph osd pool rename %s %s' % (pool_name, pool_uname))
            result = execute_cmd('ceph osd pool set %s size %s' % (pool_uname, size))
            result = execute_cmd('ceph osd pool set %s min_size %s' % (pool_uname, pool_min_size))
        if int(kind) == 2:
            result = execute_cmd('ceph osd pool rename %s %s' % (pool_name, pool_uname))
        if int(kind) == 3:
            result = execute_cmd('ceph osd pool set %s size %s' % (pool_name, size))
            result = execute_cmd('ceph osd pool set %s min_size %s' % (pool_uname, pool_min_size))
        if 0 != result['status']:
            return {'status': 'error', 'reason': result['err'], 'errorcode': result['err']}
        return {'status': 'success'}
    except Exception, e:
        log.exception(e)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'INTERNAL_SERVER_ERROR'}


def createObjUser(email, uname, bucket, client_name):
    try:
        # Add gateway user to cluster
        if email == '':
            result = execute_cmd(
                'radosgw-admin user create --subuser %s:%s --max-buckets=%s --display-name %s --key-type=swift --secret=123456 --temp-url-key=123456 -n %s' % (
                    uname, uname, bucket, uname, client_name))
        else:
            result = execute_cmd(
                'radosgw-admin user create --subuser %s:%s --max-buckets=%s --display-name %s --email=%s --key-type=swift --secret=123456 --temp-url-key=123456 -n %s' % (
                    uname, uname, bucket, uname, email, client_name))

        if 0 != result['status']:
            return {'status': 'error', 'reason': result['err']}

        perm_result = execute_cmd(
            'radosgw-admin subuser modify --subuser %s:%s --access full -n %s' % (uname, uname, client_name))

        if 0 != perm_result['status']:
            return {'status': 'error', 'reason': perm_result['err']}
        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def createObjUsers(uname, max_size, client_name):
    try:
        # Add gateway user to cluster
        result = execute_cmd(
            'radosgw-admin user create --subuser %s:%s  --display-name %s --key-type=swift --secret=123456 --temp-url-key=123456 -n %s' % (
                uname, uname, uname, client_name))
        if 0 != result['status']:
            return {'status': 'error', 'reason': result['err']}
        perm_result = execute_cmd(
            'radosgw-admin subuser modify --subuser %s:%s --access full -n %s' % (uname, uname, client_name))
        if 0 != result['status']:
            return {'status': 'error', 'reason': result['err']}
        enable_result = enableObjUser(uname, client_name)
        if 'success' != enable_result['status']:
            return {'status': 'error', 'reason': perm_result['err']}
        else:
            quota_result = quotaObjUsers(uname, max_size, client_name)
        if 'success' != quota_result['status']:
            return {'status': 'error', 'reason': quota_result['reason']}
        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def quotaObjUsers(uname, max_size, client_name):
    try:
        max_size = int(max_size)
        # Remove gateway user from cluster
        result = execute_cmd(
            'radosgw-admin quota set --max-size=%s --quota-scope=user --uid %s -n %s' % (max_size, uname, client_name))

        if 0 != result['status']:
            return {'status': 'error', 'reason': result['err']}

        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def removeObjUser(uid, client_name):
    try:
        # Remove gateway user from cluster
        result = execute_cmd('radosgw-admin user rm --uid %s --purge-data -n %s' % (uid, client_name))

        if 0 != result['status']:
            return {'status': 'error', 'reason': result['err']}

        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def updateObjs(email, uname, bucket, client_name):
    try:
        uname = str(uname)
        bucket = int(bucket)
        # update gateway user to cluster
        if email == '':
            result = execute_cmd('radosgw-admin user modify --uid=%s --max-buckets=%s --display-name=%s -n %s' % (
                uname, bucket, uname, client_name))
        else:
            result = execute_cmd(
                'radosgw-admin user modify --uid=%s --max-buckets=%s --display-name=%s --email=%s -n %s' % (
                    uname, bucket, uname, email, client_name))

        if 0 != result['status']:
            return {'status': 'error', 'reason': result['err']}

        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def suspendObjUser(uname, client_name):
    try:
        result = execute_cmd('radosgw-admin user suspend --uid=%s  -n %s' % (uname, client_name))
        if 0 != result['status']:
            return {'status': 'error', 'reason': result['err']}
        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def enableObjUser(uname, client_name):
    try:
        result = execute_cmd('radosgw-admin user enable --uid=%s  -n %s' % (uname, client_name))
        if 0 != result['status']:
            return {'status': 'error', 'reason': result['err']}
        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def getObjUserQuota(uname, client_name):
    try:
        result = os.popen('radosgw-admin user info --uid %s -n %s' % (uname, client_name)).read()
        result = json.loads(result)
        results = {}
        results['enabled'] = result['user_quota']['enabled']
        results['max_size_kb'] = result['user_quota']['max_size_kb']
        return {'status': 'success', 'result': results}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def objUserQuota(uname, client_name, max_objs, max_size, swift):
    try:
        max_objs = int(max_objs)
        max_size = int(max_size)
        if swift == 'off':
            result = execute_cmd('radosgw-admin quota disable --uid %s -n %s --quota-scope=user' % (uname, client_name))
            if 0 != result['status']:
                return {'status': 'error', 'reason': result['err']}
            return {'status': 'success', 'result': 'off'}
        else:
            result = execute_cmd('radosgw-admin quota enable --uid %s -n %s --quota-scope=user' % (uname, client_name))
            if 0 != result['status']:
                return {'status': 'error', 'reason': result['err']}
            else:
                result = execute_cmd(
                    'radosgw-admin quota set --uid %s -n %s --max-objects=%s --max-size=%s --quota-scope=user' % (
                        uname, client_name, max_objs, max_size))
                if 0 != result['status']:
                    return {'status': 'error', 'reason': result['err']}
                return {'status': 'success', 'result': 'update'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def patchRbd(conf_file, pool_name, rbd_name, rbd_name_new, old_size, new_size, matadata):
    try:
        with rados.Rados(conffile=conf_file) as cluster:
            with cluster.open_ioctx(matadata) as ioctx:
                with rbd.Image(ioctx, str(rbd_name)) as image:
                    if old_size != new_size:
                        image.resize(int(new_size))
                with rbd.Image(ioctx, str(rbd_name)) as image:
                    rbd_inst = rbd.RBD()
                    if rbd_name != rbd_name_new:
                        # API: rename(ioctx, src, dest)
                        rbd_inst.rename(ioctx, str(rbd_name), str(rbd_name_new))

        return {'status': 'success'}
    except rbd.ImageNotFound, e:
        return {'status': 'error', 'reason': u'块 “%s” 不存在' % rbd_name, 'errorcode': 'RBD_NOT_EXIST'}
    except rbd.ImageExists, e:
        return {'status': 'error', 'reason': u'块 “%s” 已经存在' % rbd_name_new, 'errorcode': 'RBD_EXIST'}
    except Exception, e:
        log.exception(e)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'INTERNAL_SERVER_ERROR'}


def roolbackSnap(conf_file, pool_name, rbd_name, snapshot_name):
    try:
        with rados.Rados(conffile=conf_file) as cluster:
            with cluster.open_ioctx(pool_name) as ioctx:
                with rbd.Image(ioctx, str(rbd_name)) as image:
                    image.rollback_to_snap(str(snapshot_name))

        return {'status': 'success'}
    except rbd.IOError, e:
        log.exception(e)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'IOError'}
    except Exception, e:
        log.exception(e)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'INTERNAL_SERVER_ERROR'}


def removeSnap(conf_file, pool_name, rbd_name, snapshot_name):
    try:
        with rados.Rados(conffile=conf_file) as cluster:
            with cluster.open_ioctx(pool_name) as ioctx:
                with rbd.Image(ioctx, str(rbd_name)) as image:
                    if image.is_protected_snap(str(snapshot_name)):
                        try:
                            image.unprotect_snap(str(snapshot_name))
                        except Exception, e:
                            return {'status': 'error', 'reason': u'快照 “%s” 存在克隆块' % snapshot_name,
                                    'errorcode': 'SNAPSHOT_HAS_CLONED_RBD'}
                        else:
                            image.remove_snap(str(snapshot_name))
                            return {'status': 'success'}
                    else:
                        image.remove_snap(str(snapshot_name))
                        return {'status': 'success'}
    except rbd.IOError, e:
        log.exception(e)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'IOError'}
    except rbd.ImageBusy, e:
        return {'status': 'error', 'reason': u'块 “%s” 正在被使用' % rbd_name, 'errorcode': 'SNAPSHOT_BUSY'}
    except Exception, e:
        log.exception(e)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'INTERNAL_SERVER_ERROR'}

        # BEGIN ADD BY D11564 2016/04/08 PN:201604080108 概览页面容量图显示异常


def getPoolRawUsedByName(space_detail, pool_name):
    try:
        if 'pools' in space_detail:
            for pool in space_detail['pools']:
                if pool['name'] == pool_name:
                    return pool['stats']['raw_bytes_used']

        return 0
    except KeyError:
        return {'status': 'error', 'reason': 'KeyError'}
    except Exception, e:
        return 0


# END ADD BY D11564 2016/04/08 PN:201604080108

# add by z11524
def getPoolStat(conf_file):
    try:
        returned = []
        now = time.time()
        spaces = json.loads(os.popen('ceph df detail --format json').read())
        osd_dump_str = os.popen('ceph osd dump -f json').read().strip()
        osd_dump_obj = json.loads(osd_dump_str)
        pools = osd_dump_obj['pools']
        with rados.Rados(conffile=conf_file) as cluster:
            for pool in pools:
                poolname = str(pool['pool_name'])
                erasure_code_profile = str(pool['erasure_code_profile'])
                with cluster.open_ioctx(poolname) as ioctx:
                    stat = ioctx.get_stats()
                    for val in stat:
                        if stat['num_bytes'] == '':
                            stat['num_bytes'] = '-'
                    pool['stats'] = stat

                    returned.append({'id':pool['pool'], 'name':pool['pool_name'], 'size':pool['size'], \
                        'num_bytes':pool['stats']['num_bytes'],'tie':pool['tiers'],'tie_of':pool['tier_of'], \
                        'max_size':getPoolSpaceByName(spaces, poolname), 'min_size': pool['min_size'], 'type': pool['type'], \
                        'raw_bytes_used':getPoolRawUsedByName(spaces, poolname), 'erasure_code_profile':pool['erasure_code_profile']})
        diff_time = time.time() - now
        return {'status': 'success', 'data': returned, 'diff_time': diff_time}
    except Exception, e:

        return {'status': 'error', 'reason': str(e)}


# end by z11524
'''
    BEGIN Add by d10039 2015/07/20
'''


# add by z11524
def osd_tree():
    try:
        re_str = os.popen('timeout 30 ceph osd tree -f json').read().strip()
        result = json.loads(re_str)
        return {'status': 'success', 'data': result}
    except Exception, e:
        return {'status': 'error', 'reason': e}


def get_rack_info():
    """
    # PN: 201704110041 【BBIT】集群支持的最大机架个数超出了最大限制32个
    :Date 2017/4/22
    :return: List
    """
    tree_info = osd_tree()
    rack_list = []
    if 'success' == tree_info['status']:
        for node in tree_info['data']['nodes']:
            if 'rack' == node['type'] and (not node['name'].endswith('_ssd')):
                rack_list.append({'id': node['id'], 'name': node['name']})
        return {'status': 'success', 'result': rack_list}
    else:
        return tree_info


def count_osd():
    try:
        re_str = int(os.popen('ceph osd tree | grep osd. | wc -l').read().strip())
        return {'status': 'success', 'data': re_str}
    except Exception, e:
        return {'status': 'error', 'reason': e}


def check_erasure(erasure_val):
    try:
        re_str = os.popen('ceph osd erasure-code-profile get profile%sp2' % erasure_val).read().strip()
        if '' == re_str:
            os.popen('ceph osd erasure-code-profile set profile%sp2 k=%s m=2' % (erasure_val, erasure_val)).read()
            return {'status': 'success'}
        else:
            return {'status': 'exists'}
    except Exception, e:
        return {'status': 'error', 'reason': e}

        # end by z11524


def ceph_command(command_args):
    stdout = os.popen('ceph %s' % command_args).read()

    return {
        'out': stdout
    }


def add_default_bucket():
    ret_str = []
    ret = ceph_command('ceph', ['osd', 'crush', 'add-bucket', 'ssd_root', 'root'])
    if '' != ret['err']:
        ret_str.append(ret['err'])
    ret = ceph_command('ceph', ['osd', 'crush', 'rule', 'create-simple', 'rule_ssd', 'ssd_root', 'host', 'firstn'])
    if '' != ret['err']:
        ret_str.append(ret['err'])
    ret = ceph_command('ceph', ['osd', 'crush', 'add-bucket', 'hdd_root', 'root'])
    if '' != ret['err']:
        ret_str.append(ret['err'])
    ret = ceph_command('ceph', ['osd', 'crush', 'rule', 'create-simple', 'rule_hdd', 'hdd_root', 'host', 'firstn'])
    if '' != ret['err']:
        ret_str.append(ret['err'])
    return ret_str


def deteck_onestor_bucket():
    has_hdd_root = False
    has_sdd_root = False
    rules = ceph_command('ceph', ['osd', 'crush', 'rule', 'dump'])
    for rule in json.loads(rules['out']):
        if 'rule_hdd' == rule['rule_name']:
            has_hdd_root = True
        elif 'rule_ssd' == rule['rule_name']:
            has_sdd_root = True

    if not (has_hdd_root and has_sdd_root):
        print add_default_bucket()
    else:
        print 'No need to add bucket'


# add by z11524
def count_pg_num(pool_size=2):
    try:
        osd_num = 0
        rack_info = json.loads(os.popen('ceph osd tree -f json').read().strip())
        for node in rack_info['nodes']:
            if node['type'] == 'osd':
                osd_num += 1
        # pg个数等于 osd个数 * 100 / 副本个数，取2的幂次
        pg_num = int(math.pow(2, math.ceil(math.log((100 * osd_num) / int(pool_size)) / math.log(2))))
        # modified by l11544 纠删码优化项目
        pg_num = 256 if pg_num < 256 else pg_num
        # end by l11544 2017/3/27
        pg_num = 8192 if pg_num > 8192 else pg_num
        return {'pg_num': pg_num}
    except Exception, e:
        return {'status': 'error', 'reason': e, 'errorcode': 'INTERNAL_SERVER_ERROR'}

def exec_local_cmd(command):
    filepath = '/opt/h3c/cmd/'
    _result = os.popen("%s./run %s" % (filepath, command)).read().rstrip()
    return _result

def add_pool(conf_file, pool_name_old, pool_size, crush_rule,pool_erasure_status, pool_pg, k, m, host_num):
    try:
        pool_name = str(pool_name_old)
        with rados.Rados(conffile=conf_file) as cluster:
            if cluster.pool_exists(pool_name):
                return {'status': 'error', 'errorcode': 'POOL_EXIST', 'reason': u'Pool “%s” 已经存在' % pool_name}
            else:
                if pool_erasure_status == 0:
                    ceph_command('osd pool create %s %s %s replicated' % (pool_name, pool_pg, pool_pg))
                    ceph_command('osd pool set %s size %s' % (pool_name, pool_size))

                    if int(pool_size) > 2:
                        pool_min_size = 2
                    else:
                        pool_min_size = 1

                    ceph_command('osd pool set %s min_size %s' % (pool_name, pool_min_size))

                    if str(crush_rule) != '0':
                        ceph_command('osd pool set %s crush_ruleset %s' % (pool_name, crush_rule))
                    return {'status': 'success'}
                else:
                    ret = check_erasure(pool_erasure_status)
                    ceph_command('osd erasure-code-profile set k%sm%sprofile k=%s m=%s' %(k, m, k ,m))

                    rule_name = 'k%sm%srule' %(k, m)
                    rule_result = execute_cmd('ceph osd crush rule create-erasure %s k%sm%sprofile' %(rule_name, k ,m))
                    rule_result = rule_result['err']
                    if -1 != rule_result.find('already exists'):
                        rule_jsons = execute_cmd('ceph osd crush rule dump -f json')
                        rule_jsons = json.loads(rule_jsons['out'])
                        for rule_json in rule_jsons:
                            try:
                                if rule_json['rule_name'] == rule_name:
                                    rule_id = rule_json['rule_id']
                                    break
                            except Exception,e:
                                pass
                    else:
                        rule_id = rule_result.split('rule at ')[1]
                        rule_id = rule_id.split('\n')[0]
                        #设置crush rule
                        chunk_num_in_host = int((int(k)+int(m)+int(host_num)-1)/int(host_num))
                        shell_result = exec_local_cmd('bash /var/lib/ceph/shell/set_crush_rule.sh %s %s %s' %(rule_name, host_num, chunk_num_in_host))
                        if 'rule_name is not exists!' == shell_result:
                            log_info(u'创建Pool “%s” 失败' %pool_name, u'Rule “%s” 不存在' %rule_name)
                            return {'status':'error', 'errorcode':'RULE_NOT_EXIST', 'reason': u'Rule “%s” 不存在' %rule_name}
                        elif 'success' != shell_result:
                            log_info(u'创建Pool “%s” 失败' %pool_name, u'设置crush rule “%s” 失败' %rule_name)
                            return {'status':'error', 'errorcode':'RULE_SET_ERROR', 'reason': u'设置crush rule “%s” 失败' %rule_name}

                    ceph_command('osd pool create %s %s %s erasure k%sm%sprofile'  %(pool_name, pool_pg, pool_pg, k, m))
                    ceph_command('osd pool set %s crush_ruleset %s' %(pool_name, rule_id))
                    ceph_command('osd crush rule rm %s' %pool_name)

                    return {'status': 'success'}
    except Exception, e:
        log.exception(e)
        return {'status': 'error', 'errorcode': 'INTERNAL_SERVER_ERROR', 'reason': u'操作失败，详见后台日志'}


def remove_pool(pool_name_old):
    try:
        pool_name = str(pool_name_old)
        with rados.Rados(conffile='/etc/ceph/ceph.conf') as cluster:
            if cluster.pool_exists(pool_name):
                # MODIFY BY D10039 2016/05/31 PN:201605300116 删除Pool前后都记录日志
                log.warn('[ONEStor] remove pool before, pool_name is %s', pool_name)
                cluster.delete_pool(pool_name)
                log.warn('[ONEStor] remove pool after, pool_name is %s', pool_name)
            else:
                # ADD BY D10039 2016/05/31 如果Pool不存在则返回错误信息
                log.error('[ONEStor] remove pool, pool %s not exist', pool_name)
                return {'status': 'error', 'reason': u'Pool “%s” 不存在' % pool_name_old, 'errorcode': 'POOL_NOT_EXIST'}

        return {'status': 'success'}
    except Exception, e:
        log.error('[ONEStor] remove pool, meet exception: %s', e, exc_info=True)
        return {'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'INTERNAL_SERVER_ERROR'}


# end by z11524
def set_cache_tier(cache_pool, storage_pool):
    try:
        ceph_command('osd tier add %s %s' % (storage_pool, cache_pool))
        ceph_command('osd tier cache-mode %s writeback' % cache_pool)
        ceph_command('osd tier set-overlay %s %s' % (storage_pool, cache_pool))
        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'error_code': 'P99', 'reason': e}


def remove_cache_tier(cache_pool, storage_pool):
    try:
        ceph_command('osd tier remove-overlay %s' % storage_pool)
        ceph_command('osd tier remove %s %s' % (storage_pool, cache_pool))
        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'error_code': 'P99', 'reason': e}


def deploy_ssl(newIp):
    if os.path.exists('/etc/ceph/ssl'):
        if not newIp:
            os.system('rm -rf /etc/ceph/ssl')
        else:
            os.system('cp -rf /etc/ceph/ssl /etc/ceph/ssl.bak')
            os.system('rm -rf /etc/ceph/ssl')
    os.system('mkdir -p /etc/ceph/ssl')
    # create ssl
    os.system('expect /var/lib/ceph/shell/deploy_ceph_ssl.sh')

    os.system('cp -rf /etc/ceph/ssl/server.key /etc/ceph/ssl/server.key.orig')
    os.system('expect /var/lib/ceph/shell/deploy_ssl_server.sh')

    os.system(
        'openssl x509 -req -days 3650 -in /etc/ceph/ssl/server.csr -signkey /etc/ceph/ssl/server.key -out /etc/ceph/ssl/server.crt')
    os.system('cp /etc/ceph/ssl/server.crt /etc/ceph/ssl/server.pem')
    os.system('cat /etc/ceph/ssl/server.key >> /etc/ceph/ssl/server.pem')
    # add soft link

    ssl_wc = os.popen('cat /etc/ceph/ssl/server.pem | wc -l').read().rstrip()
    ssl_certificate = os.popen("cat /etc/ceph/ssl/server.pem | grep 'BEGIN CERTIFICATE' | wc -l").read().rstrip()
    ssl_private = os.popen("cat /etc/ceph/ssl/server.pem | grep 'END RSA PRIVATE KEY' | wc -l").read().rstrip()
    if ssl_wc > 5 and ssl_certificate != 0 and ssl_private != 0:
        if not newIp:
            os.system('ln -s /lib/x86_64-linux-gnu/libcrypto.so.1.0.0 /lib/x86_64-linux-gnu/libcrypto.so')
            os.system('ln -s /lib/x86_64-linux-gnu/libssl.so.1.0.0 /lib/x86_64-linux-gnu/libssl.so')
        return {'result': 'success', 'reason': 'ssl created success'}
    else:
        return {'result': 'error', 'reason': 'ssl created failed'}


def create_target(tid, name):
    try:
        os.system('tgtadm --lld iscsi --mode target --op new --tid %s --targetname %s' % (tid, name))
        os.system('tgtadm --lld iscsi --op bind --mode target --tid %s -I ALL' % tid)
        os.system('echo "<target %s>" > /etc/tgt/conf.d/%s.conf' % (name, name))
        os.system('echo "\tbs-type rbd" >> /etc/tgt/conf.d/%s.conf' % name)
        os.system('echo "\t# lun end" >> /etc/tgt/conf.d/%s.conf' % name)
        os.system('echo "\tbsopts \\\"conf=/etc/ceph/ceph.conf\\\"" >> /etc/tgt/conf.d/%s.conf' % name)
        os.system('echo "\tcontroller_tid %s" >> /etc/tgt/conf.d/%s.conf' % (tid, name))
        os.system('echo "</target>" >> /etc/tgt/conf.d/%s.conf' % name)
        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': e}


def remove_target(tid, targetName):
    try:
        os.system('tgtadm --lld iscsi --mode target --op delete --tid %s' % tid)
        os.system('rm -rf /etc/tgt/conf.d/%s.conf' % targetName)
        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': e}


def create_lun(tid, lunid, poolName, rbdName, targetName):
    try:
        os.system(
            'tgtadm --lld iscsi --mode logicalunit --op new --tid %s --lun %s --backing-store %s/%s --bstype rbd' % (
                tid, lunid, poolName, rbdName))

        isExist = os.popen('ls /etc/tgt/conf.d | grep "%s.conf" | wc -l' % targetName).read().strip()
        if 0 == isExist:
            create_target(tid, targetName)

        orderList = []
        for line in open("/etc/tgt/conf.d/%s.conf" % targetName):
            if -1 != line.find("# lun end"):
                orderList.append("\t<backing-store %s/%s>" % (poolName, rbdName))
                orderList.append("\t\tlun %s" % lunid)
                orderList.append("\t</backing-store>")
            if '' != line.strip():
                orderList.append(line.replace('"', '\\\"').rstrip())

        for line in orderList:
            if line == "<target %s>" % targetName:
                os.system('echo "%s" > /etc/tgt/conf.d/%s.conf' % (line, targetName))
            else:
                os.system('echo "%s" >> /etc/tgt/conf.d/%s.conf' % (line, targetName))

        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': e}


def remove_lun(tid, lunid, poolName, rbdName, targetName):
    try:
        os.system('tgtadm --lld iscsi --mode logicalunit --op delete --tid %s --lun %s' % (tid, lunid))

        orderList = []
        number = 0

        for line in open("/etc/tgt/conf.d/%s.conf" % targetName):
            if -1 != line.find("<backing-store %s/%s>" % (poolName, rbdName)) or 1 == number or 2 == number:
                number += 1
            else:
                orderList.append(line.replace('"', '\\\"').rstrip())

        for line in orderList:
            if line == "<target %s>" % targetName:
                os.system('echo "%s" > /etc/tgt/conf.d/%s.conf' % (line, targetName))
            else:
                os.system('echo "%s" >> /etc/tgt/conf.d/%s.conf' % (line, targetName))

        return {'status': 'success'}
    except Exception, e:
        return {'status': 'error', 'reason': e}


def add_disk(osd_node, install_disk, cluster_deploy_dir):
    try:
        topo = osd_tree()['data']
        for info in topo['nodes']:
            if info['type'] == 'host' and info['name'] == osd_node:
                host_id = info['id']
                break

        for info in topo['nodes']:
            if host_id in info['children'] and info['type'] == 'rack' and info['name'].find('_ssd') == -1:
                rack_name = info['name']
                break
    except Exception, e:
        return {'success': False, 'error': 'get rack error', 'exception_error': e}

    try:
        os.system('cd /home/ceph-cluster && ceph-deploy --overwrite-conf config pull %s' % osd_node)
        os.system(
            "sed -i 's/osd_crush_update_on_start = false/osd_crush_update_on_start = true/g' /home/ceph-cluster/ceph.conf")
        add_disk_command = 'ceph-deploy --overwrite-conf osd create %s --zap-disk' % install_disk

        p = subprocess.Popen(add_disk_command.split(' '), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             cwd=cluster_deploy_dir)
        p.wait()
        results = p.stderr.read()

        os.system(
            "sed -i 's/osd_crush_update_on_start = true/osd_crush_update_on_start = false/g' /home/ceph-cluster/ceph.conf")
        os.system('cd /home/ceph-cluster && ceph-deploy --overwrite-conf admin %s' % osd_node)

        if results.find('is now ready for osd use'):
            return {'success': True, 'rack': rack_name}
        else:
            return {'success': False, 'rack': rack_name, 'error': 'add disk error'}
    except Exception, e:
        return {'success': False, 'rack': rack_name, 'error': 'add disk error', 'exception_error': e}


def initial_ssd(host, host_rack, ssd_disk_arry):
    try:
        df_ret = os.popen('df | grep /var/lib/ceph/osd/').read().rstrip()
        mount_info = df_ret.split('/dev/')
        ssd_osd = []
        for ssd_disk in ssd_disk_arry:
            for mount_disk in mount_info:
                if -1 != mount_disk.find(ssd_disk.split('/dev/')[1]):
                    ssd_osd.append('osd.' + mount_disk.split('/var/lib/ceph/osd/ceph-')[1].replace('\n', ''))
                    break

        crush_weight_arry = []
        topo = osd_tree()['data']
        for info in topo['nodes']:
            if info['type'] == 'osd' and info['name'] in ssd_osd:
                crush_weight_arry.append({'osd_name': info['name'], 'crush_weight': info['crush_weight']})
                continue

        if -1 == str(topo).find(host + '_ssd'):
            os.system('ceph osd crush add-bucket ' + host + '_ssd host')
            os.system('ceph osd crush move ' + host + '_ssd rack=' + host_rack + '_ssd')

        for osd in crush_weight_arry:
            os.system(
                'ceph osd crush set ' + osd['osd_name'] + ' ' + str(osd['crush_weight']) + ' host=' + host + '_ssd')

        return {'success': True, 'ssd_osd': ssd_osd}

    except Exception, e:
        return {'success': False, 'error': 'intial ssd error', 'exception_error': e}


def removeOsd(osdid):
    distro = platform.dist()[0]
    if distro == "centos":
        os.system('systemctl stop ceph-osd@{}.service'.format(osdid))
    else:
        os.system('stop ceph-osd id=%s' % osdid)
    os.system('umount /var/lib/ceph/osd/ceph-%s' % osdid)
    os.system('rm -r /var/lib/ceph/osd/ceph-%s' % osdid)
    os.system('ceph osd out %s' % osdid)
    os.system('ceph osd down %s' % osdid)
    os.system('ceph osd rm %s' % osdid)
    os.system('ceph osd crush remove osd.%s' % osdid)
    os.system('ceph osd crush remove device%s' % osdid)
    os.system('ceph auth del osd.%s' % osdid)


def remove_host(hostname):
    try:
        crush_map_str = os.popen('ceph osd crush dump -f json').read()
        crush_map_json = json.loads(crush_map_str)

        for node in crush_map_json['buckets']:
            if node['type_name'] == 'host' and (node['name'] == hostname or node['name'] == hostname + '_ssd'):
                for osd in node['items']:
                    removeOsd(osd['id'])

        os.system('ceph osd crush rm %s' % hostname)
        os.system('ceph osd crush rm %s_ssd' % hostname)
        return {'success': True}

    except Exception, e:
        return {'success': False, 'error': e}


def is_target_used(tid):
    targets = os.popen('tgt-admin -s').read().rstrip()

    lines = targets.split('\n')

    is_found = False
    num = 0
    for line in lines:
        if line.strip().startswith('Target %s:' % tid):
            is_found = True

        if is_found:
            if line.strip().startswith('LUN information:'):
                return 1 != (num - 4)
            num += 1

    return 'TargetNotFound'
