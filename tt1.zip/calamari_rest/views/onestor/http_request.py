# -*- coding:utf-8 -*-
# !/usr/bin/env python
"""
Author: dai.xinchun@h3c.com
"""
import json
import httplib


class HttpClient(object):
    """
    ADD BY D10039 2016/06/21
    HTTP请求客户端
    """

    def __init__(self, hostip='127.0.0.1', port=80, username=None, password=None):
        super(HttpClient, self).__init__()
        self.hostip = hostip
        self.port = int(port)
        self.username = username
        self.password = password
        self.auth_token = None
        self.TIMEOUT = 30

    def get(self, uri):
        """
        直接发送GET请求
        :param uri:
        :return:
        """
        http_client = None
        try:
            headers = {
                "Content-Type": "application/json"
            }

            http_client = httplib.HTTPConnection(self.hostip, self.port, timeout=self.TIMEOUT)
            http_client.request('GET', uri, '', headers)

            response = http_client.getresponse()

            # 状态码不为200则返回失败
            if 200 != response.status:
                return {'success': False, 'reason': response.reason}

            # 如果返回值为json字符串，则转换为json对象再返回
            try:
                result = json.loads(response.read())
            except ValueError:
                result = response.read()
            except Exception, e:
                print 'return msg can not json loads, %s' % e
                result = response.read()

            return {'success': True, 'data': result}
        except IOError:
            return {'success': False, 'reason': 'IOError'}
        except Exception, e:
            return {'success': False, 'reason': e}
        finally:
            if http_client:
                http_client.close()

    def get_server_monitoring_data(self, _servers, _server_info_results):
        """
        获取服务器的监控信息
        :param _servers: 服务器列表
        :return:
        """
        server_datas = {}
        server_datas1 = {}
        for server in _servers:
            graphite_uri = '/graphite/render?format=json&from=-2minute'
            graphite_uri += '&target=asPercent(servers.{server}.cpu.total.idle,' \
                            'sumSeries(servers.{server}.cpu.total.*))'.format(server=server)
            graphite_uri += '&target=servers.{server}.memory.%7BBuffers,Cached,MemFree,MemTotal%7D' \
                .format(server=server)
            result = self.get(graphite_uri)
            # 如果返回不是成功，则置为None
            if not result['success']:
                server_datas[server] = self._get_server_info_data(server, _server_info_results)
                # server_datas[server] = None
                continue

            server_datas1[server] = []
            # 遍历5列数据，返回值分别为cpu空闲率、内存Buffers、Cached、MemFree、MemTotal
            for col in range(5):
                # 从倒数第二个数据开始往回获取数据，防止取到空值
                for i in range(-1, -4, 1):
                    try:
                        current_data = result['data'][col]['datapoints'][i][0]
                        if current_data is not None:
                            server_datas1[server].append(current_data)
                            break
                    except:
                        # 保证在第一个没取到值时给此server赋值
                        server_datas[server] = self._get_server_info_data(server, _server_info_results)

        # 处理数据，格式化输出
        for server in server_datas1:
            # if not server_datas[server]:
            #     continue
            try:
                cpu_used = '%.2f' % (100 - server_datas1[server][0])
                mem_buffers = server_datas1[server][1]
                mem_cached = server_datas1[server][2]
                mem_free = server_datas1[server][3]
                mem_total = server_datas1[server][4]
                server_datas[server] = {
                    'cpu': cpu_used,
                    'mem': {
                        'buffers': mem_buffers,
                        'cached': mem_cached,
                        'total': mem_total,
                        'free': mem_free,
                        'used': mem_total - mem_free,
                        'share': 0,
                        'pct': "%.2f" % (100 * ((mem_total - mem_free - mem_buffers - mem_cached) / mem_total))
                    }
                }
            except:
                server_datas[server] = self._get_server_info_data(server, _server_info_results)
        return server_datas

    def _get_server_info_data(self, server, _server_info_results):
        """
        获取服务器的监控信息
        :param _servers: 服务器列表
        :return:
        """
        server_datas={}
        for _server_info in _server_info_results:
            server_name = _server_info.keys()[0]
            server_val = _server_info.values()[0]
            if server == server_name:
                for itm in server_val['mem']:
                    server_val['mem'][itm] = float(server_val['mem'][itm])
                have_used = server_val['mem']['total'] - server_val['mem']['free'] - server_val['mem']['buffers'] - server_val['mem']['cached']
                pct = "%.2f" % (100 * (have_used / server_val['mem']['total']))
                server_datas = {
                'cpu': server_val['cpu'],
                'mem': {
                    'buffers': server_val['mem']['buffers'],
                    'cached': server_val['mem']['cached'],
                    'total': server_val['mem']['total'],
                    'free': server_val['mem']['free'],
                    'used': server_val['mem']['total'] - server_val['mem']['free'],
                    'share': 0,
                    'pct': pct
                 }
                }
        return server_datas

