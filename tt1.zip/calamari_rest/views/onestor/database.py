# -*- coding:utf-8 -*-
import os
import json
import db
import time
import datetime

from calamari_rest.views.common import const


# Use leveldb to save table
# Author: dai.xinchun@h3c.com
# Date: 2015/07/16

def unique_check(items, key, value):
    try:
        for item in items:
            if str(value) == str(item[key]):
                return True

        return False
    except KeyError:
        return True
    except Exception:
        return True


def add_obj(table_name, args):
    try:
        if table_name == 'operationlog':
            result = db.insert(table_name, {
                'user': args[0],
                'ip': args[1],
                'time': args[2],
                'content': args[3],
                'status': args[4],
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
        # ADD BY KF7397 对象网关增加节点池/硬盘池字段
        elif table_name == 'gateway':
            result = db.insert(table_name, {
                'hostip': args[0],
                'hostname': args[1],
                'ssl': args[2],
                'status': args[3],
                'diskpool_name': args[4], 
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
        elif table_name == 'iscsitarget':
            target_name = args[1]
            isExist = unique_check(find_all(table_name), 'target_name', target_name)
            if isExist:
                return {'status': 'error', 'reason': u'target “%s” 已经存在' % target_name}

            # 容灾兼容分区，添加容灾标识 add by l11544 2017/5/25
            usage_mode = args[6] if len(args) > 6 else ''

            result = db.insert(table_name, {
                'target_id': args[0],
                'target_name': args[1],
                'iqn_switch': args[2],
                'iqns': args[3],
                'lun_id': args[4],
                'lun_num': args[5],
                'usage_mode': usage_mode,
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
        elif table_name == 'iscsilun':
            # 容灾兼容分区，添加容灾标识 add by l11544 2017/5/25
            usage_mode = args[9] if len(args) > 9 else ''

            result = db.insert(table_name, {
                'lun_id': args[0],
                'lun_name': args[1],
                'target_id': args[2],
                'target_name': args[3],
                'pool_name': args[4],
                'rbd_name': args[5],
                'rbd_size': args[6],
                'rbd_description': args[7],
                'matadata': args[8],
                'usage_mode': usage_mode,
                'update_time': time.mktime(datetime.datetime.now().timetuple())

            })
        elif table_name == 'snapshot':
            result = db.insert(table_name, {
                'snap_name': args[0],
                'size': args[1],
                'status': args[2],
                'snap_type': args[3],
                'rbd_name': args[4],
                'pool_name': args[5],
                'create_time': args[6],
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
        elif table_name == 'rbdlist':
            # 容灾兼容分区，添加容灾标识 add by l11544 2017/5/25
            usage_mode = args[10] if len(args) > 10 else ''

            result = db.insert(table_name, {
                'rbd_name': args[0],
                'rbd_size': str(args[1]),
                'pool_name': args[2],
                'rbd_type_convert': str(args[3]),
                'snap_nums': args[4],
                'is_clone': args[5],
                'baseon_snap_name': args[6],
                'lun_id': args[7],
                'rbd_description': args[8],
                'usage_mode': usage_mode,
                'matadata': args[9],
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
        elif table_name == 'gatewayuser':
            result = db.insert(table_name, {
                'uname': args[0],
                'email': str(args[1]),
                'max_bucket': args[2],
                'status': str(args[3]),
                'quota': args[4],
                'user_type': args[5],
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
        # 邮件告警特性 增加邮件配置表和邮件告警接收人表 add by d11564 2016/1/15
        elif table_name == 'mailServers':
            result = db.insert(table_name, {
                'server_address': args[0],
                'port_number': int(args[1]),
                'sender_address': args[2],
                'user_name': str(args[3]),
                'pass_word': args[4],
                'alarm_interval': args[5],
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
        elif table_name == 'alarmReceiver':
            result = db.insert(table_name, {
                'name': args[0],
                'phone': args[1],
                'email': args[2],
                'type': str(args[3]),
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
        elif table_name == 'highavailableconfig':
            if args[7] == '0' and args[5] == '1':
                result = db.insert(table_name, {
                    'vip': args[0],
                    'master': args[1],
                    'slave': args[2],
                    'vrid': args[3],
                    'priority_list': args[4],
                    'ha_switch': args[5],
                    'balance_switch': args[6],
                    'disaster_switch': args[7],
                    'disaster_info' : args[8],
                    'state': 'running',
                    'update_time': time.mktime(datetime.datetime.now().timetuple())
                })
            else:
                result = db.insert(table_name, {
                    'vip': args[0],
                    'master': args[1],
                    'slave': args[2],
                    'vrid': args[3],
                    'priority_list': args[4],
                    'ha_switch': args[5],
                    'balance_switch': args[6],
                    'disaster_switch': args[7],
                    'disaster_info' : args[8],
                    'update_time': time.mktime(datetime.datetime.now().timetuple())
                })
        # 邮件告警特性 增加邮件配置表和邮件告警接收人表 end by d11564 2016/1/15
        # Begin add by d11564 NAS项目
        elif table_name == 'nas_server_new':
            result = db.insert(table_name, {
                'hostname': args[0],
                'hostip': args[1],
                'use': args[2],
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
            # End by d11564 NAS项目
        # BEGIN ADD BY D10039 2016/08/08 FOR HANDY HA
        elif table_name == 'handyha':
            result = db.insert(table_name, {
                'vip': args[0],
                'master': args[1],
                'slave': args[2],
                'vrid': args[3],
                'priority_list': args[4],
                'master_public_ip': args[5],
                'slave_public_ip': args[6],
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
        # END ADD BY D10039 2016/08/08 FOR HANDY HA
        elif table_name == 'disasterBackup':
            result = db.insert(table_name, {
                'pool_name':args[0],
                'rbd_name':args[1],
                'backup_pool':args[2],
                'backup_rbd':args[3],
                'host_retention_time':args[4],
                'alternate_retention_time':args[5],
                'backup_interval':args[6],
                'target_info':args[7],
                'original_block':args[8],
                'backup_block':args[9],
                'is_open':args[10],
                'update_time': time.mktime(datetime.datetime.now().timetuple())
            })
        return {'status': 'success', 'result': result}
    except ValueError:
        return {'status': 'error', 'reason': 'ValueError'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def del_obj(table, _id):
    try:
        db.delete_one(table, [{'id': int(_id)}])

        return {'status': 'success'}
    except ValueError:
        return {'status': 'error', 'reason': 'ValueError'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def list_objs(table_name):
    try:
        if table_name == 'clusterconfig' or const.ONESTTOR_PROCESS_CONFIG_KEY == table_name:
            objs = os.popen('ceph config-key get %s --connect-timeout 60' % table_name).read()
            if objs == '':
                return {"status": "error", "reason": "clusterconfig not exist"}

            return json.loads(objs)
        else:
            objs = db.get_all_with_currentid(table_name)
            if 'current_id' not in objs:
                return {"current_id": 0, "%s" % table_name: []}

            objs[table_name].sort(key=lambda item: item['update_time'] \
                if 'update_time' in item else 1, reverse=True)
            return objs
    except KeyError:
        return {'status': 'error', 'reason': 'KeyError'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def update_obj(table_name, _id, args):
    try:
        _id = int(_id)
        if table_name == 'operationlog':
            result = db.update_one(table_name, {
                'id': _id,
                '$set': {
                    'user': args[0],
                    'ip': args[1],
                    'time': args[2],
                    'content': args[3],
                    'status': args[4],
                    'update_time': time.mktime(datetime.datetime.now().timetuple())
                }
            })
        elif table_name == 'gateway':
            result = db.update_one(table_name, {
                'id': _id,
                '$set': {
                    'hostip': args[0],
                    'hostname': args[1],
                    'ssl': args[2],
                    'status': args[3],
                    'update_time': time.mktime(datetime.datetime.now().timetuple())
                }
            })
        elif table_name == 'iscsitarget':
            # 容灾兼容分区，添加容灾标识 add by l11544 2017/5/25
            usage_mode = args[6] if len(args) > 6 else find_one(table_name, [{'id': _id}])[0]['usage_mode']

            result = db.update_one(table_name, {
                'id': _id,
                '$set': {
                    'target_id': args[0],
                    'target_name': args[1],
                    'iqn_switch': args[2],
                    'iqns': args[3],
                    'lun_id': args[4],
                    'lun_num': args[5],
                    'usage_mode': usage_mode,
                    'update_time': time.mktime(datetime.datetime.now().timetuple())
                }
            })
        elif table_name == 'iscsilun':
            # 容灾兼容分区，添加容灾标识 add by l11544 2017/5/25
            usage_mode = args[9] if len(args) > 9 else find_one(table_name, [{'id': _id}])[0]['usage_mode']

            result = db.update_one(table_name, {
                'id': _id,
                '$set': {
                    'lun_id': args[0],
                    'lun_name': args[1],
                    'target_id': args[2],
                    'target_name': args[3],
                    'pool_name': args[4],
                    'rbd_name': args[5],
                    'rbd_size': args[6],
                    'rbd_description': args[7],
                    'matadata': args[8],
                    'usage_mode': usage_mode,
                    'update_time': time.mktime(datetime.datetime.now().timetuple())

                }
            })
        elif table_name == 'snapshot':
            result = db.update_one(table_name, {
                'id': _id,
                '$set': {
                    'snap_name': args[0],
                    'size': args[1],
                    'status': args[2],
                    'snap_type': args[3],
                    'rbd_name': args[4],
                    'pool_name': args[5],
                    'create_time': args[6],
                    'update_time': time.mktime(datetime.datetime.now().timetuple())
                }
            })
        elif table_name == 'rbdlist':
            # 容灾兼容分区，添加容灾标识 add by l11544 2017/5/25
            usage_mode = args[10] if len(args) > 10 else find_one(table_name, [{'id': _id}])[0]['usage_mode']

            result = db.update_one(table_name, {
                'id': _id,
                '$set': {
                    'rbd_name': args[0],
                    'rbd_size': str(args[1]),
                    'pool_name': args[2],
                    'rbd_type_convert': str(args[3]),
                    'snap_nums': args[4],
                    'is_clone': args[5],
                    'baseon_snap_name': args[6],
                    'lun_id': args[7],
                    'rbd_description': args[8],
                    'matadata': args[9],
                    'usage_mode': usage_mode,
                    'update_time': time.mktime(datetime.datetime.now().timetuple())
                }
            })
        elif table_name == 'gatewayuser':
            result = db.update_one(table_name, {
                'id': _id,
                '$set': {
                    'uname': args[0],
                    'email': str(args[1]),
                    'max_bucket': args[2],
                    'status': str(args[3]),
                    'quota': args[4],
                    'update_time': time.mktime(datetime.datetime.now().timetuple())
                }
            })
            # 邮件告警特性 增加修改邮件配置表和邮件告警接收人表 add by d11564 2016/1/15
        elif table_name == 'mailServers':
            result = db.update_one(table_name, {
                'id': _id,
                '$set': {
                    'server_address': args[0],
                    'port_number': int(args[1]),
                    'sender_address': args[2],
                    'user_name': str(args[3]),
                    'pass_word': args[4],
                    'alarm_interval': args[5],
                    'update_time': time.mktime(datetime.datetime.now().timetuple())
                }
            })
        elif table_name == 'alarmReceiver':
            result = db.update_one(table_name, {
                'id': _id,
                '$set': {
                    'name': args[0],
                    'phone': args[1],
                    'email': args[2],
                    'type': str(args[3]),
                    'update_time': time.mktime(datetime.datetime.now().timetuple())
                }
            })
        # MODIFY BY D10039 2016/08/08 FOR HANDY HA
        elif table_name == 'highavailableconfig' or table_name == 'handyha':
            if len(args) > 5:
                result = db.update_one(table_name, {
                    'id': _id,
                    '$set': {
                        'vip': args[0],
                        'slave': args[1],
                        'priority_list': args[2],
                        'disaster_info': args[3],
                        'balance_switch': args[4],
                        'state': args[5],
                        'update_time': time.mktime(datetime.datetime.now().timetuple())
                }
                })
            else:
                result = db.update_one(table_name, {
                    'id': _id,
                    '$set': {
                        'vip': args[0],
                        'slave': args[1],
                        'priority_list': args[2],
                        'disaster_info': args[3],
                        'balance_switch': args[4],
                        'update_time': time.mktime(datetime.datetime.now().timetuple())
                }
            })
        elif table_name == 'disasterBackup':
            result = db.update_one(table_name, {
                'id':_id,
                '$set':{
                'original_block':args[0],
                'host_retention_time':args[1],
                'backup_interval':args[2],
                'alternate_retention_time':args[3],
                'is_open':args[4],
                'update_time':  time.mktime(datetime.datetime.now().timetuple())
                }
            })          
        return {'status': 'success', 'result': result}
    except ValueError:
        return {'status': 'error', 'reason': 'ValueError'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def get_obj_byname(table_name, params):
    result = db.find(table_name, [{
        'pool_name': params[0],
        'rbd_name': params[1]
    }])
    return result


# end database common

def find_by_target_id(_id):
    results = db.find('iscsilun', [{'target_id': int(_id)}])
    return None if [] == results else results


def del_rbd_by_lun_id(lun_id):
    try:
        db.delete_one('rbdlist', [{'lun_id': int(lun_id)}])

        return {'status': 'success'}
    except ValueError:
        return {'status': 'error', 'reason': 'ValueError'}
    except Exception, e:
        return {'status': 'error', 'reason': str(e)}


def find_by_id(table, _id):
    try:
        return db.find(table, [{'id': int(_id)}])[0]
    except ValueError:
        return 'ValueError'
    except Exception:
        return 'NotFound'


def find_one(table, params):
    return db.find_one(table, params)


def find_all(table):
    return db.getAll(table)


def find(table, params):
    return db.find(table, params)


def delete(table, params):
    return db.delete(table, params)


def delete_one(table, params):
    return db.delete_one(table, params)


def update(table, params):
    return db.update(table, params)


def update_one(table, params):
    return db.update_one(table, params)


def table_init():
    tables = ['gateway', 'gatewayuser', 'highavailableconfig', 'iscsitarget', 'iscsilun', 'operationlog', 'snapshot',
              'rbdlist']
    for table in tables:
        os.popen("ceph config-key put %s '{\"current_id\": 0, \"%s\": []}'" % (table, table)).read()
    return {'status': 'success'}


def retry_get_database(table_name):
    """
    调用重复的接口获取数据库内信息
    :param table_name: 数据库名
    :return:
    """
    data = db.sub_command("get", "%s" % table_name)
    return json.loads(data)


def retry_put_database(table_name, data_json):
    """
    调用重复的接口获取数据库内信息
    :param table_name: 数据库名
    :param data_json: 数据
    :return:
    """
    db.sub_command("put", table_name + " '%s'" % json.dumps(data_json))

# db的使用方法
# db.insert(table_name, {'name': yourname})
# 返回值是个数组

# db.find(table_name, [{'name': yourname}])
# 返回值是个数组

# db.find_one(table_name, [{'name': yourname}])
# 返回值是个数组

# db.delete(table_name, [{'name': yourname}])
# 返回值是个数组

# db.delete_one(table_name, [{'name': yourname}])
# 返回值是个数组

# db.update(table_name, {'name': yourname, '$set': {'ege': yourege}})
# 返回值是个数组

# db.update_one(table_name, {'name': yourname, '$set': {'ege': yourege}})
# 返回值是个数组

# db.getAll(table_name)
# 返回值是个数组

# db.get_all_with_currentid(table_name)
# 返回值是个数组

# db.clear_table(table_name)
# 删除数据表，切勿随意使用
