# coding=utf-8
import os
import json
import misc
import threading

# PN: 201704280308 三网合一部署集群，创建分区的时候，断handy节点的网络，
# 3分钟后恢复网络，发现断网之前的操作日志记录被删除
import logging
log = logging.getLogger('django.request')
from calamari_rest.decorator2 import retry
from calamari_common.cmdprocess import ceph_database_command, TimeoutExpired, DatebaseError
# END by l11544 2017/4/29


MAX_LENGTH = 100000
COMMAND_TIMEOUT = ' --connect-timeout 60'
COMMAND_PREFIX_TIMEOUT = 'timeout 60 '


@retry(times=5, raise_exc=True)
def sub_command(handle_type, string_data=""):
    """
    多线程处理数据库数据操作
    :param string_data: 类型
    :return: String
    :Data 2017/4/29
    :Author l11544
    """
    # 若非list类型需要多加如一个空格
    if 'list' != handle_type:
        string_data = " " + string_data
    comm_data = COMMAND_PREFIX_TIMEOUT + "ceph config-key " + handle_type + string_data + COMMAND_TIMEOUT
    try:
        log.debug('excute command {0}'.format(comm_data))
        comm_result = ceph_database_command(comm_data, 60, True)
        if 0 == comm_result['code']:
            return comm_result['stdout']
        elif 'list' != handle_type and 2 == comm_result['code']:
            log.warning('"%s" result is None, detail is %s', comm_data, comm_result['stderr'])
            return ''
        else:
            log.error(comm_result['stderr'])
            raise DatebaseError
    except TimeoutExpired:
        log.error("excute command {0} timeout, time is 60 seconds".format(comm_data[:100]))
        raise TimeoutExpired
    except Exception, e:
        log.error("excute command {0} error, reason is {1}".format(comm_data[:100], e))
        raise e


def insert_to_table(table_name, params):
    table_exist = misc.is_table_exist(table_name)
    result = []
    log.debug('table is {0}, params is {1}'.format(table_name, params))

    def add_to_table(table_name, params, result):
        tables = [item for item in json.loads(sub_command("list")) if item.startswith(table_name + '__')]
        _cv = threading.Condition()
        event = threading.Event()
        event1 = threading.Event()

        def task(table, params, result):
            if not event.is_set():
                data_result = sub_command("get", "%s" % table)
                with _cv:
                    if event.is_set():
                        return
                    if len(data_result + json.dumps(params)) <= MAX_LENGTH:
                        data = json.loads(data_result)
                        data[table_name].append(params)
                        result.append(params)
                        sub_command("put", table + " '%s'" % json.dumps(data))
                        event1.set()
                        event.set()

        t_list = []
        for table in tables:
            t = threading.Thread(target=task, args=(table, params, result))
            t_list.append(t)
            t.start()
        for item in t_list:
            item.join()
        if not event1.is_set():
            if tables == []:
                new_table_name = table_name + '__' + str(0)
            else:
                new_table_name = table_name + '__' + str((max([int(item.split('__')[1]) for item in tables]) + 1))
            data = '{"%s": []}' % table_name
            data = json.loads(data)
            data[table_name].append(params)
            result.append(params)
            sub_command("put", new_table_name + " '%s'" % json.dumps(data))

    if len(json.dumps(params)) >= MAX_LENGTH:
        return False
    data = sub_command("get", table_name)
    if data == '':
        if table_exist:
            raise misc.CephCommandError(
                'Failed to get leveldb table "{0}" when insert.'.format(table_name))
        data = '{"%s": [], "current_id": 1}' % table_name
        params['id'] = 1
        data = json.loads(data)
        data[table_name].append(params)
        result.append(params)
        result = sub_command("put", table_name + " '%s'" % json.dumps(data))
    else:
        data_obj = json.loads(data)
        params['id'] = data_obj['current_id'] + 1
        if len(data + json.dumps(params)) >= MAX_LENGTH:
            add_to_table(table_name, params, result)
        else:
            data_obj[table_name].append(params)
            result.append(params)
        data_obj['current_id'] = data_obj['current_id'] + 1
        sub_command("put", table_name + " '%s'" % json.dumps(data_obj))
    return result


def clear_table(table_name):
    tables = [table for table in
              json.loads(sub_command("list")) if table.startswith(table_name + '__') or table == table_name]
    t_list = []
    for table in tables:
        t = threading.Thread(
            target=lambda name: os.popen(COMMAND_PREFIX_TIMEOUT + 'ceph config-key del %s' % name + COMMAND_TIMEOUT),
            args=(table,))
        t_list.append(t)
        t.start()
    for t in t_list:
        t.join()
    return True


def getAll(table_name):
    tables = [table for table in
              json.loads(sub_command("list")) if table.startswith(table_name + '__') or table == table_name]
    result = []

    def read_table(table, result):
        data = sub_command("get", table)
        if data != '':
            result += json.loads(data)[table_name]

    t_list = []
    for table in tables:
        t = threading.Thread(target=read_table, args=(table, result,))
        t_list.append(t)
        t.start()
    for item in t_list:
        item.join()
    return result


def update(table_name, params):
    tables = [table for table in
              json.loads(sub_command('list')) if table.startswith(table_name + '__') or table == table_name]
    all_data = {}

    def task(table, all_data):
        table_result = sub_command("get", table)
        if table_result != '':
            result_data = json.loads(table_result)
            all_data[table] = result_data
        else:
            raise misc.CephCommandError(
                'Failed to get leveldb table "{0}" when update.'.format(table_name))

    t_list = []
    for table in tables:
        t = threading.Thread(target=task, args=(table, all_data))
        t_list.append(t)
        t.start()
    for t in t_list:
        t.join()
    update_table = []
    result = []
    for key, value in params.items():
        if key != '$set':
            for name, data in all_data.items():
                for item in data[table_name]:
                    if key in item and item[key] == value:
                        for set_key, set_value in params['$set'].items():
                            item[set_key] = set_value
                        if update_table.count(name) == 0:
                            update_table.append(name)
                        result.append(item)

    def save_ceph(table, data):
        sub_command("put", table + " '%s'" % json.dumps(data))

    t_list = []
    for table in update_table:
        t = threading.Thread(target=save_ceph, args=(table, all_data[table]))
        t_list.append(t)
        t.start()
    for t in t_list:
        t.join()
    return result


def get_currentId(table_name):
    data = sub_command("get", " " + table_name)
    if data != '':
        data = json.loads(data)
        return data['current_id']


def update_one(table_name, params):
    tables = [table for table in
              json.loads(sub_command("list")) if table.startswith(table_name + '__') or table == table_name]
    all_data = {}

    def task(table, all_data):
        table_result = sub_command("get", table)
        if table_result != '':
            data_result = json.loads(table_result)
            all_data[table] = data_result
        else:
            raise misc.CephCommandError(
                'Failed to get leveldb table "{0}" when update.'.format(table_name))
    t_list = []
    for table in tables:
        t = threading.Thread(target=task, args=(table, all_data))
        t_list.append(t)
        t.start()
    for t in t_list:
        t.join()
    update_table = []
    is_find = False
    result = []
    for key, value in params.items():
        if key != '$set':
            is_find = False
            for name, data in all_data.items():
                for item in data[table_name]:
                    if key in item and item[key] == value:
                        for set_key, set_value in params['$set'].items():
                            item[set_key] = set_value
                        is_find = True
                        if update_table.count(name) == 0:
                            update_table.append(name)
                        result.append(item)
                        break
                if is_find == True:
                    break
    for table in update_table:
        sub_command("put", table + " '%s'" % json.dumps(all_data[table]))
    return result


def find_one(table_name, params):
    result = []
    data = getAll(table_name)
    for param in params:
        key, value = param.items()[0]
        for item in data:
            if key in item and item[key] == value:
                result.append(item)
                break
    return result


def find(table_name, params):
    tables = [table for table in
              json.loads(sub_command("list")) if table.startswith(table_name + '__') or table == table_name]
    result = []

    def task(table, params, result):
        table_result = sub_command("get", table)
        if table_result != '':
            data = json.loads(table_result)
            for param in params:
                key, value = param.items()[0]
                for item in data[table_name]:
                    if key in item and item[key] == value:
                        result.append(item)

    t_list = []
    for table in tables:
        t = threading.Thread(target=task, args=(table, params, result))
        t_list.append(t)
        t.start()
    for t in t_list:
        t.join()
    return result


def delete(table_name, params):
    tables = [table for table in
              json.loads(sub_command('list')) if table.startswith(table_name + '__') or table == table_name]
    result = []

    def task(table, params, result):
        table_result = sub_command("get", table)
        if table_result != '':
            is_find = False
            data = json.loads(table_result)
            temp = []
            for param in params:
                key, value = param.items()[0]
                for item in data[table_name]:
                    if key in item and value == item[key]:
                        result.append(item)
                        temp.append(item)
                        is_find = True
            if is_find == True:
                for item in temp:
                    data[table_name].remove(item)
                if data[table_name] == [] and table.find('__') != -1:
                    sub_command("del", table)
                else:
                    sub_command("put " + table + " '%s'" % json.dumps(data))
        else:
            raise misc.CephCommandError(
                'Failed to get leveldb table "{0}" when delete.'.format(table_name))
    t_list = []
    for table in tables:
        t = threading.Thread(target=task, args=(table, params, result))
        t_list.append(t)
        t.start()
    for t in t_list:
        t.join()
    return result


def delete_one(table_name, params):
    tables = [table for table in
              json.loads(sub_command("list")) if table.startswith(table_name + '__') or table == table_name]

    def task(table, result):
        table_result = sub_command("get", table)
        if table_result != '':
            result[table] = json.loads(table_result)
        else:
            raise misc.CephCommandError(
                'Failed to get leveldb table "{0}" when delete.'.format(table_name))
    all_data = {}
    t_list = []
    for table in tables:
        t = threading.Thread(target=task, args=(table, all_data))
        t_list.append(t)
        t.start()
    for t in t_list:
        t.join()

    result = []
    find_table = []
    for param in params:
        is_find = False
        key, value = param.items()[0]
        for name, data in all_data.items():
            for item in data[table_name]:
                if key in item and item[key] == value:
                    data[table_name].remove(item)
                    if find_table.count(name) == 0:
                        find_table.append(name)
                    result.append(item)
                    is_find = True
                    break
            if is_find == True:
                break
    for item in find_table:
        if all_data[item][table_name] == [] and item.find('__') != -1:
            sub_command("del", item)
        else:
            sub_command("put", item + " '%s'" % json.dumps(all_data[item]))
    return result


def insert(table_name, params):
    return insert_to_table(table_name, params)


def _get_all_with_name(table_name):
    tables = [table for table in
              json.loads(sub_command('list')) if table.startswith(table_name + '__') or table == table_name]
    result = {}

    def task(table, result):
        table_result = sub_command("get", table)
        if table_result != '':
            result[table] = json.loads(table_result)

    t_list = []
    for table in tables:
        t = threading.Thread(target=task, args=(table, result))
        t_list.append(t)
        t.start()
    for t in t_list:
        t.join()
    return result


def get_all_with_currentid(table_name):
    all_data = _get_all_with_name(table_name)
    result = {}
    result[table_name] = []
    for name, data in all_data.items():
        if name == table_name:
            result['current_id'] = data['current_id']
        result[table_name] += data[table_name]
    return result
