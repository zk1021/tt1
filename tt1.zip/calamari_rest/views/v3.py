#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
import time
import os
# from onestor import const
from rest_framework.response import Response
from calamari_rest.views.rpc_view import RPCViewSet
from calamari_rest.views.common.forward import ForwardView
from calamari_rest.views.common.forward import OPLOG_USER, OPLOG_IP, LOG_KEY
from calamari_rest.views.common.forward import (
     COMP_UM,
     COMP_FS,
     COMP_PATCH,
     COMP_MULTICLUSTER,
     OP_LIST_USER_PERMISSION,
     OP_USER_CHECK_SAMEUSER,
     OP_PATCH_UPLOAD,
     OP_PATCH_DELETE,
     OP_MULTICLUSTER_QUERY
     )
from calamari_rest.views.onestor_common import ONEStorCommon
LOG = logging.getLogger('django.request')

PATCH_PATH = '/opt/h3c/patch/'


class UniStorViewSet(ForwardView):

    def __init__(self, leader_router, *args, **kwargs):
        super(UniStorViewSet, self).__init__(*args, **kwargs)
        self.leader_router = leader_router
        self.get_url_path = getattr(self, 'get_url_path')

    def get_request(self, request, fsid=''):
        """
        GET请求的公共入口
        :param request: 请求
        :param fsid: 集群ID
        :return: Response对象
        """
        data = request.GET.copy()
        try:
            url_path = self.get_url_path(request.path, fsid)
            comp_op = self.leader_router.url_get_op[url_path, 'GET']
            for key in data:
                if data[key] == 'false':
                    data[key] = False
                elif data[key] == 'true':
                    data[key] = True
            data[LOG_KEY] = False
            self.before_request_um(comp_op, data, request)
            return self.send_request_to_leader(comp_op, data, request, is_get=True)
        except KeyError, e:
            LOG.exception(e)
            return Response()

    def post_request(self, request, fsid=''):
        """
        POST请求的公共入口
        :param request: 请求
        :param fsid: 集群ID
        :return: Response对象
        """
        data = request.DATA.copy()
        url_path = self.get_url_path(request.path, fsid)
        comp_op = self.leader_router.url_get_op[url_path, 'POST']
        self.before_request_fs_import_user(comp_op, data, request)
        self.before_request_upload_patch(comp_op, data, request)
        return self.before_request(comp_op, data, request)

    def delete_request(self, request, fsid=''):
        """
        DELETE请求的公共入口
        :param request: 请求
        :param fsid: 集群ID
        :return: Response对象
        """
        data = request.GET.copy()
        url_path = self.get_url_path(request.path, fsid)
        comp_op = self.leader_router.url_get_op[url_path, 'DELETE']
        for key in data:
            if data[key] == 'false':
                data[key] = False
            elif data[key] == 'true':
                data[key] = True
        self.before_request_delete_patch(comp_op, data)
        return self.before_request(comp_op, data, request)

    def patch_request(self, request, fsid=''):
        """
        PATCH请求的公共入口
        :param request: 请求
        :param fsid: 集群ID
        :return: Response对象
        """
        data = request.DATA.copy()
        url_path = self.get_url_path(request.path, fsid)
        comp_op = self.leader_router.url_get_op[url_path, 'PATCH']
        return self.before_request(comp_op, data, request)

    def before_request(self, comp_op, data, request):
        """
        发送请求之前的操作
        :param comp_op: (COPM,OP)
        :param data: 请求参数
        :param request: 请求
        :return:
        """
        data[OPLOG_USER] = request.user.username
        data[OPLOG_IP] = request.META.get('REMOTE_ADDR')
        return self.send_request_to_leader(comp_op, data, request)

    @staticmethod
    def before_request_um(comp_op, data, request):
        """
        Handy的用户和用户组发送请求之前的操作
        :param comp_op:  (COPM,OP)
        :param data: 请求参数
        :param request: 请求
        :return:
        """
        comp, op = comp_op
        if (COMP_UM == comp and OP_LIST_USER_PERMISSION == op) or \
                (COMP_MULTICLUSTER == comp and OP_MULTICLUSTER_QUERY == op):
            data['user_name'] = request.user.username

    @staticmethod
    def before_request_fs_import_user(comp_op, data, request):
        if comp_op == (COMP_FS, OP_USER_CHECK_SAMEUSER):
            upload_file = request.FILES['infile']
            safe_name = upload_file.name.replace(",", "").encode('utf-8')
            tmp_file_name = '/tmp/%s_%s' % (long(time.time()), safe_name)
            with open(tmp_file_name, 'wb') as tmp_file:
                tmp_file.write(upload_file.read())
                tmp_file.close()
            data['file_name'] = tmp_file_name

    def before_request_upload_patch(self, comp_op, data, request):
        if comp_op == (COMP_PATCH, OP_PATCH_UPLOAD):
            upload_file = request.FILES['patch']
            safe_name = upload_file.name.replace(",", "").encode('utf-8')
            self.generate_file_path(PATCH_PATH)
            tmp_file_name = PATCH_PATH + safe_name
            with open(tmp_file_name, 'wb') as tmp_file:
                tmp_file.write(upload_file.read())
                tmp_file.close()
            data['file_name'] = tmp_file_name

    @staticmethod
    def before_request_delete_patch(comp_op, data):
        if comp_op == (COMP_PATCH, OP_PATCH_DELETE):
            data['file_name'] = PATCH_PATH + data['file_name']

    @staticmethod
    def generate_file_path(file_path):
        """
        生成临时的License文件存储路径
        :param file_name: 文件名称
        :return: None
        :author: zhangyingnan <zhangyingnan@h3c.com>
        """
        common = ONEStorCommon()
        if not os.path.exists(file_path):
            common.exec_local_cmd('mkdir -p %s && chmod 755 %s' % (file_path, file_path))
        #  适配CentOS
        if os.path.exists('/etc/redhat-realease'):
            common.lf.exec_local_cmd('chown apache:apache %s' % file_path)
        else:
            common.exec_local_cmd('chown www-data:www-data %s' % file_path)

