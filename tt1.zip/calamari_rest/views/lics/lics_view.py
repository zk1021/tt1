#!/usr/bin/env python
# coding: utf-8

import logging
import traceback
import json
import csv
import os
import codecs
import time

from onestor import message
from onestor.config import CephConf
from calamari_rest.views.onestor import database
from calamari_rest.views.onestor_common import ONEStorCommon
from onestor.plat.lics import licsmessage
from onestor.plat.lics import lics_common
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view
from rest_framework.decorators import permission_classes
from rest_framework.response import Response
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.cache import never_cache
from django import http
from calamari_rest.views.common import util, const, errno, op_log
from calamari_rest.constant import COUNTRYS
from calamari_rest.common import is_email, is_name, is_phone
from calamari_web import docker_get_leader_ip


LICENSE_DIR = '/opt/h3c/lics/'
LOG = logging.getLogger('django.request')


class LicsViewSet(ONEStorCommon):
    """
    license管理视图
    """
    def __init__(self, *args, **kwargs):
        super(LicsViewSet, self).__init__(*args, **kwargs)

    @util.send_response(
        op=op_log.OP_BACKUP_LICENSE,
        ret_type=const.RETURN_TYPE_2
    )
    def backup_license(self, request, fsid):
        """
        备份激活的License文件
        :param request: 页面请求
        :param fsid: 集群id
        :return: None
        :author: zhangyingnan <zhangyingnan@h3c.com>
        """
        yield op_log.OP_BACKUP_LICENSE

        op = licsmessage.OP_LICS_BACKUP
        user = request.user.username or u'Anonymous'
        ip = request.META.get('REMOTE_ADDR', None)
        data = request.GET.copy()
        data['.OPLOG_user'] = user
        data['.OPLOG_ip'] = ip
        result = common_request_lics(op, data)
        if result['response'].is_successful():
            license_file = result['response'].data['license_file']
            file_name = 'license_file'
            self.generate_temp_file_path(file_name)
            file_path = const.LICS_FILE_PATH + file_name
            with open(file_path, 'wb') as temp_file:
               temp_file.write(license_file)
        else:
            LOG.error('backup license file error, the reason is %s', result['response'].result)
            raise errno.ONEStorError(result['response'].result)

    @util.send_response(
        op=op_log.OP_EXPORT_AUTHCODE,
        ret_type=const.RETURN_TYPE_2
    )
    def export_auth_code(self, request, fsid):
        """
        导出License的授权条码信息
        :param request: 页面请求
        :param fsid: 集群id
        :return: 授权条码文件
        :author: zhangyingnan <zhangyingnan@h3c.com>
        """
        yield op_log.OP_EXPORT_AUTHCODE

        op = licsmessage.OP_LICS_EXPORT_AUTH_CODE
        user = request.user.username or u'Anonymous'
        ip = request.META.get('REMOTE_ADDR', None)
        data = request.GET.copy()
        data['.OPLOG_user'] = user
        data['.OPLOG_ip'] = ip
        result = common_request_lics(op, data)
        if result['response'].is_successful():
            auth_codes = ''
            vendor_check_result = self.check_x10000(None, None, None, is_handy=True)
            vendor_name = vendor_check_result['product_info']['product']
            file_name = '{0}LicenseAuthCode.csv'.format(vendor_name)
            self.generate_temp_file_path(file_name)
            for _sn in result['response'].data['auth_codes']:
                auth_codes += _sn + '\n'
            file_path = const.LICS_FILE_PATH + file_name
            with open(file_path, 'wb') as temp_file:
               temp_file.write(auth_codes)
        else:
            LOG.error('export license authcode error, the reason is %s', result['response'].result)
            raise errno.ONEStorError(result['response'].result)

    def generate_temp_file_path(self, file_name):
        """
        生成临时的License文件存储路径
        :param file_name: 文件名称
        :return: None
        :author: zhangyingnan <zhangyingnan@h3c.com>
        """
        file_path = const.LICS_FILE_PATH + file_name
        if not os.path.exists(const.LICS_FILE_PATH):
            self.exec_local_cmd('mkdir -p %s && chmod 755 %s' % (const.LICS_FILE_PATH, const.LICS_FILE_PATH))
        if os.path.exists(file_path):
            self.exec_local_cmd('rm -rf %s' % file_path)
        # 适配CentOS
        if os.path.exists('/etc/redhat-realease'):
            self.exec_local_cmd('chown apache:apache %s' % const.LICS_FILE_PATH)
        else:
            self.exec_local_cmd('chown www-data:www-data %s' % const.LICS_FILE_PATH)

    @staticmethod
    def init_trial_license():
        """
        集群安装时初始化license
        :return: None
        :author: zhangyingnan <zhangyingnan@h3c.com>
        """
        op = licsmessage.OP_LICS_INIT
        result = common_request_lics(op)
        if result['response'].is_successful():
            LOG.info('initialize trial license successful')
        else:
            LOG.error('initialize trial license error, the reason is %s', result['response'].result)
            raise errno.ONEStorError(result['response'].result)

    @staticmethod
    def check_x10000(host_list, user, passwd, is_handy=False):
        op = licsmessage.OP_CHECK_X10000
        data = {'host_list': host_list if isinstance(host_list, list) else [host_list],
                'user': user,
                'passwd': passwd} if not is_handy else {'is_handy': True}
        result = common_request_lics(op, data)
        if result['response'].is_successful():
            if is_handy:
                return result['response'].data
            if isinstance(host_list, list):
                return result['response'].data
            else:
                is_x10000 = result['response'].data[host_list]['is_X10000']
                return is_x10000
        else:
            raise errno.ONEStorError(result['response'].result)

    @staticmethod
    def check_license():
        """
        用户登录时检查license是否合法
        :return: dict
        :author: zhangyingnan <zhangyingnan@h3c.com>
        """
        op = licsmessage.OP_LICS_CHECK
        result = common_request_lics(op)
        if result['response'].is_successful():
            return {'success': True}
        else:
            LOG.error('check license error, the reason is %s', result['response'].result)
            return {'success': False, 'reason': result['response'].result}

    @staticmethod
    def get_license_features():
        """
        读取当前License的特性
        :return: dict
        :author: zhangyingnan <zhangyingnan@h3c.com>
        """
        is_docker = os.path.exists("/.dockerenv")
        op = licsmessage.OP_LICS_FEATURES_QUERY
        result = common_request_lics(op)
        if result['response'].is_successful():
            return {'success': True, 'rt': result['response'].data, 'is_docker': is_docker}
        else:
            LOG.error('get license features error %s', result['response'].result)
            return {'success': False, 'reason': result['response'].result[2], 'is_docker': is_docker}

    def check_diskpool_capacity(self, disk_pool_list, host_list):
        """
        对新添加的硬盘池容量进行校验
        :param disk_pool_list: 硬盘池列表
        :param host_list: 主机列表
        :return: dict
        :author: zhangyingnan <zhangyingnan@h3c.com>
        """
        op = licsmessage.OP_LICS_ADD_DISKPOOL
        data = self.get_cluster_capacity(disk_pool_list, host_list)
        result = common_request_lics(op, data)
        if result['response'].is_successful():
            LOG.info('deploying cluster and check the capacity of disk pool successful ')
            return {'success': True}
        else:
            LOG.error('deploying cluster and check the capacity of disk pool error,the reason is %s', result['response'].result)
            return {'success': False, 'reason': result['response'].result[2]}

    def get_cluster_capacity(self, disk_pool_list, host_list):
        """
        获取三种存储服务硬盘池的硬盘总容量信息
        :param disk_pool_list: 硬盘池列表 [{"diskpool_name":"dp",
               "diskpool_service_type": "rbd",
               "nodepool_list": ["np"],
               "data_disk_type": "SSD",
               "flashcache_disk_type": "None",
               "journal_disk_type": "None",
               "flashcache_size": 40,
               "journal_size": 10,
               "description": ""
               }]
        :param host_list: 主机列表
        :return: dict
        :author: zhangyingnan <zhangyingnan@h3c.com>
        """
        bs_add_capacity = 0
        os_add_capacity = 0
        fs_add_capacity = 0
        if disk_pool_list:
            for disk_pool in disk_pool_list:
                disk_pool_name = disk_pool['diskpool_name']
                if disk_pool['diskpool_service_type'] == 'rbd':
                    bs_add_capacity += self.get_add_capacity(disk_pool_name, host_list)
                if disk_pool['diskpool_service_type'] == 'rgw':
                    os_add_capacity += self.get_add_capacity(disk_pool_name, host_list)
                if (disk_pool['diskpool_service_type'] == 'cephfs'
                        or disk_pool['diskpool_service_type'] == 'cephfs-data'
                        or disk_pool['diskpool_service_type'] == 'cephfs-metadata'):
                    fs_add_capacity += self.get_add_capacity(disk_pool_name, host_list)
        result = {
             'blockstorage': bs_add_capacity,
             'objectstorage': os_add_capacity,
             'filestorage': fs_add_capacity
        }
        return result

    def get_add_capacity(self, disk_pool_name, host_info):
        """
        获取某个硬盘池下的硬盘总容量信息
        :param disk_pool_name: 硬盘池名称
        :param host_list: 主机列表 [{"name": "node79",
                     "remark": "",
                     "dp": {"data": ['sdc:85899345920:SATA', 'sdc:85899345920:SATA'], "journal":[], "flash":[]},
                     "dp2": {"data": ['sdc:85899345920:SATA', 'sdc:85899345920:SATA'], "journal":[], "flash":[]},
                     "dp3": {"data": ['sdc:85899345920:SATA', 'sdc:85899345920:SATA'], "journal":[], "flash":[]},
                     "dp4": {"data": [], "journal":[], "flash":[]}
                    }]
        :return: 容量信息（单位 byte）
        :author: zhangyingnan <zhangyingnan@h3c.com>
        """
        capacity_sum = 0
        if not host_info:
            return capacity_sum
        if isinstance(host_info, list):
            for host in host_info:
                capacity_sum += self.get_disks_data(disk_pool_name, host)
        else:
            capacity_sum = self.get_disks_data(disk_pool_name, host_info)
        return capacity_sum

    @staticmethod
    def get_disks_data(disk_pool_name, host):
        capacity = 0
        if disk_pool_name not in host:
            return capacity
        host_disks = host[disk_pool_name]
        disks_data = host_disks['data']
        if disks_data:
            for disk in disks_data:
                capacity += int(disk.split(':')[1])
        return capacity

    @staticmethod
    def is_soft_version():
        return lics_common.check_product_version()


@api_view(['POST'])
@permission_classes((AllowAny,))
@ensure_csrf_cookie
@never_cache
def generate_license(request):
    op = licsmessage.OP_LICS_REGISTER
    user = request.user.username or u'Anonymous'
    ip = request.META.get('REMOTE_ADDR', None)
    name = request.DATA['name']
    company = request.DATA['company']
    country = request.DATA['country']
    city = request.DATA['city']
    email = request.DATA['email']
    phone = request.DATA.get('phone', None)
    isuis = request.DATA.get('isuis', None)
    if country not in COUNTRYS:
        return Response({'success': False, 'error': errno.ERROR_PARAMETER})
    if is_name(name) and is_name(company) and is_name(city) and is_email(email):
        if phone and not is_phone(phone):
            return Response({'success': False, 'error': errno.ERROR_PARAMETER})
        try:
            data = {'name': name, 'country': country, 'company': company, 'city': city, 'email': email, 'phone': phone,
                    'isuis': isuis, '.OPLOG_user': user,
                    '.OPLOG_ip': ip}
            result = common_request_lics(op, data)
        except Exception as e:
            error = traceback.format_exc()
            LOG.error(error)
            return Response({'success': False, 'error': errno.ERROR_GENERATE_FILE})
        if result['response'].is_successful():
            return Response({'success': True, 'rt': result['response'].data['license']})
        else:
            return Response({'success': False, 'error': errno.ERROR_GENERATE_FILE})
    else:
        return Response({'success': False, 'error': errno.ERROR_PARAMETER})


@api_view(['POST'])
@permission_classes((AllowAny,))
def upload_license(request):
    op = licsmessage.OP_LICS_ACTIVATE
    user = request.user.username or u'Anonymous'
    ip = request.META.get('REMOTE_ADDR', None)
    license_file = request.FILES['license']
    data = {'license_file': license_file.read(),
            '.OPLOG_user': user,
            '.OPLOG_ip': ip
            }
    result = common_request_lics(op, data)
    _time = int(time.time() * 1000)
    if result['response'].is_successful():
        return Response({'success': True, 'rt': result['response'].data['features']})
    else:
        LOG.error('activate license error, the reason is %s', result['response'].result)
        return Response({'success': False, 'error': result['response'].result})


@api_view(['POST'])
@permission_classes((AllowAny,))
def pre_upload_license(request):
    op = licsmessage.OP_LICS_PREACTIVATE
    user = request.user.username or u'Anonymous'
    ip = request.META.get('REMOTE_ADDR', None)
    license_file = request.FILES['license']
    data = {'license_file': license_file.read(),
            '.OPLOG_user': user,
            '.OPLOG_ip': ip
            }
    result = common_request_lics(op, data)
    if result['response'].is_successful():
        return Response({'success': True, 'license_file_type': result['response'].data['license_file_type']})
    else:
        LOG.error('activate license error, the reason is %s', result['response'].result)
        return Response({'success': False, 'error': result['response'].result})


@api_view(['POST'])
@permission_classes((AllowAny,))
def download_license(request):
    file_name = request.DATA['file_name']
    filename = 'host_info'
    if file_name.endswith('.tar.gz'):
        filename = 'host_info.tar.gz'
    with open(LICENSE_DIR + file_name) as f:
        data = f.read()
        response = http.HttpResponse()
        response['Content-Disposition'] = 'attachment; filename="{}"'.format(filename)
        response['Content-Type'] = 'text/plain'
        response.write(data)
        return response


@api_view(['GET'])
@permission_classes((AllowAny,))
def query_license(request):
    """
    获取License信息
    :param request: 页面请求
    :return: 响应结果
    :author: zhangyingnan <zhangyingnan@h3c.com>
    """
    is_docker = os.path.exists("/.dockerenv")
    op = licsmessage.OP_LICS_QUERY
    result = common_request_lics(op, request.GET.copy())
    if result['response'].is_successful():
        return Response({'success': True, 'rt': result['response'].data, 'is_docker': is_docker})
    else:
        LOG.error('get license info error , the reason is %s', result['response'].result)
        return Response({'success': False, 'error': result['response'].result, 'is_docker': is_docker})


@api_view(['POST'])
@permission_classes((AllowAny,))
@ensure_csrf_cookie
def connect_lics_server(request):
    op = licsmessage.OP_LICS_SERVER_CONFIG
    user = request.user.username or u'Anonymous'
    ip = request.META.get('REMOTE_ADDR', None)
    data = request.DATA.copy()
    data['.OPLOG_user'] = user
    data['.OPLOG_ip'] = ip
    result = common_request_lics(op, data)
    return Response(result['response'].to_json())


@api_view(['POST'])
@permission_classes((AllowAny,))
@ensure_csrf_cookie
def disconnect_lics_server(request):
    op = licsmessage.OP_LICS_SERVER_DISCONNECT
    user = request.user.username or u'Anonymous'
    ip = request.META.get('REMOTE_ADDR', None)
    data = request.DATA.copy()
    data['.OPLOG_user'] = user
    data['.OPLOG_ip'] = ip
    result = common_request_lics(op, data)
    return Response(result['response'].to_json())


@api_view(['GET'])
@permission_classes((AllowAny,))
def query_lics_server(request):
    """
    获取License信息
    :param request: 页面请求
    :return: 响应结果
    :author: zhangyingnan <zhangyingnan@h3c.com>
    """
    op = licsmessage.OP_LICS_SERVER_QUERY
    result = common_request_lics(op)
    return Response(result['response'].to_json())


def common_request_lics(op, data={}):
    """
    license 通用请求方法
    :param data: 请求参数
    :param op: 操作码
    :return: 响应结果
    :author: zhangyingnan <zhangyingnan@h3c.com>
    """
    request_msg = licsmessage.make_request(op)
    request_msg.data = data
    LOG.debug('send request to onestor-leader ,the request is {0}'.format(request_msg))
    if CephConf().multicluster_ip is None:
        client = message.Messenger.create_leaderclient(
            host='localhost', timeout=licsmessage.estimate_time(op))
    else:
        if os.path.exists("/.dockerenv"):
            _host = docker_get_leader_ip()
        else:
            _host = '127.0.0.1'
        client = message.Messenger.create_multicluster_client(
            host=_host, timeout=licsmessage.estimate_time(op))
    if not client:
        response_msg = message.Response(request_msg.req_id)
        response_msg.result = errno.ERR_CONNECT
        return {'response': response_msg, 'req_id': request_msg.req_id}

    response = client.send_request(request_msg)
    LOG.debug('get response from onestor-leader ,the response is {0},{1},{2}'
              .format(response.result[0], response.result[1], response.data))
    return {'response': response, 'req_id': request_msg.req_id}
