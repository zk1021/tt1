#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
import time

from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.decorators import permission_classes
from calamari_rest.views.common.forward import ForwardView
from calamari_rest.views.common.forward import \
    OPLOG_USER, OPLOG_IP, LOG_KEY, COMP_UM, COMP_FS, OP_LIST_USER_PERMISSION, OP_USER_CHECK_SAMEUSER

LOG = logging.getLogger('django.request')


@permission_classes((AllowAny,))
class UniStorAllowAnyViewSet(ForwardView):

    def __init__(self, leader_router, *args, **kwargs):
        super(UniStorAllowAnyViewSet, self).__init__(*args, **kwargs)
        self.leader_router = leader_router
        self.get_url_path = getattr(self, 'get_url_path')

    def get_request(self, request, fsid=''):
        """
        GET请求的公共入口
        :param request: 请求
        :param fsid: 集群ID
        :return: Response对象
        """
        data = request.GET.copy()
        try:
            url_path = self.get_url_path(request.path, fsid)
            comp_op = self.leader_router.url_get_op[url_path, 'GET']
            for key in data:
                if data[key] == 'false':
                    data[key] = False
                elif data[key] == 'true':
                    data[key] = True
            data[LOG_KEY] = False
            self.before_request_um(comp_op, data, request)
            return self.send_request_to_leader(comp_op, data, request, is_get=True)
        except KeyError, e:
            LOG.exception(e)
            return Response()

    def post_request(self, request, fsid=''):
        """
        POST请求的公共入口
        :param request: 请求
        :param fsid: 集群ID
        :return: Response对象
        """
        data = request.DATA.copy()
        url_path = self.get_url_path(request.path, fsid)
        comp_op = self.leader_router.url_get_op[url_path, 'POST']
        self.before_request_fs_import_user(comp_op, data, request)
        return self.before_request(comp_op, data, request)

    def delete_request(self, request, fsid=''):
        """
        DELETE请求的公共入口
        :param request: 请求
        :param fsid: 集群ID
        :return: Response对象
        """
        data = request.GET.copy()
        url_path = self.get_url_path(request.path, fsid)
        comp_op = self.leader_router.url_get_op[url_path, 'DELETE']
        for key in data:
            if data[key] == 'false':
                data[key] = False
            elif data[key] == 'true':
                data[key] = True
        return self.before_request(comp_op, data, request)

    def patch_request(self, request, fsid=''):
        """
        PATCH请求的公共入口
        :param request: 请求
        :param fsid: 集群ID
        :return: Response对象
        """
        data = request.DATA.copy()
        url_path = self.get_url_path(request.path, fsid)
        comp_op = self.leader_router.url_get_op[url_path, 'PATCH']
        return self.before_request(comp_op, data, request)

    def before_request(self, comp_op, data, request):
        """
        发送请求之前的操作
        :param comp_op: (COPM,OP)
        :param data: 请求参数
        :param request: 请求
        :return:
        """
        data[OPLOG_USER] = request.user.username
        data[OPLOG_IP] = request.META.get('REMOTE_ADDR')
        return self.send_request_to_leader(comp_op, data, request)

    @staticmethod
    def before_request_um(comp_op, data, request):
        """
        Handy的用户和用户组发送请求之前的操作
        :param comp_op:  (COPM,OP)
        :param data: 请求参数
        :param request: 请求
        :return:
        """
        comp, op = comp_op
        if COMP_UM == comp and OP_LIST_USER_PERMISSION == op:
            data['user_name'] = request.user.username

    @staticmethod
    def before_request_fs_import_user(comp_op, data, request):
        if comp_op == (COMP_FS, OP_USER_CHECK_SAMEUSER):
            upload_file = request.FILES['infile']
            safe_name = upload_file.name.replace(",", "").encode('utf-8')
            tmp_file_name = '/tmp/%s_%s' % (long(time.time()), safe_name)
            with open(tmp_file_name, 'wb') as tmp_file:
                tmp_file.write(upload_file.read())
                tmp_file.close()
            data['file_name'] = tmp_file_name
