#!/usr/bin/env python
# coding: utf-8

"""
主机管理回滚
"""

import os
import logging

from calamari_rest.views.common.cmd import *
from calamari_rest.views.common import const
from calamari_rest.views.backup import messanger
from calamari_common.config import CalamariConfig
from calamari_rest.views.host.host_util import HostUtil
from rest_framework.request import Request

LOG = logging.getLogger('django.request')
config = CalamariConfig()


class HostFinalRollback(HostUtil):
    """
    主机管理finally和回滚方法类
    """

    @staticmethod
    def __remove_cocurrent_flag(session, flag):
        """
        删除并发保护的标识
        Date: 2016/12/07
        """
        if flag in session and not session[flag]:
            if os.path.exists(flag):
                os.remove(flag)
            del session[flag]

    def add_host_finally(self, *args):
        """
        部署主机finally执行函数
        Date: 2016/12/07
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 删除并发保护标识
        self.__remove_cocurrent_flag(session, const.FLAG_ADDING_OSD)
        # 删除部署进度
        if os.path.exists(const.FLAG_DEPLOY_STATUS):
            os.remove(const.FLAG_DEPLOY_STATUS)
        # 还原/etc/hosts配置
        if const.NEED_RESTORE_ETC_HOSTS in session:
            try:
                self._recovery_etc_hosts()
            finally:
                del session[const.NEED_RESTORE_ETC_HOSTS]
        if const.NEED_RESTORE_CLUSTER_CONF in session:
            del session[const.NEED_RESTORE_CLUSTER_CONF]
        if const.NEED_RESTORE_ONEBACKUP in session:
            del session[const.NEED_RESTORE_ONEBACKUP]
        # 删除 /tmp/tgt 目录 add by h13051 PN:201704140460
        self.exec_local_cmd('rm -rf /tmp/tgt')

    def add_host_single_rollback(self, *args):
        """
        手动部署回滚
        Date: 2016/12/07
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 回滚创建的机架
        if const.NEED_RESTORE_RACK in session:
            try:
                rack_info = request.DATA['rack_info']
                rack_name = rack_info.split(',')[0]
                if rack_info.split(',')[1] == '0':
                    LOG.info('begin rollback rack...')
                    self._remove_rack(rack_name)
            finally:
                del session[const.NEED_RESTORE_RACK]
        # begin add by d11564 2017/10/20 多MDS项目
        # 回滚MDS服务器
        if const.NEED_RESTORE_MDS in session:
            try:
                node_ip = request.DATA['node_ip']
                host_name = request.DATA['osd_node']
                LOG.info('begin roll back mds...')
                self._remove_mds(node_ip, host_name, 'MDS')
            finally:
                del session[const.NEED_RESTORE_MDS]
        # 删除主机
        if const.NEED_DELETE_HOST in session:
            try:
                node_ip = request.DATA['node_ip']
                host_name = request.DATA['osd_node']
                roles = self.get_host_roles_by_name(host_name)
                ping_result = self.test_ping_single(node_ip)
                # 在线主机删除主机
                LOG.info('begin roll back host...')
                if ping_result:
                    self._process_remove_host(host_name, roles, offline=False)
                # 离线主机仅清除Handy上的onestor_hosts、cluster_hosts
                else:
                    self._process_remove_host(host_name, roles, offline=True)
            finally:
                del session[const.NEED_DELETE_HOST]
        # end add by d11564 2017/10/20 多MDS项目
        # 回滚集群配置
        if const.NEED_RESTORE_CLUSTER_CONF in session:
            try:
                node_ip = request.DATA['node_ip']
                host_name = request.DATA['osd_node']
                LOG.info('begin clear cluster config...')
                self._clear_cluster_config({host_name: node_ip})
            finally:
                del session[const.NEED_RESTORE_CLUSTER_CONF]
        # 回滚onebackup元数据
        if const.NEED_RESTORE_ONEBACKUP in session:
            try:
                disaster_ips = session[const.NEED_RESTORE_ONEBACKUP]
                # 检查是否存在容灾，若不存在，则不再删除主机灾备IP信息
                if self.disaster_pool_exist():
                    messanger.send_remove_backup_host_msg(disaster_ips)
            finally:
                del session[const.NEED_RESTORE_ONEBACKUP]

        LOG.info('finish rollback when add host single.')
        # end add by d11564 2017/10/20 多MDS项目

    def remove_host_finally(self, *args):
        """
        删除主机finally执行函数
        Date: 2016/12/07
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 移除标识硬盘删除状态的文件 For 维护模式
        if const.FLAG_REMOVING_OSD not in session:
            session[const.FLAG_REMOVING_OSD] = self._check_cocurrent_event(const.FLAG_REMOVING_OSD)
        if not session[const.FLAG_REMOVING_OSD]:
            self.exec_local_cmd(CMD_RM_FILE.format(
                const.PROGRESS_FILE.format(const.OP_REMOVE_DISK)))
        # 删除并发保护标识
        self.__remove_cocurrent_flag(session, const.FLAG_REMOVING_OSD)
        if const.NEED_RESTORE_ONEBACKUP in session:
            del session[const.NEED_RESTORE_ONEBACKUP]

    def remove_host_rollback(self, *args):
        """
        删除主机rollback执行函数
        Date: 2016/12/07
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 回滚onebackup元数据
        if const.NEED_RESTORE_ONEBACKUP in session:
            try:
                disaster_ips = session[const.NEED_RESTORE_ONEBACKUP]
                # 检查是否存在容灾，若不存在，则不再添加灾备IP信息
                if self.disaster_pool_exist():
                    messanger.send_add_backup_host_msg(disaster_ips)
            finally:
                del session[const.NEED_RESTORE_ONEBACKUP]
                LOG.info('finish rollback when remove host.')

    def add_disk_finally(self, *args):
        """
        增加硬盘finally执行函数
        Date: 2016/12/07
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 删除并发保护标识
        self.__remove_cocurrent_flag(session, const.FLAG_ADDING_OSD)

    def add_disk_batch_finally(self, *args):
        """
        批量增加硬盘finally执行函数
        Date: 2018/01/13
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 删除并发保护标识
        self.__remove_cocurrent_flag(session, const.FLAG_ADDING_OSD)

    def remove_disk_finally(self, *args):
        """
        删除硬盘finally执行函数
        Date: 2016/12/07
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 移除标识硬盘删除状态的文件 For 维护模式
        if const.FLAG_REMOVING_OSD not in session:
            session[const.FLAG_REMOVING_OSD] = self._check_cocurrent_event(const.FLAG_REMOVING_OSD)
        if not session[const.FLAG_REMOVING_OSD]:
            self.exec_local_cmd(CMD_RM_FILE.format(
                const.PROGRESS_FILE.format(const.OP_REMOVE_DISK)))
        # 删除并发保护标识
        self.__remove_cocurrent_flag(session, const.FLAG_REMOVING_OSD)

    def add_host_batch_rollback(self, *args):
        """
        自动部署回滚
        Date: 2016/12/07
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # begin add by d11564 2017/10/20 多MDS项目
        #     回滚MDS服务器
        if const.NEED_RESTORE_MDS in session:
            try:
                all_node_ip = request.DATA['all_node_ip']
                node_ip_array = all_node_ip.split(',')
                LOG.info('begin roll back mds...')
                for node_ip in node_ip_array:
                    host_name = self.ip_to_name(node_ip)
                    self._remove_mds(node_ip, host_name, 'MDS')
            finally:
                del session[const.NEED_RESTORE_MDS]
        # 删除主机
        if const.NEED_DELETE_HOST in session:
            try:
                all_node_ip = request.DATA['all_node_ip']
                node_ip_array = all_node_ip.split(',')
                for node_ip in node_ip_array:
                    host_name = self.ip_to_name(node_ip)
                    roles = self.get_host_roles_by_name(host_name)
                    ping_result = self.test_ping_single(node_ip)
                    # 在线主机删除主机
                    if ping_result:
                        self._process_remove_host(host_name, roles, offline=False)
                    # 离线主机仅清除Handy上的onestor_hosts、cluster_hosts
                    else:
                        self._process_remove_host(host_name, roles, offline=True)
            finally:
                del session[const.NEED_DELETE_HOST]
        # end add by d11564 2017/10/20 多MDS项目
        # 回滚集群配置
        if const.NEED_RESTORE_CLUSTER_CONF in session:
            try:
                nodes_info = session[const.NEED_RESTORE_CLUSTER_CONF]
                LOG.info('begin clear cluster config for %s...', nodes_info)
                self._clear_cluster_config(nodes_info)
            finally:
                del session[const.NEED_RESTORE_CLUSTER_CONF]
        # 回滚onebackup元数据
        if const.NEED_RESTORE_ONEBACKUP in session:
            try:
                disaster_ips = session[const.NEED_RESTORE_ONEBACKUP]
                # 检查是否存在容灾，若不存在，则不再删除主机灾备IP信息
                if self.disaster_pool_exist():
                    messanger.send_remove_backup_host_msg(disaster_ips)
            finally:
                del session[const.NEED_RESTORE_ONEBACKUP]

        LOG.info('finish rollback when add host batch.')

    def add_mon_finally(self, *args):
        """
        增加MON finally执行函数
        Date: 2016/12/21
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 删除并发保护标识
        self.__remove_cocurrent_flag(session, const.FLAG_OPERATE_MON)
        # 还原/etc/hosts配置
        if const.NEED_RESTORE_ETC_HOSTS in session:
            try:
                self._recovery_etc_hosts()
            finally:
                del session[const.NEED_RESTORE_ETC_HOSTS]
        if const.NEED_RESTORE_CLUSTER_CONF in session:
            del session[const.NEED_RESTORE_CLUSTER_CONF]
        # 删除 /tmp/tgt 目录 add by h13051 PN:201704140460
        self.exec_local_cmd('rm -rf /tmp/tgt')

    def add_mon_rollback(self, *args):
        """
        增加MON回滚
        Date: 2016/12/21
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 回退ceph.conf配置
        if const.NEED_RESTORE_CEPH_CONF in session:
            try:
                self._recovery_ceph_conf()
            finally:
                del session[const.NEED_RESTORE_CEPH_CONF]
        # 回退NTP配置
        if const.NEED_RESTORE_NTP in session:
            try:
                self._recovery_ntp_conf()
            finally:
                del session[const.NEED_RESTORE_NTP]
        # 回退zk配置
        if const.NEED_RESTORE_ZK in request.session:
            try:
                self._recovery_back_zk_conf()
            finally:
                del session[const.NEED_RESTORE_ZK]
        # 回退集群配置（一定要在最后执行）
        if const.NEED_RESTORE_CLUSTER_CONF in session:
            try:
                node_ip = request.DATA['node_ip']
                host_name = self.ip_to_name(node_ip)
                # 如果获取不到主机名则不做以下的回滚
                if host_name != node_ip:
                    LOG.info('begin remove mon from quorum...')
                    self._remove_mon_from_quorum(host_name, 2)
                    LOG.info('begin clear cluster config...')
                    self._clear_cluster_config({host_name: node_ip})
            finally:
                del session[const.NEED_RESTORE_CLUSTER_CONF]
        LOG.info('finish rollback when add mon.')

    def remove_mon_finally(self, *args):
        """
        删除MON finally执行函数
        Date: 2016/12/21
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 删除并发保护标识
        self.__remove_cocurrent_flag(session, const.FLAG_OPERATE_MON)

    def remove_mon_rollback(self, *args):
        """
        删除MON回滚
        Date: 2016/12/21
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 回退ceph.conf配置
        if const.NEED_RESTORE_CEPH_CONF in session:
            try:
                self._recovery_ceph_conf()
            finally:
                del session[const.NEED_RESTORE_CEPH_CONF]
        # 回退NTP配置
        if const.NEED_RESTORE_NTP in session:
            try:
                self._recovery_ntp_conf()
            finally:
                del session[const.NEED_RESTORE_NTP]
        # 回退zk配置
        if const.NEED_RESTORE_ZK in request.session:
            try:
                self._recovery_back_zk_conf()
            finally:
                del session[const.NEED_RESTORE_ZK]
        LOG.info('finish rollback when remove mon.')
