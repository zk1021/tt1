#!/usr/bin/env python
# coding: utf-8

"""
主机管理工具类
"""

import os
import re
import json
import time
import datetime
import logging
import threading
import base64
import platform
from calamari_rest.views.common import cmd
from calamari_rest.views.common import const
from calamari_rest.views.common import errno
from calamari_rest.views.common import regexp
from calamari_common.config import CalamariConfig, ONEStorConfig
from calamari_rest.views.common.util import HandyUtil

import onestor
from onestor import errno as leadererrno
from onestor.fs import fsmessage as fsmsg
from onestor.plat.cm.host import hostmessage as hostmsg
from calamari_rest.common import send_request_onestord
from calamari_rest.views.onestor import database

try:
    from onestor import db
    from onestor.db.db_op import OpClusterHost
except ImportError as e:
    pass

LOG = logging.getLogger('django.request')
config = CalamariConfig()
cluster_behind_net = u'存储后端网'
cluster_head_net = u'存储前端网'
manage_net = u'管理网'


class HostUtil(HandyUtil):
    """
    主机管理工具类
    """
    def __init__(self, *args, **kwargs):
        super(HostUtil, self).__init__(*args, **kwargs)
        self.checked_hosts_ip = dict()
        self.network_check_success = False

    def _check_name_and_ip(self, nodes_ip, user, passwd):
        """
        检查主机名或主机IP是否已经出现在/etc/onestor_hosts中
        :param  nodes_ip 主机IP ['2.1.1.1', '2.1.1.2']
        Date: 2016/12/07
        """
        cluster_hosts = self.get_cluster_hosts_from_config()
        LOG.info('get cluster_hosts: %s', cluster_hosts)
        for node_ip in nodes_ip:
            # 获取主机名
            node_name = self.cmd_remote(node_ip, passwd, const.HOST_NAME, user)
            # 获取业务网段IP
            public_ip = self.get_node_public_ip(node_ip, passwd, user)
            # 根据业务网IP查找/etc/onestor_hosts中是否能找到主机名
            _host_name_match = [host['hostname'] for host in cluster_hosts if
                                public_ip == host['hostip']]
            # 找到了主机名但是与当前增加的主机不一致，则抛出异常
            if 0 != len(_host_name_match) and node_name != _host_name_match[0]:
                raise errno.ONEStorError(errno.ERROR_HOSTIP_EXIST, node_ip)
            # 根据主机名查找/etc/onestor_hosts中是否能找到主机IP
            _host_ip_match = [host['hostip'] for host in cluster_hosts if
                              node_name == host['hostname']]
            # 找到了主机IP但是与当前增加的主机不一致，则抛出异常
            if 0 != len(_host_ip_match) and public_ip != _host_ip_match[0]:
                raise errno.ONEStorError(errno.ERROR_HOSTNAME_EXIST, node_ip)

    def _check_host_offset_time(self, node_ips, passwd, offset_time=const.HOST_TIME_DIFF):
        """
        检查目标主机与集群的时间差是否超过5分钟
        Date: 2016/12/07
        """
        for index, node_ip in enumerate(node_ips):
            # 获取主MON节点
            quorum_leader_name = self.get_leader_mon()
            # 远程登录到目标节点上获取当前时间
            get_time_cmd = 'date +%s'
            time_node = self.exec_local_cmd("/opt/h3c/bin/python %s/handy_common.py exec_remote_cmd %s %s \"%s\" \"%s\"" %
                                             (self.filepath, node_ip, 'root', passwd, get_time_cmd))
            LOG.info('check time of node "%s": "%s"' % (node_ip, time_node))
            # 远程登录到主MON节点上获取当前时间
            time_mon = self.exec_remote_ssh_cmd(quorum_leader_name, get_time_cmd)
            LOG.info('check time of mon "%s": "%s"' % (quorum_leader_name, time_mon))
            time_diff = abs(int(time_node) - int(time_mon))
            # 如果时间差超过默认5分钟（300秒），抛出异常
            if time_diff > offset_time:
                raise errno.ONEStorError(errno.ERROR_HUGE_TIME_DIFF, node_ip)

    def _check_mon_offset_time(self, node_ip, offset_time=const.HOST_TIME_DIFF):
        """
        检查新加监控节点和集群的时间偏移
        :param node_ip: IP
        :param offset_time:时间偏移量
        :return: None
        """
        LOG.info('check mon offset time start')
        # 获取当前NTP状态
        cluster_info = self.get_clusterconfig()
        ntp_status = cluster_info['ntp_close']
        # 获取时间偏移
        ntp_server, quorum_leader_ip = self.get_ntp_server(ntp_status)
        host_offset_info = self.config_ntp_server_offset(node_ip, ntp_server, quorum_leader_ip, ntp_status)
        LOG.info('ntp_status is: %s, ntp_server: %s, quorum_leader_ip: %s,  host_offset_info result: %s',
                 ntp_status, ntp_server, quorum_leader_ip, host_offset_info)
        # 对于未配置情况若获取时间偏移失败，则通过获取时间戳的方式比较
        if not host_offset_info['status']:
            LOG.warning("ntpdate -q get time failed, ntp status may be not normal, please check")
            time_info_all = self.multi_thread_task([node_ip, quorum_leader_ip], "date +%s", ssh=True)
            LOG.info("ntp_status is: %s, offset time_info_all: %s", ntp_status, time_info_all)
            host_offset_time = abs(float(time_info_all[node_ip]) - float(time_info_all[quorum_leader_ip]))
        else:
            host_offset_time = host_offset_info['offset_time']
        if host_offset_time > offset_time:
            LOG.error("host time offset with mon leader, time is %s bigger than %s", host_offset_time, offset_time)
            raise errno.ONEStorError(errno.ERROR_HUGE_TIME_DIFF, node_ip)

    def _check_linux_host_name(self, hostnames, role=const.ROLE_STOR):
        """
        检查主机名称是否满足部署要求，主要有以下三点：
        1、不能为localhost
        2、只能以字母开头，只包含字母、数字、中划线
        3、如果是存储节点，不能与现有crush中出现的名称相同（包括default、maintain、ssd_root等）
        :param hostnames list 需要校验的主机名
        Date: 2017/01/22
        """
        LOG.info('begin check linux host name...')
        for hostname in hostnames:
            if const.LOCALHOST == hostname:
                raise errno.ONEStorError(errno.ERROR_UNSUPPORT_HOST_NAME)
            if not re.match(regexp.checkRegExp['linux_host_name'], hostname):
                raise errno.ONEStorError(errno.ERROR_UNSUPPORT_HOST_NAME)
            if const.ROLE_STOR == role and not self.handle_validate_bucket(hostname):
                raise errno.ONEStorError(errno.ERROR_REPEAT_BUCKET, '主机')

    def _check_rack_name(self, rack_name):
        """
        检查机架名称是否满足部署要求
        Date: 2017/01/22
        """
        LOG.info('begin check rack name...')
        if not self.handle_validate_bucket(rack_name):
            raise errno.ONEStorError(errno.ERROR_REPEAT_BUCKET, '机架')

    @staticmethod
    def _clear_network_error_flag(op):
        """
        删除网络故障标识
        Date: 2016/12/07
        """
        if os.path.exists(const.NETWORK_FAULT_TMP_FILE):
            with open(const.NETWORK_FAULT_TMP_FILE, 'rb') as f:
                if op == f.readline().strip():
                    os.system(cmd.CMD_RM_FILE.format(const.NETWORK_FAULT_TMP_FILE))

    @staticmethod
    def __get_disk_size(hosts_info, node_ip, disks):
        """
        增加主机、增加硬盘计算硬盘容量
        Date: 2016/12/07
        """
        hosts_info = json.loads(hosts_info)[node_ip]
        if not hosts_info['connect']:
            raise errno.ONEStorError(errno.ERROR_GET_HOST_DISK_INFO, node_ip)
        # 累加硬盘容量
        added_disks = disks.split(',')
        added_disks = [disk.split(':')[0] for disk in added_disks]
        all_disk_byte = 0
        for disk in added_disks:
            all_disk_byte += int(hosts_info['disks'][disk]['size_byte'])
        return all_disk_byte

    @staticmethod
    def __get_disk_size_batch():
        """
        批量部署主机计算硬盘容量
        Date: 2016/12/07
        """
        pass

    def _check_license(self, node_ip, disk_pool_list, host_list, user=None, passwd=None, batch=False, in_cluster = False):
        """
        检查License容量
        :param disks - 增加的硬盘，格式为/dev/sdb:1,/dev/sdc:1
        Date: 2016/12/07
        """
        LOG.info('begin check license ...')
        hosts_info_cmd = '''/opt/h3c/bin/python /opt/h3c/salt/salt/shell/host_info_ip.py list \
            --nodes={nodes}'''.format(nodes=node_ip)
        if user and passwd:
            hosts_info_cmd += ' --user={user} --passwd={passwd}'.format(user=user, passwd=passwd)
        hosts_info = self.exec_local_ssh_cmd(hosts_info_cmd)
        LOG.info('_check_license ret is: %s', hosts_info)
        if '' == hosts_info:
            raise errno.ONEStorError(errno.ERROR_GET_HOST_INFO)

        self.check_license(disk_pool_list, host_list, node_ip, user, passwd, batch, in_cluster)

    def _check_host_network(self, nodes, user, passwd, check_cluster_network=True,
                            check_mask=False, check_manage_network=True, check_public_network=True):
        """
        检查业务网IP、存储前端网IP和存储后端网IP地址
        :param nodes - 主机IP List ['1.1.1.1', '1.1.1.2']
        Date: 2016/12/07
        """
        # 增加判断是否获取灾备网IP
        disaster_exist = self.judge_disaster_exist()

        public_network = self.cluster_config['public_network']
        cluster_network = self.cluster_config['cluster_network']
        disaster_network = self.cluster_config['disaster_network'] if disaster_exist else None
        manage_network = self.cluster_config['manage_network']
        # 检查主机网络是否满足部署要求
        check_network_command = '/opt/h3c/bin/python %s/handy_common.py network_judge %s %s %s %s %s %s %s' % (
            self.filepath, '$$', user, passwd, public_network, cluster_network, disaster_network, manage_network)
        check_result_str = self.multi_thread_task(nodes, check_network_command)
        LOG.info('_check_host_network ret is: %s', check_result_str)

        connect_error, cluster_network_error, public_network_error, disaster_network_error, manage_network_error \
            = [], [], [], [], []
        passwd_error = []
        cluster_network_ips, public_network_ips, disaster_network_ips, manage_network_ips = [], [], {}, []
        cluster_mask_error, public_mask_error, disaster_mask_error, manage_mask_error = [], [], [], []
        self.checked_hosts_ip = dict()
        self.network_check_success = False

        for node in check_result_str:
            ret = check_result_str[node]
            # 网络故障的情况
            if const.NETWORK_FAULT == ret:
                connect_error.append(node)
                continue
            # 网络正常但获取不到IP的情况
            network_info = json.loads(ret)
            if not network_info['success']:
                passwd_error.append(node)
                continue
            self.checked_hosts_ip[node] = dict(name=network_info['hostname'])
            if '' == network_info['storage_ip']:
                cluster_network_error.append(node)
            else:
                cluster_network_ips.append(network_info['storage_ip'])
                cluster_ip = dict(cluster_ip=network_info['storage_ip'])
                self.checked_hosts_ip[node].update(cluster_ip)
            if '' == network_info['public_ip'] or \
                    not self.network_check(network_info['public_ip']):
                public_network_error.append(node)
            else:
                public_network_ips.append(network_info['public_ip'])
                public_ip = dict(public_ip=network_info['public_ip'])
                self.checked_hosts_ip[node].update(public_ip)
            if '' == network_info['disaster_ip']:
                disaster_network_error.append(node)
            else:
                disaster_network_ips[node] = network_info['disaster_ip']
                disaster_ip = dict(disaster_ip=network_info['disaster_ip'])
                self.checked_hosts_ip[node].update(disaster_ip)
            if '' == network_info['manage_ip']:
                manage_network_error.append(node)
            else:
                manage_network_ips.append(network_info['manage_ip'])
                manage_ip = dict(manage_ip=network_info['manage_ip'])
                self.checked_hosts_ip[node].update(manage_ip)
            # 新增对主机掩码的检查
            if not network_info['storage_mask_match']:
                cluster_mask_error.append(node)
            if not network_info['public_mask_match']:
                public_mask_error.append(node)
            if not network_info['disaster_mask_match']:
                disaster_mask_error.append(node)
            if not network_info['manage_mask_match']:
                manage_mask_error.append(node)

        if 0 == len(passwd_error) and 0 == len(connect_error) and 0 == len(cluster_network_error)\
                and 0 == len(public_network_error) and 0 == len(disaster_network_error)\
                and 0 == len(manage_network_error) and 0 == len(manage_network_error)\
                and 0 == len(cluster_mask_error) and 0 == len(public_mask_error)\
                and 0 == len(disaster_mask_error) and 0 == len(manage_mask_error):
            self.network_check_success = True

        LOG.debug("checked hosts ips: {}".format(self.checked_hosts_ip))

        if check_mask:
            return {
                'passwd_error': passwd_error,
                'connect_error': connect_error,
                'public_network_error': public_network_error,
                'cluster_network_error': cluster_network_error if check_cluster_network else [],
                'disaster_network_error': disaster_network_error if disaster_exist and
                check_cluster_network else [],
                'manage_network_error': manage_network_error if check_manage_network  else [],
                'public_mask_error': public_mask_error,
                'cluster_mask_error': cluster_mask_error if check_cluster_network else [],
                'disaster_mask_error': disaster_mask_error if disaster_exist and
                check_cluster_network else [],
                'manage_mask_error': manage_mask_error if check_manage_network else []
            }

        network_error_msg = ''
        if 0 != len(passwd_error):
            network_error_msg += '主机“%s”认证失败，请检查用户名和密码是否正确；' % (
                ','.join([str(node) for node in passwd_error]))
        if 0 != len(connect_error):
            network_error_msg += '连接主机“%s”失败；' % (
                ','.join([str(node) for node in connect_error]))
        if check_public_network and 0 != len(public_network_error):
            network_error_msg += '无法获取主机“%s”的%sIP地址；' % (
                ','.join([str(node) for node in public_network_error]), cluster_head_net)
        if check_cluster_network and 0 != len(cluster_network_error):
            network_error_msg += '无法获取主机“%s”的%sIP地址；' % (
                ','.join([str(node) for node in cluster_network_error]), cluster_behind_net)
        if disaster_exist and check_cluster_network and 0 != len(disaster_network_error):
            network_error_msg += '无法获取主机“%s”的灾备网IP地址；' % (
                ','.join([str(node) for node in disaster_network_error]))
        if check_manage_network and 0 != len(manage_network_error):
            network_error_msg += '无法获取主机“{0}”的{1}IP地址；'.format(
                ','.join([str(node) for node in manage_network_error]), manage_net)
        if '' != network_error_msg:
            raise errno.ONEStorError.make_error(
                'ERROR_NETWORK_DISSATISFY', network_error_msg.rstrip('；'))

        return disaster_network_ips

    @staticmethod
    def _update_deploy_status(current_step):
        """
        更新部署进度到文件中
        Date: 2016/12/07
        """
        LOG.info('current step: %s', current_step)
        with open(const.FLAG_DEPLOY_STATUS, 'wb') as fb:
            fb.write(current_step)

    def __backup_remote_conf(self, filename, node_type=const.BACKUP_ALL):
        """
        远程备份节点上的配置文件
        :param node_type all:集群所有节点 manage: 集群中mon+handy节点
        :param filename 需要备份的文件名
        Date: 2016/12/07
        """
        backup_ips = list()
        if const.BACKUP_ALL == node_type:
            cluster_hosts = self.get_cluster_hosts_from_config()
            backup_ips = [host[const.HOST_IP] for host in cluster_hosts]
        elif const.BACKUP_MANAGE == node_type:
            backup_ips = self.cluster_config['mon_ip']
            if not self.is_handy_in_mon():
                backup_ips.append(self.get_handy_public_ip())
        else:
            LOG.error('backup remote conf invalid node type')
        LOG.info('backup %s on nodes %s', filename, backup_ips)
        backup_result = self.multi_thread_task(
            backup_ips, 'timeout 30 ssh $$ cat {0}_bak 1>/dev/null 2>&1 && echo ok'.format(filename))
        for node_ip in backup_result:
            if 'ok' != backup_result[node_ip]:
                self.exec_remote_ssh_cmd(node_ip, 'cp {0} {0}_bak'.format(filename))

    def __recovery_remote_conf(self, filename, node_type=const.BACKUP_ALL,
                               status=const.OP_RECOVERY, restart_service=None):
        """
        远程恢复节点上的配置文件
        :param node_type all:集群所有节点 manage: 集群中mon+handy节点
        :param filename 需要恢复的文件名
        Date: 2016/12/07
        """
        recovery_ips = list()
        if const.BACKUP_ALL == node_type:
            cluster_hosts = self.get_cluster_hosts_from_config()
            recovery_ips = [host[const.HOST_IP] for host in cluster_hosts]
        elif const.BACKUP_MANAGE == node_type:
            recovery_ips = self.cluster_config['mon_ip']
            if not self.is_handy_in_mon():
                recovery_ips.append(self.get_handy_public_ip())
        else:
            LOG.error('recovery remote conf invalid node type')

        if const.OP_DELETE == status:
            LOG.info('delete %s on nodes %s...', filename, recovery_ips)
            self.multi_thread_task(
                recovery_ips, 'timeout 30 ssh $$ rm {0}_bak'.format(filename))
        elif const.OP_RECOVERY == status:
            LOG.info('recovery %s on nodes %s', filename, recovery_ips)
            recovery_result = self.multi_thread_task(
                recovery_ips, 'timeout 30 ssh $$ mv {0}_bak {0}'
                              ' 2>/dev/null && echo ok'.format(filename))
            for node_ip in recovery_result:
                if 'ok' != recovery_result[node_ip]:
                    LOG.warn('recovery %s on nodes %s failed,'
                             ' backup unsuccessful?', filename, node_ip)
            # PN: 201706200613 【凝思移植系统测试】handy节点/etc/hosts文件里有其他节点ip和主机名残留，
            # 避免对其他操作有影响，建议删除干净
            clear_command = "timeout 30 ssh $$ \"sed -i '/# ONEStor$/d' {0}\" && echo ok".format(filename)
            clear_hosts_result = self.multi_thread_task(recovery_ips, clear_command)
            LOG.debug("clear_command is: %s, clear result is: %s", clear_command, clear_hosts_result)
            failed_hosts = [hosts for hosts in clear_hosts_result if 'ok' != clear_hosts_result[hosts]]
            if len(failed_hosts) > 0:
                LOG.warn("'# ONEStor' info in /etc/hosts failed on nodes %s" % ','.join(
                    str(node) for node in failed_hosts))
            # end by l11544 2017/7/5

            if restart_service is not None:
                # 重启所有节点上的ntp进程
                self.multi_thread_task(
                    recovery_ips,
                    'timeout 30 ssh $$ service {0} restart'.format(restart_service))
        else:
            LOG.error('recovery remote conf invalid status')

    def _backup_etc_hosts(self):
        """
        备份Handy与监控节点上的/etc/hosts文件
        Date: 2016/12/07
        """
        self.__backup_remote_conf('/etc/hosts', const.BACKUP_MANAGE)

    def _recovery_etc_hosts(self):
        """
        还原Handy与监控节点上的/etc/hosts文件
        Date: 2016/12/07
        """
        self.__recovery_remote_conf('/etc/hosts', const.BACKUP_MANAGE)

    def _backup_ceph_conf(self):
        """
        备份所有节点上的/etc/ceph/ceph.conf文件，便于回滚
        Date: 2016/12/21
        """
        self.__backup_remote_conf('/etc/ceph/ceph.conf')

    def _recovery_ceph_conf(self):
        """
        操作失败时还原所有节点上的/etc/ceph/ceph.conf文件
        Date: 2016/12/21
        """
        self.__recovery_remote_conf('/etc/ceph/ceph.conf', status=const.OP_RECOVERY)

    def _remove_backup_ceph_conf(self):
        """
        删除所有节点上的/etc/ceph/ceph.conf.bak文件
        Date: 2016/12/21
        """
        self.__recovery_remote_conf('/etc/ceph/ceph.conf', status=const.OP_DELETE)

    def _backup_ntp_conf(self):
        """
        备份所有节点上的/etc/ntp.conf文件，便于回滚
        Date: 2016/12/21
        """
        self.__backup_remote_conf('/etc/ntp.conf')

    def _backup_zk_conf(self):
        LOG.info('Start to backup zk conf file...')
        self.__backup_remote_conf(const.ZK_MYID_PATH, node_type=const.BACKUP_ALL)
        self.__backup_remote_conf(const.ZK_ZOO_CFG_PATH, node_type=const.BACKUP_ALL)
        LOG.info('Succeed to backup zk conf file...')

    def _recovery_ntp_conf(self):
        """
        操作失败时还原所有节点上的/etc/ntp.conf文件
        Date: 2016/12/21
        """
        self.__recovery_remote_conf(
            '/etc/ntp.conf', status=const.OP_RECOVERY, restart_service='ntp')

    def _recovery_back_zk_conf(self):
        LOG.info('Start to recovery zk conf bak file...')
        self.__recovery_remote_conf(const.ZK_MYID_PATH,
                                    node_type=const.BACKUP_ALL,
                                    status=const.OP_RECOVERY)
        self.__recovery_remote_conf(const.ZK_ZOO_CFG_PATH,
                                    node_type=const.BACKUP_ALL,
                                    status=const.OP_RECOVERY,
                                    restart_service='zookeeper')
        cluster_hosts = self.get_cluster_hosts_from_config()
        recovery_ips = [host[const.HOST_IP] for host in cluster_hosts]
        self.multi_thread_task(recovery_ips, 'timeout 30 ssh $$ /opt/h3c/zookeeper/bin/zkServer.sh restart')
        LOG.info('Succeed to recovery zk conf bak file...')

    def _remove_backup_ntp_conf(self):
        """
        操作成功时删除所有节点上的/etc/ntp.conf_bak文件
        Date: 2016/12/21
        """
        self.__recovery_remote_conf('/etc/ntp.conf', status=const.OP_DELETE)

    def _remove_back_zk_conf(self):
        LOG.info('Start to reomve zk conf bak file...')
        self.__recovery_remote_conf(const.ZK_MYID_PATH,
                                    node_type=const.BACKUP_ALL,
                                    status=const.OP_DELETE)
        self.__recovery_remote_conf(const.ZK_ZOO_CFG_PATH,
                                    node_type=const.BACKUP_ALL,
                                    status=const.OP_DELETE)
        LOG.info('Succeed to remove zk conf bak file...')

    def _create_rack(self, rack_info):
        """
        调用Ceph命令行创建机架
        Date: 2016/12/07
        """
        # rack_info: 参数为rack,1的形式，rack为机架名，1表示现有机架，0表示创建新机架
        rack_name = rack_info.split(',')[0]
        if '0' == rack_info.split(',')[1]:
            self._check_rack_name(rack_name)
            LOG.info('begin create rack...')
            self.exec_local_cmd(
                'ceph osd crush add-bucket %s rack' % rack_name)
            self.exec_local_cmd(
                'ceph osd crush move %s root=default' % rack_name)
            self.exec_local_cmd(
                'ceph osd crush add-bucket %s_ssd rack' % rack_name)
            self.exec_local_cmd(
                'ceph osd crush move %s_ssd root=ssd_root' % rack_name)
        return rack_name

    def _remove_rack(self, rack_name):
        """
        调用Ceph命令行删除机架
        Date: 2016/12/07
        """
        self.exec_local_cmd('ceph osd crush remove %s_ssd' % rack_name)
        self.exec_local_cmd('ceph osd crush remove %s' % rack_name)

    def _deploy_disk(self, node_ip, node_name, host_disk):
        """
        部署硬盘For增加主机
        Date: 2016/12/07
        """
        data_disk = ','.join(host_disk['data'])
        if not host_disk['flash']:
            flash_disks = '-1'
            flash_switch = 'close'
        else:
            flash_disks = ','.join(host_disk['flash'])
            flash_switch = 'open'
        if not host_disk['journal']:
            journal_disks = '-1'
        else:
            journal_disks = ','.join(host_disk['journal'])
        onestor_conf = ONEStorConfig()
        install_type = onestor_conf.get('global', 'storage_type')
        deploy_osd_command = "/opt/h3c/bin/python %s/deploy_disk.py '%s' '%s' '%s' '%s' '%s' '%s' 2>/dev/null" \
                             % (const.HANDY_SHELL_PATH, node_name, data_disk, journal_disks,
                                flash_switch, flash_disks, install_type)

        LOG.info('start to deploy disk command: %s', deploy_osd_command)
        self.exec_remote_ssh_cmd(node_ip, deploy_osd_command)
        LOG.info('end deploy disk result')

    def _get_osd_status_single(self, osd_node, host_info, lock=None):
        """
        获取osdFor增加主机
        Date: 2017/03/07
        """
        LOG.info('begin get osd for %s, host info is %s', osd_node, host_info)
        osd_id_command = 'df /var/lib/ceph/osd/ceph-* | grep osd/ceph- 2>/dev/null'
        node_ip = self.name_to_ip(osd_node)
        osd_id_result = self.exec_remote_ssh_cmd(node_ip, osd_id_command).split('\n')
        LOG.info('get osd id, result is {}'.format(osd_id_result))
        if lock is not None:
            lock.acquire()
        for host in host_info:
            if osd_node == host['name']:
                for diskpool_name in host['diskpool_list']:
                    data_disk = host[diskpool_name]['data']
                    tmp = []
                    for disk in data_disk:
                        LOG.info('current disk is {}'.format(disk))
                        no_osd_id_bool = True
                        disk_name = disk.split(':')[0]
                        for osd in osd_id_result:
                            LOG.info('current osd is {}'.format(osd))
                            osd_mount = osd.split()[0]
                            osd_id = osd.split()[5].split('ceph-')[1]
                            if 'loop' in osd_mount or 'cciss' in osd_mount or 'nvme' in osd_mount:
                                if osd_mount.split('/')[-1][:-2] == disk_name:
                                    no_osd_id_bool = False
                                    tmp.append(disk + ':' + osd_id)
                            else:
                                if osd_mount.split('/')[-1][:-1] == disk_name:
                                    no_osd_id_bool = False
                                    tmp.append(disk + ':' + osd_id)
                        if no_osd_id_bool:
                            tmp.append(disk)
                    host[diskpool_name]['data'] = tmp
        if lock is not None:
            lock.release()

        LOG.info('finish get osd for %s, host info is %s', osd_node, host_info)

    def _add_disk(self, osd_node, host_disk):
        """
        部署硬盘For增加硬盘
        Date: 2016/12/07
        """
        onestor_conf = ONEStorConfig()
        install_type = onestor_conf.get('global', 'storage_type')
        data_disks = ','.join(host_disk['data'])
        if not host_disk['flash']:
            flash_disks = '0'
            flash_switch = 'close'
        else:
            flash_disks = ','.join(host_disk['flash'])
            flash_switch = 'open'
        if not host_disk['journal']:
            journal_disks = '-1'
        else:
            journal_disks = ','.join(host_disk['journal'])

        add_disk_command = '/opt/h3c/bin/python %s/add_disk.py %s %s %s %s %s %s' % (
            const.HANDY_SHELL_PATH, osd_node, data_disks, journal_disks,
            flash_switch, flash_disks, install_type)

        LOG.info('_add_disk command: %s', add_disk_command)
        add_disk_result = self.exec_remote_ssh_cmd(osd_node, add_disk_command)
        LOG.info('_add_disk result: %s', add_disk_result)

        # 检查增加结果
        if '' == add_disk_result:
            LOG.error('add disk error, ret is null, network fault?')
            raise errno.ONEStorError(errno.ERROR_ADD_DISK)

        if isinstance(add_disk_result, dict) and 'error' == add_disk_result['status']:
            raise errno.ONEStorError(errno.ERROR_NETWORK_FAULT, osd_node)

        ret_json = json.loads(add_disk_result)
        if ret_json['finish']:
            if 0 != len(ret_json['fail_disks']):
                raise errno.ONEStorError(
                    errno.ERROR_ADD_SOME_DISK,
                    ','.join(ret_json['fail_disks'])
                )
        elif 'CACHE_ENABLED' == ret_json['error']:
            LOG.error(ret_json['error'])
            raise errno.ONEStorError(errno.ERROR_DISK_CACHE_ENABLED)
        else:
            LOG.error(ret_json['error'])
            raise errno.ONEStorError(errno.ERROR_ADD_DISK)

    def _add_disk_batch(self, nodes_name_list, host_disk):
        """
        批量部署硬盘
        Date: 2016/12/07
        """
        LOG.info('begin add disk batch for %s ...', ','.join(nodes_name_list))
        self.__exec_cmd_batch(
            nodes_name_list,
            command=const.STEP_ADD_DISK_BATCH,
            host_info=host_disk
        )
        LOG.info('finish add disk batch for %s', ','.join(nodes_name_list))

    def _sync_tgt(self, node_ip, host_name, op):
        """
        同步tgt配置
        Date: 2016/12/07
        """
        roles = self.get_host_roles_by_name(host_name, self.cluster_config)
        # 如果主机已经作为监控节点而op为增加存储或者主机作为存储而op为增加监控，不再进行tgt同步
        if const.OP_ADD_STOR == op and (roles is not None and roles['mon']):
            LOG.info('[ADD STOR] host %s is mon, no need to sync tgt.', host_name)
            return
        elif const.OP_ADD_MON == op and (roles is not None and roles['stor']):
            LOG.info('[ADD MON] host %s is stor node, no need to sync tgt.', host_name)
            return
        handy_name = self.exec_local_cmd('hostname')
        handy_ip = self.name_to_ip(handy_name)
        # 从Handy tmp目录获取tgt配置
        self.exec_local_cmd('scp [%s]:/tmp/tgt/* [%s]:/etc/tgt/conf.d/' % (handy_ip, node_ip))
        # 检查配置文件是否已经成功拷贝过去，如果没有则打印错误到日志中
        tgt_conf_exist = self.exec_remote_ssh_cmd(node_ip, 'ls /etc/tgt/conf.d | wc -l')
        if '0' == tgt_conf_exist:
            LOG.warn('_sync_tgt failed or cluster has no target.')
        self.exec_local_cmd(cmd.CMD_SSH_RESTART_TGT.format(node_ip))

    def _check_add_host_result(self, host_info_list):
        """
        检查增加主机的结果
        :param  host_info_list 需要检查的主机信息，格式如下：
        [{
            'name': 'node1',
            'diskpool_list': ['dp1', 'dp2'],
            'dp1': {
                'data': ['sdb:1', 'sdc:3']
            }
            'dp2': {
                'data': ['sde:2', 'sdf:4']
            }
        }]
        Date: 2016/12/07
        """
        LOG.info('start to check add host result, host info is {}'.format(host_info_list))
        topo = self.exec_local_cmd_json('ceph osd tree -f json')
        for host_info in host_info_list:
            for diskpool_name in host_info['diskpool_list']:
                data_disk_id = [int(disk.split(':')[-1]) for disk in host_info[diskpool_name]['data']]  # 需要加的硬盘
                total_osd_id = []  # 实际加入ceph osd tree 中
                for crush_node in topo['nodes']:
                    if 'root' == crush_node['type'] and diskpool_name == crush_node['name']:
                        self.deep_search_crush(crush_node, topo['nodes'], total_osd_id)
                tmp = [id for id in data_disk_id if id in total_osd_id]  # data_disk_id,total_osd_id 并集
                LOG.info('diskpool name is {0}, data disk id is {1}, total osd id is {2}, tmp is {3}'.format(
                    diskpool_name, data_disk_id, total_osd_id, tmp))
                if data_disk_id != tmp:
                    LOG.error('check add host {} result, disk id is {}, osd id is {}, tmp is {}'.
                              format(host_info['name'], data_disk_id, total_osd_id, tmp))
                    raise errno.ONEStorError(errno.ERROR_CHECK_CRUSH_OSD, host_info['name'], diskpool_name)
        LOG.info('end to check add host result , topo is {} ########'.format(topo))

    def deep_search_crush(self, object, crush_data, total_osd):
        """
        深度递归遍历ceph osd tree
        :param object: 某个bucket
        :param crush_data: ceph osd tree
        :param total_osd: 已遍历到的osd列表数据
        :return:
        """
        if 'osd' == object['type']:
            total_osd.append(object['id'])
            return
        if not len(object['children']):
            return
        else:
            for oject_id in object['children']:
                for crush in crush_data:
                    if crush['id'] == oject_id:
                        self.deep_search_crush(crush, crush_data, total_osd)

    @staticmethod
    def __generate_remove_dir_command(dir_name, retain_files):
        """
        生成删除配置文件的命令
        :param dir_name 待删除的目录
        :param retain_files 需要保留的文件
        Date: 2016/12/07
        """
        _command = list()
        # 备份需要保留的文件
        for retain_file in retain_files:
            _command.append('cp {dir}/{file} /tmp/{file}'.format(
                dir=dir_name, file=retain_file))
        # 删除目录
        _command.append('rm -rf {dir}/*'.format(dir=dir_name))
        # 恢复备份的文件
        for retain_file in retain_files:
            _command.append('mv /tmp/{file} {dir}/{file}'.format(
                dir=dir_name, file=retain_file))
        return _command

    def _remove_host_from_cluster(self, node_ip, node_name):
        """
        从/etc/onestor_hosts和cluster_hosts中删除主机
        Date: 2016/12/07
        """
        self.remove_host_from_file(node_ip, node_name)
        self.remove_host_from_db(node_ip, node_name)
        LOG.info('begin to delete host form table base_host...')
        self.delete_host_base_info(node_name)

    def __clear_etc_ceph_dir(self, node_name, roles):
        """
        清理/etc/ceph目录
        Date: 2016/12/07
        """
        retain_files = set()
        if roles is None:
            # 当节点不作为任何角色时，/etc/ceph目录仅保留ceph.log
            retain_files.add('ceph.log')
        else:
            # 如果节点曾经为集群外的对象网关，需要删除ceph.client.radosgw.keyring文件
            if not roles['rgw']:
                self.exec_remote_ssh_cmd(
                    node_name, 'rm -f /etc/ceph/ceph.client.radosgw.keyring', raise_exc=True)
            # 当节点作为Handy/存储/监控时，进入下一次循环，/etc/ceph目录全部保留
            if roles['handy'] or roles['mon'] or roles['stor'] or roles['mds'] or roles['nas']:
                return
            # DELETE BY D11564 PN:201702220424 不需要区分mds
            if roles['rgw']:
                # 当节点作为对象网关时，/etc/ceph目录需保留ceph.conf、ceph.log和ceph.client.radosgw.keyring
                retain_files.add('ceph.log')
                retain_files.add('ceph.conf')
                retain_files.add('ceph.client.radosgw.keyring')
        clear_config_command = self.__generate_remove_dir_command('/etc/ceph', retain_files)
        LOG.info('begin clear /etc/ceph dir on "%s", cmd is "%s"...',
                 node_name, clear_config_command)
        self.exec_remote_ssh_cmd(node_name, ' || true && '.join(clear_config_command))

    def __clear_tgt_dir(self, node_name, roles):
        """
        清理/etc/tgt/conf.d目录
        Date: 2016/12/07
        """
        if roles is None or (not roles['stor'] and not roles['mon']):
            LOG.info('begin clear tgt ...')
            self.exec_remote_ssh_cmd(node_name, 'rm -rf /etc/tgt/conf.d/*')
            # update by z11524 2017/8/10 PN:201707280462
            self.exec_remote_ssh_cmd(node_name, 'pkill -9 tgtd')
            self.exec_remote_ssh_cmd(node_name, 'timeout 30 service tgt restart')

    def __clear_var_lib_ceph_dir(self, node_name, roles):
        """
        清理/var/lib/ceph/目录
        Date: 2016/12/07
        """
        if (roles is None) or (not roles['stor']):
            LOG.info('begin clear osd in /var/lib/ceph ...')
            # DELETE BY D10039 2017/03/11 不再删除osd目录，防止误删用户数据
            self.exec_remote_ssh_cmd(node_name, 'rm -rf /var/lib/ceph/bootstrap-osd/*')
        if (roles is None) or (not roles['mon']):
            LOG.info('begin clear mon in /var/lib/ceph ...')
            self.exec_remote_ssh_cmd(node_name, 'rm -rf /var/lib/ceph/mon/*')
        if (roles is None) or (not roles['rgw']):
            LOG.info('begin clear rgw in /var/lib/ceph ...')
            self.exec_remote_ssh_cmd(node_name, 'rm -rf /var/lib/ceph/bootstrap-rgw/*')
        if (roles is None) or (not roles['mds']):
            LOG.info('begin clear mds in /var/lib/ceph ...')
            self.exec_remote_ssh_cmd(node_name, 'rm -rf /var/lib/ceph/mds/*')
            self.exec_remote_ssh_cmd(node_name, 'rm -rf /var/lib/ceph/bootstrap-mds/*')

    def __clear_onestor_version(self, node_name, roles):
        """
        清理ONEStor版本文件
        Date: 2016/12/07
        """
        # modify by r13889 2017/5/31 201705080728
        if roles is None or 1 > roles['role_num']:
            LOG.info('begin clear /etc/onestor_* ...')
            self.exec_remote_ssh_cmd(node_name, 'rm -rf {0}'.format(const.ALL_ONESTOR_CONF))

    def _clear_cluster_config(self, nodes, exclude_role=None):
        """
        部署失败时清除集群配置，需要根据主机的角色清除相应的文件
        注：该方法需要放在最后执行，即回滚处理或者删除某角色成功后
        :param nodes 需要清除的主机，格式为:
            {
                'node1': '1.1.1.1',
                'node2': '1.1.1.2'
            }
        :param exclude_role 当前操作对应的主机角色
        Date: 2016/12/07
        """
        for node_name in nodes:
            roles = self.get_host_roles_by_name(node_name)
            # 对于先清除配置，再清理数据库的情况需要排除本身的角色
            if roles is not None and exclude_role:
                if roles[exclude_role]:
                    roles[exclude_role] = False
                    roles['role_num'] -= 1
            LOG.info('_clear_cluster_config for %s, roles is: %s', node_name, roles)
            # 清理tgt配置
            self.__clear_tgt_dir(node_name, roles)
            # 清理/etc/ceph目录
            self.__clear_etc_ceph_dir(node_name, roles)
            # 清理/var/lib/ceph/目录
            self.__clear_var_lib_ceph_dir(node_name, roles)
            # 清理ONEStor版本文件
            self.__clear_onestor_version(node_name, roles)
            # 清理hosts文件中的主机
            if roles is None or 1 > roles['role_num']:
                # 还原NTP配置 add by l11544 2016/12/24
                self.ntp_roll_return(node_name)
                # DELETE BY KF6602 删除修改diamond配置的代码，监控项目不再需要修改diamond配置，不需要删除graphite数据
                LOG.info('begin clear onestor_hosts and cluster_hosts...')
                self._remove_host_from_cluster(nodes[node_name], node_name)
                LOG.info('Start to stop host: "{0}" process peon...'.format(node_name))
                self.stop_nm_sub([nodes[node_name]])
            # add by r13889 2017/03/24 PN:201703160637
            # 同步onestor_hosts
            self.set_onestor_host()

    def _check_cluster_status(self, operation):
        """
        检查集群是否处于正常状态
        Date: 2016/12/07
        """
        LOG.info('checking cluster status...')
        status = self.exec_local_cmd_json('ceph -s -f json')
        if not status:
            raise errno.ONEStorError(errno.ERR_GET_CLUSTER_CONFIG)

        # MODIFY BY D10039 2017/03/11 PN:201610220299
        cluster_status = [item for item in status['pgmap']['pgs_by_state']
                          if -1 != item['state_name'].find('inconsistent') or
                          not item['state_name'].startswith('active+clean')]

        if 0 < len(cluster_status):
            raise errno.ONEStorError(errno.ERROR_CLUSTER_NOT_CLEAN, operation)
        
    @staticmethod
    def _check_host_delete(operation, host_name):
        """
        检查主机是否可以删除
        Date: 2016/12/07
        """
        LOG.info('checking partition status...')
        delete_req_data = {'host_name': host_name}
        host_delete_response = send_request_onestord('COMP_CS', 'IS_host_delete', delete_req_data)
        host_delete_data = host_delete_response['response']['data']
        if not host_delete_data['is_delete']:
            raise errno.ONEStorError(errno.ERROR_HOST_NOT_DELETE, host_name, operation)

    @staticmethod
    def _query_rebalance_progress(diskpool_list, total_recover_pg, recovered_pg):
        """
        查询数据平衡过程中，pg 恢复数量。
        Date: 2018/01/05
        """
        query_data = {
            'diskpool_list': diskpool_list,
            'recovering_pg_count': total_recover_pg,
            'last_rebalance_progress': recovered_pg
        }
        query_rebalance_response = send_request_onestord('COMP_CS', 'rebalance_progress_query', query_data)
        query_rebalance_result = query_rebalance_response['response']['result']
        if 0 != query_rebalance_result[0]:
            LOG.error('query rebalance progress, response is %s', query_rebalance_response)
            raise errno.ONEStorError(errno.ERROR_QUERY_REBALANCE_PROGRESS)
        query_rebalance_data = query_rebalance_response['response']['data']
        return query_rebalance_data['rebalance_progress']


    def _check_lost_data(self):
        """
        检查集群是否丢数据
        Date：2018/1/3
        """
        LOG.info("checking whether losted data...")
        cmd = 'ceph health'
        # 如果出现pg down或者pg stale则每隔五秒再进行两次检查
        for i in range(0, 2):
            result = self.exec_local_cmd(cmd)
            if "objects unfound" in result:
                return True
            if "pgs down" in result or "pgs stale" in result:
                time.sleep(5)
                result = self.exec_local_cmd(cmd)
                if "pgs down" in result or "pgs stale" in result:
                    return True
        return False


    def _check_tgt_initiator_status(self, node_name):
        """
        检查主机上的tgt是否有客户端连接
        Date: 2016/12/07
        """
        LOG.info('checking tgt initiator on host "%s"...', node_name)
        # BRGIN MODIFY BY KF6602 PN:201706060583
        initiator_num = self.exec_remote_ssh_cmd(
            node_name, 'tgt-admin -s 2>/dev/null | grep Initiator | wc -l', raise_exc=True)
        if '' != initiator_num and '0' != initiator_num:
            # END MODIFY BY KF6602 PN:201706060583
            raise errno.ONEStorError(errno.ERROR_TARGET_MOUNTED)

    def __remove_osd_by_id(self, osd_id):
        """
        ADD BY D10039 2016/06/18 PN:201606180056
        根据OSD的ID删除Crush中的相关信息
        """
        self.exec_local_cmd('ceph osd out %s' % osd_id)
        self.exec_local_cmd('ceph osd down %s' % osd_id)
        self.exec_local_cmd('ceph osd rm %s' % osd_id)
        self.exec_local_cmd('ceph osd crush remove osd.%s' % osd_id)
        self.exec_local_cmd('ceph osd crush remove device%s' % osd_id)
        self.exec_local_cmd('ceph auth del osd.%s' % osd_id)

    def __remove_offline_host(self, node_name, diskpool_list):
        """
        删除离线主机
        Date: 2016/12/07
        """
        LOG.info('begin remove offline host ..., node is {0}, diskpool list is {1}'.format(node_name, diskpool_list))
        # 删除该主机下的所有osd
        crush_map_json = self.exec_local_cmd_json('ceph osd crush dump -f json')
        if not crush_map_json:
            raise errno.ONEStorError(errno.ERR_GET_CLUSTER_CONFIG)
        for node in crush_map_json['buckets']:
            if 'host' == node['type_name'] and node['name'].split('.')[0] == node_name:
                for osd in node['items']:
                    self.__remove_osd_by_id(osd['id'])
        # 从crushmap中删除该主机
        for diskpool in diskpool_list:
            self.exec_local_cmd('ceph osd crush rm %s' % (node_name + '.' + diskpool))
        # 如果该主机不作为任何角色，删除cluster_hosts和onestor_hosts
        if not self.get_host_roles_by_name(node_name):
            LOG.info('begin clear onestor_hosts and cluster_hosts...')
            self._remove_host_from_cluster(self.name_to_ip(node_name), node_name)
        LOG.info('end remove offline host "%s"...', node_name)

    def _process_remove_host(self, node_name, roles, diskpool_list, offline=False):
        """
        执行删除主机脚本
        Date: 2016/12/07
        """
        LOG.info('begin remove host, name is {0}, roles is {1},'
                 'diskpool list is {2}, offline is {3}'.format(node_name, roles, diskpool_list, offline))
        if not offline:
            LOG.info('begin remove host "%s"...', node_name)
            # 删除存储前如果只剩下一个角色了，需要清空diamond等配置
            need_clear_config = 'true' if 1 == roles['role_num'] else 'false'
            remove_host_command = '/opt/h3c/bin/python %s/remove_host.py %s %s' % (
                const.HANDY_SHELL_PATH, node_name, need_clear_config)
            results = self.exec_remote_ssh_cmd(node_name, remove_host_command)
            if const.OP_SUCCSSFUL != results:
                LOG.error('remove host ret: %s', results)
                raise errno.ONEStorError(errno.ERROR_REMOVE_HOST)

        # 删除空的子分区和机架 add by h1305
        LOG.info('start to clear empty row and rack by host, host is %s', node_name)
        self.clear_empty_row_and_rack(node_name)
        LOG.info('end to clear empty row and rack by host')
        # end by h13051
        # 删除数据表中的主机记录 add by h13051
        LOG.info('start to delete host info from table, host is %s', node_name)
        self.delete_host_info_from_table(node_name)
        LOG.info('end to delete host info from table')
        # end by h13051

        # DELETE BY KF6602 监控项目不需要清除graphite监控数据

        # 从cluster_hosts中删除灾备IP地址
        self._remove_disaster_ip(self.name_to_ip(node_name))

        if offline:
            # 离线主机仅清除Handy上的onestor_hosts、cluster_hosts
            self.__remove_offline_host(node_name, diskpool_list)
        else:
            # 清理onestor_hosts、cluster_hosts、tgt、各种目录
            self._clear_cluster_config({node_name: self.name_to_ip(node_name)})
        LOG.info('end remove host, name is {0}'.format(node_name))

    def __is_disk_pull_out(self, host_name, disk_name, disk_id):
        """
        删除硬盘之前先检查是否已经被拔掉了
        """
        if '0' == self.exec_remote_ssh_cmd(
                host_name, cmd.CMD_CHECK_DISK_MOUNT.format(disk_id)):
            raise errno.ONEStorError(errno.ERROR_DISK_PULL_OUT, disk_name)

    def _remove_disk(self, host_name, osd):
        """
        删除硬盘
        Date: 2016/12/07
        """
        # 删除硬盘之前先检查是否已经被拔掉了
        self.__is_disk_pull_out(host_name, osd['name'], osd['id'])

        remove_disk_command = '/opt/h3c/bin/python %s/remove_disk.py %s %s %s' % (
            const.HANDY_SHELL_PATH, host_name, osd['name'], osd['id'])

        LOG.info('_remove_disk command: %s', remove_disk_command)
        remove_disk_result = self.exec_remote_ssh_cmd(host_name, remove_disk_command)
        LOG.info('_remove_disk result: %s', remove_disk_result)

        if isinstance(remove_disk_result, dict) and 'error' == remove_disk_result['status']:
            raise errno.ONEStorError(errno.ERROR_NETWORK_FAULT, host_name)

        if const.OP_SUCCSSFUL != remove_disk_result:
            raise errno.ONEStorError(errno.ERROR_REMOVE_DISK)

        # DELETE BY KF6602 监控项目不需要清除graphite监控数据

    @staticmethod
    def _get_host_param(request, host_info_list):
        """
        获取批量增加主机的参数
        Date: 2016/12/07
        """
        host_rack_map_str = request.DATA['host_rack_map_str']
        host_rack_map_json = json.loads(host_rack_map_str)
        host_rack_map = {}
        for host_rack in host_rack_map_json['elements']:
            host_rack_map[host_rack['key']] = host_rack['value']

        host_ip_map_str = request.DATA['host_ip_map_str']
        host_ip_map_json = json.loads(host_ip_map_str)
        host_ip_map = {}
        for host_ip_pair in host_ip_map_json['elements']:
            host_ip_map[host_ip_pair['key']] = host_ip_pair['value']

        host_nodepool_map_str = request.DATA['host_nodepool_map_str']
        host_nodepool_map_json = json.loads(host_nodepool_map_str)
        host_nodepool_map = {}
        for host_nodepool in host_nodepool_map_json['elements']:
            host_nodepool_map[host_nodepool['key']] = host_nodepool['value']

        host_domain_map_str = request.DATA['host_domain_map_str']
        host_domain_map_json = json.loads(host_domain_map_str)
        host_domain_map = {}
        for host_domain in host_domain_map_json['elements']:
            host_domain_map[host_domain['key']] = host_domain['value']

        for host_info in host_info_list:
            host_info['nodepool_name'] = host_nodepool_map[host_info['name']]
            host_info['rack'] = host_rack_map[host_info['name']]
            host_info['domain'] = host_domain_map[host_info['name']]

        return {
            'host_rack': host_rack_map,
            'host_ip': host_ip_map,
            'host_nodepool': host_nodepool_map,
            'host_domain': host_domain_map,
        }

    def _install_soft_batch(self, nodes_ip, user, passwd):
        """
        批量安装软件
        Date: 2016/12/07
        """
        install_result = self.multi_thread(
            nodes=nodes_ip,
            command=const.STEP_INSTALL_SOFT,
            passwd=passwd,
            user=user
        )
        failed_nodes = []
        for node_ip in install_result:
            if isinstance(install_result[node_ip], Exception):
                LOG.error('failed to install soft for host %s', node_ip)
                failed_nodes.append(node_ip)
            else:
                LOG.info('success to install soft for host %s', node_ip)
        if 0 != len(failed_nodes):
            raise errno.ONEStorHostError(
                errno.ERROR_INSTALL_SOFT_BATCH,
                ', '.join(failed_nodes),
                const.STEP_INSTALL_SOFT,
                ', '.join(failed_nodes)
            )

    def _ssh_config_batch(self, nodes_ip, user, passwd):
        """
        批量进行免密配置
        :return 所有节点的业务网IP和主机名
        {
            'node100': '2.1.1.44',
            'ubuntu1': '2.1.1.1'
        }
        Date: 2016/12/07
        """
        ssh_config_result = self.multi_thread(
            nodes=nodes_ip,
            command=const.STEP_SSH_CONFIG,
            passwd=passwd,
            user=user
        )
        success_nodes = dict()
        failed_nodes = []
        for node_ip in ssh_config_result:
            node_result = ssh_config_result[node_ip]
            if isinstance(node_result, Exception):
                LOG.error('failed to config ssh for host %s', node_ip)
                failed_nodes.append(node_ip)
            else:
                LOG.info('success to config ssh for host %s', node_ip)
                host_name, public_ip = node_result
                success_nodes[host_name] = public_ip
        if 0 != len(failed_nodes):
            raise errno.ONEStorHostError(
                errno.ERROR_CONFIG_SSH_BATCH,
                ', '.join(failed_nodes),
                const.STEP_SSH_CONFIG,
                ', '.join(failed_nodes)
            )
        return success_nodes

    def _sync_cluster_config_batch(self, nodes_ip, ip_cache_map=None):
        """
        批量同步集群配置
        Date: 2016/12/07
        """
        sync_result = self.multi_thread(
            nodes=nodes_ip,
            command=const.STEP_SYNC_CONFIG,
            ip_cache_map=ip_cache_map
        )
        failed_nodes = []
        for node_ip in sync_result:
            if isinstance(sync_result[node_ip], Exception):
                LOG.error('failed to sync cluster config for host %s', node_ip)
                failed_nodes.append(node_ip)
            else:
                LOG.info('success to sync cluster config for host %s', node_ip)
        if 0 != len(failed_nodes):
            raise errno.ONEStorError(
                errno.ERROR_SYNC_CONFIG_BATCH, ', '.join(failed_nodes))

    def _setup_ntp_batch(self, nodes_name):
        """
        批量同步NTP时间
        Date: 2016/12/07
        """
        setup_ntp_result = self.multi_thread(
            nodes=nodes_name,
            command=const.STEP_SETUP_NTP
        )
        failed_nodes = []
        for node_ip in setup_ntp_result:
            if isinstance(setup_ntp_result[node_ip], Exception):
                LOG.error('failed to setup ntp for host %s', node_ip)
                failed_nodes.append(node_ip)
            else:
                LOG.info('success to setup ntp for host %s', node_ip)
        if 0 != len(failed_nodes):
            raise errno.ONEStorError(
                errno.ERROR_SETUP_NTP_BATCH, ', '.join(failed_nodes))

    def _process_deploy_disk(self, node_name, host_disk, has_filesys):
        """
        批量部署硬盘时每个主机需要执行的代码
        Date: 2016/12/07
        """
        if has_filesys:
            node_ip = self.name_to_ip(node_name)
            add_mds_result = self._add_host_as_mds(node_ip, True)
            if add_mds_result != 'success':
                return add_mds_result
        if not host_disk[node_name]['flash']:
            flash_disks = '-1'
            flash_switch = 'close'
        else:
            flash_disks = ','.join(host_disk[node_name]['flash'])
            flash_switch = 'open'
        if not host_disk[node_name]['journal']:
            journal_disks = '-1'
        else:
            journal_disks = ','.join(host_disk[node_name]['journal'])

        data_disk = ','.join(host_disk[node_name]['data'])  # 格式为"sda:1,sdb:1"
        if '' == data_disk:
            LOG.info('host %s has no available disk.', node_name)
        else:
            onestor_conf = ONEStorConfig()
            install_type = onestor_conf.get('global', 'storage_type')
            deploy_osd_command = "/opt/h3c/bin/python %s/deploy_disk.py '%s' '%s' '%s' '%s' '%s' '%s' 2>/dev/null" \
                                 % (const.HANDY_SHELL_PATH, node_name, data_disk, journal_disks,
                                    flash_switch, flash_disks, install_type)

            LOG.info('start to process deploy disk command: %s', deploy_osd_command)
            self.exec_remote_ssh_cmd(node_name, deploy_osd_command)
            LOG.info('end to process deploy disk command')
        return 'success'

    def _get_osd_status(self, node_name, host_info, host_map_data, lock=None):
        """
        批量获取osd时每个主机需要执行信息的代码
        Date: 2017/03/08
        """
        LOG.info('start to get osd info for node:{} , data is {}'.format(node_name, host_info))
        osd_id_command = 'df /var/lib/ceph/osd/ceph-* | grep osd/ceph- 2>/dev/null'
        osd_id_result = self.exec_remote_ssh_cmd(node_name, osd_id_command).split('\n')
        LOG.info('get osd id, result is {}'.format(osd_id_result))
        with lock:
            for host in host_info:
                if host['name'] == node_name:
                    for disk_pool in host['diskpool_list']:
                        data_disk = host[disk_pool]['data']
                        tmp = []
                        for disk in data_disk:
                            disk_name = disk.split(':')[0]
                            for osd in osd_id_result:
                                osd_mount = osd.split()[0]
                                osd_id = osd.split()[5].split('ceph-')[1]
                                if 'loop' in osd_mount or 'cciss' in osd_mount or 'nvme' in osd_mount:
                                    if osd_mount.split('/')[-1][:-2] == disk_name:
                                        tmp.append(disk + ':' + osd_id)
                                else:
                                    if osd_mount.split('/')[-1][:-1] == disk_name:
                                        tmp.append(disk + ':' + osd_id)
                        host[disk_pool]['data'] = tmp
        LOG.info('end to get osd info for node:{} , data is {}'.format(node_name, host_info))

    def __exec_cmd_batch(self, nodes, command=None, host_info=None, host_map_data=None, op=None,
                         lock=None, has_filesys=None):
        """
        批量执行host_util中的任务
        Date: 2016/12/07
        """
        LOG.info('begin exec cmd batch for %s ...', nodes)
        results, threads = {}, []
        nloops = range(len(nodes))

        def execute(node):
            node_ip = self.name_to_ip(node)
            if not self.network_check(node_ip):
                results[node] = const.NETWORK_FAULT
            else:
                result = const.OP_SUCCSSFUL
                try:
                    if const.STEP_DEPLOY_DISK == command:
                        add_host_result = self._process_deploy_disk(node, host_map_data, has_filesys)
                        result = add_host_result
                    elif const.STEP_SYNC_TGT == command:
                        self._sync_tgt(node_ip, node, op)
                    elif const.STEP_RESTART_DIAMOND == command:
                        self._service_restart(node_ip, 'diamond')
                    elif const.STEP_GET_OSD_ID_FOR_ADD_HOST == command:
                        self._get_osd_status(node, host_info, host_map_data, lock)
                    elif const.STEP_GET_OSD_ID_FOR_ADD_DISK == command:
                        self._get_osd_status_single(node, host_info, lock)
                    elif const.STEP_ADD_DISK_BATCH == command:
                        self._add_disk(node, host_info[node])
                except Exception, e:
                    LOG.exception(e)
                    results[node] = e
                else:
                    results[node] = result

        for _node in nodes:
            t = threading.Thread(target=execute, args=(_node,))
            threads.append(t)
        for i in nloops:
            threads[i].start()
        for i in nloops:
            threads[i].join()
        LOG.info('finish exec cmd batch for %s ..., result is %s', nodes, results)
        return results

    def _deploy_disk_batch(self, nodes_name, host_disk, has_filesys):
        """
        批量部署硬盘
        Date: 2016/12/07
        :param: nodes_name 主机名
        :param: host_params 主机
        :param: has_filesys 是否有文件系统，True代表有文件系统
        """
        LOG.info('begin deploy disk for {0}, host disk is {1}, has filesys is {2} ...'.
                 format(nodes_name, host_disk, has_filesys))
        # crush_host_map = {}
        add_host_result_all = self.__exec_cmd_batch(
            nodes_name,
            command=const.STEP_DEPLOY_DISK,
            host_map_data=host_disk,
            has_filesys=has_filesys
        )
        LOG.info('finish deploy disk for %s', nodes_name)
        add_host_return = self._check_mds_result(add_host_result_all)
        return add_host_return

    def _check_mds_result(self, add_host_result_all):
        """
        对自动部署添加mds结果进行转换为字符串
        :param: add_host_result_all 自动部署主机结果
        :return: 失败原因或成功success
        """
        deploy_result = {}
        error_reason = 'success'
        for add_host_result in add_host_result_all:
            if add_host_result_all[add_host_result] != 'success':
                if errno.SUCCESS != add_host_result_all[add_host_result]['result']:
                    if add_host_result_all[add_host_result]['data']:
                        faile_item = self.reset_err_msg(add_host_result_all[add_host_result]['data']['reason'],
                                                        'MDS_create')
                        error_reason = faile_item['str_msg']
                    else:
                        error_reason = add_host_result_all[add_host_result]['result'][2]
                deploy_result[add_host_result] = error_reason
            else:
                deploy_result[add_host_result] = 'success'
        return deploy_result

    def _get_osd_status_batch(self, step_name, nodes_name, host_info):
        """
        批量获取osd id
        Date: 2016/12/07
        """
        LOG.info('begin get osd id for %s ...', ','.join(nodes_name))
        ssh_mutex_lock = threading.Lock()
        self.__exec_cmd_batch(
            nodes_name,
            command=step_name,
            host_info=host_info,
            lock=ssh_mutex_lock
        )
        LOG.info('finish get osd id for {0}, host info is {1}'.format(','.join(nodes_name), host_info))

    def _sync_tgt_batch(self, nodes_name):
        """
        批量同步tgt
        Date: 2016/12/07
        """
        LOG.info('begin sync tgt for %s ...', nodes_name)
        self.__exec_cmd_batch(
            nodes_name,
            command=const.STEP_SYNC_TGT,
            op=const.OP_ADD_STOR
        )
        LOG.info('finish sync tgt for %s', nodes_name)

    def _restart_diamond_batch(self, nodes_name):
        """
        批量重启diamond进程
        Date: 2016/12/07
        """
        LOG.info('begin restart diamond for %s ...', nodes_name)
        self.__exec_cmd_batch(
            nodes_name,
            command=const.STEP_RESTART_DIAMOND
        )
        LOG.info('finish restart diamond for %s', nodes_name)

    @staticmethod
    def _update_progress(op, progress, hostname=None, data=None):
        """
        更新操作进度
        Author: dai.xinchun@h3c.com
        Date: 2017/01/14
        """
        progress_data = {
            'progress': progress
        }
        with open(const.PROGRESS_FILE.format(op), 'wb') as f:
            if const.OP_REMOVE_DISK == op:
                progress_data['hostname'] = hostname
                progress_data['disks'] = data
            f.write(json.dumps(progress_data))

    def __sleep_with_network_check(self, host_ip):
        """
        等待60s的过程中需要检查网络
        Author: dai.xinchun@h3c.com
        Date: 2017/01/14
        """
        i = 0
        while i < 12:
            if not self.network_check(host_ip, 3):
                raise errno.ONEStorError(errno.ERROR_HOST_NETWORK_FAULT)
            time.sleep(5)
            i += 1

    def _waiting_for_data_rebalance(self, host_ip, host_name, diskpool_list):
        """
        维护模式项目等待集群数据平衡完成
        Author: dai.xinchun@h3c.com
        Date: 2017/01/14
        """
        LOG.info('start to waiting for data rebalance, node ip is {}'.format(host_ip))
        self.__sleep_with_network_check(host_ip)
        total_recover_pg = self.query_recovering_pg(diskpool_list)
        recovered_pg_progress = 0
        while True:
            try:
                # self._check_host_delete(const.OP_REMOVE_DISK_CN, host_name)
                # 进度未到100% 且 需要恢复的pg数不等于0
                if recovered_pg_progress < 100 and total_recover_pg != 0:
                    recovered_pg_progress = self._query_rebalance_progress(diskpool_list,
                                                                           total_recover_pg, recovered_pg_progress)
                    LOG.info('waiting 5s more for data rebalance, total pg num is {}, '
                             'recovered pg num is {}'.format(total_recover_pg, recovered_pg_progress))
                    time.sleep(5)
                else:
                    break
            except (errno.ONEStorError, Exception) as e:
                LOG.error('waiting for data rebalance happens exception, error is {}'.format(e))
                if not self.network_check(host_ip, 3):
                    raise errno.ONEStorError(errno.ERROR_HOST_NETWORK_FAULT)
                else:
                    raise errno.ONEStorError(errno.ERROR_WAIT_DATA_REBALANCE)
        LOG.info('end to waiting for data rebalance, node ip is {}, total_recover_pg is {},'
                 ' recovered_pg_progress is {}'.format(host_ip, total_recover_pg, recovered_pg_progress))

    # def _get_maintain_mode(self, nodepool_list, diskpool_list):
    #     """
    #     获取当前是否开启了维护模式
    #     如果节点池开启维护模式（on）：即其下属的硬盘池均开启维护模式；
    #     如果节点池关闭维护模式（off）：即其下属的硬盘池均关闭维护模式；
    #     如果节点池部分开启维护模式（partial）：即其下属的硬盘池开启、关闭维护模式都存在；
    #     Author: dai.xinchun@h3c.com
    #     Date: 2017/01/14
    #     """
    #     LOG.info('begin get maintain mode, nodepool list is {0},'
    #              ' diskpool list is {1}'.format(nodepool_list, diskpool_list))
    #     maintain_mode = False
    #     maintain_on_nodepool = []  # 开启维护模式的节点池
    #     maintain_on_diskpool = []  # 开启维护模式的硬盘池
    #     nodepool_list_data = self.query_nodepool_data()
    #     # 先判断nodepool是否开启维护模式
    #     for nodepool in nodepool_list:
    #         for nodepool_data in nodepool_list_data:
    #             if nodepool_data['nodepool_name'] == nodepool:
    #                 if 'on' == nodepool_data['maintain_mode']:
    #                     maintain_mode = True
    #                     maintain_on_nodepool.append(nodepool)
    #                 if 'partial' == nodepool_data['maintain_mode']:
    #                     # 某节点池下的部分硬盘池开启维护模式
    #                     maintain_mode = True
    #     if maintain_mode:
    #         # 存在节点池开启维护模式
    #         if len(maintain_on_nodepool):
    #             raise errno.ONEStorError(errno.ERROR_NODEPOOL_MAINTAIN_MODE, ','.join(maintain_on_nodepool))
    #     else:
    #         # 不存在节点池开启维护模式
    #         return
    #     # 存在节点池部分开启维护模式
    #     diskpool_list_data = self.query_diskpool_data({'nodepool_name': ''}, 'DISKPOOL_query_short')
    #     for diskpool in diskpool_list:
    #         for diskpool_data in diskpool_list_data:
    #             if diskpool_data['diskpool_name'] == diskpool:
    #                 if 'on' == diskpool_data['maintain_mode']:
    #                     maintain_on_nodepool.append(diskpool)
    #     if len(maintain_on_nodepool):
    #         # 存在硬盘池开启维护模式
    #         raise errno.ONEStorError(errno.ERROR_DISKPOOL_MAINTAIN_MODE, ','.join(maintain_on_diskpool))
    #     LOG.info('end get maintain mode, nodepool list data is {0},'
    #              ' diskpool list data is {1}'.format(nodepool_list_data, diskpool_list_data))

    def _check_journal_and_fcache_disks(self, host_name, disks):
        # 删除硬盘之前先检查对于的读写缓存的ssd是否已经被拔掉了
        disk_str_encode = base64.b64encode(json.dumps(disks))
        check_ssd_missing = "/opt/h3c/bin/python %s/check_journal_fcache_disk.py '%s'" % (
            const.HANDY_SHELL_PATH, disk_str_encode)

        LOG.info('_check_journal_and_fcache_disks command: %s', check_ssd_missing)
        check_disk_result = self.exec_remote_ssh_cmd(host_name, check_ssd_missing)
        LOG.info('_check_journal_and_fcache_disks result: %s', check_disk_result)

        return check_disk_result == 'fail'

    def _check_public_ip(self, node_ip):
        """
        检查IP地址是否在业务网段内
        Date: 2016/12/21
        """
        public_network = self.cluster_config['public_network']
        if not self.subnet_judge(public_network, node_ip):
            raise errno.ONEStorError(errno.ERROR_IP_NOT_IN_PUBLIC_NETWORK)

    def _check_public_ip_list(self, node_ip_list):
        """
        检查IP地址是否在业务网段内
        Date: 2016/12/21
        """
        public_network = self.cluster_config['public_network']
        fail_nodes = []
        for node in node_ip_list:
            if not self.subnet_judge(public_network, node):
                fail_nodes.append(node)
        if 0 != len(fail_nodes):
            raise errno.ONEStorHostError(errno.ERROR_IP_NOT_IN_PUBLIC_NETWORK, fail_nodes, const.STEP_VALIDATE_NETWORK)

    def _assert_network_ok(self, node_ip):
        """
        检查网络是否能通
        Date: 2016/12/21
        """
        if not self.network_check(node_ip):
            raise errno.ONEStorError(errno.ERROR_NETWORK_FAULT, node_ip)

    def _check_exist_mon(self, host_name):
        """
        检查网络是否能通
        Date: 2016/12/21
        """
        roles = self.get_host_roles_by_name(host_name, self.cluster_config)
        if roles and roles['mon']:
            raise errno.ONEStorError(errno.ERROR_MON_EXIST)

    def _check_nas_ready(self):
        """
        检查nas节点上的配置是否更改成功
        """
        LOG.info('begin deploy nas...')
        client = onestor.message.Messenger.create_leaderclient(
            host='localhost',
            timeout=fsmsg.estimate_time(fsmsg.OP_NAS_UPDATE_NODES))
        if client is None:
            raise errno.ONEStorError(errno.ERR_CONNECT)
        _request = fsmsg.make_request(fsmsg.OP_NAS_UPDATE_NODES)
        _request.data = {}
        response = client.send_request(_request)
        if leadererrno.SUCCESS != response.result:
            raise errno.ONEStorError(response.result)
        else:
            failed_nodes = []
            for host in response.data:
                if leadererrno.SUCCESS != response.data[host]['result']:
                    failed_nodes.append(host)
            if failed_nodes:
                raise errno.ONEStorError(errno.ERROR_UPDATE_NAS_CFG, ', '.join(failed_nodes))
        LOG.info('deploy nas success')

    def _get_remove_status(self, data, op):
        """
        获取删除后集群能否平衡的状态
        :return:
        """
        client = onestor.message.Messenger.create_leaderclient(
            host='localhost',
            timeout=hostmsg.estimate_time(op))
        if client is None:
            LOG.info('create client error')
            return {'status': 'error', 'reason': '连接失败'}
        _request = hostmsg.make_request(op)
        _request.data = json.loads(data)
        LOG.info('make_request result: %s', _request)
        response = client.send_request(_request)
        if leadererrno.SUCCESS != response.result:
            LOG.info('response error result is : %s', response)
            return {'status': 'error', 'reason': response.result[2]}
        else:
            return {'status': 'success', 'data': response.data}

    def _deploy_mon(self, node_ip, host_name):
        """
        开始部署监控节点
        Date: 2016/12/21
        """
        # 清除目标节点上/var/lib/ceph/mon/目录下的文件（夹）
        self.exec_remote_ssh_cmd(node_ip, 'rm -rf /var/lib/ceph/mon/*')
        # 调用ceph-deploy mon add部署监控节点
        self.exec_remote_ssh_cmd(node_ip, '/opt/h3c/bin/python /var/lib/ceph/shell/operate_mon.py '
                                 'add_mon {0} {1}'.format(host_name, node_ip))
        LOG.info('sleep 20 seconds, waiting for mon ready...')
        time.sleep(20)
        # 部署完之后的检查，最长等待2分钟，如果进程没起来则返回失败
        pre_time = datetime.datetime.now()
        while True:
            mon_pid = self.exec_remote_ssh_cmd(node_ip, 'pidof ceph-mon')
            if '' != mon_pid:
                break
            LOG.info('waiting for new mon ready...')
            time.sleep(5)
            new_time = datetime.datetime.now()
            if new_time - pre_time > datetime.timedelta(minutes=2):
                raise errno.ONEStorError(errno.ERROR_START_MON_DAEMON)
        # 检查是否操作成功
        quorum_pre_time = datetime.datetime.now()
        while True:
            quorum_status = self.exec_local_cmd_json('timeout 60 ceph quorum_status -f json')
            host_in_monmap = [mon['name'] for mon in quorum_status['monmap']['mons']
                              if host_name == mon['name']]
            if 0 != len(host_in_monmap):
                break
            LOG.info('waiting for new mon add to quorum ready...')
            time.sleep(5)
            quorum_new_time = datetime.datetime.now()
            if quorum_new_time - quorum_pre_time > datetime.timedelta(minutes=2):
                raise errno.ONEStorError(errno.ERROR_ADD_MON_TO_QUORUM)

    def mon_status_is_ok(self, mon_name):
        """
        判断mon状态
        :param mon_name:
        :return:
        """
        try:
            quorum_status = self.exec_local_cmd_json('timeout 60 ceph quorum_status -f json')
            if mon_name in quorum_status['quorum_names']:
                return True
            return False
        except Exception as e:
            LOG.exception(e)
            return False


    def _update_mon_cfg(self, node_ip, host_name, op, exclude_nodes=None):
        """
        更新ceph.conf中的MON配置
        Date: 2016/12/21
        """
        # 获取集群所有节点
        cluster_hosts = self.get_cluster_hosts_from_config()
        hosts_ip = [host[const.HOST_IP] for host in cluster_hosts]
        if exclude_nodes is not None:
            hosts_ip = list(set(hosts_ip) - set(exclude_nodes))
        # 登录到各个节点上修改mon配置
        LOG.info('update mon cfg on nodes %s...', hosts_ip)
        update_cmd = cmd.CMD_UPDATE_MON_CFG.format(
            node_ip, host_name, op)
        update_result = self.multi_thread_task(
            hosts_ip, 'timeout 300 ssh $$ {0}'.format(update_cmd))
        LOG.info('update mon cfg result: %s', update_result)
        failed_nodes = []
        for host_ip in update_result:
            if -1 == update_result[host_ip].find(const.OP_SUCCSSFUL):
                failed_nodes.append(host_ip)
        if 0 != len(failed_nodes):
            raise errno.ONEStorError(errno.ERROR_UPDATE_MON_CFG, ', '.join(failed_nodes))

    def _assert_ceph_command_useful(self):
        """
        检查ceph命令行是否可以正常执行
        Date: 2016/12/28
        """
        pre_time = datetime.datetime.now()
        while True:
            clusterconfig = self.exec_local_cmd(
                'timeout 30 ceph config-key get clusterconfig')
            LOG.info('test ceph command, clusterconfig is: %s', clusterconfig)
            if '' != clusterconfig:
                break
            LOG.info('waiting for ceph command ready...')
            time.sleep(5)
            new_time = datetime.datetime.now()
            if new_time - pre_time > datetime.timedelta(minutes=5):
                raise errno.ONEStorError(errno.ERROR_LEVELDB_UNAVAILABLE)

    def _remove_mon_from_quorum(self, node_name, sleep_time=20):
        """
        从quorum中移除监控节点
        Date: 2016/12/28
        """
        # 从quorum中删除该mon
        self.exec_local_cmd('ceph mon remove %s' % node_name)
        # 检查是否操作成功
        LOG.info('sleep %s seconds, waiting for mon ready...', sleep_time)
        time.sleep(sleep_time)
        quorum_status = self.exec_local_cmd_json('timeout 60 ceph quorum_status -f json')
        host_in_monmap = [mon['name'] for mon in quorum_status['monmap']['mons']
                          if node_name == mon['name']]
        if 0 != len(host_in_monmap):
            raise errno.ONEStorError(errno.ERROR_RM_MON_FROM_QUORUM)
        # 检查ceph config-key命令是否可以正常使用，刚刚删除完mon可能会挂住，需要增加超时等待
        self._assert_ceph_command_useful()

    def _process_remove_mon(self, node_ip, node_name, offline=False):
        """
        删除监控节点
        Date: 2016/12/28
        """
        if offline:
            LOG.info('begin remove offline mon "%s"...', node_name)
            # 更新所有其它节点上ceph.conf里的mon配置
            self._update_mon_cfg(
                node_ip, node_name, const.OP_REMOVE_MON, exclude_nodes=[node_ip])
            # 从quorum中移除监控节点
            self._remove_mon_from_quorum(node_name)
            # 更新所有其它节点上的NTP配置，排除当前离线的监控节点
            self._update_ntp_cfg(node_name, exclude_nodes=[node_name])
        else:
            LOG.info('begin remove mon "%s"...', node_name)
            # 更新所有节点上ceph.conf里的mon配置
            self._assert_network_ok(node_ip)
            self._update_mon_cfg(node_ip, node_name, const.OP_REMOVE_MON)
            # 从quorum中移除监控节点
            self._remove_mon_from_quorum(node_name)
            distro = platform.dist()[0]
            if distro == "centos":
                os.system('systemctl stop ceph-mgr@{}.service'.format(node_name))
            else:
                os.system('stop ceph-mgr id=%s' % node_name)
            time.sleep(10)
            # 删除/var/lib/ceph/mon-removed目录和/var/lib/ceph/mon/*目录
            self._assert_network_ok(node_ip)
            self.exec_remote_ssh_cmd(node_ip, 'rm -rf /var/lib/ceph/mon-removed')
            self._assert_network_ok(node_ip)
            self.exec_remote_ssh_cmd(node_ip, 'rm -rf /var/lib/ceph/mon/*')
            self.exec_remote_ssh_cmd(node_ip, 'rm -rf /var/lib/ceph/mgr/*')
            self._assert_ceph_command_useful()
            # 更新所有节点上的NTP配置
            self._assert_network_ok(node_ip)
            self._update_ntp_cfg(node_name)

    def _clear_mon_graphite_data(self, node_name, roles):
        """
        清除监控数据
        Date: 2016/12/28
        """
        # modify by r13889 2017/03/24 PN:201703160637
        need_retain_graphite = True if roles['stor'] or roles['mds'] or roles['nas'] or roles['rgw'] else False
        # 当前监控节点不作为存储、MDS、NAS、对象网关节点时需要清除graphite监控数据
        if not need_retain_graphite:
            self.exec_remote_ssh_cmd(node_name, '/opt/h3c/bin/python /var/lib/ceph/shell/stop_diamond.py')
        elif not roles['stor']:
            # 防止作为对象网关残留或存储节点删除未清理干净，需要清理存储节点信息
            need_retain_graphite = True
        if roles and roles['stor']:
            return True
        clear_graphite_cmd = '/opt/h3c/bin/python /var/lib/ceph/shell/whisper_cleaner.py ' \
                             'remove_host %s %s' % (node_name, need_retain_graphite)
        LOG.info('begin clearing graphite, cmd is: %s...', clear_graphite_cmd)
        clear_graphite_ret = self.exec_cmd_on_handy_nodes(clear_graphite_cmd)
        if const.OP_SUCCSSFUL != clear_graphite_ret:
            LOG.warn('clean graphite failed when remove mon')

    def _update_ntp_cfg(self, node_name, exclude_nodes=None):
        """
        更新NTP配置
        Date: 2016/12/28
        """
        # 集群外的NTP或没有开启NTP时删除MON无需修改任何配置
        ntp_type = self.get_ntp_type()
        if const.NTP_CLOSE == ntp_type or const.NTP_OUT_CLUSTER == ntp_type:
            return
        cluster_config = self.get_clusterconfig()
        mon_nodes = cluster_config['mon_fqdns']
        if node_name in mon_nodes:
            mon_nodes.remove(node_name)
        self._reconfig_cluster_ntp(mon_nodes, exclude_nodes)

    def _assert_cluster_nodes_network_ok(self, exclude_nodes=None):
        """
        检查集群节点网络是否正常
        :param exclude_nodes 不需要检查的节点业务网IP
        Date: 2016/12/21
        """
        # 获取集群所有节点
        cluster_hosts = self.get_cluster_hosts_from_config()
        hosts_ip = [host[const.HOST_IP] for host in cluster_hosts]
        if exclude_nodes is not None:
            hosts_ip = list(set(hosts_ip) - set(exclude_nodes))
        LOG.info('check network on nodes %s...', hosts_ip)
        for host_ip in hosts_ip:
            if not self.network_check(host_ip):
                raise errno.ONEStorError(errno.ERROR_NETWORK_FAULT, host_ip)

    def _config_lvs_server(self, hosts_name, exclude_role):
        """
        配置LVS服务器
        Date: 2016/12/21
        """
        LOG.info('begin config lvs server...')
        for host_name in hosts_name:
            roles = self.get_host_roles_by_name(host_name)
            if roles is None or (not roles[exclude_role]):
                ha_switch = '2' if const.ROLE_RGW == exclude_role else '1'
                self.add_realserver(host_name, ha_switch)
                self.realserver_ha_hosts(ha_switch, 'add', self.name_to_ip(host_name))

    def _remove_lvs_server(self, host_name, exclude_role):
        """
        删除LVS服务器
        """
        LOG.info('begin remove lvs server...')
        roles = self.get_host_roles_by_name(host_name)
        if const.ROLE_RGW == exclude_role or roles is None or (not roles[exclude_role]):
            ha_switch = '2' if const.ROLE_RGW == exclude_role else '1'
            self.remove_realserver(host_name, ha_switch)
            self.realserver_ha_hosts(ha_switch, 'del', self.name_to_ip(host_name))

    @staticmethod
    def _get_partition_ip_list_batch(host_partition_map, host_ip_map):
        """
        自动部署 获得partition_ip_list
        :param host_partition_map: 分区主机列表
        :param host_ip_map: 主机ip列表
        :return:
        """
        LOG.info('begin _get_partition_ip_list_batch ...')
        partition_ip_list = {}
        for host_name in host_partition_map:
            part_name = host_partition_map[host_name]
            if part_name not in partition_ip_list:
                partition_ip_list[part_name] = []
            host_ip = host_ip_map[host_name]
            partition_ip_list[part_name].append(host_ip)
        return partition_ip_list

    @staticmethod
    def _get_partition_ip_list_single(partition_info, node_ip):
        """
        手动部署 获得partition_ip_list
        :param partition_info: 分区名称
        :param node_ip: 主机ip
        :return:
        """
        LOG.info('begin _get_partition_ip_list_single ...')
        partition_ip_list = {partition_info: []}
        partition_ip_list[partition_info].append(node_ip)
        return partition_ip_list

    @staticmethod
    def _get_partition_ip_list_cluster(partition_host_list_obj, host_ip_map):
        """
        集群部署 获得partition_ip_list
        :param partition_host_list_obj: 分区主机列表
        :param host_ip_map: 主机ip列表
        :return:
        """
        LOG.info('begin _get_partition_ip_list_cluster ...')
        partition_ip_list = {}
        for partition_host in partition_host_list_obj:
            part_name = partition_host['partition']
            partition_ip_list[part_name] = []
            for hostname in partition_host['host']:
                if not host_ip_map[hostname] in partition_ip_list[part_name]:
                    partition_ip_list[part_name].append(host_ip_map[hostname])
        return partition_ip_list

    def _backup_mon_tgt(self):
        """
        备份主mon的tgt文件到handy节点tmp目录
        :return:
        """
        leader_mon_name = self.get_leader_mon()
        leader_mon_ip = self.name_to_ip(leader_mon_name)
        # 从主MON上获取tgt配置到handy点tmp目录
        self.exec_local_cmd('rm -rf /tmp/tgt')
        self.exec_local_cmd('mkdir -p /tmp/tgt/')
        self.exec_local_cmd('scp [%s]:/etc/tgt/conf.d/* /tmp/tgt/' % leader_mon_ip)

    def _move_pod_osd_to_host(self, hostname):
        """
        将root=maintain中，pod=hostname_pod下的所有osd，移动到host=hostname下，再将hostname_pod删除
        Date: 2017/5/16
        """
        osd_tree = json.loads(self.exec_local_cmd(cmd.CMD_CEPH_OSD_TREE))
        all_osd_id = []
        for node in osd_tree['nodes']:
            if const.HOST_NAME_POD.format(hostname) == node['name']:
                all_osd_id = node['children']
                break
        if 0 != len(all_osd_id):
            for osd_id in all_osd_id:
                self.exec_local_cmd(cmd.CMD_MOVE_OSD_BUCKET.format(
                    osd_id, const.BUCKET_HOST, hostname))
            self.exec_local_cmd(cmd.CMD_REMOVE_BUCKET.format(const.HOST_NAME_POD.format(hostname)))

    @staticmethod
    def reset_err_msg(data, op=None):
        """
        对后台创建mds返回参数进行处理
        :param data:添加mds返回结果
        :param op: 操作码
        :return:{'arr_msg': 失败数组, 'str_msg': 失败字符串}
        """
        fail_items = []
        for key in data:
            if op == fsmsg.OP_MDS_CREATE:
                fail_items.append({'ip': key,
                                   'reason': data[key][2]})
            if op != fsmsg.OP_MDS_CREATE and errno.SUCCESS != data[key]['result']:
                fail_items.append({'ip': key,
                                   'reason': data[key]['result'][2]})
        fail_str = ''
        for fail_item in fail_items:
            if op == fsmsg.OP_MDS_CREATE or op == fsmsg.OP_MDS_STOP \
                    or op == fsmsg.OP_MDS_START or op == fsmsg.OP_MDS_REMOVE:
                fail_str += '“'+fail_item['ip']+'”'+fail_item['reason']+'; '
            else:
                fail_str += fail_item['ip']+':'+fail_item['reason']+'; '
        return {'arr_msg': fail_items, 'str_msg': fail_str}

    def _add_host_as_mds(self, host_ip, auto_add=False):
        """
        将主机添加为mds节点
        :author: dangni <dang.ni@h3c.com>
        :date: 2017/10/20
        :param host_ip: 主机ip地址
        :return:
        """
        LOG.info('begin add host as mds %s... ', host_ip)
        host_ip_list = host_ip.split(',')
        add_mds_data = {'ip_addr': host_ip_list}
        add_mds_response = send_request_onestord('COMP_FS', 'MDS_create', add_mds_data, 'fs')
        LOG.error('add_mds_response=%s', add_mds_response['response'])
        error_reason = 'success'
        if errno.SUCCESS != add_mds_response['response']['result']:
            if add_mds_response['response']['data']:
                faile_item = self.reset_err_msg(add_mds_response['response']['data']['reason'], 'MDS_create')
                error_reason = faile_item['str_msg']
            else:
                error_reason = add_mds_response['response']['result'][2]
            if auto_add:
                return add_mds_response['response']
            else:
                raise errno.ONEStorHostError(
                    errno.ERROR_STOR_ADD_MDS_BATCH,
                    host_ip_list,
                    const.STEP_ADD_MDS,
                    error_reason)
        else:
            # 添加MDS成功，将主机加入NAS_server_new数据库表中
            host_name = self.ip_to_name(host_ip)
            self.add_host_to_nas_db(host_ip, host_name, 'MDS')
        LOG.info('end add host as mds %s... ', host_ip)
        return error_reason

    def check_mds_result(self, add_result):
        """
        自动部署需要检查mds添加结果
        :author: dangni <dang.ni@h3c.com>
        :date: 2017/11/18
        :param add_result:添加mds结果
        :return:{'mds_success_node': 成功节点ip, 'node_name': 成功节点主机名称,
                'error_reason': 失败原因, 'error_node_ip': 失败节点ip}
        """
        mds_failed_node = []
        mds_success_node = []
        success_node_name = []
        error_reason = []
        error_node_ip = []
        reason = ''
        for node in add_result:
            node_ip = self.name_to_ip(node)
            if add_result[node] != 'success':
                mds_failed_node.append(node_ip)
                if add_result[node].find(':'):
                    reason = add_result[node].split(';')[0]
                else:
                    reason = node_ip + add_result[node]
                error_reason.append(reason)
                error_node_ip.append(node_ip)
            else:
                mds_success_node.append({'ip': node_ip, 'name': node})
                success_node_name.append(node)
        if len(mds_success_node) == 0:
            error_reason_str = "; " .join(error_reason)
            # raise errno.ONEStorError(errno.ERROR_STOR_ADD_MDS_BATCH, error_reason_str)
            raise errno.ONEStorHostError(
                errno.ERROR_STOR_ADD_MDS_BATCH,
                mds_failed_node,
                const.STEP_ADD_MDS,
                error_reason_str)
        return {'mds_success_node': mds_success_node, 'node_name': success_node_name,
                'error_reason': error_reason, 'error_node_ip': error_node_ip}

    @staticmethod
    def _check_has_filesys():
        """
        检查当前集群是否有文件系统
        :author: dangni <dang.ni@h3c.com>
        :date: 2017/10/20
        :return: True或False,True代表有文件系统
        """
        list_filesys_data = {'first': True}
        has_filesys = False
        list_filesys_response = send_request_onestord('COMP_FS', fsmsg.OP_FS_QUERY, list_filesys_data, 'fs')
        if errno.SUCCESS != list_filesys_response['response']['result']:
            raise errno.ONEStorError(errno.ERROR_GET_FS, list_filesys_response['response']['result'][2])
        if len(list_filesys_response['response']['data']) > 0:
            has_filesys = True
        return has_filesys

    def _remove_mds(self, host_ip, node_name, use, return_result=False):
        """
        向onestord发送删除MDS的请求
        :author: dangni <dang.ni@h3c.com>
        :date: 2017/10/20
        :param host_ip: 主机ip地址
        :param node_name: 主机名称
        :param use: 用途
        :param return_result: 是否返回删除失败,回滚操作不用返回失败原因。
        :return:
        """
        remove_mds_data = {'ip_addr': host_ip}
        if host_ip:
            LOG.info('begin remove mds data=%s', remove_mds_data)
            remove_mds_response = send_request_onestord('COMP_FS', fsmsg.OP_MDS_REMOVE, remove_mds_data, 'fs')
            if errno.SUCCESS != remove_mds_response['response']['result']:
                if return_result:
                    raise errno.ONEStorError(errno.ERROR_REMOVE_MDS, remove_mds_response['response']['result'][2])
                LOG.error(remove_mds_response['response']['result'][2])
            else:
                LOG.info('begin remove mds %s from nas_server_new ...', host_ip)
                self._remove_mds_from_db(host_ip, node_name, use, return_result)
            LOG.info('end remove mds ip =%s', host_ip)

    def _remove_mds_from_db(self, node_ip, node_name, use, return_result=False):
        """
        将主机从nas_server_new表中删除
        :author: dangni <dang.ni@h3c.com>
        :date: 2017/10/20
        :host_ip:主机ip地址
        :node_name:主机名称
        :use:用途
        :return_result:是否返回删除失败
        """
        nas_server_new_db = self.exec_local_cmd_json(cmd.DB_GET_NAS_SERVER_NEW)
        if not nas_server_new_db:
            if return_result:
                raise errno.ONEStorConfigError(errno.ERR_GET_NAS_SERVER_NEW)
            LOG.error('remove mds form db get nas_sever_new error')
        for _host in nas_server_new_db[const.TABLE_NAS_SERVER_NEW]:
            if node_ip == _host[const.HOST_IP] and node_name == _host[const.HOST_NAME] and \
                    use == _host[const.HOST_USE]:
                database.delete_one(const.TABLE_NAS_SERVER_NEW, [
                    {'id': _host['id']}
                ])
        LOG.info('end remove mds %s from nas_server_new ...', node_ip)

    @staticmethod
    def _active_mds(add_host_auto=None):
        """
        激活MDS操作
        :author: dangni <dang.ni@h3c.com>
        :date: 2017/11/18
        :param add_host_auto 是否是自动部署，是自动部署传参为True,否则不传
        :return:
        """
        LOG.info('begin activate mds ...')
        active_mds_data = {}
        active_mds_response = send_request_onestord('COMP_FS', 'MDS_activate', active_mds_data, 'fs')
        LOG.info('active_mds_response=%s', active_mds_response['response'])
        if errno.SUCCESS != active_mds_response['response']['result']:
            LOG.error('active mds fail %s', active_mds_response['response']['result'][2])
            error_reason = active_mds_response['response']['result'][2]
            if add_host_auto:
                raise errno.ONEStorHostError(
                    errno.ERROR_ACTIVE_MDS,
                    error_reason,
                    const.STEP_ADD_MDS,
                    error_reason)
            else:
                raise errno.ONEStorError(errno.ERROR_ACTIVE_MDS, error_reason)

        LOG.info('end activate mds ...')

    def _check_stor_num(self, add_host_num=1):
        """
        检查存储节点个数
        :author: dangni <dang.ni@h3c.com>
        :date: 2017/11/1
        :param add_host_num: 添加的存储节点个数
        :return:
        """
        osd_tree = json.loads(self.exec_local_cmd(cmd.CMD_CEPH_OSD_TREE))
        all_host_name = []
        for node in osd_tree['nodes']:
            if node['type'] == 'host' and (not node['name'].endswith('_ssd')):
                all_host_name.append(node['name'])
        if const.HOST_NUM_LIMIT <= (len(all_host_name) + add_host_num):
            raise errno.ONEStorError(errno.ERROR_STOR_NUM_LIMIT)


    def get_partition(self, data):
        """
        批量增加主机时，获取分区列表
        :return:
        """
        partition_list = data.values()
        partition_list_not_rep = list(set(partition_list))
        return partition_list_not_rep

    def host_remove_before(self, host_name=None, roles=None):
        """
        主机删除前条件判断
        :param host_name: 主机名
        :param roles: 主机角色，为删除该节点前的角色
        :return: None
        """
        host_role = roles if roles is not None else self.get_host_roles_by_name(host_name)
        # 网关角色存在则不允许删除
        if 2 == host_role['role_num'] and host_role['rgw'] and not host_role['nas'] and not host_role['mds']:
            LOG.error("remove host %s failed, radosgw should be removed first", host_name)
            raise errno.ONEStorError(errno.ERROR_RGW_EXISTED, host_name)

    def remove_ha_before(self):
        """
        删除管理高可用前环境判断
        :return: None
        """
        ha_info = self.list_handyha()
        if ha_info['handyha']:
            handy_info = ha_info['handyha'][0]
            # 获取将要移除的Handy节点，并判断是否还是网关
            master_name = self.ip_to_name(handy_info['master_public_ip'])
            slave_name = self.ip_to_name(handy_info['slave_public_ip'])
            local_name = self.exec_local_cmd(const.HOST_NAME)
            remove_handy_name = slave_name if master_name == local_name else master_name
            self.host_remove_before(remove_handy_name)
        return True

    @staticmethod
    def setup_zookeeper(mon_manage_ips):
        """
        配置运行zookeeper集群
        :param mon_manage_ips:
        :return:
        """
        LOG.info('Start to setup zookeeper to hosts: "{}" ...'.format(mon_manage_ips))
        data = {
            'hosts': mon_manage_ips
        }
        rep = send_request_onestord(const.D_COMP_CM, const.D_OP_ZK_SETUP, data, need_log=True)
        rep_status = rep['status']
        if 'success' != rep_status:
            return False
        rep_result = rep['response']['result']
        if 0 != rep_result[0]:
            return False
        LOG.info('Succeed to setup zookeeper to hosts: "{}".'.format(mon_manage_ips))
        return True

    def add_zookeeper(self, hosts):
        """
        增加zookeeper
        :param:
        :return:
        """
        # 获取mon的三网ip
        LOG.info('Start to add zookeeper to hosts: "{0}" ...'.format(hosts))
        data = {
            'hosts': []
        }
        checked_hosts = self.checked_hosts_ip.keys()
        for host in hosts:
            if host in checked_hosts:
                data['hosts'].append(self.checked_hosts_ip[host])
            else:
                raise errno.ONEStorError(errno.ERROR_UNCHECK_NETWORK, host)
        # 发送请求
        rep = send_request_onestord(const.D_COMP_CM, const.D_OP_ZK_ADD, data, need_log=True)
        rep_status = rep['status']
        if 'success' != rep_status:
            raise errno.ONEStorError(errno.ERROR_SEND_TO_ONESTORD)
        rep_result = rep['response']['result']
        if 0 != rep_result[0]:
            raise errno.ONEStorError.make_error(rep_result[1], rep_result[2])
        LOG.info('Succeed to add zookeeper to hosts: "{0}".'.format(hosts))

    @staticmethod
    def remove_zookeeper(host, offline=False):
        LOG.info('Start to remove zookeeper form {1} host: "{0}" ...'.format(host, 'online' if offline else 'offline'))
        data = dict(hosts=[host], offline=offline)
        rep = send_request_onestord(const.D_COMP_CM, const.D_OP_ZK_DELETE, data, need_log=True)
        rep_status = rep['status']
        if 'success' != rep_status:
            raise errno.ONEStorError(errno.ERROR_SEND_TO_ONESTORD)
        rep_result = rep['response']['result']
        if 0 != rep_result[0]:
            raise errno.ONEStorError.make_error(rep_result[1], rep_result[2])
        LOG.info('Succeed to remove zookeeper form {1} host: "{0}".'.format(host, 'online' if offline else 'offline'))

    def save_hosts_base_info(self, hosts):
        # 获取mon的三网ip和主机名
        data = {'hosts': []}
        LOG.info('Start to save hosts: "{0}" base info...'.format(hosts))
        checked_hosts = self.checked_hosts_ip.keys()
        for host in hosts:
            if host in checked_hosts:
                data['hosts'].append(self.checked_hosts_ip[host])
            else:
                raise errno.ONEStorError(errno.ERROR_UNCHECK_NETWORK, host)

        rep = send_request_onestord(const.D_COMP_CM, const.D_OP_HOST_SAVE, data, need_log=True)
        rep_status = rep['status']
        if 'success' != rep_status:
            raise errno.ONEStorError(errno.ERROR_SEND_TO_ONESTORD)
        rep_result = rep['response']['result']
        if 0 != rep_result[0]:
            raise errno.ONEStorError.make_error(rep_result[1], rep_result[2])
        LOG.info('Succeed to save hosts: "{0}" base info.'.format(hosts))

    @staticmethod
    def delete_host_base_info(data, key='name'):
        """
        根据主机名删除主机
        :param key: name/manage_ip
        :param data: 主机名/管理网ip
        :return:
        """
        LOG.info('Start to delete host: "{0}" base info...'.format(data))
        if 'manage_ip' == key:
            data = dict(manage_ip=data)
            rep = send_request_onestord(const.D_COMP_CM, const.D_OP_HOST_DELETE_BY_MIP, data, need_log=True)
        else:
            data = dict(name=data)
            rep = send_request_onestord(const.D_COMP_CM, const.D_OP_HOST_DELETE, data, need_log=True)
        rep_status = rep['status']
        if 'success' != rep_status:
            raise errno.ONEStorError(errno.ERROR_SEND_TO_ONESTORD)
        rep_result = rep['response']['result']
        if 0 != rep_result[0]:
            raise errno.ONEStorError.make_error(rep_result[1], rep_result[2])
        LOG.info('Succeed to delete host: "{0}" base info.'.format(data))

    def stop_nm_sub(self, hosts):
        """
        停止nm sub进程
        :param hosts:
        :return:
        """
        ref = self.multi_thread_task(hosts, cmd.CMD_STOP_NM_SUB)
        LOG.info('Stop hosts: "{0}" process nm sub result: "{1}"'.format(hosts, ref))

    def restart_nm_sub(self, hosts):
        """
        重启nm sub进程
        :param hosts: list()
        :return:
        """
        ref = self.multi_thread_task(hosts, cmd.CMD_RESTART_NM_SUB)
        LOG.info('restart hosts: "{0}" process nm sub result: "{1}"'.format(hosts, ref))

    def restart_leader_pub_sub_nm(self, peons):
        """
        重启所有节点的leader，pub，sub，nm进程
        :param peons:
        :return:
        """
        cmd_supervisor_status = "service supervisor status"
        cmd_supervisor_restart = "service supervisor restart"
        cmd_restart_leader_pub = "supervisorctl restart onestor-leader onestor-pub"
        cmd_restart_sub_nm = "timeout 30 ssh $$ supervisorctl restart onestor-sub onestor-nm"
        ref = self.exec_local_cmd(cmd_supervisor_status)
        LOG.info("service supervisor status: {0}".format(ref))
        if 'is running' not in ref:
            ref = self.exec_local_cmd(cmd_supervisor_restart)
            LOG.info("restart supervisor result: {0}".format(ref))
        LOG.info("restart onestor-leader...")
        ref = self.exec_local_cmd(cmd_restart_leader_pub)
        LOG.info('restart onestor-leader result: {0}'.format(ref))
        LOG.info('restart hosts: "{0}" onestor-sub onestor-nm...'.format(peons))
        ref = self.multi_thread_task(peons, cmd_restart_sub_nm)
        LOG.info('restart onestor-sub onestor-nm results: {0}'.format(ref))

    @staticmethod
    def rewrite_ip(host_ips):
        """
        重写ceph.conf中的manage_addr，public_addr，cluster_addr
        :param host_ips:
        :return:
        """
        LOG.info('Start to rewrite hosts: "{0}" ceph.conf ips...'.format(host_ips))
        data = dict(hosts=host_ips)
        rep = send_request_onestord(const.D_COMP_CM, const.D_OP_HOST_REWRITE_IP, data, need_log=True)
        rep_status = rep['status']
        if 'success' != rep_status:
            raise errno.ONEStorError(errno.ERROR_SEND_TO_ONESTORD)
        rep_result = rep['response']['result']
        if 0 != rep_result[0]:
            raise errno.ONEStorError.make_error(rep_result[1], rep_result[2])
        LOG.info('Succeed to rewrite hosts: "{0}" ceph.conf ips.'.format(host_ips))

    @staticmethod
    def check_host_disk_num_limit(host_info_list, add_host_bool=False, deploy_cluster=False):
        """
        判断主机、硬盘数量规格限制（集群最大节点、硬盘数量，单节点池最大节点数量，单硬盘池最大硬盘数量）
        :param host_info_list: 主机信息
        :param add_host_bool: 是否为增加主机(集群部署、单台部署、批量部署为True)
        :param deploy_cluster: 是否部署集群
        :return
        """
        LOG.info('begin check host disk num limit, host info list is {0}, add host bool is {1}, deploy cluster is {2}'
                 .format(host_info_list, add_host_bool, deploy_cluster))
        host_num = 0
        disk_num = 0
        host_in_nodepool = {}
        disk_in_diskpool = {}
        for host_info in host_info_list:
            diskpool_list = host_info['diskpool_list']
            for diskpool in diskpool_list:
                disk_num_in_diskpool = len(host_info[diskpool]['data'])
                if diskpool in disk_in_diskpool and disk_in_diskpool[diskpool]:
                    disk_in_diskpool[diskpool] += disk_num_in_diskpool
                else:
                    disk_in_diskpool[diskpool] = disk_num_in_diskpool
                disk_num += disk_num_in_diskpool
            if add_host_bool:
                # 涉及主机增加
                host_num += 1
                if host_info['nodepool_name'] in host_in_nodepool and host_in_nodepool[host_info['nodepool_name']]:
                    host_in_nodepool[host_info['nodepool_name']] += 1
                else:
                    host_in_nodepool[host_info['nodepool_name']] = 1
            else:
                host_in_nodepool[host_info['nodepool_name']] = 0
        LOG.info('host num is {0}, disk num is {1}, host in nodepool is {2}, disk in diskpool is {3}'.format(
            host_num, disk_num, host_in_nodepool, disk_in_diskpool))
        data = {
            'host_num': host_num,
            'disk_num': disk_num,
            'host_in_nodepool': host_in_nodepool,
            'disk_in_diskpool': disk_in_diskpool,
            'deploy_cluster': deploy_cluster
        }
        check_num_response = send_request_onestord(const.COMP_CS, const.OP_CHECK_HOST_OSD_NUMBER_LIMIT, data)
        check_num_result = check_num_response['response']['result']
        if 0 != check_num_result[0]:
            LOG.error('check host disk num limit error, response is %s', check_num_response)
            raise errno.ONEStorError(check_num_result)
        LOG.info('end check host disk num limit, result is {}'.format(check_num_response))

    @staticmethod
    def update_diskpool_capacity(host_info_list, type, host_disk_capacity=None):
        """
        更新硬盘池容量大小
        :param host_info_list: 主机信息
        :param type: 类型
        :param host_disk_capacity: 各个硬盘池容量信息
        :return
        """
        LOG.info('begin update diskpool capacity, host info list is {0}, type is {1}, host disk capacity is {2}'.format(
            host_info_list, type, host_disk_capacity))
        data = {
            'type': type,
            'diskpool_list': {}
        }
        if host_disk_capacity:
            data['diskpool_list'] = host_disk_capacity
        else:
            for host_info in host_info_list:
                diskpool_list = host_info['diskpool_list']
                for diskpool in diskpool_list:
                    if diskpool not in data['diskpool_list']:
                        data['diskpool_list'][diskpool] = dict()
                        data['diskpool_list'][diskpool]['capacity'] = 0
                    if diskpool in host_info:
                        for disk in host_info[diskpool]['data']:
                            disk_size = disk.split(':')[1]
                            data['diskpool_list'][diskpool]['capacity'] += int(disk_size) / 1024
        LOG.info('update diskpool capacity, data is {0}'.format(data))
        update_capacity_response = send_request_onestord(const.COMP_CS, const.OP_DISKPOOL_UPDATE_CAPACITY, data)
        update_capacity_result = update_capacity_response['response']['result']
        if 0 != update_capacity_result[0]:
            LOG.error('update diskpool capacity disk, response is %s', update_capacity_response)
            # raise 不抛异常
        LOG.info('end update diskpool capacity, result is {}'.format(update_capacity_response))

    @staticmethod
    def pre_disk_for_host_info(host_info, disk_list):
        """
        预处理主机列表中的硬盘相关数据
        :param host_info: 主机信息
        :param disk_list: 硬盘数据
        :return
        """
        LOG.info('begin pre disk for host info, host info is {0}, disk list is {1}'.format(
            host_info, disk_list))
        for disk in disk_list:
            # 字节
            disk_str = disk['name'] + ':' + str(int(disk['physical_size']))
            diskpool_name = disk['diskpool']
            if diskpool_name is not u'-':
                if diskpool_name in host_info:
                    host_info[diskpool_name]['data'].append(disk_str)
                else:
                    host_info[diskpool_name] = {'data': [disk_str]}
        LOG.info('end pre disk for host info, host info is {0}'.format(host_info))

    @staticmethod
    def get_host_disk_capacity(host_name):
        """
        获取关于硬盘池下主机硬盘容量大小
        :param host_name: 主机名称
        :return
        """
        LOG.info('begin get host disk capacity, host name is {0}'.format(host_name))
        host_disk_capacity = send_request_onestord(const.COMP_CS, const.OP_DISKPOOL_LOGICAL_HOST_CAPACITY_QUERY,
                                                   {'host_name': host_name})
        host_disk_result = host_disk_capacity['response']['result']
        if 0 != host_disk_result[0]:
            LOG.error('get host disk capacity, response is %s', host_disk_capacity)
        LOG.info('end get host disk capacity, host name is {0}, result is {1}'.format(host_name, host_disk_capacity))
        return host_disk_capacity['response']['data']

    @staticmethod
    def pg_rebalance():
        """
        增删主机/osd时，最后向后台发送一个同步pg的请求，无论成功失败 不影响增删结果
        :return:
        """
        send_request_onestord(const.COMP_CS, 'cluster_pg_upmap', {})

    def _get_need_deploy_disk(self, data):
        """
        整理并返回需要部署的数据盘、读、写缓存盘（单机部署、增加硬盘）
        :param data: 主机信息
        :return:
        """
        host_disk = {'data': [], 'journal': [], 'flash': []}
        diskpool_data = self.query_diskpool_data(data, const.OP_DISKPOOL_QUERY_SUMMARY)
        for diskpool_name in data['diskpool_list']:
            for diskpool in diskpool_data:
                if diskpool['diskpool_name'] == diskpool_name:
                    flashcache_size = diskpool['flashcache_size']
                    journal_size = diskpool['journal_size']
                    break
            host_disk['data'].extend(
                [disk.split(':')[0] + ':' + str(journal_size) + ':' + str(flashcache_size) + ':' + diskpool_name for
                 disk in data[diskpool_name]['data']])
            host_disk['journal'].extend(
                [disk.split(':')[0] + ':' + str(journal_size) + ':' + str(flashcache_size) + ':' + diskpool_name for
                 disk in data[diskpool_name]['journal']])
            host_disk['flash'].extend(
                [disk.split(':')[0] + ':' + str(journal_size) + ':' + str(flashcache_size) + ':' + diskpool_name for
                 disk in data[diskpool_name]['flash']])
        return host_disk

    def _get_need_deploy_disk_batch(self, host_info):
        """
        整理并返回需要部署的数据盘、读、写缓存盘（批量部署）
        :param data: host_info 主机信息
        :return:
        """
        host_disk = {}
        for host in host_info:
            data_list, journal_list, flash_list = [], [], []
            # host['nodepool'] = host_map_data['host_nodepool'][host['name']]
            diskpool_data = self.query_diskpool_data(host, const.OP_DISKPOOL_QUERY_SUMMARY)
            for diskpool_name in host['diskpool_list']:
                for diskpool in diskpool_data:
                    if diskpool['diskpool_name'] == diskpool_name:
                        flashcache_size = diskpool['flashcache_size']
                        journal_size = diskpool['journal_size']
                        break
                data_list.extend(
                    [disk.split(':')[0] + ':' + str(journal_size) + ':' + str(flashcache_size) + ':' + diskpool_name for
                     disk in host[diskpool_name]['data']])
                journal_list.extend(
                    [disk.split(':')[0] + ':' + str(journal_size) + ':' + str(flashcache_size) + ':' + diskpool_name for
                     disk in host[diskpool_name]['journal']])
                flash_list.extend(
                    [disk.split(':')[0] + ':' + str(journal_size) + ':' + str(flashcache_size) + ':' + diskpool_name for
                     disk in host[diskpool_name]['flash']])
            host_disk[host['name']] = {}
            host_disk[host['name']]['data'] = data_list
            host_disk[host['name']]['journal'] = journal_list
            host_disk[host['name']]['flash'] = flash_list
        return host_disk

    @staticmethod
    def query_diskpool_data(data, op_name):
        """
        查询硬盘池列表数据
        :param op_name: OP 名称
        :return:
        """
        query_data = {'nodepool_name': data['nodepool_name']}
        diskpool_query_response = send_request_onestord(const.COMP_CS, op_name, query_data)
        diskpool_query_result = diskpool_query_response['response']['result']
        if 0 != diskpool_query_result[0]:
            LOG.error('query diskpool data error, response is %s', diskpool_query_response)
            raise errno.ONEStorError(errno.ERROR_QUERY_DISKPOOL)
        diskpool_data = diskpool_query_response['response']['data']['diskpool_list']
        return diskpool_data

    @staticmethod
    def query_nodepool_data():
        """
        查询节点池列表数据
        :return:
        """
        nodepool_query_response = send_request_onestord(const.COMP_CS, const.OP_NODEPOOL_QUERY, {})
        nodepool_query_result = nodepool_query_response['response']['result']
        if 0 != nodepool_query_result[0]:
            LOG.error('query nodepool data error, response is %s', nodepool_query_response)
            raise errno.ONEStorError(errno.ERROR_QUERY_NODEPOOL)
        nodepool_data = nodepool_query_response['response']['data']['nodepool_list']
        return nodepool_data

    def _clear_empty_logic_host(self, host_name, diskpool_list):
        """
        清除ceph osd tree 中 空的逻辑主机（即该主机下没有osd）
        :param host_name: 主机名称
        :param diskpool_list: 硬盘池列表
        :return:
        """
        # 查看该逻辑主机下的osd是否为空，为空则删除该逻辑主机
        LOG.info('begin clear empty logic host, ceph osd tree is {}'.format(
            self.exec_local_cmd('timeout 30 ceph osd tree -f json')))
        for diskpool in diskpool_list:
            empty = self.exec_local_cmd("ceph osd tree | grep -w {} -A 1 "
                                        "| grep '\<osd.'".format(host_name + '.' + diskpool))
            if not empty:
                self.exec_local_cmd("ceph osd crush rm {}".format(host_name + '.' + diskpool))
        LOG.info('end clear empty logic host, ceph osd tree is {}'.format(
            self.exec_local_cmd('timeout 30 ceph osd tree -f json')))

    @staticmethod
    def _update_host_table_for_diskpool(host_name):
        """
        更新主机表，diskpool字段
        :param host_name: 主机名称
        :return:
        """
        LOG.info('begin update host table for diskpool, host name is  {}'.format(host_name))
        query_data = {'host_name': host_name}
        disk_query_response = send_request_onestord(const.COMP_CS, const.OP_DISK_QUERY, query_data)
        disk_query_result = disk_query_response['response']['result']
        if 0 != disk_query_result[0]:
            LOG.error('query disk data error, response is %s', disk_query_response)
            return  # 暂时不抛异常
        disk_data = disk_query_response['response']['data']['data_disk']
        diskpool_list = list(set(disk_data.values()))
        db.init_db()
        model = OpClusterHost()
        result = model.get_value(host_name)
        result['diskpool_list'] = diskpool_list
        model.merge_value(result)
        LOG.info('end update host table for diskpool')

    def initialize_host_crush(self, host_list, diskpool_list, write_db=True):
        """
        修改 crush 中的host
        :param host_list:[{
            "name":"hjubuntu51",
            "ip":"172.16.83.51",
            "nodepool":"n1",
            "rack":"r1",
            'diskpool_list': 'dp1,dp2'
            "domain":"",
            "remark":"",
            "d1":{
                "data":[{"sdd:SATA:2342344:1"},{"sde:SATA:2342344:1"}],
                "journal":[],
                "flash":[]
            }
        }]
        :param diskpool_list: 硬盘池列表
        :return
        """
        LOG.info('start to initialize host crush, host list is {0}, '
                 'diskpool list is {1}'.format(host_list, diskpool_list))
        db.init_db()
        for host in host_list:
            LOG.info('start to initialize host crush, host is %s', host)
            for diskpool_name in host['diskpool_list']:
                LOG.info('start to initialize host crush, diskpool is {}'.format(diskpool_name))
                # 如果是文件系统-元数据池类型的硬盘池的保护域固定为关闭状态
                metadata_bool = False
                for diskpool_data in diskpool_list:
                    if diskpool_data['diskpool_name'] == diskpool_name:
                        if diskpool_data['diskpool_service_type'] == const.CEPH_FS_METADATA:
                            metadata_bool = True
                        break
                LOG.info('diskpool is {0}, metadata bool is {1}'.format(diskpool_name, metadata_bool))
                self.create_crush_bucket(host['name'] + '.' + diskpool_name, 'host')
                rack_bucket_name = host['rack'] + '.' + diskpool_name
                if host['domain'] and not metadata_bool:  # 保护域开启
                    rack_bucket_name = host['rack'] + '.' + host['domain'] + '.' + diskpool_name
                self.move_crush_bucket(host['name'] + '.' + diskpool_name, 'rack', rack_bucket_name)
                for disk in host[diskpool_name]['data']:
                    LOG.info('start to initialize host crush, disk is %s', disk)
                    if len(disk.split(':')) < 4:
                        raise errno.ONEStorError(errno.ERROR_DEPLOY_DISK, host['name'])
                    osd_id = disk.split(':')[3]
                    self.move_crush_bucket('osd.' + osd_id, 'host', host['name'] + '.' + diskpool_name)
            os.system('ceph osd crush rm {}'.format(host['name']))
            if write_db:
                self.write_host_info_to_table(host)
        LOG.info("end to initialize host crush...")
        return

    @staticmethod
    def create_crush_bucket(bucket_name, bucket_type):
        """
        创建指定类型的bucket
        :param bucket_name: 名称
        :param bucket_type: 类型
        """
        LOG.info("Start to add {0} bucket: {1}".format(bucket_type, bucket_name))
        os.system('ceph osd crush add-bucket {0} {1}'.format(bucket_name, bucket_type))
        LOG.info("Success to add {0} bucket: {1}".format(bucket_type, bucket_name))

    @staticmethod
    def move_crush_bucket(bucket_name, obj_type, bucket_obj):
        """
        删除crush bucket
        :param bucket_name: 名称
        :param obj_type: 类型
        :param bucket_obj: 对象
        """
        LOG.info("Start to move crush bucket {0}..{1}..{2}".format(bucket_name, obj_type, bucket_obj))
        os.system('ceph osd crush move {0} {1}={2}'.format(bucket_name, obj_type, bucket_obj))
        LOG.info("Success to move crush bucket {0}..{1}..{2}".format(bucket_name, obj_type, bucket_obj))

    def write_host_info_to_table(self, data, model=None):
        """
        主机数据写入数据表
        :param data:{
            'hostname':'ubuntu41',
            'partition':'p1',
            'rack':'rack1',
            'public_ip':'127.0.0.1'}
            "name":"hjubuntu51",
            "ip":"172.16.83.51",
            "nodepool":"n1",
            "rack":"r1",
            'diskpool_list': 'dp1,dp2'
            "domain":"",
            "remark":"",
        :param model: 数据表对象
        :return
        """
        LOG.info("Start to write host info to table, data is {0}".format(data))
        model = model if model else OpClusterHost()
        info = {
            'host_name': data['name'],
            'nodepool_name': data['nodepool_name'],
            'diskpool_list': data['diskpool_list'],
            'rack_name': data['rack'],
            'public_ip': data['public_ip'],
            'protection_domain_name': data['domain'],
            'description': data['remark'],
            'cpu_score': data['cpu_score'],
            'memory_capacity': data['mem_size'],
            'maintain_mode': 'off'
        }
        self.write_info_to_table(info, model)
        LOG.info("Success to write host info to table, data is {0}".format(data))
        return

    @staticmethod
    def write_info_to_table(info, model):
        """
        信息写入数据表
        :param info:{
            'hostname':'ubuntu41',
            'partition':'p1',
            'rack':'rack1',
            'public_ip':'127.0.0.1'}
        :param model: 数据表对象
        """
        LOG.info("Start to write info to table, info is {0}".format(info))
        model.merge_value(info)
        LOG.info("Success to write info to table, info is {0}".format(info))

    @staticmethod
    def delete_host_info_from_table(host_name):
        """
        删除主机列表中的特定名称主机
        :param host_name: 主机
        """
        LOG.info("Start to delete host info from table...{0}".format(host_name))
        db.init_db()
        model = OpClusterHost()
        model.remove_value(host_name)
        LOG.info("Success to delete host info from table...")

    @staticmethod
    def clear_empty_row_and_rack(host_name):
        """
        删除空的子分区和机架
        :param host_name:
        :return:
        """
        LOG.info("Start to clear the partition's row and rack...{0}".format(host_name))
        host_query_data = {'hostname_list': [host_name]}
        host_request_response = send_request_onestord(const.COMP_CS, const.OP_HOST_QUERY_BY_HOST_NAME, host_query_data)
        host_request_result = host_request_response['response']['result']
        if 0 != host_request_result[0]:
            LOG.error('host query error, response is %s', host_request_result)
            raise errno.ONEStorError(errno.ERROR_CLEAR_ROW_AND_RACK)
        host_request_data = host_request_response['response']['data']
        host_info = host_request_data['host_list'][0]
        host_name = host_info['host_name']
        diskpool_for_host = host_info['diskpool_list']
        rack_for_host = host_info['rack_name']
        # 删除cpeh osd tree 中该主机的信息
        for diskpool in diskpool_for_host:
            os.system('ceph osd crush rm {}'.format(host_name + '.' + diskpool))
        return

    @staticmethod
    def get_gateway_part_info(gateway):
        """
        获取网关信息
        :param gateway: 网关
        :return:
        """
        db.init_db()
        gateway['diskpool_name'] = gateway.get('diskpool_name', 'default')
        return gateway

    @staticmethod
    def query_host_data(host_name_list):
        """
        根据主机名，查主机表信息
        :param host_name_list: host_name (数组)
        :return:
        """
        LOG.info('begin query host data, host name list is {}'.format(host_name_list))
        host_response = send_request_onestord(const.COMP_CS, const.OP_HOST_QUERY_BY_HOST_NAME,
                                              {'hostname_list': host_name_list})
        host_result = host_response['response']['result']
        if 0 != host_result[0]:
            LOG.error('query host data error, response is %s', host_response)
            raise errno.ONEStorError(errno.ERROR_QUERY_HOST)
        host_data = host_response['response']['data']['host_list']
        LOG.info('end query host data, result is {}'.format(host_data))
        return host_data

    def _get_host_data(self, host_name_list, host_info_list):
        """
        补全主机信息
        :param host_name_list: 主机名列表
        :param host_info_list: 主机信息列表
        :return:
        """
        LOG.info('begin get host data, host name list is {0}, '
                 'host info list is {1}'.format(host_name_list, host_info_list))
        host_list_from_db = self.query_host_data(host_name_list)
        for host_info in host_info_list:
            host_name = host_info['name']
            for host_info_from_db in host_list_from_db:
                if host_name == host_info_from_db['host_name']:
                    host_info['domain'] = host_info_from_db['protection_domain_name']
                    host_info['rack'] = host_info_from_db['rack_name']
                    host_info['nodepool_name'] = host_info_from_db['nodepool_name']
                    if 'diskpool_list' not in host_info or not host_info['diskpool_list']:
                        host_info['diskpool_list'] = host_info_from_db['diskpool_list']
                    break
        LOG.info('end get host data, host info list is {0}'.format(host_info_list))
        return host_info_list

    @staticmethod
    def _move_logic_rack(host_list, diskpool_list):
        """
        移动机架
        :param host_list: 主机数据
        :param diskpool_list: 硬盘池数据
        :return:
        """
        try:
            LOG.info('start to move rack, host list is {0}, '
                     'diskpool list is {1}'.format(host_list, diskpool_list))
            logic_rack_dict = dict()
            for host_info in host_list:
                diskpool_name_list = host_info['diskpool_list']
                domain_name = host_info['domain']
                rack_name = host_info['rack']
                for diskpool_name in diskpool_name_list:
                    # 如果是文件系统-元数据池类型的硬盘池的保护域固定为关闭状态
                    metadata_bool = False
                    for diskpool_data in diskpool_list:
                        if diskpool_data['diskpool_name'] == diskpool_name:
                            if diskpool_data['diskpool_service_type'] == const.CEPH_FS_METADATA:
                                metadata_bool = True
                            break
                    if diskpool_name in logic_rack_dict:
                        if rack_name in logic_rack_dict[diskpool_name]['rack_info']:
                            if domain_name and not metadata_bool:
                                if domain_name not in logic_rack_dict[diskpool_name]['rack_info'][rack_name]:
                                    logic_rack_dict[diskpool_name]['rack_info'][rack_name].append(domain_name)
                        else:
                            if domain_name and not metadata_bool:
                                logic_rack_dict[diskpool_name]['rack_info'][rack_name] = [domain_name]
                            else:
                                logic_rack_dict[diskpool_name]['rack_info'][rack_name] = []
                    else:
                        logic_rack_dict[diskpool_name] = dict()
                        logic_rack_dict[diskpool_name]['rack_info'] = dict()
                        if domain_name and not metadata_bool:
                            logic_rack_dict[diskpool_name]['rack_info'][rack_name] = [domain_name]
                        else:
                            logic_rack_dict[diskpool_name]['rack_info'][rack_name] = []
            LOG.info('logic rack dict is {0}'.format(logic_rack_dict))
            logic_rack_list = []
            for key, value in logic_rack_dict.items():
                temp = {'diskpool_name': key, 'rack_info': value['rack_info']}
                logic_rack_list.append(temp)
            rack_data = {'diskpool_list': logic_rack_list}
            rack_move_response = send_request_onestord(const.COMP_CS, const.OP_RACK_MOVE, rack_data)
            rack_move_result = rack_move_response['response']['result']
            if 0 != rack_move_result[0]:
                LOG.info('rack move error, response is %s', rack_move_response)
                raise errno.ONEStorError(errno.ERROR_MOVE_RACK)
            LOG.info('end to move rack, data is {}'.format(logic_rack_list))
        except Exception, e:
            LOG.error(e)
            raise errno.ONEStorError(errno.ERROR_MOVE_RACK)

    @staticmethod
    def _remove_logic_rack(host_info, diskpool_list):
        """
        删除逻辑机架
        :param host_info: 主机数据
        :param diskpool_list: 硬盘池数据
        :return:
        """
        LOG.info('begin remove logic rack, host info data is {}, '
                 'diskpool list is {}'.format(host_info, diskpool_list))
        logic_rack_list = []
        for diskpool in host_info['diskpool_list']:
            # 如果是文件系统-元数据池类型的硬盘池的保护域固定为关闭状态
            metadata_bool = False
            for diskpool_data in diskpool_list:
                if diskpool_data['diskpool_name'] == diskpool:
                    if diskpool_data['diskpool_service_type'] == const.CEPH_FS_METADATA:
                        metadata_bool = True
                    break
            if 'domain' in host_info and host_info['domain'] and not metadata_bool:
                # 开启保护域 且 非 文件系统—元数据 硬盘池
                logic_rack_list.append(host_info['rack'] + '.' + host_info['domain'] + '.' + diskpool)
            else:
                logic_rack_list.append(host_info['rack'] + '.' + diskpool)
        rack_move_response = send_request_onestord(const.COMP_CS, const.OP_RACK_REMOVE, {'rack_list': logic_rack_list})
        rack_move_result = rack_move_response['response']['result']
        if 0 != rack_move_result[0]:
            LOG.error('remove logic rack error, response is %s', rack_move_response)
            raise errno.ONEStorError(errno.ERROR_REMOVE_RACK)
        LOG.info('end remove logic rack, result is {}'.format(rack_move_response))

    @staticmethod
    def _get_diskpool_name_list(host_info):
        """
        获取硬盘名称列表
        :param host_info: 主机数据
        :return:
        """
        diskpool_list = []
        for host in host_info:
            diskpool_list.extend(host['diskpool_list'])
        return list(set(diskpool_list))

    def _remove_host_soft(self, node_ip, roles, type):
        """
        删除主机组件
        Author: huyangjiexiong
        Date: 2018/5/30
        """
        LOG.info('start to remove host:{} {} software'.format(node_ip, type))

        #节点只作为stor或者mon节点，并且不是handy节点
        if ((type == "stor") and (roles['stor']) and (roles['role_num'] == 1)) \
            or ((type == "mon") and (roles['mon']) and (roles['role_num'] == 1)):
            moudle_sum = self.exec_remote_ssh_cmd(node_ip, "ls /opt/h3c/script")
            if not isinstance(moudle_sum, str):
                return
            moudle_sum = moudle_sum.split("\n")
            for moudle in moudle_sum:
                ret = self.exec_remote_ssh_cmd(node_ip, "bash /opt/h3c/script/%s/uninstall_%s.sh" % (moudle, moudle))
                if "uninstall complete" in ret :
                    LOG.info('remove host:{} {} successed'.format(node_ip, moudle))
                else:
                    LOG.info('remove host:{} {} failed'.format(node_ip, moudle))
        #节点作为stor和mon节点,或者handy节点作为mon节点需要删除zookeeper
        elif (roles['stor'] and roles['mon']) or (roles['handy'] and roles['mon']):
            if type == "stor":
                moudle_sum = ["vae", "tgt"]
            elif type == "mon":
                moudle_sum = ["zookeeper"]
            else:
                LOG.info('remove software type error')
            for moudle in moudle_sum:
                ret = self.exec_remote_ssh_cmd(node_ip, "bash /opt/h3c/script/%s/uninstall_%s.sh" % (moudle, moudle))
                if "uninstall complete" in ret :
                    LOG.info('remove host:{} {} successed'.format(node_ip, moudle))
                else:
                    LOG.info('remove host:{} {} failed'.format(node_ip, moudle))

        #节点不满足以上条件并不为handy节点
        elif roles['handy'] == False:
            if type == "stor":
                moudle_sum = ["open-iscsi", "ipvsadm", "tgt", "vae"]
            elif type == "mon":
                moudle_sum = ["open-iscsi", "ipvsadm", "tgt", "zookeeper"]
            else:
                LOG.info('remove software type error')

            for moudle in moudle_sum:
                ret = self.exec_remote_ssh_cmd(node_ip, "bash /opt/h3c/script/%s/uninstall_%s.sh" % (moudle, moudle))
                if "uninstall complete" in ret :
                    LOG.info('remove host:{} {} successed'.format(node_ip, moudle))
                else:
                    LOG.info('remove host:{} {} failed'.format(node_ip, moudle))
        else:
            pass

        LOG.info('end to remove host:{} {} software'.format(node_ip, type))
