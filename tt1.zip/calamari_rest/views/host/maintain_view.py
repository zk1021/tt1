#!/usr/bin/env python
# coding: utf-8

"""
维护模式模块
"""

import json
import logging
import ConfigParser

from calamari_rest.views.common.cmd import *
from calamari_rest.views.common.const import *
from calamari_rest.views.common import util
from calamari_rest.views.common import op_log
from calamari_rest.views.common import errno
from calamari_rest.views.host.host_util import HostUtil
from calamari_common.config import CalamariConfig

LOG = logging.getLogger('django.request')
config = CalamariConfig()


class MaintainViewSet(HostUtil):
    """
    维护模式视图
    """

    @util.send_response(
        op=OP_LIST
    )
    def get_maintain_status(self, request, fsid):
        """
        获取维护模式信息
        Author: z11524
        Date: 2016/1/05
        """
        yield {
            'maintain': self._get_maintain_mode(),
            'mask': self.get_clusterconfig()['public_network']
        }

    @util.send_response(
        op=OP_LIST
    )
    def get_maintain_config(self, request, fsid):
        """
        获得维护模式配置
        :param request: 请求参数
        :param fsid:    集群id
        :return:
        """
        maintain_config = self._get_maintain_config()
        yield {
            'data': maintain_config,
            'success': True
        }

    @util.send_response(
        op=OP_LIST
    )
    def get_maintain_switch(self, requst, fsid):
        """
        增加维护模式自动切换开关 默认为"false"
        :param requst:
        :param fsid:
        :return:
        """
        try:
            maintain_switch = config.get('calamari_web', 'maintain_switch')
        except ConfigParser.NoOptionError:
            yield {'status': 'false'}
        else:
            yield {'status': maintain_switch}

    def _get_maintain_config(self):
        """
        获得维护模式配置
        :return:
        """
        ceph_key_list = self.exec_local_cmd(DB_LIST)
        if BUCKET_MAINTAIN not in ceph_key_list:
            # maintain 配置不存在时写入配置
            style = MANUAL_MAINTAIN if self._get_maintain_mode() else CLOSE_MAINTAIN
            self._write_maintain_config(style=style)

        return self.exec_local_cmd_json(DB_GET_MAINTAIN)

    def _write_maintain_config(self, style=CLOSE_MAINTAIN, start_hour=DEF_START, end_hour=DEF_END):
        """
        写入维护模式配置
        :param style: 维护模式状态
        :param start_hour: 维护模式开始时间
        :param end_hour: 维护模式结束时间
        :return:
        """
        maintain_obj = {
            'style': style,
            'start_hour': start_hour,
            'end_hour': end_hour
        }
        self.exec_local_cmd(DB_SAVE_MAINTAIN.format(json.dumps(maintain_obj)))

    @util.send_response(
        ret_type=RETURN_TYPE_2
    )
    def switch_maintain_mode(self, request, fsid):
        """
        切换维护模式
        :param request: 请求参数
        :param fsid:    集群id
        :return:
        """
        style = request.DATA['style']
        start_hour = request.DATA['start_hour']
        end_hour = request.DATA['end_hour']
        if style == AUTO_MAINTAIN:
            msg = self._get_msg(start_hour, end_hour)
            yield op_log.OP_AUTO_MAINTAIN_MODE.format(msg)
        elif style == MANUAL_MAINTAIN:
            yield op_log.OP_MANUAL_MAINTAIN_MODE
        else:
            yield op_log.OP_CLOSE_MAINTAIN_MODE

        self._validate_maintain(style, start_hour, end_hour)

        # 修改ceph.conf中maintain参数
        maintain_config = self._get_maintain_config()
        self._write_maintain_config(style, start_hour, end_hour)

        # 切换维护模式
        result = self.exec_local_cmd_json(CMD_SET_MAINTAIN)
        if not result['success']:
            # 切换失败回滚配置
            self._write_maintain_config(
                maintain_config['style'],
                maintain_config['start_hour'],
                maintain_config['end_hour'])
            if result['reason'] == OP_ADD_DISK:
                raise errno.ONEStorError(errno.ERROR_HOST_BUSY)
            elif result['reason'] == OP_REMOVE_DISK:
                raise errno.ONEStorError(errno.ERROR_HOST_BUSY_REMOVE)
            elif result['reason'] == NO_MAINTAIN_CONFIG:
                raise errno.ONEStorError(errno.ERROR_NO_MAINTAIN_CONF)
            elif result['reason'] == FLAG_NO_HANDYCRON:
                raise errno.ONEStorError(errno.ERROR_NO_HANDYCRON)
            elif result['reason'] == FLAG_UPGRADE:
                raise errno.ONEStorError(errno.ERROR_UPGRADING)

    @staticmethod
    def _validate_maintain(style=None, start_hour=None, end_hour=None):
        """
        校验参数合法性
        :param style: 维护模式状态
        :param start_hour: 维护模式开始时间
        :param end_hour: 维护模式结束时间
        :return:
        """
        if not isinstance(start_hour, int) and not isinstance(end_hour, int):
            raise errno.ONEStorError(errno.ERROR_ILLEGAL_PARAMETER)

        styles = [AUTO_MAINTAIN, MANUAL_MAINTAIN, CLOSE_MAINTAIN]
        hour_illegal = start_hour > 23 or start_hour < 0 or end_hour > 23 or end_hour < 0
        if (style not in styles) or hour_illegal or end_hour == start_hour:
            raise errno.ONEStorError(errno.ERROR_ILLEGAL_PARAMETER)

    @staticmethod
    def _get_msg(start_hour=None, end_hour=None):
        """
        获得维护模式开启周期说明
        :param start_hour: 维护模式开始时间
        :param end_hour: 维护模式结束时间
        :return:
        """
        if start_hour > end_hour:
            return op_log.OP_AUTO_NEXT_DAY.format(start_hour, end_hour)
        else:
            return op_log.OP_AUTO_DAY.format(start_hour, end_hour)
