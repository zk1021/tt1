#!/usr/bin/env python
# coding: utf-8

"""
主机管理模块
"""

import os
import logging

from rest_framework.response import Response
from calamari_common.config import CalamariConfig
from calamari_rest.views.common import util
from calamari_rest.views.common import const
from calamari_rest.views.common import errno
from calamari_rest.views.common import op_log
from calamari_rest.views.common.cmd import *
from calamari_rest.views.common.util import set_onestor_progress
from calamari_rest.views.backup import messanger
from calamari_rest.views.host.final_rollback import HostFinalRollback

LOG = logging.getLogger('django.request')
config = CalamariConfig()


class HostViewSet(HostFinalRollback):
    """
    主机管理视图
    """
    @util.send_response(
        op=const.OP_ADD_STOR,
        ret_type=const.RETURN_TYPE_2
    )
    @util.before_return(
        final=HostFinalRollback.add_host_finally,
        roolback=HostFinalRollback.add_host_single_rollback
    )
    def add_host_single(self, request, fsid):
        """
        手动部署主机
        Author: dai.xinchun@h3c.com
        Date: 2016/12/07
        """
        LOG.info('add host single, data is {}'.format(request.DATA))
        user = const.USER_ROOT
        task_id = request.DATA['task_id']
        passwd = request.DATA['passwd']
        node_ip = request.DATA['node_ip']
        rack_info = request.DATA['rack_info']
        # host_info:'name'、'nodepool_name'、'diskpool_list'、'domain'、'public_ip'、'rack'、'remark'、'd1'}
        host_info = request.DATA['host_info']
        # 返回操作日志内容
        yield op_log.OP_ADD_HOST_SINGLE.format(node_ip)
        # 将当前任务记录到文件中
        self.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_ADD_STOR, task_id)
        # 判断主机和硬盘规格是否超限(集群最大节点、硬盘数量，单节点池最大节点数量，单硬盘池最大硬盘数量)
        self.check_host_disk_num_limit([host_info], True, False)
        diskpool_list = self.query_diskpool_data(host_info, const.OP_DISKPOOL_QUERY_SHORT)
        # begin add by d11564 2017/10/12 PN:201705110894 检查系统是否和handy一致
        is_match_os = self.check_os_version([node_ip], passwd)
        if not is_match_os:
            raise errno.ONEStorError(errno.ERROR_OS_VERSION)
        # end by d11564 2017/10/12 PN:201705110894 检查系统是否和handy一致
        # BEGIN ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许增加主机
        # self._get_maintain_mode([host_info['nodepool_name']], [host_info['diskpool_list']])
        # END ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许增加主机
        # 检查硬盘是否为空
        # if '' == disks:
        #    raise errno.ONEStorError(errno.ERROR_DISK_IS_NULL)
        # 检查添加的主机IP是否在业务网段内
        self._check_public_ip(node_ip)
        # 检查主机名或主机IP是否已经出现在/etc/onestor_hosts中
        self._check_name_and_ip([node_ip], user, passwd)
        # 检查当前是否正在增加其它主机或硬盘
        has_adding = self._check_cocurrent_event(const.FLAG_ADDING_OSD)
        request.session[const.FLAG_ADDING_OSD] = has_adding
        if has_adding:
            raise errno.ONEStorError(errno.ERROR_HOST_BUSY)
        # 检查存储节点个数
        self._check_stor_num()
        # 清除网络故障标识
        self._clear_network_error_flag(const.OP_ADD_STOR)
        # 检查主机时间不能与集群相差太大
        self._check_host_offset_time([node_ip], passwd)
        # 检查主机名称是否满足部署要求
        host_name = self.cmd_remote(node_ip, passwd, const.HOST_NAME, user)
        self._check_linux_host_name([host_name])
        # 检查License信息
        self._check_license(node_ip, diskpool_list, host_info, user, passwd)
        # 检查主机网络是否满足部署要求
        disaster_ips = self._check_host_network([node_ip], user, passwd)
        # 获取添加前的节点角色
        roles = self.get_host_roles_by_name(host_name)
        # 安装ONEStor软件
        self._update_deploy_status(const.STEP_INSTALL_SOFT)
        self.install_soft(node_ip, passwd, user)
        # Handy对该节点配置SSH免密，免密前先备份原有的/etc/hosts文件
        self._update_deploy_status(const.STEP_DEPLOY_ADMIN_NODE)
        self._backup_etc_hosts()
        request.session[const.NEED_RESTORE_ETC_HOSTS] = True
        LOG.info('begin config ssh...')
        host_name, public_ip = self.ssh_config(node_ip, passwd, user)
        request.session[const.NEED_RESTORE_CLUSTER_CONF] = True
        # 同步集群配置文件
        LOG.info('begin sync cluster config...')
        self.sync_cluster_config(public_ip)
        # 重启nm进程
        self.rewrite_ip([node_ip])
        self.restart_nm_sub([public_ip])
        # 配置NTP时间同步
        LOG.info('begin setup ntp...')
        self.setup_ntp_client(host_name)
        # 创建机架
        # rack_name = self._create_rack(rack_info)
        # request.session[const.NEED_RESTORE_RACK] = True
        # 将新增主机的灾备网段IP地址发送给scheduler
        # 检查是否存在容灾，若不存在，则不再写入主机灾备IP信息
        if self.disaster_pool_exist():
            messanger.send_add_backup_host_msg(disaster_ips.values())
        request.session[const.NEED_RESTORE_ONEBACKUP] = disaster_ips.values()
        # begin add by d11564 2017/10/20 多MDS项目
        # 查询当前集群是否有文件系统
        LOG.info('begin check filesystem...')
        has_filesys = self._check_has_filesys()
        # 有文件系统，向onestord发消息，将此ip加为mds节点
        if has_filesys:
            LOG.info('begin create mds ...')
            request.session[const.NEED_RESTORE_MDS] = True
            self._add_host_as_mds(node_ip)
        # end add by d11564 2017/10/20 多MDS项目
        # 部署硬盘
        LOG.info('begin deploy disk...')
        self._update_deploy_status(const.STEP_DEPLOY_DISK)
        host_disk = self._get_need_deploy_disk(host_info)
        self._deploy_disk(public_ip, host_name, host_disk)
        # 移动逻辑机架
        self._move_logic_rack([host_info], diskpool_list)
        # 获取osd
        LOG.info('begin get osd...')
        self._get_osd_status_single(host_name, [host_info])
        # 初始化Crush
        LOG.info('begin initial crush...')
        self._update_deploy_status(const.STEP_INITIAL_CRUSH)
        self.initialize_host_crush([host_info], diskpool_list)
        # 同步主MON上的tgt配置
        LOG.info('begin sync tgt...')
        # 备份主mon的tgt文件到handy节点tmp目录 add by h13051 PN:201704140460
        self._backup_mon_tgt()
        self._sync_tgt(public_ip, host_name, const.OP_ADD_STOR)
        # 配置LVS服务器
        self._config_lvs_server([host_name], const.ROLE_MON)
        # add by r13889 2017/03/24 PN:201703160637
        LOG.info('roles = %s', roles)
        # DELETE BY KF6602 删除修改diamond配置的代码，监控项目不再需要修改diamond配置
        self.set_onestor_host()
        # 将主机名对应的业务网IP保存到数据库cluster_hosts中
        LOG.info('begin add host to db...')
        self.add_host_to_db(public_ip, host_name, disaster_ip=disaster_ips[node_ip] if node_ip in disaster_ips else '')
        # 部署完硬盘和mds,向后台发送激活mds个数的消息 多MDS项目
        if has_filesys:
            request.session[const.NEED_DELETE_HOST] = True
            self._active_mds()
        self.save_hosts_base_info([node_ip])
        # 检查增加硬盘的结果
        self._check_add_host_result([host_info])
        # 更新硬盘池容量大小
        self.update_diskpool_capacity([host_info], const.ADD_DISK_FOR_UPDATE_DISKPOOL_CAPACITY)
        # 同步pg
        self.pg_rebalance()
        LOG.info('end host single :::::')

    @util.send_response(
        op=const.OP_ADD_STOR,
        ret_type=const.RETURN_TYPE_3
    )
    @util.before_return(
        final=HostFinalRollback.add_host_finally,
        roolback=HostFinalRollback.add_host_batch_rollback
    )
    def add_host_batch(self, request, fsid):
        """
        自动（批量）部署主机
        Author: dai.xinchun@h3c.com
        Date: 2016/12/07
        """
        LOG.info('start to add host batch, data is {}'.format(request.DATA))
        default_user = request.DATA['default_user']
        default_passwd = request.DATA['default_passwd']
        all_node_ip = request.DATA['all_node_ip']
        osd_nodes = request.DATA['osd_nodes']
        host_info_list = request.DATA['host_info']
        # 返回操作日志内容
        yield op_log.OP_ADD_HOST_BATCH.format(all_node_ip)
        # 判断主机和硬盘规格是否超限(集群最大节点、硬盘数量，单节点池最大节点数量，单硬盘池最大硬盘数量)
        self.check_host_disk_num_limit(host_info_list, True, False)
        # host_info_list = self._get_host_data(osd_nodes.split(','), host_info_list)
        host_map_data = self._get_host_param(request, host_info_list)
        diskpool_data_list = self.query_diskpool_data(const.NODEPOOL_NAME_EMPTY_OBJECT, const.OP_DISKPOOL_QUERY_SHORT)
        node_ip_array = all_node_ip.split(',')
        # begin add by d11564 2017/10/12 PN:201705110894 检查系统是否和handy一致
        is_match_os = self.check_os_version(node_ip_array, default_passwd)
        if not is_match_os:
            raise errno.ONEStorError(errno.ERROR_OS_VERSION)
        # end by d11564 2017/10/12 PN:201705110894 检查系统是否和handy一致
        # BEGIN ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许增加主机
        nodepool_list = list(set(host_map_data['host_nodepool'].values()))
        diskpool_name_list = []
        diskpool_name_list = list(set([diskpool_name_list.extend(host_info['diskpool_list']) for host_info in host_info_list]))
        # self._get_maintain_mode(nodepool_list, diskpool_name_list)
        # END ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许增加主机
        # 检查主机名或主机IP是否已经出现在/etc/onestor_hosts中
        node_name_array = osd_nodes.split(',')
        # 检查添加的主机IP是否在业务网段内
        self._check_public_ip_list(node_ip_array)
        # 检查主机名或主机IP是否已经出现在/etc/onestor_hosts中
        self._check_name_and_ip(node_ip_array, default_user, default_passwd)
        # 检查当前是否正在增加其它主机或硬盘
        has_adding = self._check_cocurrent_event(const.FLAG_ADDING_OSD)
        request.session[const.FLAG_ADDING_OSD] = has_adding
        if has_adding:
            raise errno.ONEStorError(errno.ERROR_HOST_BUSY)
        # 检查存储节点个数 add by d11564 多MDS项目
        # add_host_num = len(node_ip_array)
        # self._check_stor_num(add_host_num)

        # 清除网络故障标识
        self._clear_network_error_flag(const.OP_ADD_STOR)
        # 检查主机时间不能与集群相差太大
        self._check_host_offset_time(node_ip_array, default_passwd)
        # 检查主机名称是否满足部署要求
        self._check_linux_host_name(node_name_array)
        # 检查License信息
        self._check_license(all_node_ip, diskpool_data_list, host_info_list, default_user, default_passwd, batch=True)
        # 检查主机网络是否满足部署要求
        disaster_ips = self._check_host_network(
            node_ip_array, default_user, default_passwd)
        node_list = self.get_nodes_roles(node_name_array)
        # 安装ONEStor软件
        self._update_deploy_status(const.STEP_INSTALL_SOFT)
        self._install_soft_batch(node_ip_array, default_user, default_passwd)
        # Handy对节点配置SSH免密，免密前先备份原有的/etc/hosts文件
        self._update_deploy_status(const.STEP_DEPLOY_ADMIN_NODE)
        self._backup_etc_hosts()
        request.session[const.NEED_RESTORE_ETC_HOSTS] = True
        LOG.info('begin config ssh...')
        nodes_info = self._ssh_config_batch(
            node_ip_array, default_user, default_passwd)
        LOG.info('get nodes public ip and hostname: %s', nodes_info)
        request.session[const.NEED_RESTORE_CLUSTER_CONF] = nodes_info
        # 同步集群配置文件
        LOG.info('begin sync cluster config...')
        self._sync_cluster_config_batch(node_ip_array)
        # 集群外节点重启nm进程
        self.rewrite_ip(node_ip_array)
        self.restart_nm_sub(node_ip_array)
        # 配置NTP时间同步
        LOG.info('begin setup ntp...')
        self._setup_ntp_batch(node_name_array)
        # 将新增主机的灾备网段IP地址发送给scheduler
        # 检查是否存在容灾，若不存在，则不再写入主机灾备IP信息
        if self.disaster_pool_exist():
            messanger.send_add_backup_host_msg(disaster_ips.values())
        request.session[const.NEED_RESTORE_ONEBACKUP] = disaster_ips.values()
        # begin add by d11564 2017/10/20 多MDS项目
        # 判断是否有文件系统
        LOG.info('begin check filesystem...')
        has_filesys = self._check_has_filesys()
        # 有文件系统，向onestord发消息，将此ip加为mds节点
        if has_filesys:
            request.session[const.NEED_RESTORE_MDS] = True
        # end add by d11564 2017/10/20 多MDS项目
        # 部署硬盘
        self._update_deploy_status(const.STEP_DEPLOY_DISK)
        host_disk = self._get_need_deploy_disk_batch(host_info_list)
        add_result = self._deploy_disk_batch(node_name_array, host_disk, has_filesys)
        # 移动逻辑机架
        self._move_logic_rack(host_info_list, diskpool_data_list)
        LOG.info('auto_add_mds_result=%s', add_result)
        # 判断添加MDS是否成功
        mds_add_ret = self.check_mds_result(add_result)
        LOG.info('mds_add_ret=%s', mds_add_ret)
        # 获取osd
        LOG.info('begin get osd id...')
        self._get_osd_status_batch(const.STEP_GET_OSD_ID_FOR_ADD_HOST,
                                   node_name_array, host_info_list)
        # 初始化Crush
        LOG.info('begin initial crush...')
        self._update_deploy_status(const.STEP_INITIAL_CRUSH)
        self.initialize_host_crush(host_info_list, diskpool_data_list)
        # 备份主mon的tgt文件到handy节点tmp目录 add by h13051 PN:201704140460
        self._backup_mon_tgt()
        # 同步主MON上的tgt配置
        self._sync_tgt_batch(node_name_array)
        # 配置LVS服务器
        self._config_lvs_server(node_name_array, const.ROLE_MON)
        # add by r13889 2017/03/24 PN:201703160637
        # MODIFY BY KF6602 删除修改diamond配置的代码，监控项目不再需要修改diamond配置
        self.set_onestor_host()
        # 将主机名对应的业务网IP保存到数据库cluster_hosts中
        LOG.info('begin add host to db...')
        for host_name in nodes_info:
            self.add_host_to_db(
                nodes_info[host_name],
                host_name,
                disaster_ip=disaster_ips[nodes_info[host_name]] if nodes_info[host_name] in disaster_ips else ''
            )
        # 部署完硬盘和mds,向后台发送激活mds个数的消息
        if has_filesys:
            request.session[const.NEED_DELETE_HOST] = True
            add_host_auto = True
            self._active_mds(add_host_auto)
        # 检查增加硬盘的结果
        self._check_add_host_result(host_info_list)
        # 更新硬盘池容量大小
        self.update_diskpool_capacity(host_info_list, const.ADD_DISK_FOR_UPDATE_DISKPOOL_CAPACITY)
        # 同步pg
        self.pg_rebalance()
        self.save_hosts_base_info(node_ip_array)
        LOG.info('end to add host batch :::::')

    @util.send_response(
        op=const.OP_REMOVE_STOR,
        ret_type=const.RETURN_TYPE_2
    )
    @util.before_return(
        final=HostFinalRollback.remove_host_finally,
        roolback=HostFinalRollback.remove_host_rollback
    )
    def remove_host(self, request, fsid):
        """
        删除主机
        Author: dai.xinchun@h3c.com
        Date: 2016/12/07
        """
        LOG.info('start to remove host, data is {}'.format(request.META['QUERY_STRING']))
        task_id = request.GET.get('task_id')
        host_name = request.GET.get('osd_node')
        diskpool_name_list = request.GET.get('diskpool_list').split(',')
        nodepool_name = request.GET.get('nodepool_name')
        # 兼容UIS接口，host_ip为选填项
        host_ip = request.GET.get('host_ip', None)
        self._update_progress(const.OP_REMOVE_DISK, const.PROGRESS_PREPARE_RM, hostname=host_name)
        # 记录标识
        set_onestor_progress(const.STEP_PREPARE_REMOVE)
        # 返回操作日志内容
        log_content = op_log.OP_REMOVE_OFFLINE_HOST if \
            const.OFFLINE == host_ip else op_log.OP_REMOVE_HOST
        # IP地址从onestor_hosts文件中读取
        node_ip = self.name_to_ip(host_name)
        yield log_content.format(node_ip)
        diskpool_data_list = self.query_diskpool_data({'nodepool_name': nodepool_name},
                                                      const.OP_DISKPOOL_QUERY_SHORT)
        host_info = self._get_host_data([host_name], [{'name': host_name}])
        # 将当前任务记录到文件中
        self.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_REMOVE_STOR, task_id)
        # BEGIN ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许删除主机
        # self._get_maintain_mode([nodepool_name], diskpool_name_list)
        # END ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许删除主机
        # 检查当前是否正在删除其它主机或硬盘
        has_removing = self._check_cocurrent_event(const.FLAG_REMOVING_OSD)
        request.session[const.FLAG_REMOVING_OSD] = has_removing
        if has_removing:
            raise errno.ONEStorError(errno.ERROR_HOST_BUSY_REMOVE)
        # 清除网络故障标识
        self._clear_network_error_flag(const.OP_REMOVE_STOR)
        # 集群状态异常时不允许删除主机
        self._check_host_delete(const.OP_REMOVE_STOR_CN, host_name)
        # 获取灾备网IP地址
        disaster_ip = self.get_node_disaster_ip(node_ip, from_db=True)
        # 获取当前节点在集群中的角色
        roles = self.get_host_roles_by_name(host_name)
        # 如果该主机不是存储节点，则返回错误
        if (roles is None) or (not roles['stor']):
            raise errno.ONEStorError(errno.ERROR_HOST_NOT_EXIST)
        # 检查节点是否存在不允许删除的角色情况(现主要为集群外对象网关角色)
        if const.OFFLINE != host_ip:
            self.host_remove_before(host_name, roles)
        # 检查是否存在容灾，若不存在，则不再删除主机灾备IP信息
        disaster_exist = self.disaster_pool_exist()
        host_disk_capacity = self.get_host_disk_capacity(host_name)
        # begin add by d11564 2017/10/20 多MDS项目
        # 判断是否有文件系统
        has_filesys = self._check_has_filesys()
        # 如果有文件系统，进行删除对应ip的MDS
        if has_filesys:
            LOG.info('begin delete stor as mds ...')
            self._remove_mds(node_ip, host_name, 'MDS', True)
        # end add by d11564 2017/10/20 多MDS项目
        if const.OFFLINE != host_ip:
            # delete by z11524 2017/8/10 PN:201707280462
            # 发送消息给scheduler删除主机
            if disaster_exist:
                messanger.send_remove_backup_host_msg([disaster_ip])
            request.session[const.NEED_RESTORE_ONEBACKUP] = [disaster_ip]
            # BEGIN ADD BY D10039 2017/01/14 维护模式将主机移动到root=maintain下
            for diskpool in diskpool_name_list:
                self.exec_local_cmd(CMD_MOVE_OTHER_BUCKET.format(
                    host_name + '.' + diskpool, const.BUCKET_ROOT, const.BUCKET_MAINTAIN))
            # 将root=maintain下的属于该主机的osd移动到该主机下 MODIFY BY KF6602 PN:201705100130
            self._move_pod_osd_to_host(host_name)
            # 等待数据平衡完成
            self._update_progress(
                const.OP_REMOVE_DISK, const.PROGRESS_REBALANCE, hostname=host_name)
            set_onestor_progress(const.STEP_WAITING_DATA_BALANCE)
            self._waiting_for_data_rebalance(self.name_to_ip(host_name), host_name, diskpool_name_list)
            # 如果节点不是mon节点，则删除lvs配置
            self._remove_lvs_server(host_name, const.ROLE_MON)
            # 开始删除主机
            set_onestor_progress(const.STEP_BEGIN_REMOVE)
            self._update_progress(
                const.OP_REMOVE_DISK, const.PROGRESS_ROMOVING, hostname=host_name)
            self._process_remove_host(host_name, roles, diskpool_name_list, offline=False)
        else:
            # 发送消息给scheduler删除主机
            if disaster_exist:
                messanger.send_remove_backup_host_msg([disaster_ip])
            request.session[const.NEED_RESTORE_ONEBACKUP] = [disaster_ip]
            # 删除离线主机
            self._process_remove_host(host_name, roles, diskpool_name_list, offline=True)
        # 查看该逻辑主机下的osd是否为空，为空则删除该逻辑主机
        self._clear_empty_logic_host(host_name, diskpool_name_list)
        # 删除空逻辑机架
        self._remove_logic_rack(host_info[0], diskpool_data_list)
        # 更新硬盘池容量大小
        self.update_diskpool_capacity(host_info, const.DELETE_DISK_FOR_UPDATE_DISKPOOL_CAPACITY, host_disk_capacity)
        # 同步pg
        self.pg_rebalance()
        # 删除相关组件
        self._remove_host_soft(node_ip, roles, "stor")
        LOG.info('end to remove host ::::::')

    @util.send_response(
        op=const.OP_ADD_DISK,
        ret_type=const.RETURN_TYPE_2
    )
    @util.before_return(
        final=HostFinalRollback.add_disk_finally
    )
    def add_disk(self, request, fsid):
        """
        增加硬盘
        Author: dai.xinchun@h3c.com
        Date: 2016/12/07
        """
        LOG.info('start to add disk, data is {}'.format(request.DATA))
        task_id = request.DATA['task_id']
        host_name = request.DATA['osd_node']
        host_info = request.DATA['host_info']
        host_disk = self._get_need_deploy_disk(host_info)
        # 返回操作日志内容
        yield op_log.OP_ADD_DISK.format(','.join([disk.split(':')[0] + '（' + disk.split(':')[3] + '）'
                                                  for disk in host_disk['data']]), host_name)
        # 将当前任务记录到文件中
        self.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_ADD_DISK, task_id)
        # 查postgres主机表，补全主机信息（如保护域、机架字段）
        host_info = self._get_host_data([host_name], [host_info])[0]
        # 判断主机和硬盘规格是否超限(集群最大节点、硬盘数量，单节点池最大节点数量，单硬盘池最大硬盘数量)
        self.check_host_disk_num_limit([host_info])
        # 查询硬盘池数据
        diskpool_list = self.query_diskpool_data(host_info, const.OP_DISKPOOL_QUERY_SHORT)
        # BEGIN ADD BY j15537 检查集群如果丢失数据则不允许增加硬盘
        if self._check_lost_data():
            raise errno.ONEStorError(errno.ERROR_LOST_DATA)
        # END ADD BY j15537 检查集群如果丢失数据则不允许增加硬盘
        # BEGIN ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许增加硬盘
        # self._get_maintain_mode([host_info['nodepool_name']], [host_info['diskpool_list']])
        # END ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许增加硬盘
        # 检查硬盘是否为空
        if not host_disk['data']:
            raise errno.ONEStorError(errno.ERROR_DISK_IS_NULL)
        # 检查当前是否正在增加其它主机或硬盘
        has_adding = self._check_cocurrent_event(const.FLAG_ADDING_OSD)
        request.session[const.FLAG_ADDING_OSD] = has_adding
        if has_adding:
            raise errno.ONEStorError(errno.ERROR_HOST_BUSY)
        # 清除网络故障标识
        self._clear_network_error_flag(const.OP_ADD_DISK)
        # 根据主机名获取主机IP
        host_ip = self.name_to_ip(host_name)
        # 检查License信息
        self._check_license(host_ip, diskpool_list, host_info, in_cluster=True)
        # 部署硬盘
        self._add_disk(host_name, host_disk)
        # 移动逻辑机架
        self._move_logic_rack([host_info], diskpool_list)
        # 获取osd
        LOG.info('begin get osd...')
        self._get_osd_status_single(host_name, [host_info])
        # 初始化Crush
        LOG.info('begin initial crush...')
        self.initialize_host_crush([host_info], diskpool_list, False)
        # 更新主机表，diskpool字段
        self._update_host_table_for_diskpool(host_name)
        # 更新硬盘池容量大小
        self.update_diskpool_capacity([host_info], const.ADD_DISK_FOR_UPDATE_DISKPOOL_CAPACITY)
        # 同步pg
        self.pg_rebalance()
        LOG.info('end to add disk :::::')

    @util.send_response(
        op=const.OP_ADD_DISK,
        ret_type=const.RETURN_TYPE_2
    )
    @util.before_return(
        final=HostFinalRollback.add_disk_batch_finally
    )
    def add_disk_batch(self, request, fsid):
        """
        批量增加硬盘
        Date: 2018/01/13
        """
        LOG.info('add disk batch, data is {}'.format(request.DATA))
        task_id = request.DATA['task_id']
        osd_nodes = request.DATA['osd_node']
        host_info = request.DATA['host_info']
        host_info_detail = self._get_host_data(osd_nodes.split(','), host_info)
        host_disk = self._get_need_deploy_disk_batch(host_info_detail)
        diskpool_name_list = self._get_diskpool_name_list(host_info)
        # 返回操作日志内容
        yield op_log.OP_ADD_DISK_FOR_DISKPOOL.format(
            ','.join(diskpool_name_list),
            ','.join([host + '(' + ','.join([disk.split(':')[0] for disk in host_disk[host]['data']]) + ')'
                      for host in host_disk]))
        # 将当前任务记录到文件中
        self.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_ADD_DISK, task_id)
        # 判断主机和硬盘规格是否超限(集群最大节点、硬盘数量，单节点池最大节点数量，单硬盘池最大硬盘数量)
        self.check_host_disk_num_limit(host_info_detail)
        diskpool_data_list = self.query_diskpool_data(const.NODEPOOL_NAME_EMPTY_OBJECT,
                                                      const.OP_DISKPOOL_QUERY_SHORT)
        # BEGIN ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许增加硬盘
        # if self._get_maintain_mode():
        #     raise errno.ONEStorError(errno.ERROR_ADD_DISK_IN_MAINTAIN_MODE)
        # END ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许增加硬盘
        # 检查硬盘是否为空
        # if not host_disk['data']:
        #    raise errno.ONEStorError(errno.ERROR_DISK_IS_NULL)
        # 检查当前是否正在增加其它主机或硬盘
        has_adding = self._check_cocurrent_event(const.FLAG_ADDING_OSD)
        request.session[const.FLAG_ADDING_OSD] = has_adding
        if has_adding:
            raise errno.ONEStorError(errno.ERROR_HOST_BUSY)
        # 清除网络故障标识
        self._clear_network_error_flag(const.OP_ADD_DISK)
        # 根据主机名获取主机IP
        host_ip = self.name_to_ip(osd_nodes)
        # 检查License信息
        self._check_license(host_ip, diskpool_data_list, host_info, in_cluster=True)
        # 部署硬盘
        self._add_disk_batch(osd_nodes.split(','), host_disk)
        # 移动逻辑机架
        self._move_logic_rack(host_info_detail, diskpool_data_list)
        # 获取osd
        LOG.info('begin get osd...')
        self._get_osd_status_batch(const.STEP_GET_OSD_ID_FOR_ADD_DISK,
                                   osd_nodes.split(','), host_info_detail)
        # 初始化Crush
        LOG.info('begin initial crush...')
        self.initialize_host_crush(host_info_detail, diskpool_data_list, False)
        for host_name in osd_nodes.split(','):
            # 更新主机表，diskpool字段
            self._update_host_table_for_diskpool(host_name)
        # 检查增加硬盘的结果
        self._check_add_host_result(host_info_detail)
        # 更新硬盘池容量大小
        self.update_diskpool_capacity(host_info_detail, const.ADD_DISK_FOR_UPDATE_DISKPOOL_CAPACITY)
        # 同步pg
        self.pg_rebalance()
        LOG.info('end to disk batch :::::')

    @util.send_response(
        op=const.OP_REMOVE_DISK,
        ret_type=const.RETURN_TYPE_2
    )
    @util.before_return(
        final=HostFinalRollback.remove_disk_finally
    )
    def remove_disk(self, request, fsid):
        """
        删除硬盘
        :param {
            'hostname': 'node1',
            'disks': [
                {'id': 1, 'name': 'sdb', 'diskpool': 'dp1', 'physical_size': 1024 (单位：Byte)},
                {'id': 2, 'name': 'sdc', 'diskpool': 'dp1', 'physical_size': 1024},
                {'id': 3, 'name': 'sdd', 'diskpool': 'dp2', 'physical_size': 1024}
            ]
        }
        Author: dai.xinchun@h3c.com
        Date: 2016/12/07
        """
        LOG.info('start to remove disk, data is {}'.format(request.DATA))
        task_id = request.DATA['task_id']
        hostname = request.DATA['hostname']
        disks = request.DATA['disks']
        host_info = self._get_host_data([hostname], [{'name': hostname}])
        osds_id = [disk['id'] for disk in disks]
        osds_name = ','.join([disk['name'] + '(' + disk['diskpool'] + ')' for disk in disks])
        # 记录标识
        set_onestor_progress(const.STEP_PREPARE_REMOVE)
        # 返回操作日志内容
        yield op_log.OP_REMOVE_DISK.format(hostname, osds_name)
        # 将当前任务记录到文件中
        self.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_REMOVE_DISK, task_id)
        diskpool_name_list = list(set([disk['diskpool'] for disk in disks]))
        diskpool_data_list = self.query_diskpool_data(const.NODEPOOL_NAME_EMPTY_OBJECT,
                                                      const.OP_DISKPOOL_QUERY_SHORT)
        # BEGIN ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许删除硬盘
        # if self._get_maintain_mode():
        #     raise errno.ONEStorError(errno.ERROR_REMOVE_DISK_IN_MAINTAIN_MODE)
        # END ADD BY KF6602 检查当前是否开启了维护模式，维护模式下不允许删除硬盘
        # 检查当前是否正在删除其它主机或硬盘
        has_removing = self._check_cocurrent_event(const.FLAG_REMOVING_OSD)
        request.session[const.FLAG_REMOVING_OSD] = has_removing
        if has_removing:
            raise errno.ONEStorError(errno.ERROR_HOST_BUSY_REMOVE)
        # 清除网络故障标识
        self._clear_network_error_flag(const.OP_REMOVE_DISK)
        # 检测在部署了读写缓存的情况下，是否存在对应的ssd盘
        if self._check_journal_and_fcache_disks(hostname, disks):
            LOG.info('current relative flashcache ssd missing, can not be removed')
            raise errno.ONEStorError(errno.ERROR_REMOVE_DISK)
        # 集群状态异常时不允许删除硬盘
        # self._check_host_delete(const.OP_REMOVE_DISK_CN, hostname)
        self._update_progress(
            const.OP_REMOVE_DISK, const.PROGRESS_PREPARE_RM, hostname, disks)
        # BEGIN MODIFY BY KF6602 PN:201705100130
        # 将所选的OSD移动到pod=hostname_pod下，再移动到root=maintain下
        for _id in osds_id:
            self.exec_local_cmd(CMD_MOVE_OSD_BUCKET.format(
                _id, const.BUCKET_POD, const.HOST_NAME_POD.format(hostname)))
            self.exec_local_cmd(CMD_MOVE_OTHER_BUCKET.format(
                const.HOST_NAME_POD.format(hostname), const.BUCKET_ROOT, const.BUCKET_MAINTAIN))
        # END MODIFY BY KF6602 PN:201705100130
        # 等待数据平衡完成
        set_onestor_progress(const.STEP_WAITING_DATA_BALANCE)
        self._update_progress(
            const.OP_REMOVE_DISK, const.PROGRESS_REBALANCE, hostname, disks)
        self._waiting_for_data_rebalance(self.name_to_ip(hostname), hostname, diskpool_name_list)
        # 停止所选硬盘的进程
        for _id in osds_id:
            self.exec_remote_ssh_cmd(hostname, CMD_SET_OSD_UNREADY.format(osd_id=_id))
            self.exec_remote_ssh_cmd(hostname, CMD_STOP_OSD.format(osd_id=_id))
        # 逐个删除硬盘
        set_onestor_progress(const.STEP_BEGIN_REMOVE)
        self._update_progress(
            const.OP_REMOVE_DISK, const.PROGRESS_ROMOVING, hostname, disks)
        for disk in disks:
            self._remove_disk(hostname, disk)
        # 查看该逻辑主机下的osd是否为空，为空则删除该逻辑主机
        self._clear_empty_logic_host(hostname, host_info[0]['diskpool_list'])
        # 更新主机表，diskpool字段
        self._update_host_table_for_diskpool(hostname)
        # 删除空逻辑机架
        self._remove_logic_rack(host_info[0], diskpool_data_list)
        # 更新硬盘池容量大小
        self.pre_disk_for_host_info(host_info[0], disks)
        self.update_diskpool_capacity(host_info, const.DELETE_DISK_FOR_UPDATE_DISKPOOL_CAPACITY)
        # 同步pg
        self.pg_rebalance()
        LOG.info('end to remove disk :::::')

    @util.send_response(
        op=const.OP_LIST,
        ret_type=const.RETURN_TYPE_2
    )
    def check_remove_osd_event(self, request, fsid):
        """
        检查当前是否正在删除主机或硬盘
        """
        is_removing = os.path.exists(const.FLAG_REMOVING_OSD)
        yield {'has_removing': is_removing}

    @util.send_response(
        op=const.OP_LIST
    )
    def validate_netmask(self, request, fsid):
        """
        校验主机的子网掩码是否与集群配置一致
        :param request 页面过来的请求
        :param fsid 集群的ID
        :return: dict 网络检查结果
        """
        hosts = request.DATA.get('hosts')
        passwd = request.DATA.get('passwd')
        role = request.DATA.get('role')
        hosts_ip = hosts.split(',')
        check_cluster_network = True if const.ROLE_STOR == role else False
        yield self._check_host_network(
            nodes=hosts_ip,
            user=const.USER_ROOT,
            passwd=passwd,
            check_mask=True,
            check_cluster_network=check_cluster_network
        )

    def get_remove_status(self, request, fsid):
        """
        获取删除存储设备后的状态，用于判断是否让用户删除
        :param request:
        :return:删除后状态信息
        """
        data = request.GET.get('data')
        op = request.GET.get('op')
        rep = self._get_remove_status(data, op)
        return Response(rep)
