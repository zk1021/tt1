#!/usr/bin/env python
# coding: utf-8

"""
MON管理模块
"""

import logging

from calamari_rest.views.common import util
from calamari_rest.views.common import const
from calamari_rest.views.common import errno
from calamari_rest.views.common import op_log
from calamari_rest.views.onestor_common import ONEStorCommon
from calamari_rest.views.host.final_rollback import HostFinalRollback
from calamari_common.config import CalamariConfig
from calamari_rest.decorator import check_remove_osd_event
from calamari_rest.views.onestor.database import list_objs

LOG = logging.getLogger('django.request')
config = CalamariConfig()


class MonViewSet(HostFinalRollback):
    """
    MON管理视图
    """

    @check_remove_osd_event(const.OP_ADD_MON)
    @util.send_response(
        op=const.OP_ADD_MON,
        ret_type=const.RETURN_TYPE_2
    )
    @util.before_return(
        final=HostFinalRollback.add_mon_finally,
        roolback=HostFinalRollback.add_mon_rollback
    )
    def add_mon(self, request, fsid):
        """
        增加MON节点
        Author: dai.xinchun@h3c.com
        Date: 2016/12/21
        """
        task_id = request.DATA['task_id']
        user = request.DATA['user']
        passwd = request.DATA['passwd']
        node_ip = request.DATA['node_ip']

        # 返回操作日志内容
        yield op_log.OP_ADD_MON.format(node_ip)
        # begin modify by d11564 2017/04/22 PN:201704170327 同时增加mon，前台提示
        # 将当前任务记录到文件中
        self.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_ADD_MON, task_id)
        # begin add by d11564 2017/10/12 PN:201705110894 检查系统是否和handy一致
        is_match_os = self.check_os_version([node_ip], passwd)
        if not is_match_os:
            raise errno.ONEStorError(errno.ERROR_OS_VERSION)
        # end by d11564 2017/10/12 PN:201705110894 检查系统是否和handy一致
        # 检查当前是否正在操作其它MON
        has_adding = self._check_cocurrent_event(const.FLAG_OPERATE_MON)
        request.session[const.FLAG_OPERATE_MON] = has_adding
        if has_adding:
            raise errno.ONEStorError(errno.ERROR_MON_BUSY)
        # begin add by z11524 2017/8/10 PN:201708090145
        self.check_mon_num('add')
        self._assert_network_ok(node_ip)
        # 检查添加的主机IP是否在业务网段内
        self._check_public_ip(node_ip)
        # 检查主机名或主机IP是否已经出现在/etc/onestor_hosts中
        self._check_name_and_ip([node_ip], user, passwd)
        # 清除网络故障标识
        self._clear_network_error_flag(const.OP_ADD_MON)
        # 检查主机时间不能与集群相差太大
        LOG.info('begin check time...')
        self._check_host_offset_time([node_ip], passwd)
        # 检查主机网络是否满足部署要求，管理网、存储前端网、存储后端网必配
        LOG.info('begin check network...')
        self._check_host_network(
            [node_ip], user, passwd, check_cluster_network=True)
        host_name = self.cmd_remote(node_ip, passwd, const.HOST_NAME, user)
        # 检查主机名称是否满足部署要求
        self._check_linux_host_name([host_name], role=const.ROLE_MON)
        # 检查当前节点是否已经作为集群内的MON
        LOG.info('begin check exist mon...')
        self._check_exist_mon(host_name)
        # 检查集群中其它节点的网络是否正常（不包括MON节点本身）
        self._assert_cluster_nodes_network_ok(exclude_nodes=[node_ip])
        # 备份/etc/hosts文件
        self._backup_etc_hosts()
        request.session[const.NEED_RESTORE_ETC_HOSTS] = True
        # 备份/etc/ceph/ceph.conf文件
        self._backup_ceph_conf()
        request.session[const.NEED_RESTORE_CEPH_CONF] = True
        # 获取添加前的节点角色
        roles = self.get_host_roles_by_name(host_name)
        # 安装ONEStor软件
        LOG.info('begin install soft...')
        self._assert_network_ok(node_ip)
        self.install_soft(node_ip, passwd, user, node_type='mon')
        # Handy对该节点配置SSH免密
        LOG.info('begin config ssh...')
        self._assert_network_ok(node_ip)
        self.ssh_config(node_ip, passwd, user)
        request.session[const.NEED_RESTORE_CLUSTER_CONF] = True
        # 同步集群配置文件
        LOG.info('begin sync cluster config...')
        self._assert_network_ok(node_ip)
        self.sync_cluster_config(node_ip)
        # 配置NTP时间同步
        LOG.info('begin setup ntp...')
        self._assert_network_ok(node_ip)
        # 备份/etc/ntp.conf文件
        self._backup_ntp_conf()
        request.session[const.NEED_RESTORE_NTP] = True
        # NTP服务端配置
        ntp_type = self.setup_ntp_server(host_name)
        # 集群开启了NTP同步功能时检查时间同步是否成功（时间差小于1秒）
        self._check_mon_offset_time(node_ip, offset_time=const.MON_TIME_DIFF)
        # 开始部署MON
        LOG.info('begin deploy mon...')
        self._assert_network_ok(node_ip)
        # 备份主mon的tgt文件到handy节点tmp目录 add by h13051 PN:201704140460
        self._backup_mon_tgt()
        self._deploy_mon(node_ip, host_name)
        # 检查ceph config-key命令是否可以正常使用，刚刚增加完mon可能会挂住，需要增加超时等待
        self._assert_ceph_command_useful()
        # 同步主MON上的tgt配置
        LOG.info('begin sync tgt...')
        self._assert_network_ok(node_ip)
        self._sync_tgt(node_ip, host_name, const.OP_ADD_MON)
        # add by r13889 2017/03/24 PN:201703160637
        # DELETE BY KF6602 删除修改diamond配置的代码，监控项目不再需要修改diamond配置
        self.set_onestor_host()
        # 更新所有节点上ceph.conf里的mon配置
        self._assert_network_ok(node_ip)
        self._update_mon_cfg(node_ip, host_name, const.OP_ADD_MON)
        self._config_lvs_server([host_name], const.ROLE_STOR)
        # 增加zookeeper
        self._backup_zk_conf()
        self._assert_cluster_nodes_network_ok(exclude_nodes=[node_ip])
        request.session[const.NEED_RESTORE_ZK] = True
        self.add_zookeeper([node_ip])
        # 更新clusterconfig表中的mon信息
        LOG.info('begin add mon to clusterconfig...')
        self.add_mon_to_ldb(node_ip, host_name)
        # 将主机名对应的业务网IP保存到数据库cluster_hosts中
        LOG.info('begin add mon to cluster_hosts...')
        self.add_host_to_db(node_ip, host_name)
        # 如果增加mon成功，需要删除备份的ceph.conf和ntp.conf文件
        self._remove_backup_ceph_conf()
        self._remove_backup_ntp_conf()
        self._remove_back_zk_conf()
        self._check_nas_ready()

    @check_remove_osd_event(const.OP_REMOVE_MON)
    @util.send_response(
        op=const.OP_REMOVE_MON,
        ret_type=const.RETURN_TYPE_2
    )
    @util.before_return(
        final=HostFinalRollback.remove_mon_finally,
        roolback=HostFinalRollback.remove_mon_rollback
    )
    def remove_mon(self, request, fsid):
        """
        删除MON节点
        Author: dai.xinchun@h3c.com
        Date: 2016/12/28
        """
        task_id = request.GET.get('task_id')
        node_ip = request.GET.get('node_ip')
        host_name = request.GET.get('host_name')
        # 返回操作日志内容
        log_content = op_log.OP_REMOVE_OFFLINE_MON if \
            const.OFFLINE == node_ip else op_log.OP_REMOVE_MON
        # IP地址从onestor_hosts文件中读取
        host_ip = self.name_to_ip(host_name)
        yield log_content.format(host_ip)
        # begin modify by d11564 2017/04/22 PN:201704170327 同时删除mon，前台提示
        # 将当前任务记录到文件中
        self.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_REMOVE_MON, task_id)
        # 检查当前是否正在操作其它MON
        has_adding = self._check_cocurrent_event(const.FLAG_OPERATE_MON)
        request.session[const.FLAG_OPERATE_MON] = has_adding
        if has_adding:
            raise errno.ONEStorError(errno.ERROR_MON_BUSY)
        # end modify by d11564 2017/04/22 PN:201704170327 同时删除mon，前台提示
        # 获取当前节点在集群中的角色
        roles = self.get_host_roles_by_name(host_name)
        # 检查节点是否存在不允许删除的角色情况(现主要为集群外对象网关角色)
        if const.OFFLINE != node_ip:
            self.host_remove_before(host_name, roles)
        if const.OFFLINE != node_ip and self.mon_status_is_ok(host_name):
            # mon状态正常且在线  检测mon数量
            self.check_mon_num('remove')
        # 清除网络故障标识
        self._clear_network_error_flag(const.OP_REMOVE_MON)
        # 检查集群中其它节点的网络是否正常（不包括MON节点自身）
        self._assert_cluster_nodes_network_ok(exclude_nodes=[host_ip])
        # 操作之前先备份所有节点上的ceph.conf文件
        self._backup_ceph_conf()
        request.session[const.NEED_RESTORE_CEPH_CONF] = True
        self._backup_ntp_conf()
        request.session[const.NEED_RESTORE_NTP] = True
        self._backup_zk_conf()
        request.session[const.NEED_RESTORE_ZK] = True
        if const.OFFLINE == node_ip:
            self.remove_zookeeper(host_ip, offline=True)
            self._process_remove_mon(host_ip, host_name, offline=True)
        else:
            # delete by z11524 2017/8/10 PN:201707280462
            # 开始删除监控节点
            self.remove_zookeeper(host_ip)
            self._assert_network_ok(host_ip)
            self._process_remove_mon(host_ip, host_name, offline=False)
        # DELETE BY KF6602 监控项目不需要清除graphite监控数据
        # 如果节点不是存储节点，则删除lvs配置
        self._remove_lvs_server(host_name, const.ROLE_STOR)
        # 如果删除mon成功，需要删除其它节点上备份的ceph.conf和ntp.conf文件
        self._remove_backup_ceph_conf()
        self._remove_backup_ntp_conf()
        if const.OFFLINE == node_ip:
            # 如果该主机不作为任何角色，删除cluster_hosts和onestor_hosts
            if not roles or 1 == roles['role_num']:
                LOG.info('begin clear onestor_hosts and cluster_hosts...')
                self._remove_host_from_cluster(host_ip, host_name)
        else:
            # 清理onestor_hosts、cluster_hosts、tgt、各种目录
            self._assert_network_ok(host_ip)
            self._clear_cluster_config({host_name: host_ip}, exclude_role=const.ROLE_MON)
        self._check_nas_ready()
        # 删除clusterconfig中的mon节点
        if const.OFFLINE != node_ip:
            self._assert_network_ok(host_ip)
        self.remove_mon_from_ldb(host_ip, host_name)
        self._remove_back_zk_conf()
        # 删除相关组件
        self._remove_host_soft(node_ip, roles, "mon")
        LOG.info('remove mon %s success', host_name)
        self.set_onestor_host()

    @staticmethod
    def check_mon_num(model="add"):
        """
        计算mon数量
        begin add by z11524 2017/8/10 PN:201708090145
        Date: 2017/8/10
        """
        mon_info = list_objs(const.CLUSTERCONFIG)
        if 'mon_fqdns' in mon_info:
            if 7 <= len(mon_info['mon_fqdns']) and model == 'add':
                raise errno.ONEStorError(errno.ERROR_MON_NUM_LIMIT)
            elif 3 >= len(mon_info['mon_fqdns']) and model == 'remove':
                raise errno.ONEStorError(errno.ERROR_MON_MIN_MUN_LIMIT)
        elif 'status' in mon_info:
            raise errno.ONEStorError(errno.ERROR_GET_MON_STATUS)
