#!/usr/bin/env python
# coding: utf-8

"""
对象网关模块
"""

import logging

from calamari_rest.decorator import module_required
from calamari_rest.decorator import check_remove_osd_event

from calamari_rest.views.common import misc
from calamari_rest.views.common import util
from calamari_rest.views.common import const
from calamari_rest.views.common import errno
from calamari_rest.views.common import op_log
from calamari_rest.views.obs.final_rollback import ObsFinalRollback

from rest_framework.response import Response

LOG = logging.getLogger('django.request')


class RadosGatewayViewSet(ObsFinalRollback):
    """
    对象网关视图
    """

    @util.send_response(
        op=const.OP_LIST
    )
    def list_rados_gateway(self, request, fsid):
        """
        查询对象网关
        Author: dai.xinchun@h3c.com
        Date: 2017/04/15
        """
        gateways = misc.query_ceph_leveldb(const.TABLE_GATEWAY)
        if not isinstance(gateways, dict) or const.TABLE_GATEWAY not in gateways:
            LOG.info('===query rados gateway, invalid data returned, %s===', gateways)
            yield []
        yield self._set_rgw_info(gateways)

    @check_remove_osd_event(
        const.OP_DEPLOY_GATEWAY
    )
    @util.send_response(
        op=const.OP_DEPLOY_GATEWAY,
        ret_type=const.RETURN_TYPE_1
    )
    @util.before_return(
        final=ObsFinalRollback.add_rados_gateway_finally,
        roolback=ObsFinalRollback.add_rados_gateway_rollback
    )
    def add_rados_gateway(self, request, fsid):
        """
        增加对象网关
        Author: dai.xinchun@h3c.com
        Date: 2017/04/15
        """
        user = const.USER_ROOT
        task_id = request.DATA['task_id']
        node_ip = request.DATA['node_ip']
        passwd = request.DATA['password']
        exist_host = request.DATA['exist_host']
        deploy_from_exist = request.DATA['deploy_from_exist']
        # 返回操作日志内容
        node_ip = exist_host.split(':')[0] if deploy_from_exist else node_ip
        yield op_log.OP_DEPLOY_GATEWAY.format(node_ip)
        # 将当前任务记录到文件中
        self.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_DEPLOY_GATEWAY, task_id)
        # 检查当前是否正在操作其它对象网关
        has_adding = self._check_cocurrent_event(const.FLAG_OPERATE_RGW)
        request.session[const.FLAG_OPERATE_RGW] = has_adding
        if has_adding:
            raise errno.ONEStorError(errno.ERROR_OPERATE_RGW_BUSY)
        # 清除网络故障标识
        self._clear_network_error_flag(const.OP_DEPLOY_GATEWAY)
        # 如果指定新的主机部署对象网关，需要先进行各种校验
        LOG.info('begin deploy rgw on node %s...', node_ip)
        if not deploy_from_exist:
            self._deploy_rgw_on_new_node(request, node_ip, user, passwd)
        else:
            self._deploy_rgw_on_exist_node(request, node_ip)
        LOG.info('success to deploy rgw %s', node_ip)

    @check_remove_osd_event(
        const.OP_REMOVE_GATEWAY
    )
    @util.send_response(
        op=const.OP_REMOVE_GATEWAY,
        ret_type=const.RETURN_TYPE_1
    )
    @util.before_return(
        final=ObsFinalRollback.remove_rados_gateway_finally
    )
    def remove_rados_gateway(self, request, fsid):
        """
        删除对象网关
        Date: 2017/04/22
        """
        task_id = request.GET.get('task_id')
        clear_rgw_data = request.GET.get('clear_rgw_data')
        gateway_ip = request.GET.get('gateway_ip')
        gateway_hostname = request.GET.get('gateway_hostname')
        gateway_id = request.GET.get('gateway_nodeId')
        network_status = request.GET.get('network_status', True)
        # 返回操作日志内容
        yield op_log.OP_REMOVE_OFFLINE_GATEWAY.format(gateway_ip) if ('false' == network_status or not network_status) \
            else op_log.OP_REMOVE_GATEWAY.format(gateway_ip)
        # 将当前任务记录到文件中
        self.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_REMOVE_GATEWAY, task_id)
        # 检查当前是否正在操作其它对象网关
        has_removing = self._check_cocurrent_event(const.FLAG_OPERATE_RGW)
        request.session[const.FLAG_OPERATE_RGW] = has_removing
        if has_removing:
            raise errno.ONEStorError(errno.ERROR_OPERATE_RGW_BUSY)
        # 清除网络故障标识
        self._clear_network_error_flag(const.OP_REMOVE_GATEWAY)
        # 若为离线删除网关，则不再前往对端清理配置
        if not network_status or 'false' == network_status:
            self._remove_offline_gateway(gateway_hostname, gateway_ip, gateway_id, clear_rgw_data, fsid)
        else:
            # 检查网络是否有故障
            self._assert_network_ok(gateway_ip)
            # 检查对象网关进程是否正在被使用
            # self._check_rgw_is_used(gateway_ip)
            # 检查是否是最后一个对象网关，若是则需要删除
            if 'Y' == clear_rgw_data:
                self._clear_rados_gateway_datas(gateway_ip, fsid)
            # 删除对象网关配置
            self._remove_gateway_conf(gateway_ip, gateway_hostname)
            # DELETE BY KF6602 监控项目不需要清除graphite监控数据
            # 删除LVS配置
            self._remove_lvs_server(gateway_hostname, const.ROLE_RGW)
            # 清理其它配置信息
            self._clear_cluster_config({
                gateway_hostname: self.name_to_ip(gateway_hostname)
            }, exclude_role=const.ROLE_RGW)
            # 从数据库中删除对象网关
            self.remove_rgw_from_ldb(gateway_id)
            LOG.info('success to remove rgw %s', gateway_ip)

    def _remove_offline_gateway(self, gateway_hostname, gateway_ip, gateway_id, clear_rgw_data, fsid):
        """
        离线删除对象网关，不影响正常删除操作
        :param gateway_hostname: 网关名称
        :param gateway_ip: 网关IP
        :param gateway_id: 网关数据库ID
        :param clear_rgw_data: 是否清理对象存储数据
        :param fsid: 集群ID
        :return: None
        """
        # 检查是否是最后一个对象网关，若是则需要删除
        if 'Y' == clear_rgw_data:
            self._clear_rados_gateway_datas(gateway_ip, fsid, offline=True)
        # 删除对象网关配置
        self._remove_gateway_conf(gateway_ip, gateway_hostname, offline=True)
        # 如果该主机不作为任何角色，删除cluster_hosts和onestor_hosts
        roles = self.get_host_roles_by_name(gateway_hostname)
        if not roles or (1 == roles['role_num'] and roles['rgw']):
            LOG.info('begin clear onestor_hosts and cluster_hosts...')
            self._remove_host_from_cluster(self.name_to_ip(gateway_hostname), gateway_hostname)
        # DELETE BY KF6602 监控项目不需要清除graphite监控数据
        # 从数据库中删除对象网关
        self.remove_rgw_from_ldb(gateway_id)
        LOG.info('success to remove offline rgw %s', gateway_ip)

    def gateway_is_in_used(self, request, fsid):
        """
        检查网关是否处于被使用状态，若被使用，则向用户告警
        :param request:
        :param fsid:
        :return: True or False
        """
        gateway_ip = request.GET.get('gateway_ip')
        gateway_used = self.rgw_is_in_used(gateway_ip)
        return Response({'gateway_used': gateway_used})
