#!/usr/bin/env python
# coding: utf-8

"""
主机管理回滚
"""

import os
import logging

from calamari_rest.views.common import const
from calamari_rest.views.common import cmd
from calamari_rest.views.obs.obs_util import ObsUtil
from rest_framework.request import Request

LOG = logging.getLogger('django.request')


class ObsFinalRollback(ObsUtil):
    """
    对象存储管理finally和回滚方法类
    """

    @staticmethod
    def __remove_cocurrent_flag(session, flag):
        """
        删除并发保护的标识
        Date: 2016/12/07
        """
        if flag in session and not session[flag]:
            if os.path.exists(flag):
                os.remove(flag)
            del session[flag]

    def add_rados_gateway_finally(self, *args):
        """
        部署对象网关finally执行函数
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 删除并发保护标识
        self.__remove_cocurrent_flag(session, const.FLAG_OPERATE_RGW)
        # 还原/etc/hosts配置
        if const.NEED_RESTORE_ETC_HOSTS in session:
            try:
                self._recovery_etc_hosts()
            finally:
                del session[const.NEED_RESTORE_ETC_HOSTS]
        # 删除其它节点上备份的ceph.conf
        if const.NEED_RESTORE_CEPH_CONF in session:
            try:
                self._remove_backup_ceph_conf()
            finally:
                del session[const.NEED_RESTORE_CEPH_CONF]
        if const.NEED_RESTORE_CLUSTER_CONF in session:
            del session[const.NEED_RESTORE_CLUSTER_CONF]

    def add_rados_gateway_rollback(self, *args):
        """
        部署对象网关回滚函数
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 回退ceph.conf配置
        if const.NEED_RESTORE_CEPH_CONF in session:
            try:
                LOG.info('need restore ceph.conf when rollback')
                self._recovery_ceph_conf()
            finally:
                del session[const.NEED_RESTORE_CEPH_CONF]
        # 回滚集群配置
        if const.NEED_RESTORE_CLUSTER_CONF in session:
            try:
                LOG.info('need restore cluster conf when rollback')
                node_ip = request.DATA['node_ip']
                exist_host = request.DATA['exist_host']
                deploy_from_exist = request.DATA['deploy_from_exist']
                node_ip = exist_host.split(':')[0] if deploy_from_exist else node_ip
                host_name = self.ip_to_name(node_ip)
                # 如果根据IP地址无法获取到主机名，则不进行回滚
                if host_name != node_ip:
                    # 回退对象网关配置
                    LOG.info('begin rollback rgw config...')
                    self.exec_remote_ssh_cmd(node_ip, cmd.CMD_REMOVE_RGW_CONF.format(host_name))
                    # 回退ceph auth list中的认证信息
                    LOG.info('begin rollback rgw auth...')
                    self.exec_local_cmd(cmd.CMD_REMOVE_RGW_AUTH.format(host_name))
                    LOG.info('begin clear cluster config...')
                    self._clear_cluster_config({host_name: node_ip})
            finally:
                del session[const.NEED_RESTORE_CLUSTER_CONF]
        LOG.info('finish rollback when add rados gateway.')

    def remove_rados_gateway_finally(self, *args):
        """
        删除对象网关finally执行函数
        """
        request = [arg for arg in args if isinstance(arg, Request)][0]
        session = request.session
        # 删除并发保护标识
        self.__remove_cocurrent_flag(session, const.FLAG_OPERATE_RGW)
