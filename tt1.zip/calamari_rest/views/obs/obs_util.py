#!/usr/bin/env python
# coding: utf-8

"""
对象存储管理工具类
"""
import json
import rados
import logging
import os

from django.contrib.auth.models import User

from calamari_rest.views.common import cmd
from calamari_rest.views.common import const
from calamari_rest.views.common import errno
from calamari_rest.views.host.host_util import HostUtil
from calamari_rest.views.onestor import onestor

from calamari_rest.common import send_request_onestord
from calamari_rest.common import delete_user as delete_user_by_sql
from calamari_common.config import CalamariConfig


LOG = logging.getLogger('django.request')
config = CalamariConfig()


class ObsUtil(HostUtil):
    """
    对象存储管理工具类
    """

    def _set_rgw_info(self, gateways):
        """
        获取并设置对象网关的状态
        """
        for gateway in gateways[const.TABLE_GATEWAY]:
            curl_ret = self.exec_local_cmd(
                'curl --connect-timeout 2 --max-time 2 %s' % gateway[const.HOST_IP])
            gateway = self.get_gateway_part_info(gateway)
            if -1 != curl_ret.find('<?xml version="1.0" encoding="UTF-8"?>'):
                gateway['status'] = 'OK'
            else:
                gateway['status'] = 'ERROR'
        return gateways[const.TABLE_GATEWAY]

    def _check_exist_cluster_host(self, node_ip, node_name):
        """
        检查主机名或IP是否与集群现有主机相同
        """
        cluster_hosts_exclude_rgw = self.get_cluster_hosts_from_config(
            exclude_roles=[const.ROLE_RGW])
        for _host in cluster_hosts_exclude_rgw:
            if node_name == _host[const.HOST_NAME]:
                raise errno.ONEStorError(errno.ERROR_ADD_RGW_EXIST_HOST_NAME)
            if node_ip == _host[const.HOST_IP]:
                raise errno.ONEStorError(errno.ERROR_ADD_RGW_EXIST_HOST_IP)

    def __validate_rgw(self, node_ip, user, passwd):
        """
        指定新的主机部署对象网关，需要进行以下的校验：
        1、IP地址是否在业务网段内
        2、/etc/onestor_hosts中的主机名称和IP校验
        3、主机名称或IP不能与集群现有主机相同
        4、主机名称不能包含特殊字符
        5、主机时间不能与集群相差太大
        6、业务网IP地址能够ping通
        """
        # 检查添加的主机IP是否在业务网段内
        LOG.info('begin check ip in public network...')
        self._check_public_ip(node_ip)
        # 检查主机名或主机IP是否已经出现在/etc/onestor_hosts中
        LOG.info('begin check name&ip in onestor_hosts...')
        self._check_name_and_ip([node_ip], user, passwd)
        # 检查主机名称是否满足部署要求
        host_name = self.cmd_remote(node_ip, passwd, const.HOST_NAME, user)
        LOG.info('begin check linux name...')
        self._check_linux_host_name([host_name], role=const.ROLE_RGW)
        # 检查该主机是否已经存在/etc/ceph/ceph.conf文件
        LOG.info('begin check ceph.conf...')
        self._check_exist_ceph_conf(node_ip, passwd)
        # 检查主机名或主机IP是否与集群现有主机相同（因为是指定新主机的方式加的）
        self._check_exist_cluster_host(node_ip, host_name)
        # 检查主机时间不能与集群相差太大
        LOG.info('begin check local time...')
        self._check_host_offset_time([node_ip], passwd)
        # 检查主机网络是否满足部署要求，仅判断业务网即可
        LOG.info('begin check public ip is reachable...')
        self._check_host_network(
            [node_ip], user, passwd, check_cluster_network=False)

    def _check_exist_ceph_conf(self, node_ip, passwd):
        """
        检查主机上是否已经存在ceph.conf文件
        """
        conf_file_exist = self.cmd_remote(
            node_ip, passwd, 'ls /etc/ceph/ceph.conf 2>/dev/null | wc -l')
        if '1' != conf_file_exist:
            LOG.info('node %s has no ceph.conf, pass the validate.', node_ip)
            return
        # 获取Handy本地的集群ID
        local_fsid = self.exec_local_cmd(cmd.CMD_GET_FSID)
        # 判断新主机上的集群ID是否与本集群一致，如果是则为集群已有主机，如果不是则为其它集群的主机
        is_fsid_self_cluster = self.cmd_remote(
            node_ip, passwd, 'cat /etc/ceph/ceph.conf | grep {0} 2>/dev/null | wc -l'.format(local_fsid))
        if '1' == is_fsid_self_cluster:
            raise errno.ONEStorError(errno.ERROR_ADD_RGW_EXIST_CEPH_CONF)
        else:
            raise errno.ONEStorError(errno.ERROR_RGW_EXIST_OTHER_CEPH_CONF)

    def _clear_rados_gateway_datas(self, node_ip, fsid, offline=False):
        """
        判断是否为最后一个对象网关，若是则需要执行此操作
        """
        if not offline:
            result = self.exec_remote_ssh_cmd(node_ip, cmd.CMD_STOP_RGW_DAEMON)
            if isinstance(result, dict) and const.RESULT_ERROR == result['status']:
                raise errno.ONEStorError(errno.ERROR_STOP_RGW_DAEMON)
        # rgw_pools = const.RGW_POOLS.keys()
        # pool_info_all = onestor.getPoolStat(const.CEPH_CONF)
        pool_currid = ''
        # for pool in pool_info_all['data']:
        #     if pool['name'] in rgw_pools:
        #         pool_currid += str(pool['id'])
        #         pool_currid += ','
        # for pool in rgw_pools:
        #     onestor.remove_pool(pool)

        # 检查是否所有的pool都删除干净了
        # remain_pools = self.exec_local_cmd_json(cmd.CMD_LIST_POOLS)
        # failed_pools = [pool for pool in rgw_pools if pool in remain_pools]
        # if 0 != len(failed_pools):
        #     raise errno.ONEStorError(errno.ERROR_RGW_POOL_RESIDUAL, failed_pools)
        # else :
        #     # 删除postgres calamari数据库中对象网关池
        self.__send_delete_pool_msg()

        if 'true' == config.get('calamari_web', 'netdisk_switch'):
            # 删除postgres中所有的对象存储用户
            gatewayusers = self.onestor_request(
                fsid, 'database.list_objs', ['gatewayuser'])

            for user in gatewayusers['gatewayuser']:
                username = user['uname']
                # BEGIN MODIFY BY D10039 2016/09/06 删除对象网关时不删除admin用户
                if username == 'admin':
                    continue
                user = User.objects.get(username=username)
                user.groups.clear()
                delete_user_by_sql(username)
        # 删除leveldb中所有的对象存储用户
        # 获取对象网关用户的用户表列表
        config_list = self.exec_local_cmd_json("timeout 30 ceph config-key list")
        gateway_list = [gateway for gateway in config_list if 'gatewayuser' == gateway.strip() or (
            len(gateway.strip().split('__')) > 1 and 'gatewayuser' == gateway.strip().split('__')[0])]
        for gateway in gateway_list:
            LOG.info('del gateway database info, name is: %s', gateway)
            self.exec_local_cmd('timeout 300 ceph config-key del {0}'.format(gateway))

        # DELETE BY KF6602 监控项目不需要清除graphite监控数据

    def __install_rgw_soft(self, node_ip):
        """
        安装对象网关软件
        """
        # 获取Handy本地IP，必须是public_network网段的IP
        handy_ip = self.get_handy_public_ip()
        # 获取Handy的端口号
        handy_port = self.exec_local_cmd(cmd.CMD_GET_HANDY_PORT)
        # 安装对象网关软件
        install_result = self.exec_remote_ssh_cmd(
            node_ip, cmd.CMD_INSTALL_RGW.format(handy_ip, handy_port), raise_exc=True)
        LOG.info('install rgw soft result: %s', install_result)
        # 检查软件安装结果
        if -1 == install_result.find('ceph version'):
            raise errno.ONEStorError(errno.ERROR_INSTALL_RGW_SOFT)
        # 检查Diamond软件是否安装成功
        if "" == self.exec_remote_ssh_cmd(
                node_ip, cmd.CMD_CHECK_DIAMOND_INSTALLED, raise_exc=True):
            raise errno.ONEStorError(errno.ERROR_INSTALL_SOFT_BATCH, node_ip)

    def __create_gateway_pool(self, diskpool_name, redundancy, replicate_num):
        """
        创建对象网关Pool
        """
        with rados.Rados(conffile=const.CEPH_CONF) as cluster:
            rgw_pools = const.RGW_POOLS
            tmp_rgw_pools = {}
            for pool_name in rgw_pools:
                if cluster.pool_exists(pool_name):
                    continue
                tmp_rgw_pools[pool_name] = rgw_pools[pool_name]

            if len(tmp_rgw_pools) > 0:
                self.__send_create_pool_msg(
                    tmp_rgw_pools, diskpool_name, redundancy, replicate_num)

            current_pools = self.exec_local_cmd_json(cmd.CMD_LIST_POOLS)
            for pool_name in rgw_pools:
                if pool_name in current_pools:
                    continue
                raise errno.ONEStorError(errno.ERROR_CREATE_RGW_POOL, pool_name)

    @staticmethod
    def __send_create_pool_msg(pool_name, diskpool_name, redundancy, replicate_num):
        """
        发送消息给onestord创建Pool
        """
        LOG.info('begin create rgw pool, name is {0}, diskpool_name is {1}'
                .format(pool_name, diskpool_name))
        data = {
            'pool_name': pool_name,
            'diskpool_name': diskpool_name,
            'redundancy': redundancy,
            'replicate_num': replicate_num
        }
        pool_create_response = send_request_onestord('COMP_CS', 'POOL_create', data)
        LOG.info('create rgw pool, response is %s', pool_create_response)
        pool_create_result = pool_create_response['response']['result']
        if 0 != pool_create_result[0]:
            raise errno.ONEStorError.make_error('POOL_CREATE', pool_create_result[2])
        LOG.info('success to create rgw pool')

    @staticmethod
    def __send_delete_pool_msg():
        """
        发送消息给onestord删除Pool
        """
        LOG.info('begin delete rgw pool, pool name is default.rgw.buckets.data')
                
        data = {
            'pool_name': 'default.rgw.buckets.data'
        }
        pool_delete_response = send_request_onestord('COMP_CS', 'POOL_delete', data)
        LOG.info('delete rgw pool, response is %s', pool_delete_response)
        pool_delete_result = pool_delete_response['response']['result']
        if 0 != pool_delete_result[0]:
            raise errno.ONEStorError.make_error('POOL_DELETE', pool_delete_result[2])
        LOG.info('success to delete rgw pool')

    def _handle_deploy_gateway(self, request, host_name, host_ip):
        """
        处理创建对象网关的事件
        """
        # 从request中读取参数
        ssl = request.DATA['ssl']
        redundancy = request.DATA['redundancy']
        replicate_num = request.DATA['replicate_num']
        diskpool_name = request.DATA.get('diskpool_name', '')

        # 创建对象存储相关Pool
        self.__create_gateway_pool(diskpool_name, redundancy, replicate_num)
        # 远程登录到节点上生成网关配置
        result = self.exec_remote_ssh_cmd(
            host_ip, cmd.CMD_DEPLOY_RGW.format(host_name, host_ip, ssl), raise_exc=True)
        LOG.info('deploy gateway config result: %s', result)
        if -1 != result.find('ERROR_NO_PORT_AVAILABLE'):
            raise errno.ONEStorError(errno.ERROR_NO_RGW_PORT)
        elif -1 == result.find(const.OP_SUCCSSFUL):
            raise errno.ONEStorError(errno.ERROR_CREATE_RGW_CONF)
        rgw_port = result.split('success:')[1]
        # 在Handy的ceph.conf中追加该对象网关配置，防止推送配置文件覆盖对象网关的情况发生
        LOG.info('create rgw conf for handy...')
        self.exec_cmd_on_handy_nodes(cmd.CMD_CREATE_RGW_CONF.format(host_name, rgw_port, ssl))
        # 启动对象网关进程
        self.exec_remote_ssh_cmd(host_ip, cmd.SERVICE_START_RADOSGW, raise_exc=True)
        # 配置LVS服务器
        self._config_lvs_server([host_name], const.ROLE_RGW)
        # MODIFY BY KF6602 删除修改diamond配置的代码，监控项目不再需要修改diamond配置
        self.set_onestor_host()
        # 将对象网关保存到数据库中
        self.add_rgw_to_ldb(host_ip, host_name, rgw_port, ssl, diskpool_name)

    def _check_rgw_daemon(self, node_ip):
        """
        检查对象网关进程是否存在
        """
        rgw_status = self.exec_remote_ssh_cmd(
            node_ip, cmd.CMD_CHECK_RGW_STATUS, raise_exc=True)
        if '1' == rgw_status:
            return True
        else:
            return False

    def _deploy_rgw_on_new_node(self, request, node_ip, user, passwd):
        """
        在新节点上部署对象网关
        """
        # 先进行基本的校验
        LOG.info('begin validate rgw...')
        self.__validate_rgw(node_ip, user, passwd)
        # 检查网络
        self._check_host_network(nodes=[node_ip], user=user, passwd=passwd, check_cluster_network=False)
        # 先备份原有的/etc/hosts文件
        LOG.info('begin backup /etc/hosts to /etc/hosts_bak')
        self._backup_etc_hosts()
        request.session[const.NEED_RESTORE_ETC_HOSTS] = True
        # 备份/etc/ceph/ceph.conf文件
        self._backup_ceph_conf()
        request.session[const.NEED_RESTORE_CEPH_CONF] = True
        # Handy对该节点配置SSH免密
        LOG.info('begin config ssh...')
        host_name, public_ip = self.ssh_config(node_ip, passwd, user)
        request.session[const.NEED_RESTORE_CLUSTER_CONF] = True
        # 检查对象网关进程是否已经存在
        if self._check_rgw_daemon(public_ip):
            raise errno.ONEStorError(errno.ERROR_EXIST_RGW_DAEMON)
        # 将install_rgw.sh脚本传送到新主机上
        LOG.info('begin copy install_rgw.sh to node...')
        self.exec_remote_ssh_cmd(
            public_ip, 'mkdir -p /var/lib/ceph/shell', raise_exc=True)
        self.exec_local_cmd(cmd.CMD_COPY_INSTALL_RGW_FILE.format(public_ip))
        if os.path.exists("/var/lib/ceph/shell/install_rgw.sh.x"):
            self.exec_local_cmd(cmd.CMD_COPY_INSTALL_RGW_SHX_FILE.format(public_ip))
        # 安装对象网关软件
        LOG.info('begin install rgw software...')
        self.__install_rgw_soft(public_ip)
        # 配置NTP时间同步
        LOG.info('begin setup ntp...')
        self.setup_ntp_client(host_name)
        # 同步集群配置文件
        LOG.info('begin sync cluster config...')
        self.sync_cluster_config(public_ip, role=const.ROLE_RGW)
        # 开始部署对象网关
        self._handle_deploy_gateway(request, host_name, public_ip)
        # 将主机名对应的业务网IP保存到数据库cluster_hosts中
        LOG.info('begin add rgw to db...')
        self.add_host_to_db(public_ip, host_name)
        # 保存主机基础信息
        self.save_hosts_base_info([node_ip])
        # 集群外的对象网关需要删除admin.keyring文件
        LOG.info('begin remove ceph.client.admin.keyring...')
        self.exec_remote_ssh_cmd(
            public_ip, 'rm -f /etc/ceph/ceph.client.admin.keyring', raise_exc=True)

    def _deploy_rgw_on_exist_node(self, request, node_ip):
        """
        在集群已有节点上部署对象网关
        """
        # 检查对象网关进程是否已经存在
        if self._check_rgw_daemon(node_ip):
            raise errno.ONEStorError(errno.ERROR_EXIST_RGW_DAEMON)
        # 先备份原有的/etc/hosts文件
        LOG.info('begin backup /etc/hosts to /etc/hosts_bak')
        self._backup_etc_hosts()
        request.session[const.NEED_RESTORE_ETC_HOSTS] = True
        # 备份/etc/ceph/ceph.conf文件
        self._backup_ceph_conf()
        request.session[const.NEED_RESTORE_CEPH_CONF] = True
        # 安装对象网关软件
        self.__install_rgw_soft(node_ip)
        request.session[const.NEED_RESTORE_CLUSTER_CONF] = True
        # 开始部署对象网关
        self._handle_deploy_gateway(request, self.ip_to_name(node_ip), node_ip)

    def rgw_is_in_used(self, gateway_ip):
        """
        判断网关是否被使用
        :param gateway_ip: 网关IP
        :return: True代表被使用，False代表未被使用
        """
        gateway_conf = self.exec_local_cmd_json(cmd.DB_GET_GATEWAY)
        rgw_port = 0
        for gateway in gateway_conf[const.TABLE_GATEWAY]:
            if gateway_ip == gateway[const.HOST_IP].split(':')[0]:
                rgw_port = gateway[const.HOST_IP].split(':')[1]
                break
        if '0' != self.exec_remote_ssh_cmd(
                gateway_ip, cmd.CMD_CHECK_RGW_IS_USED.format(rgw_port), raise_exc=True):
            return True
        return False

    def _check_rgw_is_used(self, gateway_ip):
        """
        检查对象网关是否正在被使用
        """
        gateway_used = self.rgw_is_in_used(gateway_ip)
        if gateway_used:
            raise errno.ONEStorError(errno.ERROR_RGW_IS_USED, gateway_ip)

    def _remove_gateway_conf(self, gateway_ip, gateway_hostname, offline=False):
        """
        删除对象网关配置
        """
        LOG.info('begin remove gateway conf on node %s...', gateway_ip)
        # 若不是离线删除，前往对端清理配置
        if not offline:
            remove_result = self.exec_remote_ssh_cmd(
                gateway_ip, cmd.CMD_REMOVE_RGW_CONF.format(gateway_hostname), raise_exc=True)
            LOG.info('remove gateway result: %s', remove_result)
            if -1 == remove_result.find(const.OP_SUCCSSFUL):
                raise errno.ONEStorError(errno.ERROR_REMOVE_RGW_CONF)
        # 删除对象网关的认证信息
        LOG.info('begin remove gateway auth for %s...', gateway_ip)
        self.exec_local_cmd(cmd.CMD_REMOVE_RGW_AUTH.format(gateway_hostname))
        # 检查认证信息是否删除成功
        if '0' != self.exec_local_cmd(cmd.CMD_CHECK_RGW_AUTH.format(gateway_hostname)):
            raise errno.ONEStorError(errno.ERROR_REMOVE_RGW_AUTH)
        # 删除Handy节点上ceph.conf里的对象网关配置
        LOG.info('remove rgw conf from handy...')
        self.exec_cmd_on_handy_nodes(cmd.CMD_REMOVE_RGW_CONF_HANDY.format(gateway_hostname))
        # 删除对象网关维护标识，需要主机在线
        if not offline:
            self.exec_remote_ssh_cmd(
                gateway_ip, 'rm -rf /var/lib/ceph/shell/radosgw_maintaining', raise_exc=True)

    def _clear_rgw_graphite_data(self, gateway_hostname, roles=None):
        """
        清理对象网关的graphite数据
        """
        LOG.info('begin clear rgw graphite data for %s...', gateway_hostname)
        if not roles:
            roles = self.get_host_roles_by_name(gateway_hostname)
        if not roles or (not roles['mon'] and not roles['stor']):
            # 删除Handy上graphite目录下该主机的数据
            self.exec_cmd_on_handy_nodes(cmd.CMD_CLEAR_GRAPHITE_HOST.format(gateway_hostname, False))
            self.exec_cmd_on_handy_nodes(
                cmd.CMD_REMOVE_RGW_GRAPHITE.format(gateway_hostname))
            LOG.info("clear rgw graphite in handy all succeed")
        else:
            result = self.exec_cmd_on_handy_nodes(
                cmd.CMD_REMOVE_RGW_GRAPHITE.format(gateway_hostname))
            LOG.info('clear rgw graphite result: %s', result)
