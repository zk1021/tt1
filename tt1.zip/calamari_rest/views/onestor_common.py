﻿# -*- coding:utf-8 -*-
import os
import time
import datetime
import json
import pickle
import logging
import os.path
import threading
import re
import copy
import base64
import subprocess
import configobj
from calamari_rest.decorator2 import retry
from rest_framework.response import Response
from calamari_rest.views.onestor import database
from calamari_rest.views.onestor import onestor
from calamari_rest.views.common.const import *
from calamari_rest.views.common import errno, cmd, const
from calamari_rest.views.ha.ha_db import HandyHADatabase
from dateutil.parser import parse as dateutil_parse
from calamari_rest.views.rpc_view import RPCViewSet
from calamari_common.config import CalamariConfig, ONEStorConfig
from calamari_common.types import MON, ServiceId
from calamari_rest.common import send_request_onestord
# BEGIN ADD BY D10039 2016/04/20 修改为从内存中获取数据
# from onestorcache.socket_client import ONEStorSocketClient
# END ADD BY D10039 2016/04/20
from calamari_common.cmdprocess import command as common_cmd, TimeoutExpired

config = CalamariConfig()
OSD_SHELL_PATH = '/var/lib/ceph/shell'
log = logging.getLogger('django.request')
# add by l11544 通用命令行和命令参数
HOST_IP_COMMAND = "ip addr|grep 'inet ' |grep -v ' lo' |awk '{print $2}' |cut -d / -f 1"
VIEW_PATH = "/opt/h3c/venv/lib/python2.7/site-packages/calamari_rest_api-0.1-py2.7.egg/calamari_rest/views"
# end


class ParameterExecption(Exception):
    """
        Author: dai.xinchun@h3c.com
        Date: 2016/05/12
        Description: ONEStor参数检查异常类
    """

    def __init__(self, errorcode, reason):
        self.errorcode = errorcode
        self.reason = reason

    def __str__(self):
        return repr({'errorcode': self.errorcode, 'reason': self.reason})


class ONEBackupError(Exception):
    """
    请求处理错误类
    """

    def __init__(self, errorcode, reason):
        super(ONEBackupError, self).__init__()
        self.errorcode = errorcode
        self.reason = reason

    def __str__(self):
        return repr({'errorcode': self.errorcode, 'reason': self.reason})


class ONEStorCommon(RPCViewSet, HandyHADatabase):
    # ADD BY D10039 2016/04/20 修改为从内存中获取数据
    def __init__(self, *args, **kwargs):
        super(ONEStorCommon, self).__init__(*args, **kwargs)
        # self.socketClient = ONEStorSocketClient()

    def set_onestor_host(self):
        """
        再同步所有节点上的onestor_hosts
        # add by r13889 2017/03/24 PN:201703160637 modify by kf6615
        """
        log.info('begin sync onestor_hosts...')
        cluster_hosts = self.get_cluster_hosts_from_config()
        nodes = [host[const.HOST_IP] for host in cluster_hosts
                 if self.network_check(host[const.HOST_IP])]
        # 先备份所有节点上原有的onestor_hosts配置文件
        self.multi_thread_task(nodes, cmd.CMD_BACKUP_ONESTOR_HOSTS, ssh=True)
        # 再同步所有节点上的onestor_hosts
        sync_onestor_host = self.multi_thread_task(nodes, cmd.CMD_SCP_ONESTOR_HOSTS, ssh=False)
        log.info('sync onestor_hosts result:\t%s', sync_onestor_host)

    def _get_mon_fqdns(self, fsid):
        servers = self.client.server_list_cluster(fsid)
        # Sort to get most recently contacted server first; drop any for whom
        # last_contact is None
        servers = [s for s in servers if s['last_contact']]
        servers = sorted(servers,
                         key=lambda t: dateutil_parse(t['last_contact']),
                         reverse=True)
        mon_fqdns = []
        for server in servers:
            for service in server['services']:
                service_id = ServiceId(*(service['id']))
                if service['running'] and service_id.service_type == MON and service_id.fsid == fsid:
                    mon_fqdns.append(server['fqdn'])
        log.debug("_get_mon_fqdns: mons for %s are %s", fsid, mon_fqdns)
        return mon_fqdns

    def get_handyha(self):
        """
        获取HandyHA数据
        """
        handy_ips = []
        multi_diamond_host = ''
        handyha = {'handyha': False}
        handyha_config = self.list_handyha()
        if handyha_config['handyha']:
            handyha = handyha_config['handyha'][0]
            handyha['handyha'] = True
            handy_ips.append(handyha['master_public_ip'])
            handy_ips.append(handyha['slave_public_ip'])
            multi_diamond_host = ','.join(handy_ips)
            # 进行一次Base64编码再传输
            multi_diamond_host = base64.b64encode(multi_diamond_host)
        handyha['multi_diamond_host'] = multi_diamond_host
        return handyha

    def get_onestor_hosts_info(self):
        # add by z11524 date:2017/11/16 PN:201711030922
        onestor_hosts_info = self.exec_local_cmd('cat /etc/onestor_hosts')
        onestor_hosts_info = onestor_hosts_info.split('\n')
        ret = {}
        for host_info in onestor_hosts_info:
            if '' != host_info:
                ret[host_info.split(' ')[0]] = host_info.split(' ')[1]
        return ret

    def ntp_in_judge(self):
        """add this function to judge whether the ntp in the cluster or not"""
        try:
            ntp_status = '0'
            cluster_config = self.get_clusterconfig()
            # NTP状态0代表不配置
            # 判断修改NTP是集群内还是集群外
            ntp_status = cluster_config['ntp_close']

            return {'status': 'success', 'ntp_status': ntp_status}
        except ValueError:
            log.error('NTP judge function error')
            return {'status': 'error'}
        except Exception, e:
            log.error(e)
            return {'status': 'error'}

    @staticmethod
    def _set_network_check_command(validate_ips):
        """
        封装网络检查命令
        """
        command = list()
        for ip in validate_ips:
            command.append('ping -c 1 -W 10 {0} 1>/dev/null 2>&1'.format(ip))
        command.append('echo ok')
        return ' && '.join(command)

    def _get_cluster_stor_nodes(self):
        """
        获取集群中的所有存储节点
        """
        stor_nodes = []
        try:
            rack_info = self.exec_local_cmd_json('timeout 30 ceph osd tree -f json')
            for node in rack_info['nodes']:
                if node['type'] == 'host' and (not node['name'].endswith('_ssd')):
                    stor_nodes.append(node['name'])
        except KeyError:
            log.error('_get_cluster_stor_nodes KeyError')
        except Exception, e:
            log.error(e)

        return [self.name_to_ip(node) for node in stor_nodes]

    def _get_cluster_mon_nodes(self):
        """
        获取集群中的所有监控节点
        """
        mon_nodes = []
        try:
            clusterconfig = self.exec_local_cmd_json_v2('timeout 30 ceph config-key get clusterconfig')
            mon_nodes = clusterconfig['mon_ip']
        except KeyError:
            log.error('_get_cluster_mon_nodes KeyError')
        except Exception, e:
            log.error(e)

        return mon_nodes

    def validate_network_with_ping(self, public_ips, cluster_ips):
        """
        通过存储节点来检查所有主机的网络状态
        """
        public_network_error = True
        cluster_network_error = True

        stor_nodes = self._get_cluster_stor_nodes()
        mon_nodes = self._get_cluster_mon_nodes()

        # 没有存储节点时不再进行检查
        if not stor_nodes:
            return True, True

        # 获取不到监控节点直接返回失败
        if not mon_nodes:
            return False, False

        # 从集群中获取第一个存储节点作为检查的发起者
        stor_ip = stor_nodes[0]

        # 检查监控和存储主机上的业务网IP是否连通
        check_public_ips = list(set(stor_nodes + mon_nodes + public_ips))
        check_public_result = self.exec_remote_ssh_cmd(stor_ip, self._set_network_check_command(check_public_ips))
        if isinstance(check_public_result, dict) or 'ok' != check_public_result:
            public_network_error = False

        # 检查存储主机上的存储网IP是否连通
        check_cluster_ips = list(set(stor_nodes + cluster_ips))
        check_cluster_result = self.exec_remote_ssh_cmd(stor_ip, self._set_network_check_command(check_cluster_ips))
        if isinstance(check_cluster_result, dict) or 'ok' != check_cluster_result:
            cluster_network_error = False

        return public_network_error, cluster_network_error

    def test_ping(self, nodes_ip):
        failed_nodes = []
        threads = []
        nloops = range(len(nodes_ip))

        def test(ip):
            # add by l11544 2016/7/1 for onestor_hosts
            node_ip = self.name_to_ip(ip)
            # end by l11544
            # begin modify by d11564 2016/12/26 PN:201612020146 集群部署失败，增加网络ping次数
            if not self.network_check(node_ip):
                failed_nodes.append(ip)

        for _ip in nodes_ip:
            t = threading.Thread(target=test, args=(_ip,))
            threads.append(t)

        for i in nloops:
            threads[i].start()

        for i in nloops:
            threads[i].join()

        return failed_nodes

    def test_ping_single(self, ip):
        ip_exchange = self.name_to_ip(ip)
        # begin modify by d11564 2016/12/26 PN:201612020146 集群部署失败，增加网络ping次数
        if self.network_check(ip_exchange):
            return True
        return False
        # end by d11564 2016/12/26

    @staticmethod
    def get_onestor_progress():
        """
        获取ONEStor页面的进度
        """
        return os.popen(cmd.CMD_GET_ONESTOR_PROGRESS.format(
            const.ONESTOR_PROGRESS_HA_FILE)).read().strip()

    def read_progress(self, filepath, op, task_id=None):
        """
        :param filepath: 操作的的文件路径 '/tmp/.progress_onestor'
        :param op: 操作的op 如：'add_mon'
        :param task_id: 任务id
        :return: {
            'task_exist': True, -- 当前是否存在相同类型的任务
            'current_task': {}, -- 当前执行的任务
            'tasks': [] -- 所有的任务，包括finish的
        }
        """
        has_exists = os.path.exists(filepath)
        tasks_info = {
            'task_exist': False,
            'current_task': {
                'task_id': '',
                'op': op,
                'ctime': '',
                'ftime': '',
                'status': 'processing',
                'errorcode': '',
                'error_reason': ''
            },
            'tasks': []
        }
        # 如果文件中无此任务，初始化并返回
        if not has_exists:
            return tasks_info
        with open(filepath, 'rb') as f:
            # 读取文件中所有的tasks
            tasks_str = f.read()
            if '' == tasks_str:
                return tasks_info
            tasks = json.loads(tasks_str)
            for task in tasks:
                # status为finish时页面的定时检查就会停止，ftime是在当前操作结束后才会写入的
                if op == task['op'] and not (task['status'] == 'finish' and task['ftime']):
                    tasks_info['task_exist'] = True
                    # Handy HA需要从额外的文件中读取进度
                    if const.OP_CREATE_HANDY_HA_CFG == op or const.OP_REMOVE_STOR == op or \
                            const.OP_REMOVE_DISK == op:
                        task['status'] = const.STEP_TIPS_SHOW[self.get_onestor_progress()]
                # 根据task_id匹配任务
                if task_id == task['task_id']:
                    tasks_info['current_task'] = task
            tasks_info['tasks'] = tasks
        return tasks_info

    @staticmethod
    def write_progress(filepath, data):
        """
        :param filepath: 操作的的文件路径 '/tmp/.progress_onestor'
        :param data:[
            {
                'op': const.OP_ADD_MON, #操作的op
                'ctime': ctime,         #操作添加时间
                'ftime': '',            #操作完成时间
                'status': 'processing', #过程状态，未完成此操作时为processing，完成为finish
                'errorcode': '',        #错误信息，报错时的错误信息，正常情况为空
                'error_reason': ''      #错误原因
            }
        ]
        """
        with open(filepath, 'wb') as f:
            f.write(json.dumps(data))

    def _check_last_op_time(self):
        """
        检查上一次操作成功的时间
        :return: None
        """
        checked_op = [
            const.OP_CREATE_HANDY_HA_CFG,
            const.OP_REMOVE_HANDY_HA_CFG
        ]
        last_op_time = self.exec_local_cmd_json(cmd.DB_GET_LAST_OP_TIME)
        # 数据库中没有保存或者没有取到数据则直接返回成功
        if last_op_time is None:
            log.info('last op time is None')
            return
        _last_time = max(last_op_time[_op] for _op in last_op_time if _op in checked_op)
        current_time = time.time()
        log.info('last op time is %s, current time is %s', _last_time, current_time)
        if current_time - _last_time < const.TASK_FREQUENCY_TIME:
            raise errno.ONEStorError(errno.ERR_TASK_FREQUENCY_TIME)

    def update_last_op_time(self, op):
        """
        操作成功时更新最后操作时间到数据库中
        :param op: 操作的op
        :return: None
        """
        last_op_time = self.exec_local_cmd_json(cmd.DB_GET_LAST_OP_TIME)
        if last_op_time is None:
            log.info('last op time is None when update')
            last_op_time = dict()
        # 更新当前时间到数据库
        last_op_time[op] = time.time()
        self.exec_local_cmd(cmd.DB_UPDATE_LAST_OP_TIME.format(json.dumps(last_op_time)))

    def __check_task_frequency(self, op, progress_msg):
        """
        PN: 201706050140 限制HandyHA的操作频率为半小时
        1、当前操作为增删HandyHA
        2、找到所有task status为finish、errorcode为空、op为增删HandyHA的所有任务
        3、得出这些任务中ftime的最大值
        4、获取当前时间，如果小于ftime半小时则抛出异常
        5、防止主备切换后获取不到该文件，需要从ceph中读取该时间
        :param op: 操作的op
        :param progress_msg: 根据task id获取到的任务信息
        :return: None
        """
        checked_op = [
            const.OP_CREATE_HANDY_HA_CFG,
            const.OP_REMOVE_HANDY_HA_CFG
        ]
        # 非HandyHA的操作不做进一步的检查
        if op not in checked_op:
            return
        checked_task = []
        for _task in progress_msg['tasks']:
            if _task['op'] in checked_op and \
                    const.PROGRESS_FINISH == _task['status'] and \
                    not _task['errorcode'] and _task['ftime']:
                checked_task.append(_task)
        if not checked_task:
            # 进一步检查Ceph中保存的最后操作时间
            self._check_last_op_time()
            return
        log.info('checked_task is %s', checked_task)
        # 获取最近一次成功的操作时间
        latest_task_time = max([_task['ftime'] for _task in checked_task])
        latest_task_time_long = time.mktime(
            time.strptime(latest_task_time, '%Y-%m-%d %H:%M:%S'))
        current_time = time.time()
        if current_time - latest_task_time_long < const.TASK_FREQUENCY_TIME:
            raise errno.ONEStorError(errno.ERR_TASK_FREQUENCY_TIME)
        # 进一步检查Ceph中保存的最后操作时间
        self._check_last_op_time()

    def add_onestor_task(self, filepath, op, task_id=None):
        """
        增加一个任务并记录到 /tmp/目录的文件中
        :param filepath: 操作的的文件路径 '/tmp/.progress_onestor'
        :param op: 操作的op 如：'add_mon'
        :return:
        """
        progress_msg = self.read_progress(filepath, op)
        ctime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        msg = {
            'task_id': task_id,
            'op': op,
            'ctime': ctime,
            'ftime': '',
            'status': 'processing',
            'errorcode': '',
            'error_reason': ''
        }
        progress_msg['tasks'].insert(0, msg)
        self.write_progress(filepath, progress_msg['tasks'])
        # PN:201706050140 限制HandyHA的操作频率为半小时
        # self.__check_task_frequency(op, progress_msg)
        if progress_msg['task_exist']:
            raise errno.ONEStorError(errno.ERROR_TASK_EXIST)

    def check_os_version(self, nodes_ip, passwd):
        """

        :param node_ip:主机ip
        :param passwd:密码
        :return:
        """
        for node_ip in nodes_ip:
            handy_os_version = self.exec_local_cmd(const.LIUNX_VERSION)
            handy_os_version_str = handy_os_version.split('#')[1]
            host_os_version = self.cmd_remote(node_ip, passwd, const.LIUNX_VERSION)
            host_os_version_str = host_os_version.split('#')[1]
            if handy_os_version_str != host_os_version_str:
                return False
        return True

    def get_job_result(self, jid, minions):
        count = 0
        timeout_second = 600
        result = 'timeout'
        time.sleep(0.3)
        while count < timeout_second:
            count += 1
            log.debug('[get_job_result] waiting for %s seconds.', count)

            result = self.client.get_job_status(jid, minions)
            if None == result:
                pass
            else:
                if minions[0] in result:
                    result = result[minions[0]]['ret']
                break
        return result

    def get_all_job_result(self, jid, minions):
        count = 0
        max_count = 10
        result = 'timeout'
        while count < max_count:
            time.sleep(0.1)
            count += 1

            result = self.client.get_job_status(jid, minions)
            if None == result or len(result) != len(minions):
                pass
            else:
                break
        return result

    def _onestor_request_result(self, _request):
        count = 0
        max_times = 1200
        result = {'status': 'error', 'error_message': 'timeout'}
        while count < max_times:
            time.sleep(0.05)
            count += 1
            results = self.client.get_request(_request['request_id'])
            if None != results['result']:
                if not results['error']:
                    result = {'status': 'success', 'data': results['result']}
                else:
                    result = {'status': 'error',
                              'error_message': results['error_message']}
                break
        return result

    def _onestor_request_remote(self, fsid, command, params):
        # Execute onestor cpmmand by salt on monitor node
        mon_fqdns = self._get_mon_fqdns(fsid)

        for mon_fqdn in mon_fqdns:
            _request = self.client.run_onestor_request(
                mon_fqdn, command, params)

            results = self._onestor_request_result(_request)

            if 'success' == results['status']:
                log.debug("[ONEStor] request from %s, %s, %s, %s", mon_fqdn, command, params, results['data'])
                return results['data']
            else:
                log.error("[ONEStor] Failed to request from %s, %s, %s, %s", mon_fqdn, command, params,
                          results['error_message'])

        return None

    def onestor_request(self, fsid, command, params):

        try:
            request_start_time = time.time()
            # Execute onestor command on Handy node
            results = eval(command)(
                *[eval(repr(item)[1:]) if isinstance(item, unicode) else item for item in params])
            log.debug("[ONEStor] request %s %s cost %s s.", command, params, time.time() - request_start_time)

            if results:
                if isinstance(results, dict) and 'reason' in results \
                        and (-1 != results['reason'].find('No JSON object could be decoded')
                             or -1 != results['reason'].find('error calling conf_read_file')):
                    return self._onestor_request_remote(fsid, command, params)
                else:
                    return results

        except Exception, e:
            log.error('[ONEStor] onestor_request exception %s.', e)
            return self._onestor_request_remote(fsid, command, params)

    def onestor_request_node(self, fqdn, command, params):
        try:
            _request = self.client.run_onestor_request(fqdn, command, params)

            results = self._onestor_request_result(_request)

            if 'success' == results['status']:
                log.debug("[ONEStor] [Request Node] Request from %s, %s, %s, %s", fqdn, command, params,
                          results['data'])
                return results['data']
            else:
                log.error("[ONEStor] [Request Node] Failed to request from %s, %s, %s, %s", fqdn, command, params,
                          results['error_message'])

            return None
        except Exception, e:
            log.error('[ONEStor] onestor_request_node execute exception %s.', e)
            return None

    # 配置免密失败单独处理,分为未配置免密和免密配置成功
    def hosts_back(self, ssh_permission, mon_nodes):
        if 'ssh' == ssh_permission:
            command = 'timeout 10 ssh $$ mv /etc/hosts_bk /etc/hosts 2>/dev/null && echo ok'
            self.exec_local_ssh_cmd('mv /etc/hosts_bk /etc/hosts 2>/dev/null')
            # 对于非Handy的监控节点
            handy_name = self.exec_local_cmd('hostname')
            handy_ip = self.name_to_ip(handy_name)
            if handy_name in mon_nodes:
                mon_nodes.remove(handy_name)
            if handy_ip in mon_nodes:
                mon_nodes.remove(handy_ip)
            host_mv_result = self.multi_thread_task(mon_nodes, command)
            for mon_node in mon_nodes:
                if 'ok' != host_mv_result[mon_node]:
                    log.error('[hosts_back] get back %s hosts file failed', mon_node)

    def onestor_request_node_ssh(self, fqdn, command, *params):
        try:
            # add by l11544 2016/7/1 for onestor_hosts
            node_ip = self.name_to_ip(fqdn)
            # end by l11544

            # begin modify by d11564 2016/12/26 PN:201612020146 集群部署失败，增加网络ping次数
            if not self.network_check(node_ip, 2):
                log.error(
                    '[ONEStor] onestor_request_node_ssh %s:Host is unreachable', fqdn)
                return {'status': 'error', 'reason': 'Host is unreachable'}

            # update by z11524 date:2017/9/25 PN:201709140342
            ssh_command = 'ssh %s timeout 12000 /opt/h3c/bin/python %s/onestor.py %s %s' % (
                node_ip, OSD_SHELL_PATH, command, ' '.join([str(param) for param in params]))
            log.info('onestor_request_node_ssh: %s', ssh_command)

            result = self.exec_local_cmd(ssh_command)

            if -1 != result.find('success'):
                return {'status': 'success'}

            return {'status': 'error', 'reason': result}
        except Exception, e:
            log.error(e)
            return {'status': 'error', 'reason': e}

    def network_check(self, node, retry_times=5):
        """
        :des: 检查目标节点的网络是否故障
        :author: dai.xinchun@h3c.com
        :date: 2016/05/12
        :param node: 主机名称或IP
        :return: True——正常 False——异常
        """
        node_ip = self.name_to_ip(node)
        if node_ip is None:
            log.warn('<network_check> node_ip is None')
            return True
        times = 0
        while times < retry_times:
            test_ping = self.exec_local_cmd(
                'ping -c 1 -W 3 %s 1>/dev/null 2>&1 && echo ok' % node_ip)
            if 'ok' == test_ping:
                return True
            log.error('<network_check> Host "%s" is unreachable, retry again...', node_ip)
            times += 1
        return False

    @staticmethod
    def _get_useful_gateway():
        """
            Author: dai.xinchun@h3c.com
            Date: 2016/05/12
            Description: 获取可用的对象网关
        """
        gateway_list = database.list_objs('gateway')
        if not gateway_list:
            return None

        for gateway in gateway_list['gateway']:
            # 通过curl测试对象网关状态是否正常
            curl_ret = os.popen('curl --connect-timeout 2 --max-time 2 %s' % gateway['hostip']).read()
            if -1 != curl_ret.find('<?xml version="1.0" encoding="UTF-8"?>'):
                # 获取对象网关客户端名称
                client_name = 'client.radosgw.%s' % gateway['hostname']
                # 获取对象网关IP地址，需要去掉后边的端口号
                gateway_ip = gateway['hostip'].split(':')[0]
                # 获取对象网关认证地址（带端口号）
                gateway_auth_url = gateway['hostip']

                return {"client_name": client_name, "gateway_ip": gateway_ip, "gateway_auth_url": gateway_auth_url}

        return None

    @staticmethod
    def _pickle_loads(data):
        """
            Author: dai.xinchun@h3c.com
            Date: 2016/05/12
            Description: 对数据进行反序列化
        """
        if 'NETWORK_FAULT' == data:
            return u'对象网关节点网络故障'
        elif '' == data:
            return u'无法获取响应数据'

        try:
            return pickle.loads(data)
        except KeyError:
            return data
        except Exception, e:
            log.error('[RadosgwKeyViewSet] <_pickle_loads> %s', e)
            return data

    def onestor_request_rgw_ssh(self, fqdn, command, *params):
        """
        :des: 通过SSH请求rgw的方法
        :author: dai.xinchun@h3c.com
        :date: 2016/05/12
        :param fqdn: 主机名
        :param command: 方法名
        :param params: 方法的参数，可以传入任意个
        :return: 请求结果
        """
        if not self.network_check(fqdn, 2):
            return 'NETWORK_FAULT'

        return self.exec_local_cmd('ssh %s timeout 60 /opt/h3c/bin/python %s/radosgw_remote_api.py %s %s' % (
            fqdn, OSD_SHELL_PATH, command, ' '.join([str(param) for param in params])))

    def onestor_request_all_node(self, command, *params, **kwargs):
        nodes = []

        collect_type = ''
        if 'collect_system_log' == command:
            collect_type = ' '.join([str(param) for param in params])

        if 'collect_system_log' == command and 'bad' == collect_type:
            cluster_config = self.get_config_from_conf_file()
            nodes = cluster_config['mon_fqdns']
        else:
            rack_info = json.loads(
                self.exec_local_cmd('ceph osd tree -f json'))
            for node in rack_info['nodes']:
                if node['type'] == 'host':
                    node_name = node['name'].split('.')[0]
                    if node_name not in nodes:
                        nodes.append(node_name)
            try:
                cluster_config = self.get_config_from_conf_file()
                mon_fqdns = cluster_config['mon_fqdns']
                for mon in mon_fqdns:
                    if mon not in nodes:
                        nodes.append(mon)
            except Exception, e:
                log.error(e)
            if 'collect_system_log' == command:
                # add by zkf6615 for nas 添加mds和nas节点
                nas_mds_all = os.popen('ceph config-key get nas_server_new').read().strip()
                if '' != nas_mds_all:
                    nas_mds_json = json.loads(nas_mds_all)
                    nas_mds_result = nas_mds_json['nas_server_new']
                    for nas_mds in nas_mds_result:
                        if nas_mds['hostname'] not in nodes:
                            nodes.append(nas_mds['hostname'])

                # 添加gateway节点
                nas_gateway_all = os.popen('ceph config-key get gateway').read().strip()
                if '' != nas_gateway_all:
                    nas_geteway_json = json.loads(nas_gateway_all)
                    nas_gateway_result = nas_geteway_json['gateway']
                    for gateway in nas_gateway_result:
                        if gateway['hostname'] not in nodes:
                            nodes.append(gateway['hostname'])
                            # end by zkf6615

        fail_results = {'nodes': [], 'reason': []}
        success_nodes = []
        return_results = []
        threads = []
        if 'server_list' in kwargs:
            nodes = kwargs['server_list']
        nloops = range(len(nodes))

        def execute(node):
            node_ip = self.name_to_ip(node)
            # begin modify by d11564 2016/12/26 PN:201612020146 集群部署失败，增加网络ping次数
            if not self.network_check(node_ip, 2):
                fail_results['nodes'].append(node)
                fail_results['reason'].append('Host is unreachable')
                log.error(
                    '[ONEStor] onestor_request_all_node %s:Host is unreachable', node)
            else:
                if 'ONESTOR_TOPO_INFO' == command:
                    ret = self.exec_remote_ssh_cmd(
                        node_ip, '/opt/h3c/bin/python %s/server.py topo' % OSD_SHELL_PATH)
                    return_results.append({node: json.loads(ret)})
                elif 'ONESTOR_HOST_INFO' == command:
                    ret = self.exec_remote_ssh_cmd(node_ip, '/opt/h3c/bin/python %s/server.py host_info %s' % (
                        OSD_SHELL_PATH, ' '.join([str(param) for param in params])))
                    return_results.append({node: json.loads(ret)})
                else:
                    _timeout = 600
                    if 'collect_system_log' == command:
                        _timeout = 24 * 60 * 60
                    ret = self.exec_local_cmd('timeout %s ssh %s timeout %s /opt/h3c/bin/python %s/onestor.py %s %s' % (
                        _timeout, node_ip, _timeout, OSD_SHELL_PATH, command, ' '.join([str(param) for param in params])))
                    if 'success' != ret:
                        fail_results['nodes'].append(node)
                        fail_results['reason'].append(ret)
                    else:
                        success_nodes.append(node)

        for node in nodes:
            t = threading.Thread(target=execute, args=(node,))
            threads.append(t)

        for i in nloops:
            threads[i].start()

        for i in nloops:
            threads[i].join()

        if 'ONESTOR_TOPO_INFO' == command or 'ONESTOR_HOST_INFO' == command:
            return return_results

        if 0 != len(fail_results['nodes']):
            log.info('command: %s, result: %s', command, fail_results)
            return {
                'success': False,
                'success_nodes': success_nodes,
                'nodes': ','.join([str(node) for node in fail_results['nodes']]),
                'error': fail_results['reason'],
                'all': True if len(fail_results['nodes']) == len(nodes) else False
            }

        return {'success': True, 'success_nodes': success_nodes}

    def onestor_all_topo_info(self):
        return self.onestor_request_all_node('ONESTOR_TOPO_INFO')

    def onestor_all_host_info(self, auto_reload):
        return self.onestor_request_all_node('ONESTOR_HOST_INFO', auto_reload)

    def saveOperationLogRPC(self, fsid, params):
        results = self.onestor_request(fsid, 'database.add_obj', [
            'operationlog', params])

        if None != results:
            return results

        return []

    def addOperationlog(self, fsid, request, content, result, network_fault=False, model=None):
        try:
            user = str(request.user).replace('AnonymousUser', '匿名用户')
            ip = request.META.get("REMOTE_ADDR", None)
            _time = self._get_current_time_cst('ms')
            status = result if (isinstance(result, str) or isinstance(result, unicode)) else (
                'success' if 'success' == result['status'] else result['reason'])

            # BEGIN ADD BY D10039 2016/09/05 如果操作日志为全英文的，提示用户查看后台日志
            if not isinstance(status, unicode):
                status = status.decode('utf8')

            if 'success' != status and not re.match(ur".*[\u4e00-\u9fa5]+.*", status):
                log.error('%s:%s', content, status)
                status = u'操作失败，详见后台日志'
            # END ADD BY D10039 2016/09/05

            if not network_fault:
                if os.path.exists('/tmp/.network_error') and model == 'guide':
                    return
                elif os.path.exists('/tmp/.nasnet_error') and model == 'nas':
                    return
                elif os.path.exists('/tmp/.mdsnet_error') and model == 'mds':
                    return
                elif os.path.exists('/tmp/.nasarrnet_error') and model == 'nasArr':
                    return
                elif os.path.exists('/tmp/.filesysnet_error') and model == 'filesys':
                    return
            params = [user, ip, _time, content, status]

            return self.saveOperationLogRPC(fsid, params)
        except Exception:
            log.error('[ONEStor] add operation log to db meet error.', exc_info=True)

    @staticmethod
    def exec_local_cmd(command):
        log.debug('exec_local_cmd: %s', command)
        filepath = '/opt/h3c/cmd/'
        _result = os.popen("%s./run %s" % (filepath, command)).read().rstrip()
        return _result

    @staticmethod
    def exec_local_ssh_cmd(command):
        filepath = '/opt/h3c/cmd/'
        _result = os.popen("%s./run ssh localhost timeout 12000 '%s'" %
                           (filepath, command)).read().rstrip()
        return _result

    def exec_remote_cmd(self, filepath, node, default_user, default_passwd, command):
        # add by l11544 2016/7/1 for onestor_hosts
        ip_exchange = self.name_to_ip(node)
        # end by l11544
        _result = self.exec_local_cmd("/opt/h3c/bin/python %s/handy_common.py exec_remote_cmd %s %s \"%s\" \"%s\"" %
                           (filepath, ip_exchange, default_user, default_passwd, command))
        log.info('exec_remote_cmd:%s --> %s', command, _result)
        return _result

    def exec_remote_ssh_cmd(self, osd_node, command, raise_exc=False, use_string=True):
        # add by l11544 2016/7/1 for onestor_hosts
        osd_ip = self.name_to_ip(osd_node)
        # begin modify by d11564 2016/12/26 PN:201612020146 集群部署失败，增加网络ping次数
        if not self.network_check(osd_ip, 2):
            log.error(
                '[ONEStor] exec_remote_ssh_cmd %s:Host is unreachable', osd_node)
            if raise_exc:
                raise errno.ONEStorError(errno.ERROR_NETWORK_FAULT, osd_ip)
            else:
                return {'status': 'error', 'reason': 'Host is unreachable'}

        # 不记录日志的关键字，如果匹配上了则不记录到日志文件中
        except_logs = [
            '/opt/h3c/bin/python /var/lib/ceph/shell/server.py host_info',
            '/opt/h3c/bin/python /var/lib/ceph/shell/osd-status.py'
        ]
        if 0 == len([except_log for except_log in except_logs if -1 != command.find(except_log)]):
            log.info("[ONEStor] exec_remote_ssh_cmd node is '%s', command is '%s'", osd_node, command)

        filepath = '/opt/h3c/cmd/'
        if use_string:
            _result = os.popen("timeout 12000 %s./run ssh %s '%s'" % (
                filepath, osd_ip, command)).read().rstrip()
        else:
            _result = os.popen("timeout 12000 %s./run ssh %s %s" % (
                filepath, osd_ip, command)).read().rstrip()
        return _result

    def reset_diamond_config(self, node_name):
        """
        ADD BY R13889 2017/03/24 PN:201703160637
        作为最后一个角色时还原diamond数据
        :param node_name:需要还原配置的节点名称
        """
        self.exec_remote_ssh_cmd(node_name, '/opt/h3c/bin/python /var/lib/ceph/shell/reset_diamond.py')

    # 将主机名转化为IP
    def name_to_ip(self, node):
        node_ip = node
        reip = re.compile(r'(?<![\.\d])(?:\d{1,3}\.){3}\d{1,3}(?![\.\d])')
        node_result = reip.findall(str(node))
        if len(node_result) == 0:
            ips = os.popen('cat /etc/onestor_hosts').read().strip().split('\n')
            node_ip = self._find_ip_by_name(ips, node)
        return node_ip

    @staticmethod
    def ip_to_name(node_ip):
        """
        将IP转化为主机名
        :param node_ip: 主机IP
        :return: 主机名称
        """
        with open('/etc/onestor_hosts', 'rb') as fr:
            node_name = [line.split()[1] for line in fr.readlines() if node_ip == line.split()[0]]
            return node_ip if 0 == len(node_name) else node_name[0]

    @retry(times=3)
    def exec_local_cmd_json(self, command):
        filepath = '/opt/h3c/cmd/'
        try:
            _result = os.popen("timeout 30 %s./run %s" %
                               (filepath, command)).read().rstrip()
            return json.loads(_result)
        except Exception, e:
            log.warn(
                '[ONEStor] exec_local_cmd_json "%s" returned can not json loads. %s', command, e)
            raise e

    @retry(times=3, raise_exc=True)
    def exec_local_cmd_json_v2(self, command):
        try:
            filepath = '/opt/h3c/cmd/'
            _result = os.popen("timeout 30 %s./run %s" %
                               (filepath, command)).read().rstrip()
            return json.loads(_result)
        except Exception, e:
            log.warn(
                '[ONEStor] exec_local_cmd_json "%s" returned can not json loads. %s', command, e)
            raise e

    def __get_exclude_host_name(self, exclude_roles):
        """
        获取需要排除的主机名列表
        :param exclude_roles ['stor', 'rgw', 'handy', 'mon', 'nas', 'mds']
        :return ['node1', 'node2']
        """
        if exclude_roles is None:
            return []

        exclude_hosts = []
        for role in exclude_roles:
            if ROLE_HANDY == role:
                exclude_hosts.append(self.exec_local_cmd(HOST_NAME))
            elif ROLE_STOR == role:
                osd_tree = self.exec_local_cmd_json('timeout 30 ceph osd tree -f json')
                exclude_hosts.extend(
                    [node['name'] for node in osd_tree['nodes'] if 'host' == node['type']])
            elif ROLE_MON == role:
                clusterconfig = self.exec_local_cmd_json(
                    'timeout 30 ceph config-key get clusterconfig')
                mons = clusterconfig['mon_fqdns']
                exclude_hosts.extend(mons)
            elif ROLE_RGW == role:
                gateways = database.list_objs('gateway')['gateway']
                exclude_hosts.extend([rgw[HOST_NAME] for rgw in gateways])
            elif ROLE_NAS == role:
                fs_servers = database.list_objs('nas_server_new')['nas_server_new']
                exclude_hosts.extend([server[HOST_NAME] for server in fs_servers if 'NAS' == server['use']])
            elif ROLE_MDS == role:
                fs_servers = database.list_objs('nas_server_new')['nas_server_new']
                exclude_hosts.extend([server[HOST_NAME] for server in fs_servers if 'MDS' == server['use']])
        return list(set(exclude_hosts))

    def get_cluster_hosts_from_config(self, exclude_roles=None):
        """
        从onestor_hosts文件中获取集群中所有的主机
        :param exclude_roles 需要排除的角色 ['stor', 'rgw', 'handy', 'mon', 'nas', 'mds']
        """
        with open(ONESTOR_HOSTS, 'rb') as f:
            hosts = f.readlines()
            # 集群所有的主机IP
            cluster_host_ip = [s.strip().split(' ')[0] for s in hosts if -1 == s.find(LOCALHOST)]
            # 集群所有的主机名
            cluster_host_name = [s.strip().split(' ')[1] for s in hosts if -1 == s.find(LOCALHOST)]
            # 封装为[{"hostname": "cvknode110", "hostip": "172.16.30.110"}, xxx]的形式
            cluster_hosts = []
            # 获取需要排除的主机名
            exclude_hosts = self.__get_exclude_host_name(exclude_roles)
            for index, ip in enumerate(cluster_host_ip):
                if cluster_host_name[index] not in exclude_hosts:
                    cluster_hosts.append({
                        HOST_NAME: cluster_host_name[index],
                        HOST_IP: ip
                    })
            return cluster_hosts

    @staticmethod
    def get_config_from_conf_file():
        cluster_config = {}
        onestor_config = ONEStorConfig()
        mons = onestor_config.get('global', 'mon_initial_members')
        mons_ip = onestor_config.get('global', 'mon_host')
        public_network = onestor_config.get('global', 'public_network')
        cluster_network = onestor_config.get('global', 'cluster_network')
        # journal_size = onestor_config.get('global', 'osd_journal_size')
        # flashcache_size = onestor_config.get('global', 'osd_flashcache_size')
        mon_fqdns = []
        for mon in mons.split(','):
            mon_fqdns.append(mon.strip())

        mon_ips = []
        for ip in mons_ip.split(','):
            mon_ips.append(ip.strip())

        if onestor_config.has_option('global', 'manage_network'):
            manage_network = onestor_config.get('global', 'manage_network')
            cluster_config['manage_network'] = manage_network
        if onestor_config.has_option('global', 'disaster_network'):
            disaster_network = onestor_config.get('global', 'disaster_network')
            cluster_config['disaster_network'] = disaster_network
        cluster_config['public_network'] = public_network
        cluster_config['cluster_network'] = cluster_network
        cluster_config['mon_fqdns'] = mon_fqdns
        cluster_config['mon_ip'] = mon_ips
        # cluster_config['journal_size'] = journal_size
        # cluster_config['flashcache_size'] = flashcache_size

        return cluster_config

    def get_clusterconfig(self):
        try:
            result = common_cmd('ceph config-key get clusterconfig', 30, True)
            if result['stdout'] != '':
                return json.loads(result['stdout'])

            return self.get_config_from_conf_file()
        except IOError:
            return self.get_config_from_conf_file()
        except Exception, e:
            log.error('get clusterconfig from cluster failed , %s', e)
            return self.get_config_from_conf_file()

    def is_handy_in_mon(self):
        cluster_config = self.get_clusterconfig()
        mon_fqdns = cluster_config['mon_fqdns']
        handy_name = os.popen('hostname').read().rstrip()
        if handy_name in mon_fqdns:
            return True
        else:
            return False

    def multi_thread_task(self, nodes, command, ssh=False, remote_passwd=None, user='root', ip_cache_map=None,
                          use_string=True):
        results = {}
        threads = []
        nloops = range(len(nodes))

        except_logs = [
            '/opt/h3c/bin/python /var/lib/ceph/shell/server.py host_info',
            '/opt/h3c/bin/python /var/lib/ceph/shell/osd-status.py',
            '/opt/h3c/bin/python /var/lib/ceph/shell/list_ha.py'
        ]
        if 0 == len([except_log for except_log in except_logs if -1 != command.find(except_log)]):
            log.info("[ONEStor] multi_thread_task nodes is '%s', command is '%s', ip_cache_map is '%s'",
                     nodes, command, ip_cache_map)

        def execute(node):
            # command示例 scp $$:/tmp/$$.tar.gz /tmp/onestor/ 会把$$替换为node名称
            node_ip = self.name_to_ip(node)

            # 先检查node节点是否能ping通
            if not self.network_check(node_ip, 2):
                results[node] = 'NETWORK_FAULT'
            else:
                # 日志收集时只能匹配主机名，将##替换为主机名
                node_command = command.replace("##", node).replace("$$", node_ip)
                pw_command = command
                # BEGIN ADD BY C13463 传入journal_size，flashcache_size 参数
                if ip_cache_map is not None and node_ip in ip_cache_map:
                    cache_command = " %d %d" % (
                        ip_cache_map[node_ip]['journal_size'], ip_cache_map[node_ip]['flashcache_size'])
                    node_command += cache_command
                    pw_command += cache_command
                # END ADD BY C13463
                # 使用密码远程登录执行命令 add by l11544 2017/2/17
                if None == remote_passwd:
                    result = self.exec_remote_ssh_cmd(node_ip, node_command, use_string=use_string) \
                        if ssh else self.exec_local_cmd(node_command)
                else:
                    result = os.popen("/opt/h3c/bin/python %s/handy_common.py exec_remote_cmd %s %s \"%s\" \"%s\"" % (
                        VIEW_PATH, node_ip, user, remote_passwd, pw_command)).read().strip()
                    log.info("[ONEStor] multi_thread_task exec_remote_cmd result is {0}".format(result))
                results[node] = result
                # end by l11544

        for _node in nodes:
            t = threading.Thread(target=execute, args=(_node,))
            threads.append(t)

        for i in nloops:
            threads[i].start()

        for i in nloops:
            threads[i].join()

        log.info('multi_thread_task result: %s', results)
        return results

    def sub_multi_thread_task(self, nodes, command):
        """
        subprocess多线程执行
        # add by z11524 2017/8/10 PN:201707280462
        """
        results = {}
        threads = []
        nloops = range(len(nodes))

        def execute(node):
            node_ip = self.name_to_ip(node)
            ssh_command = command.replace('$$', node_ip)
            p = subprocess.Popen('/opt/h3c/cmd/./run ssh -q %s "%s"' % (node_ip, ssh_command), shell=True,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = p.communicate()
            status = p.returncode
            results[node] = {
                'out': stdout.rstrip(),
                'err': stderr.rstrip(),
                'status': status
            }

        for node in nodes:
            t = threading.Thread(target=execute, args=(node,))
            threads.append(t)
            t.start()

        for i in nloops:
            threads[i].join()
        return results

    def ntp_multi_thread_task(self, nodes, command):
        results = {}
        threads = []
        nloops = range(len(nodes))

        def execute(node):
            node_ip = self.name_to_ip(node)
            ntp_command = command.replace('$$', node_ip)
            result_temp = subprocess.Popen('/opt/h3c/cmd/./run %s' % ntp_command, shell=True,
                                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            results[node] = 'ok'

        for node in nodes:
            t = threading.Thread(target=execute, args=(node,))
            threads.append(t)
            t.start()

        for i in nloops:
            threads[i].join()
        return results

    def _get_handy_public_ip(self):
        filepath = os.path.split(os.path.realpath(__file__))[0]
        cluster_config = self.get_clusterconfig()
        public_network = cluster_config['public_network']

        public_ip = os.popen('/opt/h3c/bin/python %s/handy_common.py getHandyPublicIP %s' %
                             (filepath, public_network)).read().rstrip()
        return public_ip

    def _get_current_time_cst(self, unit):
        date_info = self.exec_local_ssh_cmd("date -R")
        zone_info = date_info.split(' ')[5]

        log.debug('[ONEStor] get current time cst, zone is: %s', zone_info)

        where = zone_info[0]
        diff = int(zone_info[1:3])

        multiple = 1000 if 'ms' == unit else 1
        current_time = int(time.time() * multiple)
        ratio = 1 if '+' == where else -1

        diff_hour = diff * ratio - 8
        current_time_cst = current_time + (diff_hour * 60 * 60 * multiple)
        return current_time_cst

    @staticmethod
    def _get_time_zone_diff():
        apache_date = os.popen('date -R').read().strip()
        apache_zone = apache_date.split(' ')[5]

        log.debug('[ONEStor] get current time zone diff, zone is: %s', apache_zone)

        where = apache_zone[0]
        diff = int(apache_zone[1:3])

        ratio = 1 if '+' == where else -1
        diff_hour = diff * ratio - 8

        return diff_hour

    def _get_current_time_from_apache(self, _format, diff_hour=None):
        if None == diff_hour:
            diff_hour = self._get_time_zone_diff()

        now = self._get_current_time_cst('second') - (diff_hour * 60 * 60)
        time_array = time.localtime(now)

        return time.strftime(_format, time_array)

    def realserver_ha_hosts(self, ha_switch, _type, hostip):
        """
        多节点检查
        """
        try:
            ha_all_hosts = []
            ha_hosts = []
            date_base_list = self.exec_local_cmd_json_v2('ceph config-key list')
            if 'highavailableconfig' not in date_base_list:
                return
            highavailableconfig = self.exec_local_cmd_json('ceph config-key get highavailableconfig') \
                ['highavailableconfig']
            for ha_cfg in highavailableconfig:
                if ha_switch == ha_cfg['ha_switch'] and ha_cfg['balance_switch'] == '1':
                    ha_all_hosts = ha_all_hosts + [ha_cfg['master']] + ha_cfg['slave'].split(',')

            for host in ha_all_hosts:
                if host not in ha_hosts:
                    ha_hosts.append(host)

            if len(ha_hosts) != 0:
                threads = []
                nloops = range(len(ha_hosts))

                def execute(host):
                    """
                    单节点执行
                    """
                    command = 'timeout 300 /opt/h3c/bin/python /var/lib/ceph/shell/realserver.py %s %s %s' \
                              % (ha_switch, _type, hostip)
                    self.exec_remote_ssh_cmd(host, command)

                for host in ha_hosts:
                    t = threading.Thread(target=execute, args=(host,))
                    threads.append(t)

                for i in nloops:
                    threads[i].start()

                for i in nloops:
                    threads[i].join()

            return True

        except ValueError:
            return False
        except Exception, e:
            log.error('[ONEStor] [get_ha_hosts] %s', e)
            return False

    def remove_realserver(self, host, del_role):
        """
        删除realserver
        """
        date_base_list = self.exec_local_cmd_json_v2('ceph config-key list')
        if 'highavailableconfig' not in date_base_list:
            return
        my_role = self.get_host_roles_by_name(host)
        if my_role == None:
            role = False
        elif del_role == '1':
            role = my_role['rgw']
        else:
            role = my_role['mon'] or my_role['stor']

        ha_list = self.exec_local_cmd_json('ceph config-key get highavailableconfig') \
            ['highavailableconfig']
        switch_arp = '2'
        for ha in ha_list:
            if '1' == ha['balance_switch'] and del_role != ha['ha_switch'] and role:
                switch_arp = '0'
                break

        ha_list = self.exec_local_cmd_json('ceph config-key get highavailableconfig') \
            ['highavailableconfig']
        for ha in ha_list:
            if '1' == ha['balance_switch'] and del_role == ha['ha_switch']:
                vip = ha['vip']
                vrid = ha['vrid']
                command = 'timeout 300 /opt/h3c/bin/python %s/config_realserver.py del %s %s %s' % (
                    HANDY_SHELL_PATH, vip, vrid, switch_arp)
                self.exec_remote_ssh_cmd(host, command)

    def add_realserver(self, host, role):
        """
        添加realserver
        """
        date_base_list = self.exec_local_cmd_json_v2('ceph config-key list')
        if 'highavailableconfig' not in date_base_list:
            return
        ha_list = self.exec_local_cmd_json('ceph config-key get highavailableconfig') \
            ['highavailableconfig']
        switch_arp = '1'
        for ha in ha_list:
            if '1' == ha['balance_switch'] and role == ha['ha_switch']:
                vip = ha['vip']
                vrid = ha['vrid']
                command = 'timeout 300 /opt/h3c/bin/python %s/config_realserver.py add %s %s %s' % (
                    HANDY_SHELL_PATH, vip, vrid, switch_arp)
                self.exec_remote_ssh_cmd(host, command)

    def command_all_nodes(self, ha_switch, command, *args):
        """
        在所有主机上执行命令
        """
        try:
            command = command + ' ' + ' '.join(['%s' % arg for arg in args])
            threads = []
            node_list = []
            if ha_switch == '1':
                node_list = self._get_mon_stor()
            else:
                gateways = database.list_objs('gateway')['gateway']
                for gateway in gateways:
                    node_list.append(gateway['hostname'])

            nloops = range(len(node_list))

            def do_command(host):
                """
                在主机上执行命令
                """
                self.exec_remote_ssh_cmd(host, command)

            for host in node_list:
                t = threading.Thread(target=do_command, args=(host,))
                threads.append(t)

            for i in nloops:
                threads[i].start()

            for i in nloops:
                threads[i].join()

            return True

        except IOError:
            pass
        except:
            return False

    def handle_validate_bucket(self, name):
        """
        ADD BY D10039 2016/09/27
        校验待创建的crush bucket名称是否已经被使用
        """
        forbidden_name = ['default', 'ssd_root', 'maintain']
        if name in forbidden_name:
            return False

        osd_tree = self.exec_local_cmd_json('ceph osd tree -f json')

        if osd_tree is None:
            return None

        if 0 == len([node['name'] for node in osd_tree['nodes'] if name == node['name']]):
            return True

        return False

    def get_all_nodes(self, clusterconfig=None):
        hosts = {'host_ip': [], 'host_name': []}
        if not clusterconfig:
            clusterconfig = self.exec_local_cmd_json('timeout 30 ceph config-key get cluster_hosts')
            for host in clusterconfig:
                hosts['host_ip'].append(host['hostip'])
                hosts['host_name'].append(host['hostname'])
        return hosts

    @staticmethod
    def subnet_judge(subnet, ip):
        subnet_len = int(subnet.split('/')[1])
        all_sub_single_ip = subnet.split('/')[0].split('.')
        first_sub_ip_bin = str(bin(int(all_sub_single_ip[0]))).split('0b')[
            1].zfill(8)
        second_sub_ip_bin = str(bin(int(all_sub_single_ip[1]))).split('0b')[
            1].zfill(8)
        third_sub_ip_bin = str(bin(int(all_sub_single_ip[2]))).split('0b')[
            1].zfill(8)
        fourth_sub_ip_bin = str(bin(int(all_sub_single_ip[3]))).split('0b')[
            1].zfill(8)

        all_single_ip = ip.split('.')
        first_ip_bin = str(bin(int(all_single_ip[0]))).split('0b')[1].zfill(8)
        second_ip_bin = str(bin(int(all_single_ip[1]))).split('0b')[1].zfill(8)
        third_ip_bin = str(bin(int(all_single_ip[2]))).split('0b')[1].zfill(8)
        fourth_ip_bin = str(bin(int(all_single_ip[3]))).split('0b')[1].zfill(8)

        bin_subnet = first_sub_ip_bin + second_sub_ip_bin + third_sub_ip_bin + fourth_sub_ip_bin
        bin_ip = first_ip_bin + second_ip_bin + third_ip_bin + fourth_ip_bin

        subnet_mask = bin_subnet[0:subnet_len]
        if bin_ip[0:subnet_len] == subnet_mask:
            return True
        else:
            return False

    def _get_mon_stor(self):
        """
        获取监控存储节点
        :return:
        """
        nodes = []

        # 获取存储节点
        try:
            rack_info = json.loads(
                self.exec_local_cmd('ceph osd tree -f json'))
            for node in rack_info['nodes']:
                if node['type'] == 'host' and (not node['name'].endswith('_ssd')):
                    nodes.append(node['name'])
        except ValueError, e:
            log.error(e)
        except Exception, e:
            log.error(e)

        # 获取监控节点
        try:
            cluster_config = self.get_clusterconfig()
            mon_fqdns = cluster_config['mon_fqdns']

            for mon in mon_fqdns:
                if mon not in nodes:
                    nodes.append(mon)
        except ValueError, e:
            log.error(e)
        except Exception, e:
            log.error(e)

        return nodes

    def _server_list_all(self, need_handy_self=False, need_handyha=False):
        """
        获取存储监控handy节点
        :param need_handy_self:
        :return:
        """
        all_nodes_info = []
        nodes = []
        stors = []
        # 获取存储节点
        try:
            rack_info = json.loads(
                self.exec_local_cmd('ceph osd tree -f json'))
            for node in rack_info['nodes']:
                if node['type'] == 'host':
                    nodes.append(node['name'].split('.')[0])
                    stors.append(node['name'].split('.')[0])
            nodes = list(set(nodes))
            stors = list(set(stors))
        except ValueError, e:
            log.error(e)
        except Exception, e:
            log.error(e)

        # 获取监控节点
        try:
            cluster_config = self.get_clusterconfig()
            mon_fqdns = cluster_config['mon_fqdns']

            for mon in mon_fqdns:
                if mon not in nodes:
                    nodes.append(mon)
        except ValueError, e:
            log.error(e)
        except Exception, e:
            log.error(e)

        # BEGIN ADD BY KF6602 2016/7/25 PN:201607210440 如果是对象网关页面，还需要增加Handy本身到列表中
        if need_handy_self:
            handy_name = self.exec_local_cmd('hostname')
            if handy_name not in nodes:
                nodes.append(handy_name)
        # END ADD BY KF6602 2016/7/25 PN:201607210440

        # BEGIN ADD BY KF6602 2016/11/11 PN:201611050117
        if need_handyha:
            handyha = self.list_handyha()['handyha']
            if handyha:
                # modify by z11524 PN:201703200020
                handyha_slave_ip = handyha[0]['slave_public_ip']
                handyha_slave_name = self.ip_to_name(handyha_slave_ip)
                handyha_master_ip = handyha[0]['master_public_ip']
                handyha_master_name = self.ip_to_name(handyha_master_ip)
                if handyha_slave_name not in nodes:
                    nodes.append(handyha_slave_name)
                if handyha_master_name not in nodes:
                    nodes.append(handyha_master_name)
        # END ADD BY KF6602 2016/11/11 PN:201611050117

        hosts_info = self.exec_local_cmd('cat /etc/onestor_hosts')
        ips = hosts_info.split('\n')

        # begin add by c13463 stor partition rack
        nodepool = ""
        host_obj = self._get_hostinfo_by_nodepool_name(nodepool)
        # end add by c13463

        for node in nodes:
            node_ip = self._find_ip_by_name(ips, node)
            if node_ip is not None:
                all_nodes_info.append({
                    'fqdn': node,
                    'frontend_addr': node_ip,
                    'mon': True if node in mon_fqdns else False,
                    'stor': True if node in stors else False,
                    'status': False if self.test_ping([node_ip]) == [] else True,
                    # begin add by c13463 stor partition rack
                    'nodepool': host_obj[node]['nodepool_name'] if (
                        node in host_obj and 'nodepool_name' in host_obj[node]) else '',
                    'rack': host_obj[node]['rack_name'] if (
                        node in host_obj and 'rack_name' in host_obj[node]) else ''
                    # end add by c13463
                })

        return all_nodes_info

    @staticmethod
    def _find_ip_by_name(ips, host_name):
        for ip in ips:
            ip_pair = ip.split(' ')
            if 2 == len(ip_pair):
                if host_name == ip_pair[1]:
                    return ip_pair[0]
        return None

    def _clear_cluster_config(self, node):
        try:
            # Handy和监控节点不清除配置文件
            log.debug('[ONEStor] clear cluster config for %s', node)

            is_need_to_clear = True

            cluster_config = self.get_config_from_conf_file()
            mon_fqdns = cluster_config['mon_fqdns']
            for mon in mon_fqdns:
                if node == mon:
                    is_need_to_clear = False
                    break

            handy_name = self.exec_local_cmd('hostname')
            if node == handy_name:
                is_need_to_clear = False

            if is_need_to_clear:
                clear_config_command = 'cp /etc/ceph/ceph.log /tmp/ && rm -rf /etc/ceph/* ' \
                                       '&& mv /tmp/ceph.log /etc/ceph/ceph.log'
                self.exec_remote_ssh_cmd(node, clear_config_command)

        except Exception, e:
            log.error('_clear_cluster_config error: %s', e)

    # 获取除网关之外的所有主机信息,add by l11544 2016/5/4
    # PN:201604161522 先删除存储节点，后删除该存储节点所对应的对象网关，ceph配置文件残留
    def get_host_all(self):
        """
        获取除网关之外的所有主机信息
        :return:
        """
        return self._server_list_all(need_handy_self=True, need_handyha=True)

    # 获取包括网关和Handy在内的集群主机IP和主机名
    def getClusterHost(self):
        """
        获取包括网关和Handy在内的集群主机IP和主机名
        :return:
        """
        # 获取集群内的所有主机名和IP
        host_server_all = self.get_host_all()
        # 获取集群网关信息
        try:
            gateway_obj_list = json.loads(os.popen('ceph config-key get gateway').read())['gateway']
        except ValueError:
            log.error('json.loads gateway is wrong')
            return host_server_all
        except Exception:
            log.error('do not have gateway, ceph config-key get gateway is wrong')
            return host_server_all

        host_list = []
        for host in host_server_all:
            host_list.append(host['frontend_addr'])
        # 获取在集群内的网关主机，排除重复
        for gatewayHost in gateway_obj_list:
            if gatewayHost['hostip'].split(':')[0].strip() not in host_list:
                host_server_all.append({'fqdn': gatewayHost['hostname'],
                                        'frontend_addr': gatewayHost['hostip'].split(':')[0]})

        return host_server_all

    # 获取所有主机包括集群监控、存储和Handy的Ip
    def get_all_hostIp(self):
        """
        获取所有主机包括集群监控、存储、网关和Handy的Ip
        :return:
        """
        hostAll = self.getClusterHost()
        host_ip_list = []
        for hostCur in hostAll:
            host_ip_list.append(hostCur['frontend_addr'])
        return host_ip_list

    # add by l11544 2017/02/10
    # PN:201702070435 为NAS版本增加MDS和NAS节点
    def get_all_ip(self):
        """
        从数据库获取集群所有节点的IP
        :return: List
        """
        host_all = self.exec_local_cmd_json_v2('ceph config-key get cluster_hosts')
        host_ip_list = [host_info['hostip'] for host_info in host_all]
        return host_ip_list

    # PN:201602180530 部署集群时修改NTP配置
    # 创建日期 ：2016年3月1日
    # 作 者 ：戴新春 d10039
    # 函数描述 ：NTP服务器实现HA功能
    # 输入参数 ：无
    # 输出参数 ：无
    # 返 回 值 :
    # 注意事项 :
    # ------------------------------------------------------------------
    # 修改历史
    # 日期 姓名 描述
    # ------------------------------------------------------------------
    def _create_cluster_config_ntp(
            self, ntp_close, mon_nodes, local_ip, all_node, handy_choose, handy_in_mon, wite_type):
        # 如果ntp没有开启，则不做NTP配置修改
        # '0'代表不配置,'1'代表配置集群内
        if '0' == str(ntp_close):
            return
        ntp_task_file = '/var/lib/ceph/shell/ntp_task.py'
        filepath = '/opt/h3c/cmd/'
        host_name_in_file = ''
        # PN: 201703240058 需要在ntp配置中增加noquery参数，防止ntp攻击流量
        ntp_conf = "/etc/ntp.conf"
        param_common = "echo restrict -4 default kod notrap nomodify noquery > {0} && " \
                       "echo restrict -6 default kod notrap nomodify noquery >> {0} && " \
                       "echo restrict -6 ::1 >> {0} && echo restrict 127.0.0.1 >> {0}".format(ntp_conf)
        # end by l11544 2017/4/14
        # 为all_node补充集群外网关
        gateway_nodes = []
        try:
            gateway_list = self.exec_local_cmd_json('ceph config-key get gateway')
            if gateway_list:
                for gateway in gateway_list:
                    gateway_nodes.append(gateway['hostname'])
        except ValueError:
            log.debug('cluster NTP do not get gateway')
        except Exception, e:
            log.error(e)
        for gateway_node in gateway_nodes:
            if gateway_node not in all_node:
                all_node.append(gateway_node)
        all_node = list(set(all_node))

        ntp_server_nodes = []
        ntp_server_stratum = 2
        if isinstance(mon_nodes, list):
            mon_node_list = mon_nodes
        else:
            mon_node_list = mon_nodes.split(',')

        # STEP1 将所有的监控节点配置成NTP服务端，提供NTP HA功能
        log.info('NTP in cluster alter start, params detail is: ntp_close/%s, mon_nodes/%s, local_ip/%s, '
                 'all_node/%s, handy_choose/%s, handy_in_mon/%s, wite_type/%s',
                 ntp_close, mon_nodes, local_ip, all_node, handy_choose, handy_in_mon, wite_type)
        # 将Handy先配置为NTP服务端
        ntp_handy_command = param_common
        ntp_handy_command += ' && echo server 127.127.1.0 >> /etc/ntp.conf && ' \
                             'echo fudge 127.127.1.0 stratum 2 >> /etc/ntp.conf'
        log.info("back up cluster host ntp.conf")
        self.exec_local_ssh_cmd('/opt/h3c/bin/python %s ntp_backup' % ntp_task_file)
        self.multi_thread_task(all_node, 'ssh $$ timeout 60 /opt/h3c/bin/python %s ntp_backup' % ntp_task_file)
        # 重写Handy节点配置
        log.info("rewrite handy ntp conf and restart ntp process.")
        self.exec_local_ssh_cmd(ntp_handy_command)
        # 重启NTP进程
        restart_result = self.exec_local_cmd("/opt/h3c/bin/python {0} restart_ntp".format(ntp_task_file))
        if 'ok' != restart_result:
            log.error("restart handy ntp process failed, please check.")

        # 将所有监控节点的时间强制与Handy进行一次同步(通过Handy的业务网IP)
        # 部署集群和添加监控节点时，必须要保证监控节点和Handy时间强制同步完成
        log.info("mon hosts synchronizing time with local handy")
        multi_result = self.multi_thread_task(
            mon_node_list, "ssh $$ timeout 120 /opt/h3c/bin/python {0} ntpdate_syn_time {1} true".format(ntp_task_file, local_ip))
        # 检查节点和Handy强制同步时间的结果
        failed_ips = list()
        for node, syn_result in multi_result.iteritems():
            if 'ok' != syn_result:
                failed_ips.append(node)
        if failed_ips:
            log.warning("nodes “%s” synchronizing time to local handy failed, detail please check onestor_ntp.log",
                        failed_ips)

        log.info("rewrite mon hosts ntp conf and restart ntp process")
        ntp_syn = self.name_to_ip(mon_node_list[0])
        for mon_node in mon_node_list:
            ntp_server_command = param_common
            ntp_server_command += ' && echo server 127.127.1.0 >> /etc/ntp.conf && ' \
                                  'echo fudge 127.127.1.0 stratum %s >> /etc/ntp.conf' % ntp_server_stratum

            # 如果不是第一个监控节点，还需要配置之前所有监控节点的IP到自身
            for ntp_server in ntp_server_nodes:
                ntp_server_command += ' && echo server %s iburst minpoll 4 maxpoll 4 >> /etc/ntp.conf' % ntp_server

            # 获取MON的业务网IP，从/etc/onestor_hosts文件里可以读到
            host_name_in_file = os.popen("cat /etc/onestor_hosts | awk '{print $1,$2}'").read().strip().split('\n')
            for _host in host_name_in_file:
                # modified by l11544 2016/7/7
                if _host.strip().split()[1] == mon_node:
                    ntp_server_nodes.append(_host.strip().split()[0])
                    # end by l11544

            self.exec_remote_ssh_cmd(mon_node, ntp_server_command)

            if ntp_server_stratum < 16:
                ntp_server_stratum += 1
        # 检查监控节点的进程重启情况
        mon_result = self.multi_thread_task(
            mon_node_list, 'ssh $$ timeout 60 /opt/h3c/bin/python {0} restart_ntp'.format(ntp_task_file))
        failed_ips = list()
        for node, syn_result in mon_result.iteritems():
            if 'ok' != syn_result:
                failed_ips.append(node)
        if failed_ips:
            log.warning("nodes “%s” restart ntp process failed, detail please check onestor_ntp.log", failed_ips)

        # STEP2 修改所有非监控节点的NTP配置
        log.info("rewrite not mon hosts ntp conf, single handy is included, and restart ntp process")
        ntp_client_command = param_common

        for ntp_server in ntp_server_nodes:
            ntp_client_command += '&& echo server %s iburst minpoll 4 maxpoll 4 >> /etc/ntp.conf' % ntp_server

        for _node in all_node:
            if _node not in mon_node_list:
                self.exec_remote_ssh_cmd(_node, ntp_client_command)

        # STEP3 修改Handy节点的NTP配置，分离部署且Handy不是任何节点的情况
        handy_name = self.exec_local_ssh_cmd('hostname')
        if 'false' == handy_choose and 'false' == handy_in_mon:
            self.exec_local_ssh_cmd(ntp_client_command)
            all_node.append(handy_name)
        # 获取可使用的Server端同步时间，防止同步的NTP此时挂死
        for ntp_server in ntp_server_nodes:
            test_result = self.test_ping_single(ntp_server)
            if test_result:
                ntp_syn = ntp_server
        nodes_ntp = copy.deepcopy(all_node)
        for _host in host_name_in_file:
            # modified by l11544 2016/7/7
            if _host.strip().split()[1] == ntp_syn and _host.strip().split()[0] in nodes_ntp:
                nodes_ntp.remove(_host.strip().split()[0])

        log.info("mon hosts synchronizing time with ntp server, and restart ntp process again in the end")
        self.ntp_multi_thread_task(nodes_ntp, 'ssh $$ timeout 60 /opt/h3c/bin/python {0} ntpdate_syn_time {1}'.format(
            ntp_task_file, ntp_syn))
        self.ntp_multi_thread_task(all_node, 'ssh $$ timeout 60 /opt/h3c/bin/python {0} restart_ntp'.format(ntp_task_file))

    def loop_write_client_ntp(self, node, ntp_conf, ntp_status, ntpdate_server):
        """
        重复循环写入ntp配置并强制同步时间
        :param node: 节点名
        :param ntp_conf: 配置
        :return: True代表成功，False代表失败
        """
        try_count = 0
        while True:
            result = self.exec_remote_ssh_cmd(node, ntp_conf)
            if -1 != result.find('ntp_execute'):
                return True
            elif -1 == result.find('ntp_execute') and try_count >= 3:
                return False
            else:
                log.warning("write ntp conf or ntpdate excute failed,  restart ntp server process, "
                            "wait 10 seconds, try again...")
                if '1' == ntp_status:
                    self.exec_remote_ssh_cmd(ntpdate_server, "/opt/h3c/bin/python /var/lib/ceph/shell/ntp_task.py restart_ntp")
                time.sleep(10)
                try_count += 1

        return False

    # PN:201602180530 增加主机时修改NTP配置
    # 创建日期 ：2016年3月1日
    # 作 者 ：戴新春 d10039
    # 函数描述 ：增加主机时修改NTP配置
    # 输入参数 ：使用主机名
    # 输出参数 ：无
    # 返 回 值 :
    # 注意事项 :
    # ------------------------------------------------------------------
    # 修改历史
    # 日期 姓名 描述
    # ------------------------------------------------------------------
    def _add_host_config_ntp(self, node):
        try:
            # 获取MON的业务网IP，从/etc/onestor_hosts文件里可以读到
            cluster_config_from_db = json.loads(self.exec_local_cmd('ceph config-key get clusterconfig'))
            ntp_status = cluster_config_from_db['ntp_close']
            mon_fqdns = cluster_config_from_db['mon_fqdns']
            mon_ips = cluster_config_from_db['mon_ip']
            # 如果该节点与监控节点同名，则不做NTP配置修改
            if node in mon_fqdns:
                return {'status': 'success'}

            # 如果ntp没有开启，则不做NTP配置修改
            if '0' == str(ntp_status):
                return {'status': 'success'}

            # 对NTP配置文件进行备份操作
            self.exec_remote_ssh_cmd(node, '/opt/h3c/bin/python /var/lib/ceph/shell/ntp_task.py ntp_backup')

            ntp_server_nodes = []
            if '1' == str(ntp_status):
                host_name_in_file = os.popen("cat /etc/onestor_hosts | awk '{print $1,$2}'").read().strip().split('\n')
                for _host in host_name_in_file:
                    # modified by l11544 for hosts
                    if _host.strip().split()[1] in mon_fqdns:
                        ntp_server_nodes.append(_host.strip().split()[0])
                        # end by l11544
            else:
                # 集群外server端时获取server的IP
                for mon_ip in mon_ips:
                    test_result = self.test_ping_single(mon_ip)
                    if test_result:
                        ntp_servers_info = self.exec_remote_ssh_cmd(
                            mon_ip, 'cat /etc/ntp.conf | grep server').split('\n')
                        for ntp_server_info in ntp_servers_info:
                            ntp_server_nodes.append(ntp_server_info.split()[1])
                        break
            # PN: 201703240058 需要在ntp配置中增加noquery参数，防止ntp攻击流量
            ntp_conf = "/etc/ntp.conf"
            ntp_client_command = "echo restrict -4 default kod notrap nomodify noquery > {0} && " \
                                 "echo restrict -6 default kod notrap nomodify noquery >> {0} && " \
                                 "echo restrict -6 ::1 >> {0} && echo restrict 127.0.0.1 >> {0}".format(ntp_conf)
            # end by l11544 2017/4/14

            for ntp_server in ntp_server_nodes:
                ntp_client_command += " && echo server %s iburst minpoll 4 maxpoll 4 >> /etc/ntp.conf" % ntp_server
            # 防止主NTP挂掉
            ntpdate_server = ''
            for ntp_server in ntp_server_nodes:
                test_result = self.test_ping_single(ntp_server)
                if test_result:
                    ntpdate_server = ntp_server
                    ntp_client_command += " && ntpdate -u %s 1>/dev/null && echo ntp_execute" % ntpdate_server
                    break

            result = self.loop_write_client_ntp(node, ntp_client_command, str(ntp_status), ntpdate_server)
            if not result:
                log.error("ntpdate -u '%s' to keep time force failed", ntpdate_server)
                return {'status': 'error', 'reason': u'“%s”和服务端强制同步时间失败' % node}
            restart_result = self.exec_remote_ssh_cmd(node, '/opt/h3c/bin/python /var/lib/ceph/shell/ntp_task.py restart_ntp')
            if 'ok' != restart_result:
                log.warning("configure client ntp, restart ntp process failed, please check")
            return {'status': 'success'}
        except ValueError:
            return {'status': 'error', 'reason': u'获取服务端IP失败'}
        except Exception, e:
            log.exception(e)
            return {'status': 'error', 'reason': e}

    # 获取所有的存储节点名称
    def stor_host_all(self):
        """get all host names"""
        nodes = []
        try:
            rack_info = json.loads(self.exec_local_cmd('ceph osd tree -f json'))
            for node in rack_info['nodes']:
                if node['type'] == 'host' and (not node['name'].endswith('_ssd')):
                    nodes.append(node['name'])
        except Exception, e:
            log.error(e)
        return nodes

    # 获取集群外NTP的server端IP
    def get_ntp_server_outer(self):
        cluster_config = self.get_clusterconfig()
        mon_ips = cluster_config['mon_ip']
        ntp_list = []
        # 获取监控节点的NTP配置信息，防止Handy不写NTP以及监控节点有挂死
        mon_ntp = mon_ips[0]
        for mon_ip in mon_ips:
            test_result = self.test_ping_single(mon_ip)
            if test_result:
                mon_ntp = mon_ip

        ntp_list_info = self.exec_remote_ssh_cmd(mon_ntp, "cat /etc/ntp.conf | grep server").split('\n')
        for ntp_info in ntp_list_info:
            ntp_list.append(ntp_info.split()[1])
        return ntp_list
        # end by l11544

    def get_host_roles_by_name(self, host_name, clusterconfig=None):
        """
        ADD BY rKF6740 from v2.py D10039 2016/06/19
        根据主机名获取该主机在集群中的角色
        """
        # 判断主机是否为Handy
        is_handy = True if host_name == self.exec_local_cmd('hostname') else False

        # BEGIN ADD BY z11524 PN:201611170015 for HandyHA
        handyhaconfig = self.list_handyha()
        if handyhaconfig['handyha']:
            masterha_host_name = self.ip_to_name(handyhaconfig['handyha'][0]['master_public_ip'])
            slaveha_host_name = self.ip_to_name(handyhaconfig['handyha'][0]['slave_public_ip'])
            is_handy = True if host_name == masterha_host_name or host_name == slaveha_host_name else False
        # END ADD BY z11524 PN:201611170015 for HandyHA

        # 判断主机是否为监控节点
        if not clusterconfig:
            clusterconfig = self.exec_local_cmd_json_v2('timeout 30 ceph config-key get clusterconfig')

        mons = clusterconfig['mon_fqdns']
        is_mon = True if host_name in mons else False

        # 判断主机是否为对象网关节点
        gateways = database.list_objs('gateway')['gateway']
        is_rgw = False if 0 == len([True for rgw in gateways if host_name == rgw['hostname']]) else True

        # 判断主机是否为存储节点
        osd_tree = self.exec_local_cmd_json('timeout 30 ceph osd tree -f json')
        is_stor = False if 0 == len([True for node in osd_tree['nodes'] if 'host' == node['type'] and
                                     host_name == node['name'].split('.')[0]]) else True

        # 判断主机是否为MDS或者NAS节点此处用ip进行判断，host_name传入ip add by rKF6740
        is_mds = False
        is_nas = False
        file_node_list = database.list_objs('nas_server_new')['nas_server_new']
        for item in file_node_list:
            if item['use'] == 'MDS' and item['hostname'] == host_name:
                is_mds = True
            elif item['use'] == 'NAS' and item['hostname'] == host_name:
                is_nas = True
            else:
                continue

        if not (is_handy or is_mon or is_rgw or is_stor or is_mds or is_nas):
            return None
        role_num = len([role for role in [is_handy, is_mon, is_rgw, is_stor, is_mds, is_nas] if role])
        return {'handy': is_handy, 'mon': is_mon, 'rgw': is_rgw,
                'stor': is_stor, 'mds': is_mds, 'nas': is_nas, 'role_num': role_num}

    # PN：201701220120 使用集群外NTP服务器设计有缺陷，不应该限制NTP server IP为业务网IP，
    # 部署集群时也不应该判断NTP服务器IP在不在业务网段内 add by l11544 2017/2/17
    def get_out_server_list(self, cluster_ip_list=None, mon_ip_list=None):
        """
        获取集群外server端IP列表，通用
        :param cluster_ip_list:
        :param mon_ip_list: 若以后使用监控节点对外同步，则使用监控节点获取NTP服务端IP
        :return: List
        """
        cluster_ip_list = [ip_info['hostip'] for ip_info in self.exec_local_cmd_json(
            'ceph config-key get cluster_hosts')] if None == cluster_ip_list else cluster_ip_list
        # 获取监控节点的所有server端IP配置，不在集群列表内的
        ntp_info = self.exec_local_cmd('cat /etc/ntp.conf | grep server')
        host_list = [host.split()[1] for host in ntp_info.split('\n')]
        log.info('[get_out_server_list]get ntp.conf hosts are {0}'.format(host_list))
        # 去除127网段IP
        ntp_list = [ip for ip in host_list if ip not in cluster_ip_list and not ip.strip().startswith('127')]
        return ntp_list

    def ntp_network_in_judge(self, use_type, ntp_server, host_passwd=None, cluster_hosts=None, user='root'):
        """
        添加集群外NTP时，保证和集群内节点网络畅通，且不属于集群内主机，为单个NTP server检查
        :param use_type: 部署和修改参数配置
        :param ntp_server: IP
        :param host_passwd: String
        :param cluster_hosts: List
        :return: Dict
        """
        # 命令行参数
        ping_command = "ping -c 1 -W 5 %s 1>/dev/null 2>&1 && echo ok" % ntp_server
        cluster_hosts = [ip_info['hostip'] for ip_info in self.exec_local_cmd_json(
            'ceph config-key get cluster_hosts')] if None == cluster_hosts else cluster_hosts
        # 检查所有节点和NTP网络是否畅通
        if 'deploy_cluster' == use_type:
            ping_nodes_result = self.multi_thread_task(cluster_hosts, ping_command, False, host_passwd, user)
        else:
            ping_nodes_result = self.multi_thread_task(cluster_hosts, ping_command, True)
        log.info("[ntp_network_in_judge] host ping ntp server {0} result is:\n{1}".format(
            ntp_server, ping_nodes_result))
        # 检测网络结果
        for ping_node in ping_nodes_result:
            if 'ok' != ping_nodes_result[ping_node]:
                return {'status': 'error', 'err_code': 'network_error', 'reason': u'主机集群节点无法连接，请检查'}

        # 获取集群所有节点的IP，然后进行比较
        if 'deploy_cluster' == use_type:
            nodes_ip_string = self.multi_thread_task(cluster_hosts, HOST_IP_COMMAND, False, host_passwd)
        else:
            nodes_ip_string = self.multi_thread_task(cluster_hosts, "ssh $$ %s" % HOST_IP_COMMAND)
        log.info("[ntp_network_in_judge] ntp server {0} in the cluster hosts, result is:\n{1}".format(
            ntp_server, nodes_ip_string))
        # 检测主机IP结果
        ip_list = list()
        for ip_string in nodes_ip_string:
            node_ip_list = nodes_ip_string[ip_string].split('\n')
            for node_ip in node_ip_list:
                if -1 != node_ip.find('inet'):
                    ip_list.append((node_ip.split()[-1]).strip())
                else:
                    ip_list.append(node_ip.strip())

        if ntp_server in ip_list:
            message = u'主机已添加到集群内，不能再用于提供集群外NTP服务' if 'deploy_cluster' != use_type \
                else u'主机将添加到集群内，不能再用于提供集群外NTP服务'
            return {'status': 'error', 'err_code': 'ip_same', 'reason': message}
        return {'status': 'success'}

    def host_in_ntp_out_check(self, host_ip, host_passwd, ntp_status=None, ntp_servers=None, user='root'):
        """
        新加集群主机时，检测主机是否为NTP集群外server端主机，为单个检测
        :param host_ip: IP
        :param host_passwd: String
        :param ntp_status: 默认为'2'
        :param ntp_servers: List or None
        :return: True 代表新加主机配有IP在集群外Server端列表内, 否则为 False
        """
        # 获取NTP参数，若配置不是集群外直接返回
        ntp_status = self.exec_local_cmd_json("ceph config-key get clusterconfig")['ntp_close'] if None == ntp_status \
            else ntp_status
        if '2' != ntp_status:
            return False

        ntp_servers = self.get_out_server_list() if None == ntp_servers else ntp_servers
        # 获取新加主机的IP列表
        ip_command = "/opt/h3c/bin/python %s/handy_common.py exec_remote_cmd %s %s \"%s\" \"%s\"" % (
            VIEW_PATH, host_ip, user, host_passwd, HOST_IP_COMMAND)
        log.info('[host_in_ntp_out_check] get host ip command is %s' % ip_command)
        ip_result = os.popen(ip_command).read().strip()
        log.info('[host_in_ntp_out_check] host {0} ip list is: {1}, ntp servers is: {2}'.format(
            host_ip, ip_result, ntp_servers))

        host_in_ntp, ip_list_use = False, list()
        # 去除多余的inet
        for ip_use in ip_result.split('\n'):
            if -1 != ip_use.find('inet'):
                ip_list_use.append(ip_use.split()[-1])
            else:
                ip_list_use.append(ip_use)
        for ip in ip_list_use:
            if ip in ntp_servers:
                host_in_ntp = True
                break
        return host_in_ntp

    @staticmethod
    def _get_progress(op):
        """
        获取操作进度
        Author: dai.xinchun@h3c.com
        Date: 2017/01/14
        """
        progress_file = '/tmp/.progress_{0}'.format(op)
        if not os.path.exists(progress_file):
            return None
        with open(progress_file, 'rb') as f:
            return json.loads(f.readline())

    def setup_diamond_multi_handy(self, master_public_ip, slave_public_ip, setup_nodes=None):
        """
        配置diamond为HA方式
        # add by r13889 2017/03/24 PN:201703160637
        """
        # multi_diamond_host格式：'业务网IP1,业务网IP2'
        multi_diamond_host = ','.join([master_public_ip, slave_public_ip])

        # 进行一次Base64编码再传输
        multi_diamond_host = base64.b64encode(multi_diamond_host)
        setup_diamond_cmd = cmd.CMD_SETUP_MULTI_DIAMOND.format(multi_diamond_host)

        # 批量到节点上配置diamond
        if setup_nodes is None:
            cluster_hosts = self.get_cluster_hosts_from_config()
            # add by z11524 2016/11/9 PN:201611100264
            nodes = [host[const.HOST_IP] for host in cluster_hosts
                     if self.network_check(host[const.HOST_IP])]
        else:
            nodes = setup_nodes
        # end by z11524 2016/11/9 PN:201611100264
        # 先备份所有节点上原有的Diamond配置文件
        self.multi_thread_task(nodes, cmd.CMD_BACKUP_DIAMOND_CONF, ssh=True)
        # 再修改所有节点上的Diamond为双机的模式
        setup_diamond_result = self.multi_thread_task(nodes, setup_diamond_cmd, ssh=True)
        log.info('setup diamond result:\t%s', setup_diamond_result)

        # 检查配置结果
        for node, result in setup_diamond_result.items():
            if const.NETWORK_FAULT == result:
                raise errno.ONEStorConfigError(errno.ERR_NODE_HAS_NETWORK_FAULT)
            if -1 == result.find(const.OP_SUCCSSFUL):
                raise errno.ONEStorConfigError(errno.ERR_CONFIG_MULTI_DIAMOND)

        # 重启一下carbon进程
        self.exec_remote_ssh_cmd(slave_public_ip, cmd.SERVICE_RESTART_CARBON)

    def get_nodes_roles(self, nodes):
        """
        区分节点是集群内还是集群外
        :return:
        """
        cluster_nodes = []
        new_nodes = []
        for node in nodes:
            roles = self.get_host_roles_by_name(node)
            if None == roles or roles['role_num'] == 0:
                new_nodes.append(node)
            else:
                cluster_nodes.append(node)
        return {'new_nodes': new_nodes, 'cluster_nodes': cluster_nodes}

    def get_public_ip_by_disaster_ip(self, disaster_ip):
        """
        PN：201707060351 根据灾备网IP地址获取业务网IP地址
        :param disaster_ip: 主机的灾备网IP地址
        :return: 主机的业务网IP地址，获取不到则返回原来的IP
        """
        # 从cluster_hosts数据库中获取灾备网IP
        cluster_hosts_db = self.exec_local_cmd_json(cmd.DB_GET_CLUSTER_HOSTS)
        if not cluster_hosts_db:
            return disaster_ip
        public_ip = [_host[const.HOST_IP] for _host in cluster_hosts_db
                     if const.DISASTER_IP in _host and disaster_ip == _host[const.DISASTER_IP]]
        if 0 < len(public_ip):
            return public_ip[0]
        else:
            log.error('get public ip by disaster ip %s failed, return disaster ip.', disaster_ip)
            return disaster_ip

    # begin add by c13463
    @staticmethod
    def _get_hostinfo_by_nodepool_name(nodepool=''):
        """
        获得指定节点池的主机列表以及节点池、机架信息
        params nodepool: 节点池名称
        return:
        """
        host_obj = {}
        try:
            data = {'nodepool_name': nodepool}
            host_query_response = send_request_onestord('COMP_CS', 'HOST_query_by_nodepool_name', data)
            host_query_result = host_query_response['response']['result']
            if 0 != host_query_result[0]:
                log.error('host query error, response is %s', host_query_response)
                return Response({'success': False, 'error': host_query_result[2], 'errorcode': 'HOST_QUERY'})
            host_list = host_query_response['response']['data']['host_list']
            for host in host_list:
                host_obj[host['host_name']] = {}
                host_obj[host['host_name']]['nodepool'] = host['nodepool_name']
                host_obj[host['host_name']]['rack'] = host['rack_name']
        except Exception, e:
            log.error(e)
        return host_obj
    # end add by c13463

    @staticmethod
    def restrict_lun_num(pool_name, target_name):
        """
        检查当前存储卷数量已经超出上限，当前限制集群、POOL和Target，相关参数后面可能会修改
        :param pool_name: 所属池名称
        :param target_name: 所属Target
        :return: True 代表可以继续创建 or False 代表已经超出上限
        :author l11544
        :date 2017/5/20
        """
        lun_list, not_restrict, restrict_reason, lun_in_pool, lun_in_target = list(), True, '', list(), list()
        try:
            luns_info = database.list_objs('iscsilun')
            if None != luns_info and len(luns_info['iscsilun']) >= 0:
                lun_list = luns_info['iscsilun']
            else:
                return {'not_restrict': True}
        except KeyError:
            return {'not_restrict': True}
        except Exception:
            return {'not_restrict': True}
        # 获取到相关存储卷情况下判断
        if len(lun_list) >= const.LUN_NUM_IN_CLUSTER:
            not_restrict = False
            restrict_reason = errno.ERROR_LUN_OVER_CLUSTER[2].format(const.LUN_NUM_IN_CLUSTER)
            log.error('lun numbers in cluster is {0}'.format(len(lun_list)))
        if not_restrict:
            lun_in_pool = [lun_info for lun_info in lun_list if lun_info['pool_name'] == pool_name]
            if len(lun_in_pool) >= const.LUN_NUM_IN_POOL:
                not_restrict = False
                restrict_reason = errno.ERROR_LUN_OVER_POOL[2].format(const.LUN_NUM_IN_POOL)
                log.error('lun numbers in pool {0} is {1}'.format(pool_name, len(lun_in_pool)))
        if not_restrict:
            lun_in_target = [lun_info for lun_info in lun_list if lun_info['target_name'] == target_name]
            if len(lun_in_target) >= const.LUN_NUM_IN_TARGET:
                not_restrict = False
                restrict_reason = errno.ERROR_LUN_OVER_TARGET[2].format(const.LUN_NUM_IN_TARGET)
                log.error('lun numbers in target {0} is {1}'.format(target_name, len(lun_in_pool)))

        return {'not_restrict': not_restrict, 'restrict_reason': restrict_reason}

    @staticmethod
    def disaster_pool_exist():
        """
        查看灾备默认池是否存在
        :return: True or False
        """
        disaster_exist = False
        try:
            pool_info = common_cmd("ceph osd pool ls", 30, True)
        except TimeoutExpired:
            log.error("excute command 'ceph osd pool ls' timeout, time is 30 seconds")
            raise TimeoutExpired
        except Exception, e:
            log.error("excute command 'ceph osd pool ls' error, reason is {0}".format(e))
            raise e
        pool_list = pool_info['stdout'].split('\n')
        if len(pool_list) > 0 and const.BACKUP_POOL_NAME in pool_list:
            disaster_exist = True
        return disaster_exist

    def judge_disaster_exist(self):
        """
        主要查看容灾是否存在
        :Author l11544 2017/6/3
        :return: True代表存在，False代表不存在
        """
        # 判断灾备池是否存在
        disaster_exist = self.disaster_pool_exist()
        # 判断数据库内是否有灾备高可用
        if not disaster_exist:
            data_list_info = database.list_objs("highavailableconfig")
            if data_list_info and len(data_list_info['highavailableconfig']) > 0:
                disaster_list = [disaster_info for disaster_info in data_list_info['highavailableconfig']
                                 if '1' == disaster_info['disaster_switch']]
                if len(disaster_list) > 0:
                    disaster_exist = True
        # 判断数据库内是否有灾备target
        if not disaster_exist:
            data_list_info = database.list_objs("iscsitarget")
            if data_list_info and len(data_list_info['iscsitarget']) > 0:
                disaster_list = [target_info for target_info in data_list_info['iscsitarget']
                                 if 'usage_mode' in target_info and 'disaster' == target_info['usage_mode']]
                if len(disaster_list) > 0:
                    disaster_exist = True
        return disaster_exist

    def record_onestor_process(self, operation=None, process='', status='processing'):
        """
        数据库progress_onestor中记录当前操作下状态进度，完成后记录,现只需要两个参数用于记录即可
        :Author l11544
        :Date 2017/6/26
        :param operation: 操作名
        :param operation: 当前进度
        :param status: 状态值，一般标记用于操作开始和结束
        :return: Dict
        """
        # 如果为查询操作，则直接返回当前
        if operation is None:
            process_info = database.list_objs(const.ONESTTOR_PROCESS_CONFIG_KEY)
            if 'status' in process_info and 'error' == process_info['status']:
                return process_info
            else:
                return {'status': 'success', 'data': process_info}
        # 若有操作，则需要记录当前操作状态
        operation_obj = {
            'operation': operation,
            'operation_process': process,
            'status': status
        }
        self.exec_local_cmd("timeout 30 ceph config-key put %s '%s'" % (
            const.ONESTTOR_PROCESS_CONFIG_KEY, json.dumps(operation_obj)))

        return None

    def get_ceph_pg_id(self):
        """
        获取集群异常状态的存储池ID
        :return: List
        """
        pool_info = self.exec_local_cmd(cmd.CMD_GET_CEPH_PG_POOL_ID)
        pool_list = pool_info.split('\n') if '' != pool_info else list()
        return pool_list

    def wait_backup_pool_health(self):
        """
        循环等待灾备池恢复健康，最多等待120秒直接执行
        :return: True代表可以执行
        """
        log.info('check backup pool status')
        # 获取灾备存储池的ID
        backup_pool_id = self.exec_local_cmd(cmd.CMD_GET_BACKUP_POOL_ID)
        # 循环等待灾备池健康
        init_time = 0
        start = datetime.datetime.now()
        while init_time <= const.BACKUP_POOL_WAIT_TIME:
            now = datetime.datetime.now()
            init_time = (now - start).seconds
            # 获取集群异常状态PG ID
            pool_list = self.get_ceph_pg_id()
            if backup_pool_id in pool_list:
                time.sleep(3)
                log.info('backup pool is not healthy, wait 3 seconds, retry again...')
            else:
                return True
        return True

    def check_node_mask(self, nodes, network_type):
        """
        ADD BY D10039 2017/06/23 PN:201705110315
        检查所有节点的掩码是否与网段匹配
        前置条件：Handy已经对所有nodes免密
        :param nodes: list 待检查的所有节点(必须是IP)
        :param network_type: str 待检查的网段名称（public_network, disaster_network, .etc）
        :return: list 掩码不匹配的节点IP
        """
        log.info('begin check netmask for %s ...', nodes)
        unmatch_mask_nodes = []
        # 获取网段中的掩码
        cluster_config = self.get_config_from_conf_file()
        if network_type not in cluster_config:
            log.info('[check_node_mask] can not find %s in ceph.conf', network_type)
            return unmatch_mask_nodes
        if network_type == const.PUBLIC_NETWORK:
            block_service_segment = ''
            result = database.list_objs('block_service_network')
            if result:
                network_list = result['block_service_network']
                if network_list:
                    for instance in network_list:
                        if instance['id'] == 1:
                            block_service_segment = instance['block_service_network']
            if not block_service_segment:
                raise errno.ONEStorError(errno.ERR_BSN_NOT_EXIST)
            netmask = block_service_segment.split('/')[1]
        else:
            netmask = cluster_config[network_type].split('/')[1]
        log.info('[check_node_mask] netmask for %s in ceph.conf is %s', network_type, netmask)
        # 获取各个节点的掩码
        for _node_ip in nodes:
            _mask = self.exec_remote_ssh_cmd(
                _node_ip, cmd.CMD_GET_MASK_BY_IP.format(_node_ip), raise_exc=True)
            if '' == str(_mask):
                raise errno.ONEStorError(errno.ERROR_GET_NETWORK_INFO, _node_ip)
            # 判断是否有重复IP
            if 1 < len(_mask.split('\n')):
                raise errno.ONEStorError(errno.ERROR_DUPLICATE_IP, _node_ip)
            if str(_mask) != str(netmask):
                log.error('mask of node %s is %s, unmatched!!', _node_ip, _mask)
                unmatch_mask_nodes.append(_node_ip)
        log.info('[check_node_mask] unmatch mask nodes is %s', ','.join(unmatch_mask_nodes))
        return unmatch_mask_nodes

    @staticmethod
    def query_recovering_pg(diskpool_list):
        data = {'diskpool_list': diskpool_list}
        pg_recover_query_response = send_request_onestord('COMP_CS', 'recovering_pg_query', data)
        pg_recover_query_result = pg_recover_query_response['response']['result']
        if 0 != pg_recover_query_result[0]:
            log.error('pg recover query error, response is %s', pg_recover_query_response)
            return Response({'success': False, 'error': pg_recover_query_result[2], 'errorcode': 'ERROR_PG_RECOVER'})
        pg_recover_query_data = pg_recover_query_response['response']['data']
        if type(pg_recover_query_data['recovering_pg_count']) is int:
            return pg_recover_query_data['recovering_pg_count']
        else:
            log.error('pg recover query error, recovering pg count is %s', pg_recover_query_data)
            return Response({'success': False, 'error': pg_recover_query_result[2], 'errorcode': 'ERROR_PG_RECOVER'})

    def syn_calamari_conf(self, public_ip=None):
        """
        同步高可用calamari配置文件到备用节点
        :param public_ip: 非工作节点业务网IP
        :return: True or False
        """
        log.info('sync calamari conf to slave host')
        if public_ip is None:
            ceph_info = configobj.ConfigObj('/etc/ceph/ceph.conf')
            if 'master_addr' not in ceph_info['handy'] and 'slave_addr' not in ceph_info['handy']:
                return True
            slave_public_ip = ceph_info['handy']['slave_addr']
            master_public_ip = ceph_info['handy']['master_addr']
            # local_ip = self.name_to_ip(self.exec_local_cmd('hostname'))
            is_master_ip = self.exec_local_cmd('ip addr | grep %s/|wc -l' % master_public_ip)
            log.info('is_master_ip= %s', is_master_ip)
            public_ip = slave_public_ip if '1' == is_master_ip else master_public_ip
            log.info('public_ip= %s', public_ip)
        # 开始拷贝
        result = self.exec_local_cmd("timeout 30 scp {0} [{1}]:{0} 1>/dev/null 2>&1 && echo ok".format(
            const.CALAMARI_CONF, public_ip))
        if 'ok' != result:
            log.error('scp calamari conf to host %s failed', public_ip)
            return False

        log.info('scp calamari conf to slave host %s succeed', public_ip)
        return True

    def get_handy_public_ip_list(self):
        """
        获取集群handy节点业务网IP列表
        :return: List
        """
        handy_list = list()
        handy_info = self.list_handyha()
        if handy_info['handyha']:
            handy_list = [handy_info['handyha'][0]['master_public_ip'], handy_info['handyha'][0]['slave_public_ip']]
        else:
            handy_ip = self._get_handy_public_ip()
            handy_list.append(handy_ip)
        return handy_list

    @staticmethod
    def execute_cmd(command_args):
        """
        执行命令行，获取返回信息
        :param command_args:
        :return:
        """
        p = subprocess.Popen(command_args.split(' '), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = p.communicate()
        status = p.returncode
        return {
            'out': stdout,
            'err': stderr,
            'status': status
        }

    # def partion_over_space(self, partion_name=None, df_percent=const.CEPH_TOP_CMD_SPACE):
    #     """
    #     获取集群分区占用是否超出相应比例情况，目前用于ceph可执行和handy接口限制分区硬盘占用比例
    #     :param partion_name: 分区名称
    #     :param df_percent: 硬盘占用上限比例
    #     :return:
    #     """
    #     over_exist, osd_warn_info_all = False, list()
    #     ceph_info = self.exec_local_cmd_json("ceph -s -f json")
    #     log.info('###ceph_info = %s', ceph_info)
    #     if ceph_info:
    #         osd_warn_info_all = [osd_info for osd_info in ceph_info['osdwarn'] if int(osd_info['cap']) >= df_percent]
    #     # 若获取的osd信息不为空时，获取超出的硬盘占用情况
    #     if osd_warn_info_all:
    #         over_exist = True
    #         if partion_name is not None:
    #             osd_warn_info_all = [osd_warn_info for osd_warn_info in osd_warn_info_all if
    #                                  osd_warn_info['part'] == partion_name]
    #         log.warning('cluster exist osd space used over, detail is: %s', osd_warn_info_all)
    #     return {'over_exist': over_exist, 'osd_warn_info': osd_warn_info_all}
    #
    # @staticmethod
    # def pool_partion_info(pool_name):
    #     """
    #     获取存储池所属分区信息
    #     :return: Dict
    #     """
    #     pool_partion = None
    #     pool_info_all = send_request_onestord('COMP_CS', 'POOL_query', {})
    #     if 'success' == pool_info_all['status']:
    #         for pool_info in pool_info_all['response']['data']['pool_list']:
    #             if pool_info['name'] == pool_name:
    #                 pool_partion = pool_info
    #                 break
    #     return pool_partion

    @staticmethod
    def check_ip_used_correct(ip_addr, mask=24):
        """
        判断当前IP在子网掩码内是否为可用IP
        :param ip_addr: Ip
        :param mask: 子网掩码，默认为24位
        :return: True or False
        """
        assert isinstance(ip_addr, str) or isinstance(ip_addr, unicode)
        # 入参检查
        if not ip_addr or not mask:
            return False
        # 掩码检查
        mask = int(mask)
        if mask < 1 or mask > 31:
            return False
        # ip格式检查
        ip_split = ip_addr.split(".")
        if len(ip_split) != 4:
            return False
        # 过滤组播ip和127
        if 240 > ip_split[0] > 223 or ip_split[0] == 127:
            return False
        # 将IP转为二进制格式十位数
        ip_binary = ''
        for ip_net in ip_split:
            ip_binary += str(bin(int(ip_net))).split('0b')[1].zfill(8)
        # 过滤网络位全为0的情况
        if not int(ip_binary[:mask]):
            return False
        ip_num = int(ip_binary, 2)   # 二进制十位数
        # 检查是否为掩码内的广播地址
        mask_binary_oppose = (2 ** (32 - mask) - 1)
        host_id_binary = ip_num & mask_binary_oppose  # 主机id位 与操作
        if not int(host_id_binary) or host_id_binary == mask_binary_oppose:
            return False
        return True

    def check_ip_correct(self, subnet, ip):
        """
        判断当前IP在所属网段内是否为可用主机IP，包含所属网段和不可用IP检查
        :param subnet: IP网段掩码
        :param ip: 主机IP
        :return: True 代表正确可用， False代表不可
        """
        assert isinstance(ip, str)
        # 判断所属网段
        net_segm_corr = self.subnet_judge(subnet, ip)
        # 检查掩码内不可用IP
        mask = int(subnet.split('/')[1])
        ip_in_mask_corr = self.check_ip_used_correct(ip, mask)
        return {"net_segm_corr": net_segm_corr, "ip_in_mask_corr": ip_in_mask_corr}


class ONEStorResponse(ONEStorCommon):
    """
        Author: dai.xinchun@h3c.com
        Date: 2016/05/12
        Description: ONEStor响应类，返回之前都会记录操作日志
    """

    def __init__(self, *args, **kwargs):
        super(ONEStorResponse, self).__init__(*args, **kwargs)

    def init(self, fsid, request, content, errorcode='', reason=u'', user_return=None, model=None):
        """
        Author: dai.xinchun@h3c.com
        Date: 2016/05/12
        Description: 记录操作日志，并返回Response
        :param fsid: 集群ID
        :param request: 请求体
        :param content: 操作内容
        :param errorcode: 错误码，可不传入
        :param reason: 错误原因，可不传入
        :return: Response
        """
        if '' == errorcode:
            if not user_return:
                self.addOperationlog(fsid, request, content, 'success', False, model)
                return Response({'status': 'success'})
            else:
                if 'type' in user_return and 'handyha' == user_return['type'] and 'rt' in user_return:
                    content = user_return['rt']
                self.addOperationlog(fsid, request, content, 'success', False, model)
                return Response(user_return)

        self.addOperationlog(fsid, request, content, reason, False, model)
        if not user_return:
            return Response({'status': 'error', 'errorcode': errorcode, 'reason': reason})
        else:
            return Response(user_return)
