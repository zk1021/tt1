# -*- coding:utf-8 -*-
import logging

from onebackup import metadata
from calamari_rest.views.onestor import database
from calamari_rest.views.onestor_common import ONEStorCommon, ONEBackupError
from calamari_rest.views.backup import constant, utils, messanger
from calamari_rest.decorator import module_required

from calamari_rest.views.common import const
from calamari_common.cmdprocess import command as common_cmd

from calamari_rest.views.backup.utils import DisasterUtils

log = logging.getLogger('django.request')

"""
    Author: dai.xinchun@h3c.com
    Date: 2016/06/30
    Description: ONEStor异地灾备站点管理类
"""


class BackupStationViewSet(DisasterUtils):
    def __init__(self, *args, **kwargs):
        super(BackupStationViewSet, self).__init__(*args, **kwargs)

    def _get_all_ha_nodes(self, ha_list):
        """
        获取所有配置了高可用的节点
        :param ha_list:
        :return:
        """
        all_nodes = []
        ha_ip_list = {}

        if not ha_list:
            return all_nodes, ha_ip_list

        ha_ips = ''
        for ha in ha_list:
            all_nodes = all_nodes + [ha['master']] + ha['slave'].split(',')
            ha_ips = ha_ips + ha['vip'] + ','

        # 远程登录到每个高可用节点上获取当前工作节点
        list_ha_command = 'ssh $$ timeout 120 python %s/list_ha.py %s' % (constant.HANDY_SHELL_PATH, ha_ips.rstrip(','))
        list_ha_results = self.multi_thread_task(all_nodes, list_ha_command)

        for node, result in list_ha_results.items():
            if 'error' != result and 'none' != result:
                for ha_ip in result.split(','):
                    ha_ip_list[ha_ip] = node

        return set(all_nodes), ha_ip_list

    @staticmethod
    def _handle_switch_stations_state(results):
        """
        当在进行主备切换时，开启定时任务，判断元数据的is_primary是否改变
        当主备切换完成后需要更新数据库中保存的数据
        """
        is_primary = metadata.is_primary()

        disaster_info = {}
        agent_proxy = None
        switch_done = False
        disaster_info['disaster_type'] = is_primary

        backup_pool = metadata.BackupPool()
        status_obj = backup_pool.status

        for result in results['highavailableconfig']:
            # 站点切换失败 ADD BY h13051 2017/07/18 PN:201707120373
            if 'failed' == status_obj.status:
                return {'success': True, 'data': results, 'update': False, 'agent_vip': agent_proxy,
                        'fail_info': 'switch_failed'}

            # 备站点切换为主站点，需要清空原备站点信息
            if result['disaster_info']['disaster_type'] != is_primary and 'normal' == status_obj.status:
                switch_done = True

                if is_primary:
                    onebackup_pool = metadata.BackupPool()
                    agent_vip = onebackup_pool.primary.to_json()
                    agent_proxy = agent_vip['agent_proxy']

                    disaster_info['secondary_scheduler'] = ''
                    disaster_info['agent_vip'] = agent_proxy

                # 将主备切换结果更新到数据库中
                database.update_one('highavailableconfig', {
                    'disaster_switch': '1',
                    '$set': {
                        'disaster_info': disaster_info
                    }
                })
            return {'success': True, 'data': results, 'update': switch_done, 'agent_vip': agent_proxy}
        # ADD BY D10039 2017/06/24 PN:201705150045 for循环没有数据缺少返回值
        return {'success': True, 'data': results, 'update': False}

    @utils.send_response(constant.OP_LIST)
    def list_backup_cfg(self, request, fsid):
        """
        获取灾备配置，显示在拓扑配置列表
        """
        switch_station_flag = request.GET.get('switch_done', None)

        # 获取数据库中的所有高可用配置
        results = database.list_objs('highavailableconfig')

        # 检查当前状态是否正常开启灾备，若非正常开启，则后台回退
        check_disaster = self.check_open_status()
        results['disaster_pool_status'] = check_disaster

        # 查看是否有灾备target残留，若残留同样需要提示
        results['disaster_target_exist'] = False
        data_list_info = database.list_objs('iscsitarget')
        if {} != data_list_info and len(data_list_info['iscsitarget']) > 0:
            data_list = data_list_info['iscsitarget']
            disaster_list_info = [disaster_info for disaster_info in data_list if
                                  'usage_mode' in disaster_info and 'disaster' == disaster_info['usage_mode']]
            if len(disaster_list_info) > 0:
                results['disaster_target_exist'] = True

        # TODO 过滤出Target高可用所使用的高可用配置，判断条件没有考虑对象网关高可用
        tgt_ha_list = [ha_cfg for ha_cfg in results['highavailableconfig'] if '1' == ha_cfg['ha_switch']]
        if 0 == len(tgt_ha_list):
            return {'success': False, 'error': 'NO_TGT_HA_IP', 'data': results}

        # 获取所有已经被使用的VIP
        used_vip = [ha_cfg['vip'] for ha_cfg in results['highavailableconfig']]
        results['used_vip'] = used_vip

        # 过滤出异地灾备所使用的高可用配置
        ha_list = [ha_cfg for ha_cfg in results['highavailableconfig'] if '1' == ha_cfg['disaster_switch']]

        # 获取所有配置了高可用的节点
        all_nodes, ha_ip_list = self._get_all_ha_nodes(ha_list)

        results['ha_ip_list'] = ha_ip_list if ha_list else ''

        # 查看是否灾备池存在，不存在则不再下发通过backup的消息
        disaster_exist = self.disaster_pool_exist()

        # 若不存在灾备，直接返回即可
        if not disaster_exist or 0 == len(ha_list):
            results['highavailableconfig'] = []
            return {'success': True, 'data': results}

        # 获取元数据中的实时状态并更新到数据库查询结果中
        backup_pool = metadata.BackupPool()
        status = backup_pool.status.to_json()
        primary_info = backup_pool.primary.to_json()
        agent_proxy = primary_info['agent_proxy']

        for ha_cfg in ha_list:
            ha_cfg['status'] = status['status']
            ha_cfg['connect_status'] = status['connect_status']
            ha_cfg['proxy_ip'] = agent_proxy

        results['highavailableconfig'] = ha_list

        if switch_station_flag is None:
            # 如果不是主备切换过程中，从元数据中获取实时的主备状态到页面显示
            for ha_cfg in results['highavailableconfig']:
                is_primary = metadata.is_primary()
                ha_cfg['disaster_info']['disaster_type'] = is_primary
                # 如果当前是备站点，需要将disaster_type更新到数据库中（主备互换需要）
                if not is_primary:
                    database.update_one('highavailableconfig', {
                        'disaster_switch': '1',
                        '$set': {
                            'disaster_info': {"disaster_type": False}
                        }
                    })
            return {'success': True, 'data': results, 'update': False}

        return self._handle_switch_stations_state(results)

    @utils.send_response(constant.OP_LIST)
    def list_backup_role(self, request, fsid):
        """
        获取当前站点角色
        """
        # 判断当前站点是否为主站点
        is_primary = metadata.is_primary()

        # 获取主备站点的详细信息
        backup_pool = metadata.BackupPool()

        return {
            'primary_site': backup_pool.primary.to_json(),
            'secondary_site': backup_pool.secondary.to_json(),
            'current_site_role': 'primary' if is_primary else 'secondary'
        }

    @utils.send_response(constant.OP_LIST)
    def list_backup_agent(self, request, fsid):
        """
        获取agent的详细信息
        """
        # 获取异地灾备配置信息
        backup_pool = metadata.BackupPool()

        # 获取agent信息
        agents = backup_pool.agent.to_json()

        return {'agents': agents}

    @utils.send_response(constant.OP_LIST)
    def list_backup_host(self, request, fsid):
        """
        获取异地灾备主机
        """
        # 获取异地灾备配置信息
        try:
            backup_pool = metadata.BackupPool()

            # 获取主机列表
            backup_hosts = backup_pool.backuphosts.to_json()
            return {'status': 'success', 'data': [host['address'] for host in backup_hosts]}
        except ONEBackupError as e:
            log.error('failed to get disaster hosts, reason is: %s', str(e))
            return self.check_disaster_hostinfo_reason()
        except Exception as e:
            log.error('failed to get disaster hosts, reason is: %s', str(e))
            return self.check_disaster_hostinfo_reason()

    @utils.send_response()
    def disconnect_station(self, request, fsid):
        """
        断开主（备）站点
        """
        is_primary = metadata.is_primary()

        disconnect_site_name = '备站点' if is_primary else '主站点'

        # 将操作日志的内容返回
        yield constant.OP_DISCONNECT_STATION.format(disconnect_site_name)

        # 发送消息给scheduler
        messanger.send_disconnect_station_msg()

        yield

    @utils.send_response()
    def switch_station(self, request, fsid):
        """
        切换为主（备）站点
        """
        is_primary = metadata.is_primary()

        switch_site_name = '备站点' if is_primary else '主站点'

        # 将操作日志的内容返回
        yield constant.OP_SWITCH_STATION.format(switch_site_name)

        # 先判断是否已经断开主（备）站点的连接
        backup_pool = metadata.BackupPool()
        status = backup_pool.status.to_json()

        if 'connected' == status['connect_status']:
            raise ONEBackupError('ERROR_STATION_IS_CONNECTED', u'请先断开%s的连接' % switch_site_name)

        # 检查是否有Target的高可用IP（用于proxy的高可用）
        proxy_ha_cfg = database.find_one('highavailableconfig', [{'disaster_switch': '0'}])
        if not proxy_ha_cfg:
            raise ONEBackupError('ERROR_NO_TGT_HA_CFG', u'请先创建一个Target的高可用IP')

        # 如果是备站点切换为主站点，需要将agent_proxy更新到元数据中
        data = {} if is_primary else {'agent_proxy': proxy_ha_cfg[0]['vip']}

        # 发送消息给scheduler
        messanger.send_switch_station_msg(data)

        yield

    @utils.send_response()
    def exchange_station(self, request, fsid):
        """
        主备站点相互切换
        """
        # 将操作日志的内容返回
        yield constant.OP_EXCHANGE_STATION

        # TODO 主备互换只允许在备站点上执行
        is_primary = metadata.is_primary()

        if is_primary:
            raise ONEBackupError('ERROR_IS_NOT_SECONDARY_SITE', u'主备互换只能在备站点上执行')

        # 检查是否有Target的高可用IP（用于proxy的高可用）
        proxy_ha_cfg = database.find_one('highavailableconfig', [{'disaster_switch': '0'}])
        if not proxy_ha_cfg:
            raise ONEBackupError('ERROR_NO_TGT_HA_CFG', u'请先创建一个Target的高可用IP')

        backup_pool = metadata.BackupPool()

        primary = backup_pool.primary.to_json()
        primary_ip = primary['scheduler_address']

        secondary = backup_pool.secondary.to_json()
        secondary_ip = secondary['scheduler_address']

        # 如果是备站点切换为主站点，需要将agent_proxy更新到元数据中
        agent_vip = proxy_ha_cfg[0]['vip']
        proxy_data = {'agent_proxy': agent_vip}

        # 发送消息给scheduler
        messanger.send_exchange_station_msg(primary_ip, secondary_ip, proxy_data)

        # 切换完成后更新备站点的本地数据库
        disaster_info = dict()
        disaster_info['disaster_type'] = True
        disaster_info['agent_vip'] = agent_vip
        disaster_info['seconde_scheduler'] = primary_ip  # 原来的主站即为现在的备站

        database.update_one('highavailableconfig', {
            'disaster_switch': '1',
            '$set': {
                'disaster_info': disaster_info
            }
        })

        yield

    @utils.send_response(constant.OP_LIST)
    def disaster_used_info(self, request, fsid):
        """
        容灾所处的状态
        :info 默认容灾处于关闭状态，且可以清理容灾环境
        :return: Dict
        """
        disaster_exist = self.judge_disaster_exist()

        yield {'disaster_exist': disaster_exist}

    @utils.send_response(constant.OP_CREATE_DISATER_INFO)
    def create_disater_info(self, request, fsid):
        """
        创建容灾元数据信息
        :param request:
        :param fsid:
        :return:
        """
        partition_name = request.DATA.get('partition_name', None)
        replicate_num = request.DATA.get('replicate_num', None)
        disater_network = request.DATA.get('disater_network', None)

        # 将操作日志的内容返回
        yield constant.OP_CREATE_DISATER_INFO
        log.info('start to create disaster metadata info')

        # 先获取存储节点的灾备网IP，若有节点不存在灾备网IP，则抛出异常
        stor_disater_list = self.get_cluster_disater_ips(disater_network)
        # 将灾备IP保存到缓存中
        request.session[const.NEED_RESTORE_ONEBACKUP] = stor_disater_list
        # 将灾备网段信息，保存到数据库表和集群各节点ceph.conf内
        self.record_onestor_process(constant.OP_OPEN_DISASTER, 'save_network')
        self.save_disater_network(disater_network)

        # 创建灾备默认池
        self.record_onestor_process(constant.OP_OPEN_DISASTER, 'create_backup_pool')
        self.create_back_default_pool(partition_name, replicate_num)

        # 循环初始化元数据池信息，并保存集群灾备IP
        log.info('begin to initialize disaster pool')
        self.record_onestor_process(constant.OP_OPEN_DISASTER, 'init_backup_pool')
        self.loop_init_back_pool(stor_disater_list)

        # 开启元数据保活
        self.exec_local_cmd("timeout 30 bash %s/crontab_sync_host.sh" % constant.BACKUP_SHELL_PATH)
        # 重启容灾进程
        self.exec_local_ssh_cmd("supervisorctl restart onebackup:scheduler")
        self.record_onestor_process(constant.OP_OPEN_DISASTER, 'open_disaster', 'end')
        log.info('succed to create backup metadata')

        yield

    @utils.send_response()
    def clear_disater_info(self, request, fsid):
        """
        清理元数据信息
        :param request:
        :param fsid:
        :return: None
        """

        # 将操作日志的内容返回
        yield constant.OP_CLEAR_DISATER_INFO
        log.info('start to clear disaster metadata info')

        # 检查集群存储节点网络
        stor_nodes = self._get_cluster_stor_nodes()
        network_check = self.test_ping(stor_nodes)
        if len(network_check) > 0:
            raise ONEBackupError('NETWORK_ERROR', constant.OP_NETWORK_ERROR.format(
                ','.join(str(ip) for ip in network_check)))
        # 获取灾备高可用信息
        disaster_list_info = self.get_disaster_info()
        # 清理容灾基本环境信息
        # 检查是否存在容灾，若不存在则不再发送消息进行删除
        disaster_exist = self.disaster_pool_exist()
        if disaster_exist:
            messanger.send_remove_disaster_info(disaster_list_info)
        # 删除容灾高可用
        disaster_list_info = self.clear_disaster_ha_ip(stor_nodes, disaster_list_info)
        # 清理数据库信息
        self.clear_disaster_tag_in_database()
        # 清理ceph.conf内和cluster_hosts内灾备IP字段
        self.clear_disaster_network_info()
        # 重启容灾进程
        self.restart_disaster_ha_nodes(disaster_list_info)

        yield
