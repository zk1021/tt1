# -*- coding:utf-8 -*-

import re
import logging
import base64
import json
from calamari_rest.views.backup import constant, messanger
from rest_framework.response import Response
from django.http.request import QueryDict
from calamari_rest.views.onestor_common import ONEStorResponse, ONEBackupError, ONEStorCommon

from calamari_rest.common import send_request_onestord
from calamari_rest.views.onestor import database
from calamari_rest.views.common import const

# 引用灾备元数据信息
from onebackup import metadata
from calamari_rest.views.common import cmd

log = logging.getLogger('django.request')


"""
    Author: dai.xinchun@h3c.com
    Date: 2016/07/28
    Description: ONEStor异地灾备工具类
"""


def process_validate_params(params, func_name):
    """
    通过正则表达式校验输入参数是否合法
    """
    # 如果是GET或DELETE请求，需要对数据类型进行预处理
    if QueryDict == type(params):
        params = dict(params)
        for key in params:
            params[key] = params[key][0]

    # 先校验必填的参数
    if func_name in constant.required_item:
        required_param = constant.required_item[func_name]
        for param in required_param:
            if param not in params:
                raise ONEBackupError('INVALID_PARAM', constant.NULL_PARAM.format(param))

    # 再逐个校验必填参数是否合法
    log.info('[ONEStor] process function "%s", params is: %s', func_name, params)
    for key in params:
        if key not in constant.checkRegExp:
            continue
        if not re.match(constant.checkRegExp[key], str(params[key])):
            raise ONEBackupError('INVALID_PARAM', constant.INVALID_PARAM.format(key))


def send_response(op=None):
    """
    请求处理完成后的处理：
    1、如果是增、删、改，记录操作日志并返回HttpResponse给页面
    2、如果是查询，直接返回HttpResponse给页面
    """

    def decorate(func):
        """
        装饰器
        """

        def _decorate(_self, request, fsid=None):
            """
            装饰器
            """
            resp = []
            error_code = ''
            error_reason = ''
            operationlog = constant.DEFAULT_OPERATION_LOG
            try:
                if constant.OP_LIST == op:
                    resp = func(_self, request, fsid)
                else:
                    for result in func(_self, request, fsid):
                        if result is not None:
                            if dict == type(result) or QueryDict == type(result):
                                # 在此校验参数是否合法，如果不合法，则抛出异常
                                process_validate_params(result, func.__name__)
                            elif str == type(result) or unicode == type(result):
                                # 传过来的字符串作为操作日志
                                operationlog = result
            except ONEBackupError as ex:
                log.exception(ex)
                error_code = ex.errorcode
                error_reason = ex.reason
            except Exception as ex:
                log.exception(ex)
                error_code = ex
                error_reason = constant.DEFAULT_ERROR_REASON
            finally:
                # 查询类的操作不需要记录操作日志
                if constant.OP_LIST == op:
                    return Response(resp)
                # 记录开启容灾的回退
                if constant.OP_CREATE_DISATER_INFO == op and '' != error_code:
                    DisasterUtils().open_disaster_rollback()
                    DisasterUtils().record_onestor_process(constant.OP_OPEN_DISASTER, 'open_disaster', 'end')
                return ONEStorResponse().init(fsid, request, operationlog, error_code, error_reason)

        return _decorate

    return decorate


def set_target_info(request_data):
    """
    根据页面传过来的参数封装Target信息
    """
    target_name = request_data.get('target_name', None)
    iqn_switch = request_data.get('iqn_switch', None)
    lun_id = request_data.get('lun_id', None)
    iqns = request_data.get('iqns', None)

    target_info = dict()
    target_info['target_name'] = target_name
    target_info['lun_id'] = lun_id
    target_info['iqn_switch'] = iqn_switch
    target_info['iqns'] = iqns

    return target_info


def set_backup_strategy(block_name, backup_block_name, strategy, target_info=None, is_need_agent=None):
    """
    根据页面传过来的参数封装备份策略
    """
    backup_interval = dict()
    backup_interval_unit = strategy['interval_unit']
    backup_interval['unit'] = backup_interval_unit
    backup_interval['interval'] = host_backup_interval = strategy['host_backup_interval']

    time_slice = [{}]

    if 'day' == backup_interval_unit:
        # 备份频率单位为天，换算成小时，除以24，存入数据库
        host_backup_interval /= 24
        backup_interval['start'] = strategy['host_backup_start_time']
        backup_interval['end'] = strategy['host_backup_stop_time']
        time_slice = [{
            "start_time": strategy['host_backup_start_time'],
            "weekday": 0,
            "stop_time": strategy['host_backup_stop_time']
        }]
    elif 'week' == backup_interval_unit:
        # 备份频率单位前台传值单位为小时，换算成周，除以24小时再除以7天，存入数据库
        host_backup_interval = host_backup_interval / 24 / 7
        backup_interval['interval'] = 1
        backup_interval['quantum_weekday'] = time_slice = strategy['quantum_weekday']

    backup_strategy = {
        'name': block_name,
        'back_name': backup_block_name,
        'target_info': target_info,
        'backup_interval': {
            "interval": host_backup_interval,
            "unit": backup_interval_unit,
            "time_slice": time_slice
        },
        'alternate_retention_time': strategy['alternate_retention_time'],
        'host_retention_time': strategy['host_retention_time'],
        'enable': strategy['is_enabled'],
        'is_need_agent': is_need_agent
    }

    return backup_strategy, backup_interval


def get_disaster_target_info(disaster_name):
    """
    获取灾备块的所属target的ID
    :param disaster_name: 灾备块名称
    :return: Dict
    """
    lun_info = database.find_one('iscsilun', [{'lun_name': disaster_name}])[0]
    target_id = lun_info['target_id']
    return target_id


class DisasterUtils(ONEStorCommon):
    """
    容灾兼容分区整改公用方法调用
    """
    def __init__(self, *args, **kwargs):
        super(DisasterUtils, self).__init__(*args, **kwargs)

    def create_back_default_pool(self, partition_name, replicate_num):
        """
        创建容灾元数据池
        :param partition_name: 分区名称，带有后缀
        :param replicate_num: 副本数，现在只支持副本
        :return: None
        """
        log.info('begin to create default back pool %s', constant.BACKUP_POOL_NAME)
        disaster_exist = self.disaster_pool_exist()
        if disaster_exist:
            log.error('disaster pool exist, need clear disaster info first')
            send_request_onestord('COMP_CS', 'POOL_delete', {'pool_name': constant.BACKUP_POOL_NAME})

        partition_name_used = partition_name.split('_')[0]
        pool = {
            'pool_name': constant.BACKUP_POOL_NAME,
            'partition_name': partition_name_used,
            'radosgwJudge': 'false',
            'redundancy': 'replicate',
            'replicate_num': int(replicate_num),
            'deploy': ''
        }
        if '_ssd' in partition_name:
            pool['deploy'] = 'fast'
        if '_hdd' in partition_name:
            pool['deploy'] = 'slow'
        create_pool = send_request_onestord('COMP_CS', 'POOL_create', pool)
        # PN: 201706080229 灾备所选分区下已有5个pool的前提下，开启容灾，开启失败，没有检查分区下的pool个数是否已达上限
        if 'success' == create_pool['status']:
            create_result = create_pool['response']
            if 0 != create_result['result'][0]:
                log.error('create disaster pool failed, detail is: %s', create_result)
                raise ONEBackupError('PARTION_POOL_OVER', create_result['result'][2])
        log.info('end to create default back pool %s', constant.BACKUP_POOL_NAME)

    def loop_init_back_pool(self, stor_disater_list):
        """
        循环初始化灾备池信息
        :param stor_disater_list:
        :return:
        """
        backup_pool, init_succeed, backup_pool = None, False, None
        # 循环等待灾备池健康
        self.wait_backup_pool_health()

        try:
            # 初始化元数据信息
            backup_pool = metadata.BackupPool()
            backup_pool.initialize()
        except ONEBackupError as ex:
            log.error('failed to initialize disaster pool, reason is: %s', str(ex))
        except Exception as e:
            log.error('failed to initialize disaster pool, reason is: %s', str(e))
        else:
            log.info('initialize disaster pool succeed.')
            init_succeed = True

        if init_succeed:
            log.info('begin to save disaster info %s in pool', stor_disater_list)
            backup_hosts = backup_pool.backuphosts
            backup_hosts.hosts = []
            for host_ip in stor_disater_list:
                backup_hosts.add_host(host_ip)
            backup_pool.backuphosts = backup_hosts
        else:
            raise ONEBackupError('INIT_BACK_POOL_FAILED', constant.OP_INIT_BACK_POOL_FAILED)

    def get_cluster_disater_ips(self, disater_network):
        """
        获取集群内所有存储节点的灾备网IP
        :param disater_network:
        :return:
        """
        stor_nodes = self._get_cluster_stor_nodes()
        ip_list_info = self.multi_thread_task(stor_nodes, constant.FILTER_HOST_IP_CMD, ssh=True, use_string=False)
        # 失败主机IP，灾备IP，灾备主机、IP列表信息
        failed_ips, disaster_ip_list, disaster_info_list = list(), list(), list()
        for node, ip_info in ip_list_info.iteritems():
            # 如果网络有问题
            if 'NETWORK_FAULT' == ip_info:
                log.error('host %s is unreachable', node)
                failed_ips.append(self.name_to_ip(node))
                continue
            exit_disaster_ip = False
            for ip in ip_info.split('\n'):
                if '' != ip and self.subnet_judge(disater_network, ip):
                    disaster_ip_list.append(ip)
                    disaster_info_list.append({'name': self.ip_to_name(node), 'ip': ip})
                    exit_disaster_ip = True
                    break
            if not exit_disaster_ip:
                failed_ips.append(self.name_to_ip(node))
        if len(failed_ips) > 0:
            raise ONEBackupError('NOT_EXIST_DISATER_IP', constant.OP_NOT_EXIST_DISATER_IP.format(
                ','.join(str(ip) for ip in failed_ips)))

        # 将灾备网IP保存到cluster_hosts内
        cluster_hosts_info = self.exec_local_cmd_json("ceph config-key get cluster_hosts")
        for host_info in cluster_hosts_info:
            host_info[const.DISASTER_IP] = ''
            for disaster_info in disaster_info_list:
                if host_info['hostname'] == disaster_info['name']:
                    host_info[const.DISASTER_IP] = disaster_info['ip']
                    break
        self.exec_local_cmd("timeout 30 ceph config-key put cluster_hosts '%s'" % json.dumps(cluster_hosts_info))

        return disaster_ip_list

    def save_disater_network(self, disater_network):
        """
        将灾备网段信息保存到数据库和ceph.conf内
        :param disater_network:
        :return:
        """
        log.info('start to save disaster network info in ceph database')
        # 获取集群所有节点
        cluster_hosts_info = self.exec_local_cmd_json("ceph config-key get cluster_hosts")
        cluster_ips = [host_info['hostip'] for host_info in cluster_hosts_info]
        rewrite_result = self.multi_thread_task(cluster_ips, constant.CMD_WRITE_DISASTER_NETWORK.format(
            base64.b64encode(disater_network)
        ), ssh=True)
        # 检查写入结果，若写入失败，则回退写入抛出异常
        failed_hosts = list()
        for host_ip, host_result in rewrite_result.iteritems():
            if 'ok' != host_result:
                failed_hosts.append(host_ip)
        if len(failed_hosts) > 0:
            failed_host_string = ','.join(str(ip) for ip in failed_hosts)
            self.multi_thread_task([ip for ip in cluster_ips if ip not in failed_hosts],
                                   constant.CMD_REMOVE_DISATER_NETWORK, ssh=True)
            log.error('failed to write disaster network to host %s', failed_host_string)
            raise ONEBackupError('WRITE_DISASTER_FAILED', constant.OP_WRITE_DISASTER_FAILED)

        # 将灾备网段写入数据库
        cluster_config = self.exec_local_cmd_json("ceph config-key get clusterconfig")
        cluster_config['disaster_network'] = disater_network
        log.debug('cluster config is %s, type is %s', cluster_config, type(cluster_config))
        self.exec_local_cmd("timeout 30 ceph config-key put clusterconfig '%s'" % json.dumps(cluster_config))

    @staticmethod
    def convert_disaster_to_null(table_name):
        """
        将数据库内带有disaster标记去除,rbdlist、iscsilun和iscsitarget三个表
        :return: None
        """
        data_list_info = database.list_objs(table_name)
        log.debug('data is %s, %s', data_list_info, not data_list_info)
        if data_list_info and len(data_list_info[table_name]) > 0:
            data_list = data_list_info[table_name]
            disaster_list_info = [disaster_info for disaster_info in data_list if
                                  'usage_mode' in disaster_info and 'disaster' == disaster_info['usage_mode']]
            for data_info in disaster_list_info:
                database.update_one(table_name, {'id': data_info['id'], '$set': {'usage_mode': ''}})
        else:
            log.info('get database %s result is null, result is: %s', table_name, data_list_info)

    @staticmethod
    def covert_disaster_target(target_name, iqn_switch, iqns, old_usage_mode, select_disaster):
        """
        灾备Target转换时需要进行的操作，包括将iqn推送到backup，对rbdlist和iscsilun表进行修改
        :param target_name:
        :param iqn_switch:
        :param iqns:
        :param old_usage_mode: Target初始状态，即是否为灾备使用
        :param select_disaster: True代表仍然为灾备使用Target,False为其它使用
        :return: True or False
        """
        # 如果仅仅为非灾备的targert修改iqn，不需要继续进行
        if '' == old_usage_mode and not select_disaster:
            return True
        log.info('start to rewrite rbdlist and iscsilun database, target name is %s, iqns are %s, old usage mode is %s,'
                 'select disaster status is %s', target_name, iqns, old_usage_mode, select_disaster)
        # 切换为灾备时，无论是否修改了iqn，重新推送iqn到backup
        if select_disaster:
            messanger.send_modify_target_msg(target_name, iqn_switch, iqns)
        # 获取该Target下的rbd和lun表数据
        luns_info = database.find('iscsilun', [{'target_name': target_name}])
        rbd_list = database.list_objs('rbdlist')['rbdlist']
        rbds_in_target = list()
        for lun_info in luns_info:
            rbds_info = [rbd_info for rbd_info in rbd_list if rbd_info['rbd_name'] == lun_info['rbd_name'] and
                         rbd_info['pool_name'] == lun_info['pool_name']]
            rbds_in_target.extend(rbds_info)
        # 若灾备Target转为普通Target，需要对rbdlist和iscsilun表进行修改，iscsitarget表v2.py内已经修改
        if 'disaster' == old_usage_mode and not select_disaster:
            for lun_info in luns_info:
                database.update_one('iscsilun', {'id': lun_info['id'], '$set': {'usage_mode': ''}})
                messanger.send_remove_onbackup_lun_msg(lun_info['pool_name'], lun_info['rbd_name'])
            for rbd_info in rbds_in_target:
                database.update_one('rbdlist', {'id': rbd_info['id'], '$set': {'usage_mode': ''}})

        # 普通Target转为容灾Target
        if '' == old_usage_mode and select_disaster:
            for lun_info in luns_info:
                database.update_one('iscsilun', {'id': lun_info['id'], '$set': {'usage_mode': 'disaster'}})
                messanger.send_create_onbackup_lun_msg(
                    lun_info['pool_name'], lun_info['rbd_name'], target_name, lun_info['lun_id'])
            for rbd_info in rbds_in_target:
                database.update_one('rbdlist', {'id': rbd_info['id'], '$set': {'usage_mode': 'disaster'}})
        log.info('end to update Target')
        return True

    def clear_disaster_tag_in_database(self):
        """
        清理数据库内容灾标识
        :return: None
        """
        log.info('clear disaster tag in database rbdlist,iscsilun,iscsitarget')
        # 一般进行到清理数据库表，rbdlist、iscsilun和iscsitarget会都已经创建
        try:
            self.convert_disaster_to_null('rbdlist')
            self.convert_disaster_to_null('iscsilun')
            self.convert_disaster_to_null('iscsitarget')
        except KeyError, e:
            log.error(e)
            raise ONEBackupError('CLEAR_DISASTER_HA_FAILED', constant.OP_CLEAR_DISASTER_BLOCK_FAILED)
        except Exception, e:
            log.error(e)
            ONEBackupError('CLEAR_DISASTER_HA_FAILED', constant.OP_CLEAR_DISASTER_BLOCK_FAILED)

    @staticmethod
    def get_disaster_info():
        """
        获取灾备高可用信息
        :return:
        """
        disaster_list_info = list()
        high_data = database.list_objs("highavailableconfig")
        if high_data and len(high_data['highavailableconfig']) > 0:
            high_list_info = high_data['highavailableconfig']
            disaster_list_info = [disaster_info for disaster_info in high_list_info if
                                  '1' == disaster_info['disaster_switch']]
        else:
            log.info('database highavailableconfig is null')
        return disaster_list_info

    def clear_disaster_ha_ip(self, stor_nodes, disaster_list_info):
        """
        清理容灾高可用配置信息
        :return: Dict 返回灾备高可用信息
        """
        log.info('start to clear disaster high available info')

        if len(disaster_list_info) > 0:
            for disaster_info in disaster_list_info:
                log.info('start clear vip %s info', disaster_info['vip'])
                command = 'python %s %s %s %s 1>/dev/null 2>&1 && echo ok' % (
                    constant.ha_close_file, disaster_info['vip'], disaster_info['vrid'], "onebackup")
                multi_result = self.multi_thread_task(stor_nodes, command, ssh=True)
                # 检测灾备IP清除情况
                failed_nodes = list()
                for node, node_result in multi_result.iteritems():
                    if 'ok' != node_result:
                        failed_nodes.append(node)
                if len(failed_nodes) > 0:
                    log.error("failed to clear disaster high available IP in host '%s'", ','.join(
                        str(ip) for ip in failed_nodes))
                clear_result = database.del_obj('highavailableconfig', disaster_info['id'])
                if 'success' != clear_result['status']:
                    raise ONEBackupError('CLEAR_DISASTER_HA_FAILED', constant.OP_CLEAR_DISASTER_HA_FAILED)
                log.info('succeed to clear vip %s info', disaster_info['vip'])
        return disaster_list_info

    def clear_disaster_network_info(self):
        """
        清除集群所有主机ceph.conf内灾备网字段，cluster_hosts内灾备网IP字段
        :return:None
        """
        # 清理节点ceph.conf内的灾备字段
        cluster_hosts_info = self.exec_local_cmd_json("ceph config-key get cluster_hosts")
        self.multi_thread_task([host_info['hostip'] for host_info in cluster_hosts_info],
                               constant.CMD_REMOVE_DISATER_NETWORK, ssh=True)
        # 清理数据库表
        for host_info in cluster_hosts_info:
            if const.DISASTER_IP in host_info:
                del host_info[const.DISASTER_IP]
        self.exec_local_cmd("timeout 30 ceph config-key put cluster_hosts '%s'" % json.dumps(cluster_hosts_info))
        # 清理clusterconfig数据库表
        cluster_config = self.exec_local_cmd_json("ceph config-key get clusterconfig")
        if 'disaster_network' in cluster_config:
            del cluster_config['disaster_network']
        self.exec_local_cmd("timeout 30 ceph config-key put clusterconfig '%s'" % json.dumps(cluster_config))

    def restart_disaster_ha_nodes(self, disaster_list_info=None):
        """
        重启灾备高可用节点supervisor进程
        :return:
        """
        disaster_used_list = disaster_list_info if None != disaster_list_info else self.get_disaster_info()
        if len(disaster_used_list) > 0:
            high_hosts = list()
            for disaster_info in disaster_used_list:
                for ip, info in disaster_info['priority_list'].iteritems():
                    high_hosts.append(ip)
            # 增加重启Handy节点
            high_hosts = list(set(high_hosts))
            # local_ip = self.name_to_ip(self.exec_local_cmd("hostname"))
            # if local_ip not in high_hosts:
            #     high_hosts.append(local_ip)
            # handy_info = self.list_handyha()['handyha']
            # if len(handy_info) > 0:
            #     if handy_info[0]['master_public_ip'] not in high_hosts:
            #         high_hosts.append(handy_info[0]['master_public_ip'])
            #     if handy_info[0]['slave_public_ip'] not in high_hosts:
            #         high_hosts.append(handy_info[0]['slave_public_ip'])
            self.multi_thread_task(high_hosts, "supervisorctl restart onebackup:scheduler", ssh=True)
        self.exec_local_cmd("supervisorctl restart onebackup:scheduler")

    def clear_disaster_ha_conf(self):
        """
        清理可能残留的灾备高可用IP配置
        :return:
        """
        log.info("clear disaster ha conf")
        # 获取集群所有节点
        cluster_hosts_info = self.exec_local_cmd_json("ceph config-key get cluster_hosts")
        cluster_list = [host_info['hostip'] for host_info in cluster_hosts_info]
        clear_result_list = self.multi_thread_task(cluster_list, constant.CMD_CLEAR_DISASTER_HA, ssh=True)
        for host, clear_result in clear_result_list.iteritems():
            if 'NETWORK_FAULT' == clear_result:
                log.error("host %s is unreachable", host)
            if 'True' != clear_result and 'NETWORK_FAULT' != clear_result:
                log.error("clear cluster result is: \n%s", clear_result_list)
                return False
        return True

    def open_disaster_rollback(self):
        """
        开启容灾失败回退，不再抛出异常
        """
        log.info("open disaster failed, begin to rollback")
        # 清理容灾基本环境信息，删除灾备池
        result = send_request_onestord('COMP_CS', 'POOL_delete', {'pool_name': constant.BACKUP_POOL_NAME})
        log.info("delete disaster default pool result is: \n", result)
        # 清理灾备网段信息
        self.clear_disaster_network_info()
        log.info("open disaster rollback end")

    def check_open_status(self):
        """
        检查灾备池是否为异常开启状态，
        :return: True代表正常或回退成功，False代表失败
        """
        process_info = self.record_onestor_process()
        if 'error' != process_info['status']:
            # 检查是否完成开启，若未完成则回退
            disaster_info = process_info['data']
            status = disaster_info['status']
            if constant.OP_OPEN_DISASTER == disaster_info['operation'] and 'end' != status:
                log.error('open disaster failed, current process is %s', disaster_info['operation_process'])
                self.open_disaster_rollback()
                self.record_onestor_process(constant.OP_OPEN_DISASTER, status='end')
                return False
        else:
            log.warning('check open disaster status failed, reason is %s', process_info['reason'])
        return True

    def check_disaster_health(self):
        """
        检查灾备池健康情况
        :return: True代表正常，False代表异常
        """
        # 获取灾备存储池的ID
        backup_pool_id = self.exec_local_cmd(cmd.CMD_GET_BACKUP_POOL_ID)
        # 获取集群异常状态PG ID
        pool_list = self.get_ceph_pg_id()
        # 若灾备池不健康，则返回不健康的失败结果
        if backup_pool_id in pool_list:
            return False
        return True

    def check_disaster_hostinfo_reason(self):
        """
        检查获取灾备池信息失败原因
        :return: Dict
        """
        if not self.check_disaster_health():
            return {'status': 'error', 'reason': constant.OP_DISASTER_POOL_NOT_HEALTH}
        else:
            return {'status': 'error', 'reason': constant.OP_READ_DISASTER_POOL_ERROR}
