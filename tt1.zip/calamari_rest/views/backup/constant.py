# coding:utf-8


"""
定义常量
"""

OP_LIST = 'list'
OP_CREATE = 'create'
OP_UPDATE = 'update'
OP_DELETE = 'delete'

# 灾备文件路径
HANDY_SHELL_PATH = '/var/lib/ceph/shell'
BACKUP_SHELL_PATH = '/var/lib/ceph/shell/onebackup'
ha_close_file = "/var/lib/ceph/shell/close_tgt_ha.py"

# 备份池名称
BACKUP_POOL_NAME = ".backup"
FILTER_HOST_IP_CMD = "ip addr | grep brd | grep 'inet ' |grep -v ' lo' |awk '{print $2}' |cut -d / -f 1"
# 重写灾备网段配置
CMD_WRITE_DISASTER_NETWORK = '/opt/h3c/bin/python /var/lib/ceph/shell/onestor.py write_disaster_network {0}'
CMD_REMOVE_DISATER_NETWORK = '/opt/h3c/bin/python /var/lib/ceph/shell/onestor.py remove_disaster_network'
# 获取并删除灾备高可用配置
CMD_CLEAR_DISASTER_HA = '/opt/h3c/bin/python /var/lib/ceph/shell/onestor.py clear_disaster_ha_info'

# 操作日志内容
DEFAULT_OPERATION_LOG = u'服务器内部错误'
DEFAULT_ERROR_REASON = u'操作失败，详见系统日志'
NULL_PARAM = u'输入参数“{0}”为空'
INVALID_PARAM = u'输入参数“{0}”的格式不合法'

OP_RESTORE_SNAP = u'对块设备“{0}”恢复快照'
OP_SYNC_ALL_SNAP = u'同步主备站点所有块设备的快照'
OP_CLEAR_TASK = u'清空块设备“{0}”的所有任务'
OP_MANUAL_BACKUP = u'对块设备“{0}”执行手动备份'
OP_STOP_BACKUP = u'停止块设备“{0}”的备份任务'
OP_CREATE_BACKUP_BLOCK = u'创建备份块“{0}”'
OP_UPDATE_BACKUP_BLOCK = u'修改备份块“{0}”的备份策略'
OP_REMOVE_BACKUP_BLOCK = u'删除备份块“{0}”'
OP_CONTINUE_RESTORE = u'继续恢复备份块“{0}”'

OP_DISCONNECT_STATION = u'断开{0}的连接'
OP_SWITCH_STATION = u'切换为{0}'
OP_EXCHANGE_STATION = u'主备站点相互切换'

OP_DISASTER_POOL_NOT_HEALTH = u'灾备池状态异常，获取主机列表失败'
OP_READ_DISASTER_POOL_ERROR = u'获取容灾拓扑配置失败'

# 容灾操作日志内容
OP_NOT_EXIST_DISATER_IP = u'获取存储节点“{0}”灾备网失败'
OP_WRITE_DISASTER_FAILED = u'灾备网段配置写入失败'
OP_NETWORK_ERROR = u'主机“{0}”有网络故障'
OP_CLEAR_DISASTER_HA_FAILED = u'清理灾备高可用失败'
OP_CLEAR_DISASTER_BLOCK_FAILED = u'清理灾备存储块失败'
OP_INIT_BACK_POOL_FAILED = u'初始化灾备信息失败'


# 操作日志名称
OP_CREATE_DISATER_INFO = u'开启容灾'
OP_CLEAR_DISATER_INFO = u'关闭容灾'
OP_OPEN_DISASTER = 'open_disaster'

# 校验正则表达式
checkRegExp = dict()
checkRegExp['original_log_block'] = checkRegExp['backup_log_block'] = \
    checkRegExp['block_name'] = checkRegExp['backup_block_name'] = \
    r'(^[A-Za-z0-9][A-Za-z0-9\_\-\.]{0,29})+(/)+([A-Za-z0-9][A-Za-z0-9\_\-\.]{0,29}$)'
checkRegExp['snap_name_log_block'] = \
    r'(_onebackup_)+({[\d]+}_)+({[\d\.]+})+(_{[\s\S]*})+(_{[\s\S]*})+(_{[\s\S]*})'

# 校验非空字段，key为方法名称，value为需要校验的字段
required_item = dict()
required_item['restore_backup_block'] = ['original_log_block', 'backup_log_block', 'snap_name_log_block']
required_item['clear_backup_task'] = ['block_name']
required_item['manual_backup'] = required_item['stop_backup'] = required_item['get_snap_list'] = \
    required_item['remove_backup_block'] = ['block_name', 'backup_block_name']
