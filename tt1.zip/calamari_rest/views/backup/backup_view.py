# -*- coding:utf-8 -*-
import time
import logging
from onebackup import util
from onebackup import const
from onebackup import metadata
from calamari_rest.views.onestor import database
from calamari_rest.views.onestor_common import ONEBackupError, ONEStorCommon
from calamari_rest.views.backup import constant, utils, messanger
# PN: 201703020555 标准版的正式license，可以使用纠删码功能
from calamari_rest.decorator import module_required
# end by l11544 2017/4/21

log = logging.getLogger('django.request')

"""
    Author: dai.xinchun@h3c.com
    Date: 2016/06/30
    Description: ONEStor异地灾备管理类
"""


class BackupBaseViewSet(ONEStorCommon):
    def __init__(self, *args, **kwargs):
        super(BackupBaseViewSet, self).__init__(*args, **kwargs)

    def __format_backup_time(self, backup_time):
        """
        格式化备份时间0:8为00:08的形式
        :params backup_time 备份时间，如"8:15"
        :return str 如"08:15"
        """
        new_time = ['0{}'.format(_time) if 1 == len(_time) else _time for _time in backup_time.split(' : ')]
        return ' : '.join(new_time)

    def _set_backup_time(self, device_info):
        """
        设置备份时间策略信息
        """
        backup_interval = []
        quantum_weekday = []

        for time_slice in device_info['backup_time_slice']:
            if time_slice['start_week'] == 0:
                all_time_slice = dict()
                all_time_slice['start'] = self.__format_backup_time(
                    str(time_slice['start_hour']) + ' : ' + str(time_slice['start_min']))
                all_time_slice['end'] = self.__format_backup_time(
                    str(time_slice['end_hour']) + ' : ' + str(time_slice['end_min']))
                backup_interval.append(all_time_slice)
            else:
                all_time_slice = dict()
                all_time_slice['weekday'] = time_slice['start_week']
                all_time_slice['start_time'] = self.__format_backup_time(
                    str(time_slice['start_hour']) + ' : ' + str(time_slice['start_min']))
                all_time_slice['stop_time'] = self.__format_backup_time(
                    str(time_slice['end_hour']) + ' : ' + str(time_slice['end_min']))
                quantum_weekday.append(all_time_slice)

        device_info['backup_interval'] = backup_interval
        device_info['quantum_weekday'] = quantum_weekday
        return device_info

    @staticmethod
    def _set_block_type(backup_pool, target_info, device_info):
        """
        设置块设备类型，数据块or日志块
        """
        # 获取agent信息
        agents = backup_pool.agent.to_json()
        # 从agent信息中获取块设备列表
        device_info['block_info'] = dict()
        blocks_found = []
        agent_addr = None
        for agent in agents:
            for block in agent['blockdevices']:
                if block['target'] == target_info['target'] and int(block['lun_id']) == int(target_info['lun_id']):
                    blocks_found = agent['blockdevices']
                    agent_addr = agent['address']
                    break

        for block in blocks_found:
            if block['target'] == target_info['target'] and int(block['lun_id']) == int(target_info['lun_id']):
                device_info['device_type'] = block['device_type']
                device_info['block_info']['type'] = block['device_type']
                device_info['block_info']['agent_addr'] = agent_addr
            else:
                device_info['block_info']['pair'] = '{0}_lun_{1}'.format(block['target'], block['lun_id'])

        # 如果该块设备既不是数据块，也不是日志块，则清空pair信息
        if 'type' not in device_info['block_info'] and 'pair' in device_info['block_info']:
            del device_info['block_info']['pair']

        return device_info

    def _set_device_block_info(self, device):
        """
        设置块设备信息
        """
        is_primary = metadata.is_primary()
        # 获取异地灾备配置信息
        backup_pool = metadata.BackupPool()
        # 获取状态信息
        status = backup_pool.status.to_json()

        device_info = dict()
        device_info['original_block'] = device['primary_info']['name']
        device_info['target_info'] = device['target_info']
        device_info['is_need_agent'] = device['is_need_agent']

        device_info['backup_block'] = device['secondary_info']['name']
        device_info['strategy'] = device['primary_info']['strategy']
        device_info['is_primary'] = is_primary
        device_info['status'] = status['status']
        device_info['backup_time_slice'] = device['primary_info']['strategy']['backup_time_slice']
        device_info['is_open'] = device['primary_info']['strategy']['enable']

        # 设置块设备类型
        device_info = self._set_block_type(backup_pool, device['target_info'], device_info)
        # 设备备份时间策略
        device_info = self._set_backup_time(device_info)

        if is_primary:
            devicestatus = backup_pool.get_devicestat(device_info['original_block'])
        else:
            devicestatus = backup_pool.get_devicestat(device_info['backup_block'])

        if devicestatus is not None:
            if not devicestatus.progress['tosnap_size']:
                device_info['progress'] = 0
            else:
                # 备份块任务进度
                finish_value = util.calculate_interval_length(devicestatus.progress[const.DS_FINISH_INTERVAL])
                device_info['progress'] = float(finish_value) / float(devicestatus.progress['tosnap_size'])
            if not devicestatus.progress['timestamp']:
                device_info['time_convert'] = ''
            else:
                get_time = time.localtime(float(devicestatus.progress['timestamp']))
                device_info['time_convert'] = time.strftime("%Y-%m-%d %H:%M:%S", get_time)
            if devicestatus.progress.get('error_message'):
                device_info['error_msg'] = devicestatus.progress['error_message']
            else:
                device_info['error_msg'] = ''
            device_info['task_type'] = devicestatus.progress['task_tp']
            device_info['task_par_type'] = \
                devicestatus.progress['task_par_tp'] if 'task_par_tp' in devicestatus.progress else None
            device_info['task_status'] = devicestatus.progress['task_status']
        else:
            device_info['task_type'] = ''
            device_info['progress'] = 0
            device_info['time_convert'] = ''
            device_info['task_status'] = ''
        return device_info

    @utils.send_response(constant.OP_LIST)
    def list_backup_blocks(self, request, fsid):
        """
        获取备份块列表，并从元数据中获取备份块状态
        """
        backup_pool = metadata.BackupPool()
        # 获取所有的块设备
        devicelist = backup_pool.blockdevices.to_json()
        # 处理后返回给页面
        return [self._set_device_block_info(device) for device in devicelist]

    @utils.send_response(constant.OP_LIST)
    def get_snap_list(self, request, fsid):
        """
        获取主备站点所有的快照
        """
        block_name = request.GET.get('block_name', None)
        backup_block_name = request.GET.get('backup_block_name', None)

        # 校验入参是否合法
        utils.process_validate_params(request.GET, 'get_snap_list')

        return messanger.send_list_all_snap_msg(block_name, backup_block_name)

    @utils.send_response(constant.OP_LIST)
    def get_secondary_rbd_list(self, request, fsid):
        """
        获取备站点所有的Pool和RBD
        """
        return messanger.send_list_all_rbd_msg()

    @utils.send_response()
    def restore_backup_block(self, request, fsid):
        """
        根据所选快照，进行数据恢复
        """
        # 日志块信息
        original_log_block = str(request.DATA.get('original_log_block', None))
        backup_log_block = str(request.DATA.get('backup_log_block', None))
        snap_name_log_block = str(request.DATA.get('snap_name_log_block', None))

        # 数据块信息
        original_data_block = str(request.DATA.get('original_data_block', None))
        backup_data_block = str(request.DATA.get('backup_data_block', None))
        snap_name_data_block = str(request.DATA.get('snap_name_data_block', None))

        # 将操作日志的内容返回
        yield constant.OP_RESTORE_SNAP.format(original_log_block)

        # 校验入参是否合法
        yield request.DATA

        # 获取灾备块所属target的target_id
        disaster_name = original_log_block.split('/')[1]
        target_id = utils.get_disaster_target_info(disaster_name)

        # 查看灾备Target是否被使用
        if self._is_backup_target_used(target_id):
            raise ONEBackupError("Target is used.", "恢复快照失败，存储卷所在的Target已经被挂载")

        # 发送消息给scheduler
        messanger.send_restore_block_msg(
            original_log_block, backup_log_block, snap_name_log_block,
            original_data_block, backup_data_block, snap_name_data_block, target_id
        )

        yield

    @utils.send_response()
    def continue_restore(self, request, fsid):
        """
        继续恢复
        """
        block_name = request.DATA.get('block_name', None)
        backup_block_name = request.DATA.get('backup_block_name', None)

        # 将操作日志的内容返回
        yield constant.OP_CONTINUE_RESTORE.format(block_name)

        # 校验入参是否合法
        yield request.DATA

        # 发送消息给scheduler
        messanger.send_continue_restore_msg(block_name, backup_block_name)

        yield

    @utils.send_response()
    def sync_backup_block(self, request, fsid):
        """
        同步所有备份块的快照到备站点
        """
        # 将操作日志的内容返回
        yield constant.OP_SYNC_ALL_SNAP

        # 发送消息给scheduler
        messanger.send_sync_snap_msg()

        yield

    @utils.send_response()
    def clear_backup_task(self, request, fsid):
        """
        根据所选备份块，进行清空任务
        """
        block_name = request.GET.get('block_name', None)

        # 将操作日志的内容返回
        yield constant.OP_CLEAR_TASK.format(block_name)

        # 校验入参是否合法
        yield request.GET

        # 发送消息给scheduler
        messanger.send_clear_task_msg(block_name)

        yield

    @utils.send_response()
    def manual_backup(self, request, fsid):
        """
        手动备份
        """
        block_name = request.DATA.get('block_name', None)
        backup_block_name = request.DATA.get('backup_block_name', None)

        # 将操作日志的内容返回
        yield constant.OP_MANUAL_BACKUP.format(block_name)

        # 校验入参是否合法
        yield request.DATA

        # 发送消息给scheduler
        messanger.send_manual_backup_msg(block_name, backup_block_name)

        yield

    @utils.send_response()
    def stop_backup(self, request, fsid):
        """
        停止备份
        """
        block_name = request.DATA.get('block_name', None)
        backup_block_name = request.DATA.get('backup_block_name', None)

        # 将操作日志的内容返回
        yield constant.OP_STOP_BACKUP.format(block_name)

        # 校验入参是否合法
        yield request.DATA

        # 发送消息给scheduler
        messanger.send_stop_backup_msg(block_name, backup_block_name)

        yield

    @utils.send_response()
    def create_backup_block(self, request, fsid):
        """
        创建备份块
        """
        pool_name = request.DATA.get('pool_name', None)
        rbd_name = request.DATA.get('rbd_name', None)
        backup_pool = request.DATA.get('backup_pool', None)
        backup_rbd = request.DATA.get('backup_rbd', None)

        is_need_agent = request.DATA.get('is_need_agent', None)
        is_need_clear_snap = request.DATA.get('is_need_clear_snap', None)

        is_enabled = bool(request.DATA.get('is_open', False))
        interval_unit = request.DATA.get('interval_unit', None)
        host_retention_time = request.DATA.get('host_retention_time', '')
        alternate_retention_time = request.DATA.get('alternate_retention_time', '')
        host_backup_interval = request.DATA.get('host_backup_interval', '')
        host_backup_start_time = request.DATA.get('host_backup_start_time', None)
        host_backup_stop_time = request.DATA.get('host_backup_stop_time', None)
        quantum_weekday = request.DATA.get('quantum_weekday', None)

        block_name = pool_name + '/' + rbd_name
        backup_block_name = backup_pool + '/' + backup_rbd

        # 将操作日志的内容返回
        yield constant.OP_CREATE_BACKUP_BLOCK.format(block_name)

        # TODO 校验入参是否合法
        yield request.DATA

        # 从请求参数中获取Target的信息
        target_info = utils.set_target_info(request.DATA)

        # 备份策略参数
        strategy = {
            'is_enabled': is_enabled,
            'interval_unit': interval_unit,
            'host_retention_time': host_retention_time,
            'alternate_retention_time': alternate_retention_time,
            'host_backup_interval': host_backup_interval,
            'host_backup_start_time': host_backup_start_time,
            'host_backup_stop_time': host_backup_stop_time,
            'quantum_weekday': quantum_weekday
        }

        # 从请求参数中获取备份策略信息
        backup_strategy, backup_interval = utils.set_backup_strategy(
            block_name, backup_block_name, strategy, target_info, is_need_agent)

        # 发送消息给scheduler清除残留的快照
        if is_need_clear_snap:
            messanger.send_clear_snap_msg(block_name, backup_block_name)

        # 发送消息给scheduler创建备份块
        messanger.send_create_strategy_msg(backup_strategy)

        # 将创建的备份块保存到数据库中
        params = [
            pool_name,
            rbd_name,
            backup_pool,
            backup_rbd,
            host_retention_time,
            alternate_retention_time,
            backup_interval,
            target_info,
            block_name,
            backup_block_name,
            is_enabled
        ]
        database.add_obj('disasterBackup', params)

        yield

    @utils.send_response()
    def update_backup_block(self, request, fsid):
        """
        修改备份块的备份策略
        """
        block_name = request.DATA.get('block_name', None)
        backup_block_name = request.DATA.get('backup_block_name', None)

        host_retention_time = request.DATA.get('host_retention_time', '')
        host_backup_interval = request.DATA.get('host_backup_interval', '')
        alternate_retention_time = request.DATA.get('alternate_retention_time', '')

        interval_unit = request.DATA.get('interval_unit', None)
        host_backup_start_time = request.DATA.get('host_backup_start_time', None)
        host_backup_stop_time = request.DATA.get('host_backup_stop_time', None)
        quantum_weekday = request.DATA.get('quantum_weekday', None)
        is_enabled = bool(request.DATA.get('is_open', False))

        # 将操作日志的内容返回
        yield constant.OP_UPDATE_BACKUP_BLOCK.format(block_name)

        # TODO 校验入参是否合法
        yield request.DATA

        # 备份策略参数
        strategy = {
            'is_enabled': is_enabled,
            'interval_unit': interval_unit,
            'host_retention_time': host_retention_time,
            'alternate_retention_time': alternate_retention_time,
            'host_backup_interval': host_backup_interval,
            'host_backup_start_time': host_backup_start_time,
            'host_backup_stop_time': host_backup_stop_time,
            'quantum_weekday': quantum_weekday
        }

        # 从请求参数中获取备份策略信息
        backup_strategy, backup_interval = utils.set_backup_strategy(block_name, backup_block_name, strategy)

        # 发送消息给scheduler
        messanger.send_modify_strategy_msg(backup_strategy)

        # 将备份块更新到数据库中
        database.update_one('disasterBackup', {
            'original_block': block_name,
            '$set': {
                'host_retention_time': host_retention_time,
                'backup_interval': backup_interval,
                'alternate_retention_time': alternate_retention_time,
                'is_open': is_enabled
            }
        })

        yield

    @utils.send_response()
    def remove_backup_block(self, request, fsid):
        """
        删除备份块
        """
        block_name = request.GET.get('block_name', None)
        backup_block_name = request.GET.get('backup_block_name', None)

        # 将操作日志的内容返回
        yield constant.OP_REMOVE_BACKUP_BLOCK.format(block_name)

        # 校验入参是否合法
        yield request.GET

        # 发送消息给scheduler
        messanger.send_remove_strategy_msg(block_name, backup_block_name)

        # 从数据库中删除备份块
        database.delete_one('disasterBackup', [{'original_block': block_name}])

        yield

    def _is_backup_target_used(self, target_id):
        result = self.onestor_request_all_node('is_target_used', target_id)
        all_idle = True
        for used in result['error']:
            if used == 'True':
                all_idle = False
        if not all_idle:
            return True
        else:
            return False
