# -*- coding:utf-8 -*-

import time
import logging
import datetime
from onebackup import util
from onebackup import const
from onebackup import metadata
from onebackup import connect
from onebackup import scheduler
from calamari_rest.views.onestor_common import ONEBackupError, ONEStorCommon
from calamari_rest.views.backup import constant
from calamari_rest.decorator import logging_to_file

onestor_common = ONEStorCommon()

log = logging.getLogger('django.request')

"""
    Author: dai.xinchun@h3c.com
    Date: 2016/07/28
    Description: ONEStor异地灾备消息发送器
"""


@logging_to_file
def send_restore_block_msg(original_log_block, backup_log_block, snap_name_log_block, original_data_block,
                           backup_data_block, snap_name_data_block, target_id=None):
    """
    发送消息给scheduler开始还原
    """
    data_block = None

    # 如果是达梦数据库，需要联动还原数据块的信息
    if '{DB}' == snap_name_log_block.split('_')[4] and '{dm}' == snap_name_log_block.split('_')[5]:
        data_block = {
            'name': original_data_block,
            'back_name': backup_data_block,
            'snap_name': snap_name_data_block
        }

    # 发送消息给scheduler进行日志块的还原
    log_block = {
        'name': original_log_block,
        'target_id': target_id,
        'back_name': backup_log_block,
        'snap_name': snap_name_log_block,
        'union_restore': data_block
    }

    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_RESTORE_SNAP)
    scheduler_request.data = log_block
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_restore_block_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_sync_snap_msg():
    """
    发送消息给scheduler开始同步
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_SYNC_DATA_TO_SECONDARY)
    scheduler_request.data = {
        'all': True
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_sync_snap_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_clear_task_msg(block_name):
    """
    发送消息给scheduler开始清理任务
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_CLEAR_TASK)
    scheduler_request.data = {
        'name': block_name
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_clear_task_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_manual_backup_msg(block_name, backup_block_name):
    """
    发送消息给scheduler开始手动备份
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_MANUAL_BACKUP)
    scheduler_request.data = {
        'name': block_name,
        'back_name': backup_block_name
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_manual_backup_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_stop_backup_msg(block_name, backup_block_name):
    """
    发送消息给scheduler开始停止备份
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_STOP_BACKUP_MANUAL)
    scheduler_request.data = {
        'name': block_name,
        'back_name': backup_block_name
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_stop_backup_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_continue_restore_msg(block_name, backup_block_name):
    """
    发送消息给scheduler开始继续恢复
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_CONTINUE_RESTORE)
    scheduler_request.data = {
        'name': block_name,
        'back_name': backup_block_name
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_continue_restore_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


def send_list_all_rbd_msg():
    """
    发送消息给scheduler获取备站点所有的RBD
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_GET_RBD_LIST)
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_list_all_rbd_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])

    # 过滤掉无效的Pool
    del result_msg.data['.MSG_reserved']

    return {
        'all_pool': result_msg.data.keys(),
        'all_result': result_msg.data
    }


def _parse_snapshot(result_msg, site, result):
    """
    格式化快照名称
    """
    which_site = '本地' if const.PRIMARY == site else '远端'
    for snap_name in result_msg.data[site]:
        parsed_result = util.parse_snapshot_name(snap_name)
        snap_seq = parsed_result['snap_seq']
        # 将long型的时间格式化为可读类型
        timestamp = time.localtime(float(parsed_result['timestamp']))
        time_convert = time.strftime("%Y-%m-%d %H:%M:%S", timestamp)
        result.append({
            'snap_name': snap_name,
            'snap_seq': snap_seq,
            'display_name': '快照' + snap_seq + '：' + time_convert+'（{0}）'.format(which_site)
        })


def send_list_all_snap_msg(block_name, backup_block_name):
    """
    发送消息给scheduler获取主备站点所有的快照
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_GET_SNAP_LIST)
    scheduler_request.data = {
        'name': block_name,
        'back_name': backup_block_name
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_list_all_snap_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])

    result = []
    _parse_snapshot(result_msg, const.PRIMARY, result)
    _parse_snapshot(result_msg, const.SECONDARY, result)

    # 按照快照的编号进行排序
    result.sort(key=lambda snap: int(snap['snap_seq']), reverse=True)
    return {
        'all_snap': result
    }


@logging_to_file
def send_create_strategy_msg(backup_strategy):
    """
    发送消息给scheduler开始创建备份块
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_CREATE_STRATEGY)
    scheduler_request.data = backup_strategy
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_create_strategy_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_modify_strategy_msg(backup_strategy):
    """
    发送消息给scheduler开始修改备份块
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_MODIFY_STRATEGY)
    scheduler_request.data = backup_strategy
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_modify_strategy_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_remove_strategy_msg(block_name, backup_block_name):
    """
    发送消息给scheduler开始删除备份块
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_DELETE_STRATEGY)
    scheduler_request.data = {
        'name': block_name,
        'back_name': backup_block_name
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_remove_strategy_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_disconnect_station_msg(is_primary=None):
    """
    发送消息给scheduler开始断开主（备）站点
    """
    if is_primary is None:
        is_primary = metadata.is_primary()

    # 当前为主站点，则断开备站点；当前为备站点，则断开主站点
    msg_op = scheduler.schedulerops.OP_DISCONNECT_SECONDARY_STATIONS \
        if is_primary else scheduler.schedulerops.OP_DISCONNECT_PRIMARY_STATIONS

    scheduler_request = scheduler.schedulerops.make_request(msg_op)
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_disconnect_station_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_switch_station_msg(data, scheduler_address=None, is_primary=None):
    """
    发送消息给scheduler开始切换主（备）站点
    """
    if is_primary is None:
        is_primary = metadata.is_primary()

    # 当前为主站点，则切换为备站点；当前为备站点，则切换为主站点
    msg_op = scheduler.schedulerops.OP_SWITCH_TO_SECONDARY_STATIONS \
        if is_primary else scheduler.schedulerops.OP_SWITCH_TO_PRIMARY_STATIONS

    scheduler_request = scheduler.schedulerops.make_request(msg_op)
    scheduler_request.data = data
    result_msg = connect.send_to_scheduler(scheduler_request, scheduler_address)

    log.info('send_switch_station_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_clear_snap_msg(block_name, backup_block_name):
    """
    发送消息给scheduler开始清除快照
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_SNAP_REMOVE_ALL)
    scheduler_request.data = {
        const.PRIMARY: block_name,
        const.SECONDARY: backup_block_name
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_clear_snap_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_modify_station_msg(data, scheduler_address=None):
    """
    发送消息给scheduler开始修改主备站点
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_MODIFY_PRIMARY_STATIONS)
    scheduler_request.data = data
    # 主站点修改与主备连接使用handy到onebackup的同步消息处理，超时时间3小时。
    result_msg = connect.send_to_scheduler(scheduler_request, scheduler_address, 10800)

    log.info('send_modify_station_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


def _wait_for_exchange_station(is_primary=False, scheduler_address=None):
    """
    等待主备站点切换完成
    """
    backup_pool = metadata.BackupPool()
    pre_time = datetime.datetime.now()
    while True:
        log.info('Waiting 5 seconds for exchange station...')
        time.sleep(5)

        # 如果是主站点切换为备站点，需要给主站点发送断开备站点消息，如果报错则说明已经切换到备站点了
        if is_primary:
            try:
                send_disconnect_station_msg(is_primary)
            except ONEBackupError:
                break
        else:
            secondary_site_status = backup_pool.status.to_json()
            if 'normal' == secondary_site_status['status'] and metadata.is_primary():
                break

        new_time = datetime.datetime.now()
        if new_time - pre_time > datetime.timedelta(minutes=5):
            break


@logging_to_file
def send_exchange_station_msg(primary_ip, secondary_ip, proxy_data):
    """
    发送消息给scheduler一键切换主备站点
    """
    # step1: 断开主备站点
    send_disconnect_station_msg()

    # step2: 原主站点切换为备站点
    send_switch_station_msg({}, primary_ip, is_primary=True)

    # step3: 等待主站点切换为备站点完成
    _wait_for_exchange_station(is_primary=True)

    # step4: 原备站点切换为主站点
    send_switch_station_msg(proxy_data, secondary_ip, is_primary=False)

    # step5: 等待备站点切换为主站点完成
    _wait_for_exchange_station(is_primary=False)

    # step6: 在新的主站点上重连备站点
    data = {
        'scheduler_address': secondary_ip,
        'secondary_scheduler': primary_ip
    }
    send_modify_station_msg(data, secondary_ip)

    return primary_ip, secondary_ip


@logging_to_file
def send_modify_target_msg(target_name, iqn_switch, iqns):
    """
    ADD BY D10039 2016/09/02
    发送消息给scheduler开始修改修改Target
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_MODIFY_TARGET)
    scheduler_request.data = {
        'target_name': target_name,
        'iqn_switch': iqn_switch,
        'iqns': iqns
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_modify_target_msg primary result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])

    result_msg = connect.send_to_secondary_scheduler(scheduler_request)
    log.info('send_modify_target_msg secondary result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_create_onbackup_lun_msg(pool_name, rbd_name, target_name, lun_id):
    """
    发送消息给scheduler开始创建异地灾备卷
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_CREATE_ONEBACKUP_LUN)
    scheduler_request.data = {
        'name': '{0}/{1}'.format(pool_name, rbd_name),
        'target_info': {
            'lun_id': lun_id,
            'iqn_switch': '0',
            'target': target_name,
            'iqns': 'none',
        }
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_create_onbackup_lun_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_remove_onbackup_lun_msg(pool_name, rbd_name):
    """
    发送消息给scheduler开始删除异地灾备卷
    """
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_DELETE_ONEBACKUP_LUN)
    scheduler_request.data = {
        'name': '{0}/{1}'.format(pool_name, rbd_name)
    }
    result_msg = connect.send_to_scheduler(scheduler_request)

    log.info('send_remove_onbackup_lun_msg result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])


@logging_to_file
def send_add_backup_host_msg(disaster_ips):
    """
    发送消息给scheduler开始增加主机
    """
    try:
        scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_ADD_BACKUP_HOST)
        scheduler_request.data = {
            'backup_ip': disaster_ips
        }
        result_msg = connect.send_to_scheduler(scheduler_request)

        log.info('send_add_backup_host_msg result_msg: %s', result_msg)
        if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
            log.error('send_add_backup_host_msg error, reason is: %s', result_msg.result[1])
    except ONEBackupError as ex:
        log.error('oneback error, reason is %s', str(ex))
    except Exception as e:
        log.error('oneback add host error, reason is: %s', str(e))


@logging_to_file
def send_remove_backup_host_msg(disaster_ips):
    """
    发送消息给scheduler开始删除主机
    """
    try:
        scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_DELETE_BACKUP_HOST)
        scheduler_request.data = {
            'backup_ip': disaster_ips
        }
        result_msg = connect.send_to_scheduler(scheduler_request)
        log.info('send_remove_backup_host_msg result_msg: %s', result_msg)
        if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
            raise ONEBackupError(result_msg.result[1], result_msg.result[2])
    except ONEBackupError as ex:
        log.error('oneback error, reason is %s', str(ex))
        raise ONEBackupError(ex.errorcode, ex.reason)
    except Exception as e:
        log.error(e)
        raise ONEBackupError('DEFAULT_ERROR', constant.DEFAULT_ERROR_REASON)


@logging_to_file
def send_remove_disaster_info(disaster_list_info):
    """
    发送消息给scheduler开始删除主机
    """
    # 发送消息，删除灾备池信息
    scheduler_request = scheduler.schedulerops.make_request(scheduler.schedulerops.OP_CLOSE_DISASTER_RECOVERY)
    scheduler_request.data = {}
    scheduler_addr = "127.0.0.1" if not disaster_list_info else None
    result_msg = connect.send_to_scheduler(scheduler_request, scheduler_addr)

    log.info('send_remove_disater_info result_msg: %s', result_msg)
    if scheduler_request.req_id != result_msg.req_id or not result_msg.is_successful():
        raise ONEBackupError(result_msg.result[1], result_msg.result[2])
