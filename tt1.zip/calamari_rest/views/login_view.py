#!/usr/bin/env python
# -*- coding:utf-8 -*-


import logging

LOG = logging.getLogger('django.request')

import time
from rest_framework import status
from calamari_rest.models import UserLoginPermitPersist


class LoginPermit:
    """
    用于限制客户端登录
    """

    def __init__(self, request):
        """
        初始化默认对象
        :param request: 网络请求封装对象
        :return: None
        """
        self.request = request
        self.client_ip = request.META.get("REMOTE_ADDR", '127.0.0.1')
        self.login_data_obj = UserLoginPermitPersist()
        self.time_now = int(time.time())
        self.last_info = self.login_data_obj.filter_ip_one(client_ip=self.client_ip)
        self.login_info = {
            'login_ip': self.client_ip,
            'login_count': 0,
            'last_login_time': self.time_now
        }

    def check_before_login(self):
        """
        在登录验证之前检查是否满足登录规则，即是否处于登录失败限制时间内
        :return: Dict
        {
            login_permit: True/False,
            error_status: {}
        }
        """
        if self.last_info:
            # 若连续登录间隔小于60秒，且上次登录次数大于3，则不允许再次登录
            if abs(self.time_now - self.last_info['last_login_time']) <= 60 and self.last_info['login_count'] > 3:
                LOG.info("login failed, and more than 3 times, please wait 60 seconds and try again")
                self.login_info['login_count'] = self.last_info['login_count']
                self.login_data_obj.update_or_save(self.login_info)
                return {
                    "login_permit": False,
                    "error_status": {
                        'message': u'连续登录失败超过3次，请1分钟后再重试。',
                        'errorcode': 'LOGIN_OVER_THREE_TIMES',
                        'message_en': 'Continuous landing failed more than 3 times, '
                                      'please wait one minute and try again.'
                    }
                }
        else:
            # 若未查询到，则初始化记录该次登录
            self.login_data_obj.update_or_save(self.login_info)

        return {"login_permit": True}

    def login_failed_record(self):
        """
        登录失败后，记录登录失败次数或更新上次登录时间戳
        :return: Dict
        """
        error_result = {
            'message': u'用户名或密码错误',
            'message_en': "Incorrect username or password.",
            'errorcode': 'USERNAME_OR_PASSWORD_ERROR'
        }
        # 处理上，连续1分钟以内，失败即加1，无论是否达到3次，一分钟之外，重新开始计数
        if not self.last_info or (self.time_now - self.last_info['last_login_time']) > 60:
            self.login_info['login_count'] = 1
        else:
            self.login_info['login_count'] = self.last_info['login_count'] + 1
            # 登录次数达到4次，则提示用户
            if self.login_info['login_count'] > 3:
                error_result['message'] = u'连续登录失败超过3次，请1分钟后再重试。'
                error_result['message_en'] = 'Continuous landing failed more than 3 times, ' \
                                             'please wait one minute and try again.'
        self.login_data_obj.update_or_save(self.login_info)
        LOG.info("login failed, client ip '%s' has logined %s times 1 minutes in a row",
                 self.client_ip, self.login_info['login_count'])
        return error_result

    def login_succeed_reset(self):
        """
        登录成功后，重置数据库表内记录
        :return:
        """
        self.login_info['login_count'] = 0
        self.login_data_obj.update_or_save(self.login_info)
        LOG.info("login succeed, reset client ip '%s' login times to zero", self.client_ip)
