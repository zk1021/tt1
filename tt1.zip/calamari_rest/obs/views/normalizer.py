import six
import base64
import binascii


PLAIN_TEXT = ['text/plain',
              'text/plain;charset=utf-8',
              'text/plain; charset=utf-8']
PLAIN_TEXT_CHARSETS = ['utf-8']
BINARY = ['application/octet-stream',]
SUPPORTED = PLAIN_TEXT + BINARY

INTERNAL_CTYPES = {'text/plain': 'text/plain',
                   'text/plain;charset=utf-8': 'text/plain',
                   'text/plain; charset=utf-8': 'text/plain',
                   'application/octet-stream': 'application/octet-stream'}

CTYPES_PLAIN = {'default': 'text/plain'}
CTYPES_BINARY = {'default': 'application/octet-stream'}
CTYPES_MAPPINGS = {'text/plain': CTYPES_PLAIN,
                   'application/octet-stream': CTYPES_BINARY,}




def encode_as_bytes(s, encoding='utf-8'):
    if isinstance(s, six.text_type):
        s = s.encode(encoding)
    return base64.b64encode(s)


def encode_as_text(s, encoding='utf-8'):
    encoded = encode_as_bytes(s, encoding=encoding)
    return encoded.decode('ascii')


def decode_as_bytes(encoded):
    if isinstance(encoded, bytes):
        encoded = encoded.decode('ascii')
    try:
        return base64.b64decode(encoded)
    except binascii.Error as e:
        # Transform this exception for consistency.
        raise TypeError(str(e))


def decode_as_text(encoded, encoding='utf-8'):
    decoded = decode_as_bytes(encoded)
    return decoded.decode(encoding)



def normalize_before_encryption(unencrypted, content_type, content_encoding,
                                secret_type, enforce_text_only=False):
    # Process plain-text type.
    if content_type in PLAIN_TEXT:
        # normalize text to binary and then base64 encode it
        if six.PY3:
            b64payload = base64.b64encode(unencrypted)
        else:
            unencrypted_bytes = unencrypted.encode('utf-8')
            b64payload = base64.b64encode(unencrypted_bytes)

    # Process binary type.
    else:
        if not content_encoding:
            b64payload = base64.encode(unencrypted)
        elif content_encoding.lower() == 'base64':
            b64payload = unencrypted
        elif enforce_text_only:
            raise Exception('Secret content encoding must be base64')
        else:
            raise Exception('Secret content encoding %s not supported' % content_encoding)

    return b64payload, content_type


def denormalize_after_decryption(unencrypted, content_type):

    # Process plain-text type.
    if content_type in PLAIN_TEXT:
        # normalize text to binary string
        try:
            unencrypted = decode_as_text(unencrypted)
        except UnicodeDecodeError:
            raise Exception('Secret Accept Not Supported: %s' % content_type)

    # Process binary type.
    elif content_type in BINARY:
        unencrypted = decode_as_bytes(unencrypted)
    else:
        raise Exception('Secret Content Type Not Supported: %s' % content_type)

    return unencrypted
