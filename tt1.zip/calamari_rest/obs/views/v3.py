#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
from calamari_rest.obs import leader_router
from calamari_rest.views.v3 import UniStorViewSet
from calamari_rest.views.common.forward import OPLOG_USER

LOG = logging.getLogger('django.request')


class ObjectStorViewSet(UniStorViewSet):

    def __init__(self, *args, **kwargs):
        super(ObjectStorViewSet, self).__init__(leader_router, *args, **kwargs)

    @staticmethod
    def get_url_path(request_path, fsid=''):
        LOG.debug("request path is {0}".format(request_path))
        if fsid:
            url_path = request_path.split(fsid + '/objectstorage')[1]
        elif 'onestor/objectstorage' in request_path:
            url_path = request_path.split('onestor/objectstorage')[1]
        else:
            url_path = request_path.split('v3/')[1]
        return url_path

    @staticmethod
    def before_request_um(comp_op, data, request):
        data[OPLOG_USER] = request.user.username
