#!/usr/bin/env python
# -*- coding: utf-8 -*-

import calamari_rest.views.v2
import calamari_rest.obs.views.v3
from django.conf.urls import patterns, url

urlpatterns = patterns(
    '',
    # 匹配onestor/(?P<fsid>[a-zA-Z0-9-]+)/objectstorage开头的所有URL
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/objectstorage', calamari_rest.obs.views.v3.ObjectStorViewSet.as_view(
        {'get': 'get_request', 'post': 'post_request', 'delete': 'delete_request', 'patch': 'patch_request'})),
)
