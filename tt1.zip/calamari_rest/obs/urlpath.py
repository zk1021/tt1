#!/usr/bin/env python
# -*- coding: utf-8 -*-

RGW = '/obs'
CLUSTER_POOL = '/cluster/pool'
USER = '/user'
KMS = '/kms'
TENANT = '/tenant'
TENANT_ME = '/tenant/me'
TENANT_PLAT_USERS = '/tenant/plat_users'
USER_KEY = '/user/key'
USER_DEL = '/user/delete'

HA_SERVICE = '/ha/service'
RGW_USED = '/obs/used'
RGW_COMPRESS = '/obs/compress'
RGW_CLOUD_SYNC = '/obs/cloudsync'

RGW_START = '/obs/start'
RGW_STOP = '/obs/stop'
RGW_LOG_COLLECTION_ENABLE = '/obs/ops_log_enable'
RGW_LOG_COLLECTION_DISABLE = '/obs/ops_log_disable'
RGW_ENCRYPT = '/obs/encrypt'


OBS_GROUP = '/obs/group'
OBS_BALANCE = '/obs/balance'
OBS_SERVER = '/obs/server'
OBS_VIPS = '/obs/vips'
OBS_CHECKVIPS = '/obs/checkvip'
OBS_CREATE_CHECKVIPS = '/obs/create/checkvip'
OBS_MODIFY_CHECKVIPS = '/obs/modify/checkvip'
OBS_CHECK_NEWHOST = '/obs/checkNewHost'

DASHBOARD_SUMMARY = '/dashboard/summary'
DASHBOARD_GRAPH = '/dashboard/graph'

BUCKET = '/bucket'
BUCKET_DEL = '/bucket/delete'
BUCKET_QUOTA = '/bucket/quota'
BUCKET_LIFECYCLE = '/bucket/lifecycle'
BUCKET_POLICY = '/bucket/policy'
BUCKET_WORM = '/bucket/worm'
BUCKET_SYNC = '/bucket/sync'
BUCKET_REFRESH = '/bucket/refresh'
BUCKET_LOG = '/bucket/log'
