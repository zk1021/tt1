#!/usr/bin/env python
# coding: utf-8

"""
模块装饰方法2
"""

import os
import time

import logging
LOG = logging.getLogger('django.request')


def retry(times=1, return_result=None, raise_exc=False):
    """
    此方法用于需要执行多次，降低风险的操作
    times:方法需要执行次数，默认一次
    raise_exc: 判断返回值是否抛异常，默认不抛异常
    return_result: 如果raise_exc为False,则返回return_result的值
    return:执行成功时，返回执行的结果，若多次执行仍失败则返回None
    """
    def retry_func(func):
        def retry_times(*args, **kwargs):
            if not os.path.exists('/etc/ceph/ceph.conf'):
                return func(*args, **kwargs)
            i = 0
            while i < times:
                try:
                    return func(*args, **kwargs)
                except Exception, e:
                    time.sleep(2)
                    i += 1
                    if i == times:
                        LOG.error('run func %s failed, the reason is: %s', func.__name__, e)
                        if raise_exc:
                            raise e
                        else:
                            return return_result
                    LOG.debug('run func %s failed, try again, try times is: %s', func.__name__, i+1)
        return retry_times
    return retry_func
