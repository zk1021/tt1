#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 太保监控接口
MR_CLUSTER = '/cluster'
MR_SERVER = '/server'
MR_POOL = '/pool'
MR_RGW = '/rgw'
MR_VOLUME = '/volume'
MR_CLUSTER_HEALTH_INFO = '/clusterHealthInfo'
MR_DISK_INFO = '/diskInfo'
MR_HOST_INFO = '/hostInfo'
