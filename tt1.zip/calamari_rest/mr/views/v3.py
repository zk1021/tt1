#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
from calamari_rest.mr import leader_router
from calamari_rest.views.v3 import UniStorViewSet

LOG = logging.getLogger('django.request')


class MRViewSet(UniStorViewSet):

    def __init__(self, *args, **kwargs):
        super(MRViewSet, self).__init__(leader_router, *args, **kwargs)

    @staticmethod
    def get_url_path(request_path, fsid=''):
        LOG.debug("request path is {0}".format(request_path))
        if fsid:
            url_path = request_path.split(fsid + '/mr')[1]
        elif 'onestor/mr' in request_path:
            url_path = request_path.split('onestor/mr')[1]
        else:
            url_path = request_path.split('v3/')[1]
        return url_path


