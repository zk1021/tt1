#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
common operation
"""

from calamari_common.config import CalamariConfig
config = CalamariConfig()

import os
import logging
import smtplib
from email.mime.text import MIMEText
from email.header import Header
import psycopg2
import paramiko
import threading
import re
import copy
import onestor
from onestor import message
from onestor import errno
from onestor.config import CephConf
from onestor.errno import ONEStorError
from onestor.plat.cm.ha import hamessage as hamsg
from onestor.sys import sysmessage as sysmsg
from onestor.plat.cm.host import hostmessage as hostmsg

from onestor.fs import fsmessage as fsmsg
from onestor.cs import csmessage as csmsg
from onestor.cm import cmmessage as cmmsg
from onestor.scrub import scrubmessage as scrubmsg
from onestor.fs import fsmessage

from onestor.opt import optmessage
from calamari_web import docker_get_leader_ip

log = logging.getLogger('django.request')

def delete_user(username):
    try:
        params = {
            'database': config.get('calamari_web', 'db_name'),
            'user': config.get('calamari_web', 'db_user'),
            'password': config.get('calamari_web', 'db_password'),
            'host': config.get('calamari_web', 'db_host')
        }
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        cur.execute("SELECT * FROM auth_user WHERE username='%s'" % username)
        result = cur.fetchall()
        if result != []:
            _id = result[0][0]
            cur.execute("DELETE FROM account_profile WHERE user_id='%s'" % _id)
        cur.execute("DELETE FROM auth_user WHERE username='%s'" % username)
        conn.commit()
        conn.close()
    except Exception, e:
        raise e


def is_name(data):
    if data.startswith(' ') or data.endswith(' '):
        return False
    if len(data) > 0 and len(data) < 31:
        return True
    return False


def is_email(email):
    if email.startswith(' ') or email.endswith(' '):
        return False
    if re.match(r'^([a-zA-Z0-9\_\-\.])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-]+)+$', email):
        return True
    return False


def is_phone(phone):
    if phone.startswith(' ') or phone.endswith(' '):
        return False
    if re.match(r'^(1[3|4|5|7|8|][0-9]\d{8}|(\d{3,4}-?)?\d{7,8})$', phone):
        return True
    return False


# 新增邮件告警特性发送邮件方法
# 函 数 名 : send_mail
# 创建日期 ：2016年1月15日
# 作 者 ：党妮 d11564
# 函数描述 ：邮件告警特性发送邮件方法
# 输入参数 ：serverAddress,portNumber,senderAddress,userName,passWord,to_list,sub,content
# 输出参数 ：成功返回status 为success，失败返回status 为error 原因 reason
# 返 回 值 ：success或者error，失败原因
# 注意事项 :
# ------------------------------------------------------------------
# 修改历史
# 日期 姓名 描述
# --------------------------------------------------------------------
def send_mail(params, to_list, sub, content,format='plain'):
    # begin modify by d11564 PN:201703220394 邮件乱码
    if isinstance(content, unicode):
        content = unicode(content)

    mail_host = params[0]
    mail_port = params[1]
    mail_user = params[3]
    mail_pass = params[4]
    # mail_address = mail_user+"<"+params[2]+">"
    mail_address = ("%s<"+params[2]+">") %(Header(mail_user, 'utf-8'))
    msg = MIMEText(content, format, 'utf-8')
    if not isinstance(sub, unicode):
        sub = unicode(sub)
    msg['Subject'] = sub
    msg['From'] = mail_address
    msg['To'] = ";".join(to_list)
    msg['Accept-Language'] = "zh-CN"
    msg['Accept-Charset'] = "ISO-8859-1, utf-8"
    # end modify by d11564 PN:201703220394 邮件乱码
    # MODIFY BY KF6602 2016/9/23 PN:201608040523
    server = smtplib.SMTP(timeout=60)

    err_msg = ''

    try:
        # ADD BY KF6602 2016/8/10 PN: 201608040523
        response = server.connect(mail_host, mail_port)
    except KeyError:
        err_msg = u'连接邮件服务器参数错误'
    except Exception:
        err_msg = u'无法连接邮件服务器'
    # BEGIN ADD BY KF6602 2016/8/10 PN: 201608040523
    else:
        if response[0] == -1:
            err_msg = u'无法连接邮件服务器'
    # END ADD BY KF6602 2016/8/10 PN: 201608040523

    if '' != err_msg:
        return {'status':'error', 'reason': err_msg}

    try:
        server.login(mail_user, mail_pass)
    except KeyError:
        err_msg = u'用户名或密码参数错误'
    except Exception:
        err_msg = u'用户名或密码不正确'

    if '' != err_msg:
        return {'status':'error', 'reason': err_msg}

    try:
        server.sendmail(mail_address, to_list, msg.as_string())
    except KeyError:
        return {'status':'error', 'reason': u'发送邮件参数错误'}
    except Exception:
        return {'status': 'error', 'reason': u'发送邮件失败'}
    else:
        return {'status': 'success'}
    finally:
        server.close()

SSH_PORT = 22
FTP_PORT = 22
LIST_DISK_SHELL = '/opt/h3c/salt/salt/shell/list_disk.sh'

def gethost_by_ip(host, user, passwd, result, lock):
    try:
        #get ssh connection
        s = paramiko.SSHClient()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        s.connect(host, SSH_PORT, user, passwd)

        scan_host_command = 'hostname && lsb_release -d && ls /etc/ceph/ceph.conf'

        #get the hostinfo {'connect': True, 'hostname', 'linux_version', 'cluster_exist': True}
        stdin, stdout, stderr = s.exec_command(scan_host_command)
        scan_host_ret = stdout.read().rstrip()
        host_info = {}
        scan_ret_array = scan_host_ret.splitlines()
        host_info['connect'] = True
        host_info['hostname'] = scan_ret_array[0]
        host_info['linux_version'] = scan_ret_array[1].split('Description:')[1].strip()
        if len(scan_ret_array) == 2:
            host_info['cluster_exist'] = False
        else:
            host_info['cluster_exist'] = True

        if user == None:
            stdin, stdout, stderr = s.exec_command("cat /etc/ssh/sshd_config | "\
                "grep UseDNS | wc -l")
            if '1' != stdout.read().rstrip():
                s.exec_command('echo UseDNS no >> /etc/ssh/sshd_config && '\
                    'service ssh restart')
            stdin, stdout, stderr = s.exec_command('bash /var/lib/ceph/shell/list_disk.sh')
            disk_ret = stdout.read().rstrip()
        else:
            t = paramiko.Transport((host, FTP_PORT))
            t.connect(username=user, password=passwd)
            sftp = paramiko.SFTPClient.from_transport(t)

            #move '/opt/h3c/salt/salt/shell/list_disk.sh' to /tmp/list_disk.sh and get disk_ret
            stdin, stdout, stderr = s.exec_command("cat /etc/ssh/sshd_config | grep UseDNS | wc -l")
            if '1' != stdout.read().rstrip():
                s.exec_command('echo UseDNS no >> /etc/ssh/sshd_config && service ssh restart')
            sftp.put(LIST_DISK_SHELL, '/tmp/list_disk.sh')
            stdin, stdout, stderr = s.exec_command('chmod 777 /tmp/list_disk.sh && bash /tmp/list_disk.sh')
            disk_ret = stdout.read().rstrip()
            s.exec_command('rm -rf /tmp/list_disk.sh')

        #set host_info
        host_info['disks'] = {}
        disk_ret = disk_ret.split('-->')[1]
        if disk_ret != '':
            disk_arr = disk_ret.split(';')
            for disk in disk_arr:
                temp = re.split(r'[\s:,]*', disk)
                disk_detail = {}
                name = temp[1]
                disk_detail['name'] = name
                disk_detail['size_byte'] = temp[4]
                disk_detail['type'] = temp[6]
                host_info['disks'][name] = disk_detail

    except KeyError:
        host_info = {'connect': False}
    except:
        host_info = {'connect': False}
    finally:
        with lock:
            result[host] = host_info
        try:
            s.close()
            t.close()
        except IOError:
            pass
        except:
            pass
        return

def get_host_info(hosts, user=None, passwd=None):
    result = {}
    lock = threading.Lock()
    t_records = []
    for host in hosts:
        t = threading.Thread(target=gethost_by_ip, args=(host, user, passwd, result, lock))
        t.start()
        t_records.append(t)
    for t in t_records:
        t.join()
    return result


#add by s11435 start
def get_onestor_host():
    with open('/etc/onestor_hosts', 'rt') as onestor_host_file:
        host_arr = onestor_host_file.read().strip().splitlines()
        host_arr = [list(reversed(host.split()[:2])) for host in host_arr if host and not host.strip().startswith('#')]
        return dict(host_arr)
#add by s11435 end


def make_request(comp, op):
    """
    request生成器
    :param comp: 模块名
    :param op：操作名
    """

    def _make_request(data):
        """
        闭包函数，根据操作码生成对应组件下的request请求
        """
        if message.COMP_CS == comp:
            _request = csmsg.make_request(op)
        elif message.COMP_SCRUB == comp:
            _request = scrubmsg.make_request(op)
        # begin add by d11564 2017/10/20 多MDS项目
        elif message.COMP_FS == comp:
            _request = fsmessage.make_request(op)
        # end add by d11564 2017/10/20 多MDS项目
        elif message.COMP_CM == comp:
            _request = cmmsg.make_request(op)
        elif message.COMP_HOST == comp:
            _request = hostmsg.make_request(op)
        else:
            raise ONEStorError(errno.ERR_INVALID_OP)
        _request.data = data
        return _request

    return _make_request


def get_model_timeout(comp, op):
    """
    获取超时时间
    :return:
    """
    _timeout = 80
    if message.COMP_HA == comp:
        _timeout = hamsg.estimate_time(op)
    elif message.COMP_SYS == comp:
        _timeout = sysmsg.estimate_time(op)
    elif message.COMP_HOST == comp:
        _timeout = hostmsg.estimate_time(op)
    elif message.COMP_LB == comp:
        _timeout = fsmsg.estimate_time(op)
    elif message.COMP_FS == comp:
        _timeout = fsmsg.estimate_time(op)
    elif message.COMP_SCRUB == comp:
        _timeout = scrubmsg.estimate_time(op)
    elif message.COMP_CS == comp:
        _timeout = csmsg.estimate_time(op)
    return _timeout


def filter_password(data, password_list=None):
    """
    实现具体过滤（即："password"："QWRtaW5AMTIz" 转为 "password"："******"）
    :param data：源数据
    :param password_list：过滤关键字列表(密码) 一般为：passwd、password
    return
    """
    try:
        if password_list and len(password_list):
            data = copy.deepcopy(data)
            data = do_filter(data, password_list)
        return data
    except Exception as e:
        log.exception(e)
        return data


def do_filter(data, filter_key_list):
    """
    实现具体过滤
    :param data：源数据
    :param filter_key_list：过滤关键字列表
    return
    """
    if isinstance(data, (dict, list)):
        # 字典&列表 类型
        for key in data:
            if isinstance(data[key], dict):
                do_filter(data[key], filter_key_list)
            elif isinstance(data[key], list):
                for ele_in_list in data[key]:
                    do_filter(ele_in_list, filter_key_list)
            else:
                if key in filter_key_list:
                    data[key] = "******"
    elif isinstance(data, str):
        # 字符串类型
        for key in filter_key_list:
            reg_template = r"[\'\"]{}[\'\"]:\s*u?[\'\"].*?[\'\"],".format(key)
            content_template = "\'{}\': \'******\',".format(key)
            tmp_str = re.subn(reg_template, content_template, data)
            data = tmp_str[0]
    return data


def send_request_onestord(comp, op, data, model='cs', need_log=False):
    """
    handy server send request to onestord
    :param comp：模块名
    :param op：操作名
    :param data：数据
    :param need_log：是否打印日志（默认打印）
    return
    """
    try:
        if need_log:
            content = filter_password(data, ["passwd", "password"])
            log.info('start request onestord <COMP:{0}, OP:{1}>, the params is {2}'.format(comp, op, content))
        timeout_1 = get_model_timeout(comp, op)
        if CephConf().multicluster_ip is None:
            client = onestor.message.Messenger.create_leaderclient(
                host='localhost', timeout=timeout_1)
        else:
            if os.path.exists("/.dockerenv"):
                _host = docker_get_leader_ip()
            else:
                _host = '127.0.0.1'
            client = onestor.message.Messenger.create_multicluster_client(
                host=_host, timeout=timeout_1)
        if client is None:
            result = {'result': errno.ERR_CONNECT}
            return {'status': 'error', 'response': result}
        request_forward = make_request(comp, op)(data)
        response = client.send_request(request_forward)
        if need_log:
            log.info('end request onestord <COMP:{0}, OP:{1}>, the response is {2}'.format(comp, op, response))
        return {'status': 'success', 'response': response.to_json()}
    except Exception as e:
        log.exception(e)
        return {'status': 'error', 'response': u'请求onestord失败'}
