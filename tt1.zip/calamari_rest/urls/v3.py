#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.conf.urls import patterns, url, include
from rest_framework import routers
import calamari_rest.views.v1
import calamari_rest.views.v2
# ADD BY D10039 2016/09/07 FOR HANDY REFACTORY
from calamari_rest.views.common import forward

import calamari_rest.views.host.host_view as host
import calamari_rest.views.deploy.deploy_view as deploy
import calamari_rest.views.host.mon_view as mon
# ADD BY KF6602 for maintain
import calamari_rest.views.host.maintain_view as maintain

from calamari_rest.views.backup import backup_view, station_view
# ADD by D10039 2016/08/05 用户管理和用户组管理支持Handy HA
from calamari_rest.views.usermanage import group_view, user_view
from calamari_rest.views.ha import ha_view
from calamari_rest.views.obs import rgw_view

from calamari_rest.views.sso import sso_view
from calamari_rest.views.sso import sso_api
from calamari_rest.views.lics import lics_view
router = routers.DefaultRouter(trailing_slash=False)

# Presentation of django.contrib.auth.models.User
router.register(r'user', calamari_rest.views.v1.UserViewSet)

# Information about each Ceph cluster (FSID), see sub-URLs
router.register(r'cluster', calamari_rest.views.v2.ClusterViewSet, base_name='cluster')

urlpatterns = patterns(
    '',
    # 获取任务队列
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/cm/task$', calamari_rest.views.v2.ONEStorViewSet.as_view({
        'get': 'get_task_info'
    })),
    # 获取任务队列中任务数量
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/cm/task/num$', calamari_rest.views.v2.ONEStorViewSet.as_view({
        'get': 'get_task_num'
    })),
    url(r'^grains', calamari_rest.views.v2.grains),
    url(r'^info', calamari_rest.views.v1.Info.as_view()),
    url(r'^auth/login', calamari_rest.views.v1.login),
    url(r'^auth/logout', calamari_rest.views.v1.logout),
    # ADD BY D10039 2017/01/5 License支持特性区分
    url(r'^auth/modules$', calamari_rest.views.v1.AuthModule.as_view({'get': 'get'})),
    url(r'^permission/create', calamari_rest.views.v2.PermissionManage.as_view({'post': 'create_permission'})),
    url(r'^permission/list', calamari_rest.views.v2.PermissionManage.as_view({'get': 'permission_list'})),
    url(r'^permission/user', calamari_rest.views.v2.PermissionManage.as_view({'get': 'permission_user'})),
    # This has to come after /user/me to make sure that special case is handled
    url(r'^', include(router.urls)),

    # About ongoing operations in cthulhu
    url(r'^request/(?P<request_id>[a-zA-Z0-9-]+)/cancel$',
        calamari_rest.views.v2.RequestViewSet.as_view({'post': 'cancel'}),
        name='request-cancel'),
    url(r'^request/(?P<request_id>[a-zA-Z0-9-]+)$',
        calamari_rest.views.v2.RequestViewSet.as_view({'get': 'retrieve'}),
        name='request-detail'),
    url(r'^request$',
        calamari_rest.views.v2.RequestViewSet.as_view({'get': 'list'}),
        name='request-list'),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/request/(?P<request_id>[a-zA-Z0-9-]+)$',
        calamari_rest.views.v2.RequestViewSet.as_view({'get': 'retrieve'}),
        name='cluster-request-detail'),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/request$',
        calamari_rest.views.v2.RequestViewSet.as_view({'get': 'list'}),
        name='cluster-request-list'),

    # OSDs, Pools, CRUSH
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/crush_map$',
        calamari_rest.views.v2.CrushMapViewSet.as_view({'get': 'retrieve', 'post': 'replace'}),
        name='cluster-crush_map'),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/crush_rule_set$',
        calamari_rest.views.v2.CrushRuleSetViewSet.as_view({'get': 'list'}),
        name='cluster-crush_rule_set-list'),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/crush_rule$',
        calamari_rest.views.v2.CrushRuleViewSet.as_view({'get': 'list'}),
        name='cluster-crush_rule-list'),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/crush_node$',
        calamari_rest.views.v2.CrushNodeViewSet.as_view({'get': 'list', 'post': 'create'}),
        name='cluster-crush_node-list'),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/crush_node/(?P<node_id>-?\d+)$',
        calamari_rest.views.v2.CrushNodeViewSet.as_view({'get': 'retrieve', 'patch': 'update', 'delete': 'destroy'}),
        name='cluster-crush_node-detail'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/pool$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'post': 'createPool'}),
        name='onestor-pool'),
    # add by z11524
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/poolcheck$',
        calamari_rest.views.v2.PoolViewSet.as_view({'get': 'check_rootSsd'}),
        name='cluster-pool-list'),
    # end by z11524
    # add by l11544
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/poolInfo$',
        calamari_rest.views.v2.PoolViewSet.as_view({'get': 'poolInfoAll'}),
        name='cluster-pool-list'),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/poolIdList$',
        calamari_rest.views.v2.PoolViewSet.as_view({'get': 'get_pool_id_info'}),
        name='cluster-pool-id-list'),
    # end by l11544
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/pool/(?P<pool_id>\d+)$',
        calamari_rest.views.v2.PoolViewSet.as_view({'get': 'retrieve',
                                                    'patch': 'update',
                                                    'delete': 'destroy'}),
        name='cluster-pool-detail'),

    # Direct access to SyncObjects, mainly for debugging
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/sync_object$',
        calamari_rest.views.v2.SyncObject.as_view({'get': 'describe'}),
        name='cluster-sync-object-describe'),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/sync_object/(?P<sync_type>[a-zA-Z0-9-_]+)$',
        calamari_rest.views.v2.SyncObject.as_view({'get': 'retrieve'}),
        name='cluster-sync-object'),
    url(r'^server/(?P<fqdn>[a-zA-Z0-9-\.]+)/debug_job',
        calamari_rest.views.v2.DebugJob.as_view({'post': 'create'}),
        name='server-debug-job'),

    # All about servers
    url(r'^key$', calamari_rest.views.v2.SaltKeyViewSet.as_view(
        {'get': 'list', 'patch': 'list_partial_update', 'delete': 'list_destroy'})),
    url(r'^key/(?P<minion_id>[a-zA-Z0-9-\.]+)', calamari_rest.views.v2.SaltKeyViewSet.as_view(\
        {'get': 'retrieve', 'patch': 'partial_update', 'delete': 'destroy'})),

    url(r'^server$',
        calamari_rest.views.v2.ServerViewSet.as_view({'get': 'list'})),
    url(r'^server/(?P<fqdn>[a-zA-Z0-9-\.]+)$',
        calamari_rest.views.v2.ServerViewSet.as_view({'get': 'retrieve', 'delete': 'destroy'})),
    url(r'^server/(?P<fqdn>[a-zA-Z0-9-\.]+)/grains$',
        calamari_rest.views.v2.ServerViewSet.as_view({'get': 'retrieve_grains'})),

    # Begin added by wuxiangwei@h3c.com
    url(r'^server/(?P<fqdn>[a-zA-Z0-9-\.]+)/command$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'post': 'apply'})),

    url(r'^server/(?P<fqdn>[a-zA-Z0-9-\.]+)/filesync$',
        calamari_rest.views.v2.ServerViewSet.as_view({'post': 'sync'})),

    url(r'^server/(?P<fqdn>[a-zA-Z0-9-\.]+)/salt/config$',
        calamari_rest.views.v2.ServerViewSet.as_view({'post': 'salt_config'})),

    url(r'^server/(?P<fqdn>[a-zA-Z0-9-\.]+)/salt/cp$',
        calamari_rest.views.v2.ServerViewSet.as_view({'post': 'salt_cp'})),
    # End added by wuxiangwei@h3c.com
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/server/(?P<fqdn>[a-zA-Z0-9-\.]+)$',
        calamari_rest.views.v2.ServerClusterViewSet.as_view({'get': 'retrieve'}),
        name='cluster-server-detail'),

    # Ceph configuration settings
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/config$',
        calamari_rest.views.v2.ConfigViewSet.as_view({'get': 'list'})),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/config/(?P<key>[a-zA-Z0-9_]+)$',
        calamari_rest.views.v2.ConfigViewSet.as_view({'get': 'retrieve'})),

    # Events
    url(r'^event$',
        calamari_rest.views.v2.EventViewSet.as_view({'get': 'list'})),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/event$',
        calamari_rest.views.v2.EventViewSet.as_view({'get': 'list_cluster'})),
    url(r'^server/(?P<fqdn>[a-zA-Z0-9-\.]+)/event$',
        calamari_rest.views.v2.EventViewSet.as_view({'get': 'list_server'})),

    # Log tail
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/log$',
        calamari_rest.views.v2.LogTailViewSet.as_view({'get': 'get_cluster_log'})),
    url(r'^server/(?P<fqdn>[a-zA-Z0-9-\.]+)/log$',
        calamari_rest.views.v2.LogTailViewSet.as_view({'get': 'list_server_logs'})),
    url(r'^server/(?P<fqdn>[a-zA-Z0-9-\.]+)/log/(?P<log_path>.+)$',
        calamari_rest.views.v2.LogTailViewSet.as_view({'get': 'get_server_log'})),

    # Ceph CLI access
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/cli$',
        calamari_rest.views.v2.CliViewSet.as_view({'post': 'create'})),

    # add by d10039 start
    url(r'^command', calamari_rest.views.v2.LocalCmd.as_view({'post': 'execute'})),

    url(r'^netdisk/upload', calamari_rest.views.v2.NetDiskViewSet.as_view({'post': 'upload'})),
    url(r'^netdisk/download/(?P<dir>[\s\S]+)/(?P<filename>[\s\S]+)', \
        calamari_rest.views.v2.NetDiskViewSet.as_view({'get': 'download'})),
    url(r'^netdisk/list/(?P<dir>[\s\S]+)', calamari_rest.views.v2.NetDiskViewSet.as_view({'get': 'list'})),
    url(r'^netdisk/remove/(?P<dir>[\s\S]+)/(?P<filename>[\s\S]+)', \
        calamari_rest.views.v2.NetDiskViewSet.as_view({'get': 'remove'})),
    url(r'^netdisk/addfloder/(?P<dir>[\s\S]+)/(?P<foldername>[\s\S]+)', \
        calamari_rest.views.v2.NetDiskViewSet.as_view({'get': 'add_floder'})),
    url(r'^netdisk/removefloder/(?P<foldername>[\s\S]+)', \
        calamari_rest.views.v2.NetDiskViewSet.as_view({'get': 'remove_floder'})),
    url(r'^netdisk/createuser/(?P<username>[\s\S]+)', \
        calamari_rest.views.v2.NetDiskViewSet.as_view({'post': 'create_user'})),
    url(r'^netdisk/createcontainer/(?P<containername>[\s\S]+)', \
        calamari_rest.views.v2.NetDiskViewSet.as_view({'post': 'create_container'})),
    url(r'^netdisk/changepasswd', calamari_rest.views.v2.NetDiskViewSet.as_view({'post': 'change_password'})),
    url(r'^netdisk/geturl', calamari_rest.views.v1.ShareView.as_view()),
    url(r'^netdisk/makeurl', calamari_rest.views.v2.NetDiskViewSet.as_view({'get': 'make_temp_url'})),
    url(r'^netdisk/cancelshare', calamari_rest.views.v2.NetDiskViewSet.as_view({'get': 'cancel_share'})),

    url(r'^host/connect', calamari_rest.views.v2.HostConfigViewSet.as_view({'post': 'connect_host'})),
    url(r'^ceph/install', calamari_rest.views.v1.InstallView.as_view()),
    url(r'^log/collect', calamari_rest.views.v2.HostConfigViewSet.as_view({'get': 'collect_logs'})),
    # ADD BY D10039 2016/05/27 PN:201605130545 修改为apache下载日志
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/systemLogURL$', calamari_rest.views.v2.HostConfigViewSet.as_view({
        'get': 'collect_logs'})),
    # add by d10039 end

    # Add by d10039 2015/07/14 ONEStor start
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/rbd$', calamari_rest.views.v2.ONEStorViewSet.as_view(\
        {'get': 'getRbdlistsFromDB', 'post': 'createRbd', 'patch': 'resize'}), name='cluster-rbd-list'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/patchRbd$', calamari_rest.views.v2.ONEStorViewSet.as_view(\
        {'patch': 'patchRbd'}), name='cluster-rbd-list'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/space$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'space'}),
        name='cluster-space'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/poolpg$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'count_pg'}),
        name='onestor-pool'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/clusterInfo$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'clusterInfo'}),
        name='onestor-clusterInfo'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/getFlashCacheSize$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'getFlashCacheSize'}),
        name='getFlashCacheSize'),
    # Add by d10039 2015/07/14 ONEStor end

    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/disasterHAConf$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({
            'get': 'list_disasterha_conf',
            'post': 'create_disasterha_conf'}),
        name='disasterHAConf'),

    # BEGIN MODIFY by D10039 2016/08/05 For Handy HA
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/ha$', ha_view.HaViewSet.as_view({
        'get': 'list_ha_cfg',
        'post': 'create_ha_cfg',
        'delete': 'remove_ha_cfg',
        'patch': 'modify_ha_cfg'
    })),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/ha/manage_network$', ha_view.HaViewSet.as_view({
        'post': 'create_manage_network'
    })),

    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/ha/handy/ip$', ha_view.HaViewSet.as_view({
        'get': 'get_self_manage_ip',
    })),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/progress$', ha_view.HaViewSet.as_view({
        'get': 'get_current_progress',
    })),
    url(r'^onestor/backupPsql', ha_view.HaViewSet.as_view({
        'post': 'auto_backup_psql',
    })),
    url(r'^onestor/deployNtp$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'deploy_ip_check'}),
        name='onestor-cephInfo'),

    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/DisasterAvailable$',
        calamari_rest.views.v2.ONEStorViewSet.as_view(
            {'post': 'create_disater_available', 'patch': 'patch_disater_available'}),
        name='DisasterAvailable'),

    # BEGIN ADD BY KF6602 2016/12/22 for maintain
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/maintain/status$',
        maintain.MaintainViewSet.as_view({'get': 'get_maintain_status'}),
        name='maintain_status'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/maintain/open$',
        maintain.MaintainViewSet.as_view({'post': 'open_maintain_mode'}),
        name='open_maintain'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/maintain/close$',
        maintain.MaintainViewSet.as_view({'post': 'close_maintain_mode'}),
        name='close_maintain'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/maintain/config$',
        maintain.MaintainViewSet.as_view({'get': 'get_maintain_config'}),
        name='get_maintain_config'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/maintain/switch$',
        maintain.MaintainViewSet.as_view({
            'get': 'get_maintain_switch',
            'post': 'switch_maintain_mode'
        }),
        name='switch_maintain_mode'),
    # END ADD BY KF6602 2016/12/22 for maintain

    # Add by f11523 2015/7/22 start
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/cluster/status$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'check_cluster_status'}),
        name='check_cluster_status'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/getlogs$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'collect_system_log'}),
        name='collectSystemLog'),

    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/flashCachelist$',
        calamari_rest.views.v2.OsdViewSet.as_view({'get': 'flashCachelist'}),
        name='flashCachelist'),

    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/target$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'listTarget', 'post': 'createTarget',
                                                       'delete': 'removeTarget', 'patch': 'patchTarget'}),
        name='target'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/lunsInTarget$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'getLunsByTargetID'}),
        name='lunsInTarget'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/lun$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'listLUN', 'post': 'createLUN', 'delete': 'removeLUN'}),
        name='lun'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/dashboard$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'dashboard'}),
        name='dashboard'),
    url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/topo$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'topoInfo'}),
        name='topoInfo'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/systemLogExcelDownload$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'downSystemLogExcel'}),
        name='systemLogExcelDownload'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/systemLogDownload$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'downSystemLog'}),
        name='systemLogDownload'),
    url(r'^onestor/scanHost$', calamari_rest.views.v2.HostConfigViewSet.as_view({'post': 'scanHost'})),
    url(r'^onestor/scanHostInfo$', calamari_rest.views.v2.HostConfigViewSet.as_view({'get': 'scanHostInfo'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/health$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'health'}),
        name='health'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/journalSize$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'journalSize'}),
        name='journalSize'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/gatewayPool$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'patch': 'updateGatewayPool'}),
        name='gatewayPool'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/validate/mask$',
        host.HostViewSet.as_view({'post': 'validate_netmask'}), name='validate_netmask'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/bucketInfo$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'bucketInfo'}),
        name='bucketInfo'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/poolcapacity$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'getClusterCapacityV3'}),
        name='poolcapacity'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/lunStatus$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'getLunStatus'}),
        name='getLunStatus'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/publicNetwork$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'publicNetwork'}),
        name='publicNetwork'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/timezone$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'getTimeZone'}),
        name='getTimeZone'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/remoteCmd$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'post': 'execteRemoteCmd'}),
        name='execteRemoteCmd'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/clearRgw$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'delete': 'clearRadosGatewayDatas'}),
        name='clearRadosGatewayDatas'),
    url(r'^onestor/version$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'version'}),
        name='version'),
    url(r'^onestor/keepAlive$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'keepAlive'}),
        name='keepAlive'),
    # BEGIN ADD by d10039 2016/02/23 PN:201511070269
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/rbdToLun$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'post': 'convertRBDToLUN'}),
        name='convertRBDToLUN'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/lunToRbd$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'delete': 'convertLUNToRBD'}),
        name='convertLUNToRBD'),
    # END ADD by d10039 2016/02/23 PN:201511070269

    # BEGIN ADD by d10039 2016/03/03 PN:201601210379 批量删除硬盘先停止进程
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/stopDiskDaemon$',
        calamari_rest.views.v2.OsdViewSet.as_view({'post': 'stop_disk_daemon'}),
        name='stopDiskDaemon'),
    # END ADD by d10039 2016/03/03

    # BEGIN ADD by d10039 2016/06/16 PN:201606150545 增加批量导入用户功能开关
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/netdiskState$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'netdisk_state'}),
        name='netdisk_state'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/monSwitch$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'mon_op_switch'}),
        name='mon_op_switch'),
    # END ADD by d10039 2016/06/16
    # BEGIN ADD by KF6615 2017/07/19 PN:201707130264 获取系统时间
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/sysTime$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'get_sys_time'}),
        name='get_sys_time'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/partitionIsEmpty$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'post': 'partition_is_empty'}),
        name='partition_is_empty'),
    # END ADD by h13051 2017/02/21
    # ADD BY KF6602 2017/3/20 PN:201701110100 获取VIP
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/allVips$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'get_all_vips'}),
        name='get_all_vips'),

    # BEGIN ADD by d10039 2016/07/01 异地灾备URL
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/cfg$', station_view.BackupStationViewSet.as_view({
        'get': 'list_backup_cfg'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/role$', station_view.BackupStationViewSet.as_view({
        'get': 'list_backup_role'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/agent$', station_view.BackupStationViewSet.as_view({
        'get': 'list_backup_agent'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/host$', station_view.BackupStationViewSet.as_view({
        'get': 'list_backup_host'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/site/disconnect$', station_view.BackupStationViewSet.as_view({
        'patch': 'disconnect_station'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/site/switch$', station_view.BackupStationViewSet.as_view({
        'patch': 'switch_station'})),

    # add by l11544 容灾元数据兼容分区
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/disaster$', station_view.BackupStationViewSet.as_view({
        'get': 'disaster_used_info', 'post': 'create_disater_info', 'delete': 'clear_disater_info'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/blocks$', backup_view.BackupBaseViewSet.as_view({
        'get': 'list_backup_blocks'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/rbds/secondary$', backup_view.BackupBaseViewSet.as_view({
        'get': 'get_secondary_rbd_list'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/block/restore$', backup_view.BackupBaseViewSet.as_view({
        'patch': 'restore_backup_block', 'post': 'continue_restore'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/block/sync$', backup_view.BackupBaseViewSet.as_view({
        'patch': 'sync_backup_block'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/block/cleartask$', backup_view.BackupBaseViewSet.as_view({
        'delete': 'clear_backup_task'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/block/backup$', backup_view.BackupBaseViewSet.as_view({
        'post': 'manual_backup', 'patch': 'stop_backup'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/block/snaps$', backup_view.BackupBaseViewSet.as_view({
        'get': 'get_snap_list'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/block$', backup_view.BackupBaseViewSet.as_view({
        'post': 'create_backup_block', 'patch': 'update_backup_block', 'delete': 'remove_backup_block'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/onebackup/exchange$', station_view.BackupStationViewSet.as_view({
        'post': 'exchange_station'})),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/HighAvailable$',
        calamari_rest.views.v2.ONEStorViewSet.as_view(
            {'get': 'listHighAvailable', 'post': 'createHighAvailable',
             'delete': 'removeHighAvailable', 'patch': 'patchHighAvailable'}),
        name='HighAvailable'),
    # 开启关闭高可用
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/serverList$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'serverList'}),
        name='serverList'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/hastate$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'patch': 'enablehighavailable',  'post': 'disablehighavailable'}),
        name='hastate'),
    # END ADD by d10039 2016/07/01 异地灾备URL

)
urlpatterns += patterns(
    '',
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/request$',
        forward.ForwardView.as_view({'post': 'handle_request_message'})),
    url(r'^sso/casurl$', sso_view.get_cas_config_api),
    url(r'^sso/permissions$', sso_api.SsoApiSet.as_view({'get': 'query_permission_list'})),
    url(r'^sso/group$', sso_api.SsoApiSet.as_view({
        'get': 'query_group',
        'post': 'add_group',
        'patch': 'modify_group',
        'delete': 'delete_group'
    })),
    url(r'^sso/group/user$', sso_api.SsoApiSet.as_view({
        'get': 'query_user_list',
        'patch': 'associate_user_group',
        'post': 'create_user',
        'delete': 'delete_user'
    })),
    url(r'^onestor/onestor_conf$', calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'query_onestor_conf'}),
        name='query_onestor_conf'),
)
