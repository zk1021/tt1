#!/usr/bin/env python
# -*- coding: utf-8 -*-
from onestor.message import COMP_CM,COMP_CS
from onestor.cs import csmessage
from calamari_rest.views.common import const
import logging
LOG = logging.getLogger('django.request')


def response_adapter_v2_api(comp, op, response_data):
    '''
    适配onestor2.0 接口的响应参数
    :param comp: 组件名
    :param op: 操作码
    :param responseData: UniStor1.0 响应参数
    :return:
    '''
    if comp == COMP_CS:
        if op == csmessage.OP_RACK_QUERY:
            response_data = rack_query_response_adapter(response_data)
    return response_data


def request_adapter_v2_api(comp, op, data):
    '''

    :param comp:
    :param op:
    :param responseData:
    :return:
    '''
    if comp == COMP_CS:
        if op == csmessage.OP_RACK_CREATE:
            data = rack_create_request_adapter(data)
        if op == csmessage.OP_RACK_DELETE:
            data = rack_delete_request_adapter(data)
        if op == csmessage.OP_POOL_QUERY:
            data = pool_query_request_adapter(data)
    return data


def rack_query_response_adapter(response_data):
    rack_list = response_data['data']['rack_list']
    for rack in rack_list:
        rack['partition'] = const.DEFAULT
        rack['name'] = rack.pop('rack_name')
    return response_data


def rack_create_request_adapter(request_data):
    rack_info = {}
    rack_name = request_data['rack_list'][0]
    rack_info[rack_name] = 1
    request_data['rack_info'] = rack_info
    return request_data


def rack_delete_request_adapter(request_data):
    LOG.info(request_data)
    request_data['rack_name'] = request_data.pop('rackname')
    return request_data


def pool_query_request_adapter(request_data):
    '''
    适配查询存储池请求参数
    :param request_data:
          ONEStor 2.0接口 ： "data": {},
          UniStor 1.0接口： "data": {"diskpool_name": "", "application": ""}
    :return:
    '''
    request_data['diskpool_name'] = ''
    request_data['application'] = ''
    return request_data



