#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
from calamari_rest.views.v3 import UniStorViewSet
from calamari_rest.plat import leader_router

LOG = logging.getLogger('django.request')


class PlatViewSet(UniStorViewSet):

    def __init__(self, *args, **kwargs):
        super(PlatViewSet, self).__init__(leader_router, *args, **kwargs)

    @staticmethod
    def get_url_path(request_path, fsid=''):
        LOG.debug("request path is {0}".format(request_path))
        if fsid:
            url_path = request_path.split(fsid + '/plat')[1]
        elif 'onestor/plat' in request_path:
            url_path = request_path.split('onestor/plat')[1]
        elif 'v3/plat' in request_path:
            url_path = request_path.split('v3/plat')[1]
        else:
            url_path = request_path.split('v3/onestor')[1]
        return url_path

