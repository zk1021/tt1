#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
from calamari_rest.views.v3_allow_any import UniStorAllowAnyViewSet
from calamari_rest.plat import leader_router_allow_any

LOG = logging.getLogger('django.request')


class PlatAllowAnyViewSet(UniStorAllowAnyViewSet):

    def __init__(self, *args, **kwargs):
        super(PlatAllowAnyViewSet, self).__init__(leader_router_allow_any, *args, **kwargs)

    @staticmethod
    def get_url_path(request_path, fsid=''):
        LOG.debug("request path is {0}".format(request_path))
        if fsid:
            url_path = request_path.split(fsid + '/allowany/plat')[1]
        elif 'onestor/allowany/plat' in request_path:
            url_path = request_path.split('onestor/allowany/plat')[1]
        elif 'v3/allowany/plat' in request_path:
            url_path = request_path.split('v3/allowany/plat')[1]
        else:
            url_path = request_path.split('v3/onestor/allowany/')[1]
        return url_path
