#!/usr/bin/env python
# -*- coding: utf-8 -*-
from onestor.message import (
    COMP_CM,
    COMP_ALARM,
    COMP_UM
)
from onestor.plat.alarm import alarm_message
from onestor.cm import cmmessage
from calamari_rest.plat import urlpath
from onestor.plat.cm.usermanage import ummessage

# 查询各级别告警数量与TOP3告警详情
OP_ALARM_QUERY_TOP3 = (COMP_ALARM, alarm_message.OP_ALARM_GET_TOP3_REAL_TIME_ALARM_INFO)

# FULL SCREEN
OP_FLS_QUERY_CLUSTER = (COMP_CM, cmmessage.OP_FLS_QUERY_CLUSTER)    # 查询大屏展示集群数据

# 修改用户密码
OP_MODIFY_USER_PASSWD = (COMP_UM, ummessage.OP_MODIFY_USER_PASSWD)
url_get_op = {
    # full screen
    (urlpath.FULL_SCREEN_CLUSTER, 'GET'): OP_FLS_QUERY_CLUSTER,
    (urlpath.FULL_SCREEN_ALARM, 'GET'): OP_ALARM_QUERY_TOP3,
    (urlpath.HANDY_USER_PASSWORD, 'PATCH'): OP_MODIFY_USER_PASSWD
}
