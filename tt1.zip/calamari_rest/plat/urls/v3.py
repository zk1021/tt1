#!/usr/bin/env python
# -*- coding: utf-8 -*-
import calamari_rest.views.v2
import calamari_rest.plat.views.v3
import calamari_rest.plat.views.v3_allow_any
from django.conf.urls import patterns, url, include
from calamari_rest.views.lics import lics_view
from calamari_rest.plat import urlpath
import calamari_rest.views.host.mon_view as mon
import calamari_rest.views.host.host_view as host
from calamari_rest.views.sso import sso_view
from calamari_rest.views.obs import rgw_view
from calamari_rest.views.ha import ha_view
import calamari_rest.views.deploy.deploy_view as deploy

urlpatterns = patterns(
    '',
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/cephParam$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'post': 'post_ceph_param', 'get': 'get_ceph_param'}),
        name='onestor-cephInfo'),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/passwdParam$',
        calamari_rest.views.v2.ONEStorViewSet.as_view({'post': 'post_passwd_param', 'get': 'get_passwd_param'})),

    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/sso$', sso_view.SsoViewSet.as_view({
        'get': 'get_cas_config',
        'post': 'change_cas_config'
    })),
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/casurl$', sso_view.SsoViewSet.as_view({
        'get': 'get_cas_config_status',
    })),
    # 注册信息
    url(r'^onestor/license$', lics_view.generate_license),
    url(r'^onestor/download/license$', lics_view.download_license),
    url(r'^onestor/upload/license$', lics_view.upload_license),
    url(r'^onestor/info/license$', lics_view.query_license),
    url(r'^onestor/license/authcode$', lics_view.LicsViewSet.as_view({'get': 'export_auth_code'})),
    url(r'^onestor/license/backup$', lics_view.LicsViewSet.as_view({'get': 'backup_license'})),
    url(r'^onestor/preUpload/license', lics_view.pre_upload_license),
    url(r'^onestor/license/server/connect$', lics_view.connect_lics_server),
    url(r'^onestor/license/server/disconnect$', lics_view.disconnect_lics_server),
    url(r'^onestor/license/server/info$', lics_view.query_lics_server),
    url(r'^onestor/license/server/sync$', calamari_rest.plat.views.v3.PlatViewSet.as_view({'post': 'post_request'})),
    url(r'^onestor' + urlpath.CLUSTER_CREATE + '$',
        calamari_rest.plat.views.v3.PlatViewSet.as_view({'post': 'post_request'})),
    url(r'^onestor' + urlpath.AUTH_PERMISSION + '$',
        calamari_rest.plat.views.v3.PlatViewSet.as_view({'get': 'get_request'})),

    url(r'^onestor/plat/language', calamari_rest.plat.views.v3.PlatViewSet.as_view(
        {'post': 'post_request'})),
    # 匹配onestor/plat开头的所有URL
    url(r'^onestor/plat', calamari_rest.plat.views.v3.PlatViewSet.as_view(
        {'get': 'get_request', 'post': 'post_request', 'delete': 'delete_request', 'patch': 'patch_request'})),
    # 匹配onestor/(?P<fsid>[a-zA-Z0-9-]+)/plat开头的所有URL
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/plat', calamari_rest.plat.views.v3.PlatViewSet.as_view(
        {'get': 'get_request', 'post': 'post_request', 'delete': 'delete_request', 'patch': 'patch_request'})),
    # 匹配plat开头的所有URL
    url(r'^plat', calamari_rest.plat.views.v3.PlatViewSet.as_view(
        {'get': 'get_request', 'post': 'post_request', 'delete': 'delete_request', 'patch': 'patch_request'})),
    # 匹配onestor/allowany/plat开头的所有URL
    url(r'^onestor/allowany/plat', calamari_rest.plat.views.v3_allow_any.PlatAllowAnyViewSet.as_view(
        {'get': 'get_request', 'post': 'post_request', 'delete': 'delete_request', 'patch': 'patch_request'})),
    # 匹配onestor/(?P<fsid>[a-zA-Z0-9-]+)/allowany/plat开头的所有URL
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/allowany/plat', calamari_rest.plat.views.v3_allow_any.PlatAllowAnyViewSet.as_view(
        {'get': 'get_request', 'post': 'post_request', 'delete': 'delete_request', 'patch': 'patch_request'})),
    # 匹配allowany/plat开头的所有URL
    url(r'^allowany/plat', calamari_rest.plat.views.v3_allow_any.PlatAllowAnyViewSet.as_view(
        {'get': 'get_request', 'post': 'post_request', 'delete': 'delete_request', 'patch': 'patch_request'})),
)
