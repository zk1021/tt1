#!/usr/bin/env python
# -*- coding: utf-8 -*-
import calamari_rest.views.v2
import calamari_rest.views.host.host_view as host
from django.conf.urls import patterns, url, include
from calamari_rest.views.lics import lics_view
from calamari_rest.views.common import forward
import calamari_rest.views.host.mon_view as mon


urlpatterns = patterns(
    '',
    # # 注册信息接口
    # url(r'^onestor/license$', lics_view.generate_license),
    # url(r'^onestor/download/license', lics_view.download_license),
    # url(r'^onestor/upload/license', lics_view.upload_license),
    # url(r'^onestor/info/license', lics_view.query_license_v2),
    # url(r'^onestor/download/licsn', lics_view.LicsViewSet.as_view({'get': 'export_auth_code_v2'})),
    # url(r'^onestor/license/backup', lics_view.LicsViewSet.as_view({'get': 'backup_license'})),
    # # ONEStor2.0接口
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/request$',
    #     forward.ForwardView.as_view({'post': 'handle_request_message'})),
    # # 主机管理
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/server$',
    #     calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'serverInfo'}),
    #     name='serverInfo'),
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/server/v1$',
    #     calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'serverInfo'}),
    #     name='serverInfo'),
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/serverList$',
    #     calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'serverList'}),
    #     name='serverList'),
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/serverOne$',
    #     calamari_rest.views.v2.ONEStorViewSet.as_view({'get': 'serverInfoByFqdn'}),
    #     name='serverInfoByFqdn'),
    # url(r'^onestor/hostScanBatch$',
    #     calamari_rest.views.v2.HostConfigViewSet.as_view({'get': 'scanHostBatch'})),
    # url(r'^onestor/[a-zA-Z0-9-]+/scanHost$',
    #     calamari_rest.views.v2.HostConfigViewSet.as_view({'post': 'scanHost'})),
    # url(r'^onestor/scanHost$',
    #     calamari_rest.views.v2.HostConfigViewSet.as_view({'post': 'scanHost'})),
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/addHostManual$',
    #     host.HostViewSet.as_view({'post': 'add_host_single'}),
    #     name='add_host_single'),
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/addHostAuto$',
    #     host.HostViewSet.as_view({'post': 'add_host_batch'}),
    #     name='add_host_batch'),
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/removeHost$',
    #     host.HostViewSet.as_view({'delete': 'remove_host'}),
    #     name='remove_host'),
    # url(r'^onestor/scanExistHostDisk$',
    #     calamari_rest.views.v2.HostConfigViewSet.as_view({'get': 'scanExistHostDisk'})),
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/removeMon$',
    #     mon.MonViewSet.as_view({'delete': 'remove_mon'}),
    #     name='removeMon'),
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/addMon$',
    #     mon.MonViewSet.as_view({'post': 'add_mon'}),
    #     name='addMon'),
    # url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/addDisk$',
    #     host.HostViewSet.as_view({'post': 'add_disk'}),
    #     name='addDisk'),
    # url(r'^cluster/(?P<fsid>[a-zA-Z0-9-]+)/removeDisk$',
    #     host.HostViewSet.as_view({'patch': 'remove_disk'}),
    #     name='removeDisk'),
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/removeOSDEvent$',
    #     host.HostViewSet.as_view({'get': 'check_remove_osd_event'}),
    #     name='check_remove_osd_event'),
    # url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/removeStatus$',
    #     host.HostViewSet.as_view({'get': 'get_remove_status'}),
    #     name='removeStatus'),
)
