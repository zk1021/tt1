#!/usr/bin/env python
# -*- coding: utf-8 -*-

import calamari_rest.fs.views.v3
from django.conf.urls import patterns, url

urlpatterns = patterns(
    '',
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/filestorage', calamari_rest.fs.views.v3.FileStorViewSet.as_view(
        {'get': 'get_request', 'post': 'post_request', 'delete': 'delete_request', 'patch': 'patch_request'})),
)
