#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging

from calamari_rest.views.v3 import UniStorViewSet
from calamari_rest.fs import leader_router

LOG = logging.getLogger('django.request')


class FileStorViewSet(UniStorViewSet):

    def __init__(self, *args, **kwargs):
        super(FileStorViewSet, self).__init__(leader_router, *args, **kwargs)

    @staticmethod
    def get_url_path(request_path, fsid=''):
        if fsid:
            url_path = request_path.split(fsid + '/filestorage')[1]
        elif 'onestor/filestorage' in request_path:
            url_path = request_path.split('onestor/filestorage')[1]
        else:
            url_path = request_path.split('v3/')[1]
        return url_path
