#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
from rest_framework.response import Response
from calamari_rest.views.common.forward import ForwardView
from calamari_rest.fs import leader_router

LOG = logging.getLogger('django.request')


class FileStorViewV2Set(ForwardView):

    @staticmethod
    def get_nas_pool(request, fsid):
        comp_op = leader_router.OP_POOL_MANILA_QUERY
        response = ForwardView().send_request_to_leader(comp_op, unistor_api=False)
        if 0 == response['result'][0]:
            return Response({'status': 'success', 'data': response['data']})
        else:
            return Response({'status': 'error', 'reason': response['result'][2]})

    @staticmethod
    def get_nas_user(request, fsid):
        comp_op = leader_router.OP_USER_QUERY_MANILA
        data = request.GET
        response = ForwardView().send_request_to_leader(comp_op, data, unistor_api=False)
        if 0 == response['result'][0]:
            return Response({'status': 'success', 'data': response['data']})
        else:
            return Response({'status': 'error', 'reason': response['result'][2]})

    @staticmethod
    def get_nas_group(request, fsid):
        comp_op = leader_router.OP_NAS_QUERY_GROUPS_MANILA
        response = ForwardView().send_request_to_leader(comp_op, unistor_api=False)
        if 0 == response['result'][0]:
            return Response({'status': 'success', 'data': response['data']})
        else:
            return Response({'status': 'error', 'reason': response['result'][2]})
