#!/usr/bin/env python
# coding: utf-8

"""
模块装饰方法
"""

import functools
import os
import logging
from django.contrib.auth import logout
from rest_framework.response import Response
from rest_framework import status
from onestor.plat.lics import lics,lics_const
from calamari_rest.views.common import const, errno, op_log
from calamari_rest.views.common.op_log import OP_BS_ALL
from calamari_rest.views.common import util
from calamari_rest.views.onestor_common import ONEStorCommon
# add by l11544 2017/4/27
onestor_common = ONEStorCommon()
log = logging.getLogger('django.request')
# end


class DecorateUtil(ONEStorCommon):
    """
    装饰器工具方法
    """
    def __init__(self, *args, **kwargs):
        super(DecorateUtil, self).__init__(*args, **kwargs)

    @staticmethod
    def get_fun_param_name(op, request):
        """
        获取当前函数操作对象名称
        :param op: 函数名
        :Author l11544 li.shan@h3c.com
        :Date 2017/4/27
        :param request: 参数
        :return: String
        """
        snap_name_list = [const.OP_CREATE_SNAPSHOT, const.OP_BACK_SNAP]
        # target_name_list = [const.OP_CREATE_TARGET, const.OP_MODIFY_TARGET]
        rbd_name_list = [const.OP_CREATE_RBD, const.OP_RBD_TO_LUN]
        param_name = ''
        if 'GET' == request.method or 'DELETE' == request.method:
            if op == const.OP_REMOVE_SNAP:                  # 删除快照
                param_name = request.GET.get('snapshot_name')
            # elif op == const.OP_REMOVE_TARGET:              # 删除Target
            #     param_name = request.GET.get('target_name')
            elif op == const.OP_REMOVE_LUN:                 # 删除块
                param_name = request.GET.get('rbdName')
            elif op == const.OP_LUN_TO_RBD:                 # 转为块
                param_name = request.GET.get('rbd_name')
        else:
            if op in snap_name_list:                        # 创建和恢复快照
                param_name = request.DATA['snapshot_name']
            elif op == const.OP_CLONE_RBD:                  # 克隆块
                param_name = request.DATA['clone_name']
            elif op == const.OP_MODIFY_LUN:                 # 修改块
                param_name = request.DATA['rbd_name_old']
            elif op == const.OP_MODIFY_TARGET:              # 修改Target
                param_name = request.DATA['targetName']
            elif op == const.OP_CREATE_LUN:                 # 创建存储卷
                param_name = request.DATA['lunName']
            elif op in rbd_name_list:                       # 创建块和转为存储卷
                param_name = request.DATA['rbd_name']
        return param_name

    # OP_CREATE_LUN
    @staticmethod
    def need_astrict_rbd_space(op, request, param_name):
        """
        判断创建块时是否超出创建大小规格，暂定为64T, 若超出则返回失败
        :param op: 操作方法
        :param request: 参数对象
        :return: True代表需要限制, False代表不需要
        """
        astrict_op_list = [const.OP_CREATE_LUN, const.OP_CREATE_RBD, const.OP_MODIFY_LUN]
        # 如果是创建块设备，则检测块的大小
        if ('POST' == request.method or 'PATCH' == request.method) and op in astrict_op_list:
            if op == const.OP_CREATE_LUN:
                rbd_size = int(request.DATA['rbdSize'])
            elif op == const.OP_MODIFY_LUN:
                rbd_size = int(request.DATA['new_size'])
                log.info('rbd new size {}'.format(rbd_size))
            else:
                rbd_size = int(request.DATA['rbd_size'])
            if rbd_size > const.ASTRICT_RBD_DISPACE:
                log.error('rbd "%s" size over max diskapce: %s byte', param_name, const.ASTRICT_RBD_DISPACE)
                return True

        return False

    # def restrict_over_operation(self, op, request):
    #     """
    #     限制块存储块设备操作实体，根据所在分区
    #     :param op: 操作名称
    #     :param request: 参数对象
    #     :return: Dict, True代表超出， False代表未超出
    #     """
    #     over_space, pool_name = False, None
    #     partion_info_all, partion_name = self.partion_over_space(df_percent=const.HANDY_TOP_CMD_SPACE), None
    #     # 若存在集群硬盘占用超出，则获取相关操作涉及的存储池，池所属分区
    #     if partion_info_all['over_exist']:
    #         # 获取块存储操作涉及到的存储池
    #         pool_name = self.restrict_rbd_pool(op, request)
    #         # 若直接未获取到存储池，则默认为target的灾备相关，允许操作
    #         if pool_name is None:
    #             return {'over_space': over_space, 'partion_name': partion_name}
    #         # 获取集群所有池信息,并获取当前池所属分区
    #         partion_info = self.pool_partion_info(pool_name)
    #         partion_name = partion_info['partition']
    #         # 检查当前池所属分区是否有容量超出硬盘
    #         if partion_name is not None:
    #             partion_osd_info = [osd_info for osd_info in partion_info_all['osd_warn_info'] if
    #                                 osd_info['part'] == partion_name]
    #             # 若创建存储卷且所在池分区未超出，开启容灾，则需要检测灾备元数据池所在分区是否硬盘超出
    #             if op == const.OP_CREATE_LUN and request.DATA['selectDisaster'] and not partion_osd_info:
    #                 pool_name = const.BACKUP_POOL_NAME
    #                 partion_name = self.pool_partion_info(pool_name)['partition']
    #                 partion_osd_info = [osd_info for osd_info in partion_info_all['osd_warn_info'] if
    #                                     osd_info['part'] == partion_name]
    #                 log.error('disaster pool partion %s disk space over, info is: %s', partion_name, partion_osd_info)
    #             # 若存在超出情况，则不允许创建
    #             if partion_osd_info:
    #                 log.warning('operation op is: %s, pool %s belonged partion %s disk space is over',
    #                             op, pool_name, partion_name)
    #                 over_space = True
    #         else:
    #             log.error('get pool %s belong partion error', pool_name)
    #     return {'over_space': over_space, 'partion_name': partion_name, 'pool_name': pool_name}


def module_required(*feature_name):
    """
    装饰器 license特性权限判断
    :param feature_name: license特性
    :type : list
    :return:
    """

    def wrapper(func):
        """装饰方法"""

        @functools.wraps(func)
        def real_func(*args, **kwargs):
            """被装饰的方法"""
            support_features = lics.get_license_features()
            feature_list = []
            for service_type in lics_const.SERVICE_TYPE:
                feature_list.extend(support_features[service_type])
            for feature in feature_name:
                if feature not in feature_list:
                    return Response('The currnet license version does not support the {0} feature.'.format(feature),
                                    status=status.HTTP_405_METHOD_NOT_ALLOWED)
            return func(*args, **kwargs)
        return real_func

    return wrapper


def assert_tgtd_normal(op):
    """断言所有tgt server的进程都是正常的"""

    def wrapper(func):
        """装饰方法"""

        @functools.wraps(func)
        def real_func(_self, request, *args, **kwargs):
            """被装饰的方法"""
            if const.OP_REMOVE_LUN == op:
                lun_id = request.GET.get('lunID', None)
                if lun_id is None:
                    lun_id = request.GET.get('lun_id', -1)
                # 删除访问方式为RBD的块设备不需要检查tgt进程
                if 0 > int(lun_id):
                    return func(_self, request, *args, **kwargs)
            if const.OP_MODIFY_LUN == op:
                lun_id = request.DATA.get('lun_current_id', -1)
                # 修改访问方式为RBD的块设备不需要检查tgt进程
                if 0 > int(lun_id):
                    return func(_self, request, *args, **kwargs)

            tgt_servers = _self._get_mon_stor()
            check_tgt_status = _self.multi_thread_task(tgt_servers, 'pidof tgtd', ssh=True)
            for tgt_server in check_tgt_status:
                if not check_tgt_status[tgt_server]:
                    error_reason = u'主机“{0}”的tgt进程异常，请检查'.format(_self.name_to_ip(tgt_server))
                    error_rt = {
                        'status': 'error',
                        'reason': error_reason,
                        'errorcode': 'TGT_DAEMON_ERROR'
                    }
                    if const.OP_CREATE_TARGET == op:
                        name = request.DATA.get('targetName', '')
                    elif const.OP_MODIFY_TARGET == op:
                        name = request.DATA.get('targetName', '')
                        error_rt = {
                            'success': False,
                            'error': error_reason,
                            'errorcode': 'TGT_DAEMON_ERROR'
                        }
                    elif const.OP_REMOVE_TARGET == op:
                        name = request.GET.get('target_name', '')
                    elif const.OP_CREATE_LUN == op:
                        name = request.DATA.get('lunName', '')
                        if not name:
                            name = request.DATA.get('rbd_name', '')
                    elif const.OP_MODIFY_LUN == op:
                        name = request.DATA.get('rbd_name_old', '')
                    elif const.OP_REMOVE_LUN == op:
                        name = request.GET.get('rbdName', '')
                        if not name:
                            name = request.GET.get('rbd_name', '')
                    else:
                        name, error_rt = '', ''
                    _self.addOperationlog('', request, OP_BS_ALL[op].format(name), error_reason)
                    return Response(error_rt)
            return func(_self, request, *args, **kwargs)

        return real_func

    return wrapper


def check_remove_osd_event(op):
    """
    检查当前正在删除主机或硬盘时，需要阻止的操作
    Author: KF6602
    Date: 2017/03/15
    """

    def wrapper(func):
        """装饰方法"""

        @functools.wraps(func)
        def real_func(_self, request, *args, **kwargs):
            """被装饰的方法"""

            is_removing_osd = os.path.exists(const.FLAG_REMOVING_OSD)
            if is_removing_osd:
                log_content = ''
                op_content = op
                error_reason = u'正在删除主机或硬盘，请稍后再试'
                errorcode = 'ERROR_HOST_BUSY_REMOVE'
                error_rt_type1 = {
                    'status': 'error',
                    'reason': error_reason,
                    'errorcode': errorcode
                }
                error_rt_type2 = {
                    'success': False,
                    'error': error_reason,
                    'errorcode': errorcode
                }
                if const.OP_DEPLOY_GATEWAY == op:
                    name = request.DATA.get('node_ip', '')
                    if not name:
                        name = request.DATA.get('exist_host', '').split(':')[0]
                    error_rt = error_rt_type1
                elif const.OP_REMOVE_GATEWAY == op:
                    name = request.GET.get('gateway_ip', '')
                    error_rt = error_rt_type1
                elif const.OP_ADD_MON == op:
                    name = request.DATA.get('node_ip', '')
                    task_id = request.DATA.get('task_id', '')
                    onestor_common.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_ADD_MON, task_id)
                    error_rt = error_rt_type2
                elif const.OP_REMOVE_MON == op:
                    node_ip = request.GET.get('node_ip', '')
                    host_name = request.GET.get('host_name')
                    name = onestor_common.name_to_ip(host_name) if const.OFFLINE == node_ip else node_ip
                    task_id = request.GET.get('task_id', '')
                    onestor_common.add_onestor_task(const.ONESTOR_PROGRESS, const.OP_REMOVE_MON, task_id)
                    error_rt = error_rt_type2
                    log_content = const.OP_REMOVE_MON + '_' + const.OFFLINE \
                        if const.OFFLINE == node_ip else const.OP_REMOVE_MON
                elif const.OP_CREATE_HA_CFG == op:
                    name = request.DATA.get('vip', '')
                    error_rt = error_rt_type2
                elif const.OP_MODIFY_HA_CFG == op:
                    name = request.DATA.get('oldVip', '')
                    error_rt = error_rt_type2
                elif const.OP_REMOVE_HA_CFG == op:
                    name = request.GET.get('vip', '')
                    error_rt = error_rt_type2
                elif const.OP_CREATE_HANDY_HA_CFG == op:
                    name = request.DATA.get('vip', '')
                    error_rt = error_rt_type2
                elif const.OP_MODIFY_HANDY_HA_CFG == op:
                    name = request.DATA.get('vip', '')
                    error_rt = error_rt_type2
                elif const.OP_REMOVE_HANDY_HA_CFG == op:
                    name = request.GET.get('vip', '')
                    error_rt = error_rt_type2
                elif const.OP_POST_NTP_INFO == op:
                    name = ''
                    error_rt = error_rt_type1
                elif const.OP_POST_CEPH_PARAM == op:
                    name = ''
                    error_rt = error_rt_type1
                else:
                    name, error_rt = '', ''
                if log_content:
                    op_content = log_content
                _self.addOperationlog('', request, OP_BS_ALL[op_content].format(name), error_reason)
                util.__update_task_progress(_self, op, errorcode, error_reason, request)
                return Response(error_rt)
            return func(_self, request, *args, **kwargs)

        return real_func

    return wrapper


def check_cluster_dispace(fun_op=None, need_operation=True):
    """
    检测集群容量占用比例，但超出上限95%时，阻止继续操作，提示扩容;且增加限制创建块设备大小
    :param fun_op: 方法的操作码
    :param need_operation: 是否需要直接返回结果给前台并记录操作日志，若是最外层装饰器需要单独记录
    :Author l11544 li.shan@h3c.com
    :Date 2017/4/27
    :return: fun
    """
    def wrapper(func):
        """装饰方法"""

        @functools.wraps(func)
        def real_func(*args, **kwargs):
            """被装饰的方法"""
            # 基本的参数
            save_operation, over_space, ceph_command = need_operation, False, True
            # 操作对象名称
            param_name = DecorateUtil().get_fun_param_name(fun_op, args[1])
            error_reason, error_rt_type = u'集群容量不足请先扩容', dict()
            if fun_op == const.OP_MODIFY_TARGET:
                error_rt_type = {
                    'success': False,
                    'error': error_reason,
                    'errorcode': 'LOW_CEPH_SPACE'
                }
            else:
                error_rt_type = {
                    'status': 'error',
                    'reason': error_reason,
                    'errorcode': 'LOW_CEPH_SPACE'
                }
            # PN:201707170091 【SIT】块存储创建RBD块和卷的规格是64T,但是创建的时候能创建超出64T的块和卷
            if DecorateUtil().need_astrict_rbd_space(fun_op, args[1], param_name):
                error_reason = u'大小超出规格上限'
                error_rt_type['reason'] = error_reason
                onestor_common.addOperationlog('', args[1], OP_BS_ALL[fun_op].format(param_name), error_reason)
                return Response(error_rt_type)
            # end by l11544 2017/7/17
            ceph_osd_info = onestor_common.exec_local_cmd_json("timeout 15 ceph osd df -f json")
            log.debug('op is {0}, object name is {1}'.format(fun_op, param_name))
            osd_status_full = False
            if ceph_osd_info:
                # 判断是否有主机硬盘占用全满
                for osd_percent in ceph_osd_info['nodes']:
                    if float(osd_percent['utilization']) >= const.CEPH_TOP_CMD_SPACE:
                        osd_status_full = True
                        break
                if osd_status_full:
                    log.warning(
                        "excute function {0}, ceph cluster low sapce, ceph osd df used percent is over 0.90, "
                        "detail is {1}".format(func.__name__, ceph_osd_info['nodes']))
                    over_space = True
            else:
                # 记录错误，原因不明，不在这里直接返回
                ceph_command = False
                log.error('excute function {0}, get ceph df failed, result is {1}'.format(
                    func.__name__, ceph_osd_info['nodes']))
            if not over_space:
                return func(*args, **kwargs)
            elif ceph_command:
                # 记录操作日志
                if need_operation:
                    if fun_op == const.OP_REMOVE_LUN and int(args[1].GET.get('lunID')) <= 0:
                        operation_contant = u'删除块“{0}”'.format(param_name)
                    else:
                        operation_contant = OP_BS_ALL[fun_op].format(param_name)
                    onestor_common.addOperationlog('', args[1], operation_contant, error_reason)
                    return Response(error_rt_type)
                else:
                    # 针对不需要日志，列出快照的情况
                    if fun_op == const.LIST_SNAPS:
                        return Response([error_rt_type])
                    return Response(error_rt_type)
            else:
                onestor_common.addOperationlog('', args[1], OP_BS_ALL[fun_op].format(param_name), u'执行命令失败')
                return Response({'status': 'error', 'reason': u'操作失败，详见后台日志', 'errorcode': 'FAIL_COMMAND'})
        return real_func

    return wrapper


def permit_login(func):
    """装饰器，检查是否有权限管理集群"""

    def real_func(*args, **kwargs):
        """被装饰的方法"""
        request = args[1] if 'health' == func.__name__ else args[0]
        # 登录页面的GET请求不需要被装饰
        if 'login' == func.__name__ and request.method == 'GET':
            return func(*args, **kwargs)
        if func.__name__ != 'health':
            # permit_login() 函数中调用 request.session['__permit_login__'] 会触发 set-cookie 动作，(可能是django自身的bug)
            # 会设置浏览器 cookie 的过期时间，但 health 请求并不需要设置 cookie 过期时间，
            # 且 health 请求中设置 session['__permit_login__'] 并没什么实际用处
            request.session['__permit_login__'] = True
        fsid = onestor_common.exec_local_cmd('timeout 3 ceph fsid 2>/dev/null')
        if '' != fsid:
            # 从数据库中获取当前所有的Handy节点
            handys = onestor_common.exec_local_cmd_json('ceph config-key get handy_key')
            if handys is None:
                return func(*args, **kwargs)
            handys_name = [handy.keys()[0] for handy in handys['ssh_pub_key']]
            handys_key = [handy.values()[0] for handy in handys['ssh_pub_key']]
            # 获取本地的主机名
            local_name = onestor_common.exec_local_cmd('hostname')
            # 获取本地的秘钥
            local_pub_key = onestor_common.exec_local_cmd('cat /root/.ssh/id_rsa.pub')
            if local_name not in handys_name or local_pub_key not in handys_key:
                if 'health' == func.__name__:
                    # 如果是health请求的，则执行注销操作
                    log.error('[ERROR] no permission to manage cluster, system logout')
                    logout(request)
                else:
                    log.error('[ERROR] no permission to login')
                    request.session['__permit_login__'] = False

        return func(*args, **kwargs)

    return real_func


def logging_to_file(func):
    """装饰器，发送消息前打印相关的参数"""

    def real_func(*args, **kwargs):
        """被装饰的方法"""
        log.info('[onebackup] %s, params: %s, %s', func.__name__, args, kwargs)
        return func(*args, **kwargs)

    return real_func


def send_api_response(func):
    """
    api请求参数记录与消息返回
    :param func: 被装饰方法
    :return:
    """
    @functools.wraps(func)
    def real_func(_self, request, *args, **kwargs):
        """被装饰的方法"""
        error = ''
        resp = None
        if request.DATA:
            log.info('[api {0}] {1} params: {2}'.format(request.method, func.__name__, request.DATA))
        elif request.GET:
            if request.method == 'GET':
                log.debug('[api {0}] {1} params: {2}'.format(request.method, func.__name__, request.GET))
            else:
                log.info('[api {0}] {1} params: {2}'.format(request.method, func.__name__, request.GET))
        elif request.method == 'GET':
            log.debug('[api {0}] {1}'.format(request.method, func.__name__))
        else:
            log.info('[api {0}] {1}'.format(request.method, func.__name__))

        try:
            resp = func(_self, request, *args, **kwargs)
        except errno.APIError as ex:
            log.info('[api {0} error] {1} {2}'.format(request.method, func.__name__, ex))
            error = ex.error
        except Exception as ex:
            log.exception(ex)
            error = ex
        finally:
            if not error:
                if request.method == 'GET':
                    return Response(resp)
                elif request.method == 'DELETE':
                    return Response(status=status.HTTP_204_NO_CONTENT)
                elif request.method == 'PATCH':
                    return Response(status=status.HTTP_202_ACCEPTED)
                elif request.method == 'POST':
                    return Response(status=status.HTTP_201_CREATED)
                else:
                    return Response(resp)
            else:
                return Response(error, status=status.HTTP_400_BAD_REQUEST)
    return real_func


def api_operate_log(func):
    """
    api请求 操作日志记录
    :param func: 被装饰方法
    :return:
    """
    @functools.wraps(func)
    def real_func(_self, request, *args, **kwargs):
        """
        装饰器
        :param _self:
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        fsid = None
        operationlog = op_log.DEFAULT_OPERATION_LOG
        error = ''
        error_reason = op_log.DEFAULT_ERROR_REASON
        error_type = 'Exception'
        resp = None
        try:
            resp = func(_self, request, *args, **kwargs)
        except errno.APIError as ex:
            error = ex.error
            error_reason = error[2]
            error_type = 'APIError'
        except Exception as ex:
            log.exception(ex)
            error = ex
        finally:
            if const.OPERATE in request.session:
                operationlog = request.session[const.OPERATE]
                del request.session[const.OPERATE]
            if not error:
                onestor_common.addOperationlog(fsid, request, operationlog, 'success', False, None)
                return resp
            onestor_common.addOperationlog(fsid, request, operationlog, error_reason, False, None)
            if error_type == 'APIError':
                raise errno.APIError(error)
            else:
                raise Exception(error)
    return real_func
