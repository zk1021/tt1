#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
from rest_framework.response import Response
from calamari_rest.views.v3 import UniStorViewSet
from calamari_rest.blk import leader_router

LOG = logging.getLogger('django.request')


class BlockStorViewSet(UniStorViewSet):

    def __init__(self, *args, **kwargs):
        super(BlockStorViewSet, self).__init__(leader_router, *args, **kwargs)

    @staticmethod
    def get_url_path(request_path, fsid=''):
        LOG.debug("request path is {0}".format(request_path))
        if fsid:
            url_path = request_path.split(fsid + '/blk')[1]
        elif 'v3/blk' in request_path:
            url_path = request_path.split('v3/blk')[1]
        return url_path
