#!/usr/bin/env python
# -*- coding: utf-8 -*-
import calamari_rest.views.v2
import calamari_rest.blk.views.v3
from django.conf.urls import patterns, url, include
from calamari_rest.blk import urlpath


urlpatterns = patterns(
    '',
    # 匹配onestor/(?P<fsid>[a-zA-Z0-9-]+)/blk开头的所有URL
    url(r'^onestor/(?P<fsid>[a-zA-Z0-9-]+)/blk', calamari_rest.blk.views.v3.BlockStorViewSet.as_view(
        {'get': 'get_request', 'post': 'post_request', 'delete': 'delete_request', 'patch': 'patch_request'})),
)
