# -*- coding:utf-8 -*-

"""
邮件告警失败处理
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from alarm.persistence.models import SendMailFailedModel
from calamari_common.config import CalamariConfig
from contextlib import contextmanager

config = CalamariConfig()
engine = create_engine(config.get('alarm', 'db_path'))
Session = scoped_session(sessionmaker(bind=engine))


@contextmanager
def get_session():
    """
    获取session
    """
    global Session
    try:
        session = Session()
        yield session
    finally:
        Session.remove()


def get_alarm_failed():
    """
    获取告警失败信息
    """
    with get_session() as session:
        data = session.query(SendMailFailedModel).all()
        return data


class AlarmDB:
    """
    邮件服务器故障数据库
    """
    def __init__(self, session, model=None):
        """
        初始化
        """
        self.session = session
        self.model = SendMailFailedModel if model is None else model

    def clear(self):
        """
        清除告警
        """
        session = self.session()
        session.query(self.model).filter().delete()
        session.commit()
        self.session.remove()


alarmdb = AlarmDB(Session)
