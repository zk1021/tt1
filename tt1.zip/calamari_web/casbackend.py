#!/usr/bin/env python
# -*- coding:utf-8 -*-

from django.contrib.auth.models import User
from calamari_common import casauth


class CASBackend(object):
    """
    sso 认证服务
    """

    @staticmethod
    def authenticate(ticket, service):
        """
        sso 用户认证
        :param ticket:
        :param service:
        :return:
        """
        username = casauth.cas_verify(ticket, service)

        user = User.objects.get(username=username)
        return user

    @staticmethod
    def get_user(user_id):
        """
        获取用户
        :param user_id:
        :return:
        """
        return User.objects.get(pk=user_id)
