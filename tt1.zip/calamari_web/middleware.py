#!/usr/bin/env python
# -*- coding:utf-8 -*-

from calamari_common import cmdprocess
from calamari_rest.models import Session
from django.contrib.sessions.models import Session as django_Session
from django.http.response import HttpResponse
from calamari_web import send_add_oplog_msg, exec_local_cmd
from calamari_web import validate_ac_token
from calamari_common.cluster_api import cluster_size_kb
from django.contrib.auth import logout
import datetime
from calamari_common.config import CalamariConfig
import re
import os
import rados
import logging
import json
import time
import configobj

LOG = logging.getLogger('django.request')

try:
    from calamari_rest.views.common import const, util
    from calamari_rest.views.common import cmd
    from calamari_rest.views.ha.ha_view import test_psql_db
    from calamari_rest.views.ha.ha_view import repair_psql_db
    from calamari_rest.views.ha.ha_view import switch_to_master
    from calamari_rest.views.lics.lics_view import LicsViewSet as LicsView
    from onestor.errno import ONEStorError, ERR_ZMQ_TIMEOUT
    from onestor.mr import restapi_adapter
    from calamari_rest.views.language_db import LanguageDatabase
    from onestor.errno import ERR_EXIST_LICENSE_DB, ERR_LICENSE_EXPIRED, ERR_WRONG_SYSTEM_TIME, ERR_UNMATCH_DEVICE, \
        ERR_LICENSE_AMOUNT_EXCEED
    from onestor.plat.lics.lics_errno import ERROR_QUERY_LICS_SREVER
except Exception, e:
    LOG.exception(e)


class AngularCSRFRename(object):
    ANGULAR_HEADER_NAME = 'HTTP_X_XSRF_TOKEN'

    def process_request(self, request):
        if self.ANGULAR_HEADER_NAME in request.META:
            request.META['HTTP_X_CSRFTOKEN'] = request.META[self.ANGULAR_HEADER_NAME]
            del request.META[self.ANGULAR_HEADER_NAME]
        return None


class PermitLoginMiddleware(object):
    """
    判断是否允许登录
    """
    @staticmethod
    def __get_handy_vip():
        """
        获取HandyHA的虚IP
        :return: HandyHA VIP
        """
        ceph_conf = configobj.ConfigObj('/etc/ceph/ceph.conf')
        if 'handy' in ceph_conf and 'vip' in ceph_conf['handy']:
            return ceph_conf['handy']['vip']
        else:
            return '127.0.0.1'

    @staticmethod
    def __get_local_manage_ip():
        ceph_conf = configobj.ConfigObj('/etc/ceph/ceph.conf')
        if 'global' in ceph_conf and 'manage_addr' in ceph_conf['global']:
            return ceph_conf['global']['manage_addr']
        else:
            return '127.0.0.1'

    def __set_tip_context(self, request, is_switch=False, repair=False):
        """
        根据当前访问的IP提示不同的内容到前台页面
        :param request 请求
        :return string 页面上的提示内容
        """
        # 判断语言
        is_en = self.get_language()
        filepath = os.path.split(os.path.realpath(__file__))[0]
        server_ip = request.META['SERVER_ADDR'] if 'SERVER_ADDR' in request.META else ''
        handy_vip = self.__get_handy_vip()
        handy_manage_ip = self.__get_local_manage_ip()
        vendor_check_result = LicsView().check_x10000(None, None, None, is_handy=True)
        product_name = vendor_check_result['product_info']['product']
        company_name = vendor_check_result['product_info']['company']
        is_handyha = "true"
        handy_ip = ""

        if repair:
            # error_tips = '当前Handy节点数据库状态异常 ' \
            #              '<br><br><span onclick="repairPsql()" ' \
            #              'class="hvr-shutter-out-horizontal">点击修复</span>'
            error_tips = '当前Handy节点数据库状态异常，如果长时间无法恢复，请联系{0}技术支持人员'.format(company_name)
            error_tips_en = 'Database error occurred on the current Handy node. Please contact {0} Support if the issue persists'.format(company_name)

        elif server_ip and handy_vip != '127.0.0.1' and handy_vip != server_ip:
            # 当前访问IP不是高可用IP，需要Ping一把高可用IP，如果能通，则提示用户使用高可用IP登录
            error_tips = '请通过管理高可用IP（{0}）来登录管理平台'.format(handy_vip)
            error_tips_en = 'Please login the management system at its HA VIP({0})'.format(handy_vip)
            handy_ip = handy_vip
        elif server_ip != handy_manage_ip:
            LOG.info('SERVER_ADDR is not manage ip')
            error_tips = '请通过管理IP（{0}）来登录管理平台'.format(handy_manage_ip)
            error_tips_en = 'Please login the management system at its management IP({0})'.format(
                handy_manage_ip)
            is_handyha = "false"
            handy_ip = handy_manage_ip
        else:
            error_tips = '当前高可用IP访问的Handy处于备用状态'
            error_tips_en = 'The current Handy node at the HA VIP is in standby state'
        if is_switch:
            error_tips = '正在切换为主用状态...请稍候'
            error_tips_en = 'Switching to active state...Please wait'
        path_cn = '403.html'
        path_en = '403_en.html'

        error_tips = error_tips_en if is_en else error_tips
        path = path_en if is_en else path_cn

        return exec_local_cmd('cat {}'.format(os.path.join(filepath, path))).replace(
            '{{tips}}', error_tips).replace('{{title}}', product_name)\
            .replace('{{company}}', company_name).replace('{{is_handyha}}', is_handyha)\
            .replace('{{handy_ip}}', handy_ip)

    @staticmethod
    def get_language():
        retry_time = 0
        is_en = False
        while True:
            try:
                language_conf = LanguageDatabase.list_language()
                if language_conf is not None:
                    language = language_conf['language']
                    if language == 'en-us':
                        is_en = True
                    else:
                        is_en = False
                    break
                else:
                    break
            except Exception as ex:
                LOG.exception(ex)
                if retry_time <= 3:
                    LOG.info('get language retry time %s', retry_time)
                    retry_time += 1
                    time.sleep(5)
                    continue
                else:
                    break
        return is_en

    def __check_remote_addr(self, request):
        calmari_conf = CalamariConfig()
        if calmari_conf.has_option('calamari_web', 'manage_only'):
            try:
                manage_only = calmari_conf.getboolean('calamari_web', 'manage_only')
            except Exception as exception:
                LOG.warn('Can not get conf manage_only value, reason: {}'.format(exception))
                manage_only = True
        else:
            manage_only = True
        if manage_only is False:
            return True
        server_addr = request.META['SERVER_ADDR']
        if server_addr == '127.0.0.1':
            return True
        LOG.info("SERVER_ADDR {}".format(request.META['SERVER_ADDR']))

        if os.path.exists('/etc/ceph/ceph.conf'):
            handy_manage_ip = self.__get_local_manage_ip()
            if handy_manage_ip == '127.0.0.1':
                LOG.warn('Can not get handy manage ip.')
                return True
            handy_vip = self.__get_handy_vip()
            if server_addr == handy_manage_ip or server_addr == handy_vip:
                return True
            else:
                return False
        return True

    def process_request(self, request):
        """
        检查当前是否为备用节点
        """
        status_code = validate_ac_token(request)
        if status_code != 200:
            return HttpResponse(
                'You do not have permission to access this page.',
                status=status_code
            )
        # 容器环境下不需要检查HandyHA主备
        if os.path.exists("/.dockerenv"):
            return None
        if request.META['PATH_INFO'].startswith('/api/v2/onestor/handyha/'):
            if request.META['PATH_INFO'].endswith('/repairdb'):
                return HttpResponse(repair_psql_db())
            elif request.META['PATH_INFO'].endswith('/testdb'):
                # update by z11524 date:2017/9/7 PN:201709040775
                if '1' == exec_local_cmd('ls /var/lib/postgresql/*/main/ | grep recovery.conf | wc -l'):
                    return HttpResponse('has_recovery_conf')
                else:
                    return HttpResponse(test_psql_db())
            elif request.META['PATH_INFO'].endswith('/switch'):
                return HttpResponse(switch_to_master())
            else:
                return None

        if request.META['PATH_INFO'].startswith('/api/v3/onestor/download/license') or \
                request.META['PATH_INFO'].startswith('/api/v3/onestor/license'):
            return None

        manage_check_url = re.match("/api/v3/onestor/[0-9a-z-]*/plat/cluster/health",
                                    request.META['PATH_INFO']) \
                           or re.match("/api/v3/onestor/[0-9a-z-]*/health",
                                       request.META['PATH_INFO']) \
                           or request.META['PATH_INFO'].startswith('/api/v2/onestor/language') \
                           or request.META['PATH_INFO'].startswith('/api/v1/auth/login/') \
                           or request.META['PATH_INFO'].startswith('/login/')

        if manage_check_url and not self.__check_remote_addr(request):
            return HttpResponse(self.__set_tip_context(request), status=403)

        # 如果当前存在切换的任务，则直接返回失败
        if os.path.exists(const.FLAG_SWITCH_HANDY_HA):
            # update add by z11524 date:2017/12/27 PN:201710160741
            handy_util = util.HandyUtil()
            result = handy_util.check_concurrent_event2(const.FLAG_SWITCH_HANDY_HA, 1800, 'check')
            if not result:
                return None
            return HttpResponse(
                self.__set_tip_context(request, is_switch=True, repair=False),
                status=403
            )
        # 当前Handy节点为postgres备用节点则在页面提供切换按钮
        if '1' == exec_local_cmd('ls /var/lib/postgresql/*/main/ | grep recovery.conf | wc -l'):
            return HttpResponse(
                self.__set_tip_context(request, is_switch=False, repair=False),
                status=403
            )
        # 往数据库中测试表中增删数据，如果不成功则在页面提供修复按钮
        if not self.check_psql_status():
            return HttpResponse(
                self.__set_tip_context(request, repair=True),
                status=503
            )
        return None

    @staticmethod
    def check_psql_status():
        """检查数据库的状态"""
        if '0' == exec_local_cmd(cmd.CMD_CHECK_PSQL_STATUS) or \
                -1 == exec_local_cmd(cmd.CMD_TEST_PSQL_STATUS).find('PSQL_READY'):
            # 再次检查,防止误判
            time.sleep(5)
            if '0' == exec_local_cmd(cmd.CMD_CHECK_PSQL_STATUS) or \
                    -1 == exec_local_cmd(cmd.CMD_TEST_PSQL_STATUS).find('PSQL_READY'):
                return False
        return True


class LicenseMiddleware(object):

    @staticmethod
    def process_request(request):
        client_addr = request.META.get('REMOTE_ADDR', None)
        username = request.user.username
        if request.META['PATH_INFO'].startswith('/manage/') and \
                -1 != str(request.POST).find('logoutRequest'):
            session_id = request.GET.get('sessionid', None)
            if session_id:
                _session_key = Session.objects.get(session_id=session_id)
                django_Session.objects.get(pk=_session_key).delete()
        if request.META['PATH_INFO'].startswith('/api/v1/cluster/') or \
                re.match("/api/v3/onestor/[0-9a-z-]*/health", request.META['PATH_INFO']):

            # BEGIN ADD BY Z14172 2017/12/25
            try:
                license_check_result = LicsView().check_license()
            except ONEStorError, err:
                LOG.exception(err)
                return None

            if not license_check_result['success']:
                # begin add by z14172 2018/01/09 PN 201801090884
                if 'ERR_CONNECT' == license_check_result['reason'][1] \
                        or -1 < license_check_result['reason'][1].lower().find('timeout') \
                        or -350 == license_check_result['reason'][0]:
                    return None
                # end add by z14172 2018/01/09 PN 201801090884
                check_lics_errorcode = [ERR_EXIST_LICENSE_DB[0], ERR_LICENSE_EXPIRED[0], ERR_WRONG_SYSTEM_TIME[0],
                                        ERR_UNMATCH_DEVICE[0], ERR_LICENSE_AMOUNT_EXCEED[0], ERROR_QUERY_LICS_SREVER[0]]
                if license_check_result['reason'][0] in check_lics_errorcode:
                    send_add_oplog_msg(
                        request, (
                            license_check_result['reason'][2] + '，系统自动登出',
                            license_check_result['reason'][1] + ', system logout'
                        )
                    )
                logout(request)
                return HttpResponse(license_check_result['reason'], status=405)
            else:
                return None
            # END ADD BY Z14172 2017/12/25
        else:
            return None


class GraphiteMiddleware(object):

    @staticmethod
    def process_request(request):
        if request.META['PATH_INFO'].startswith('/graphite/render'):
            errno, data = restapi_adapter.process(request)
            if errno[0] == 0:
                return HttpResponse(data, content_type='application/json')
            return HttpResponse(json.dumps([{"result": errno}]), content_type='application/json')
