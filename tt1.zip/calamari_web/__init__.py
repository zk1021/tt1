# -*- coding:utf-8 -*-
import os
import time
import requests
import logging

from calamari_rest.views.common.errno import SUCCESS
from calamari_rest.views.onestor import database

conf_path = "/etc/calamari/calamari.conf"

LOG = logging.getLogger('django.request')


def add_operation_log(ip, username, content, status):
    """记录操作日志"""
    _time = time.time() * 1000
    params = [username, ip, _time, content, status]
    database.add_obj('operationlog', params)


def send_add_oplog_msg(request, content, result=SUCCESS):
    """发送消息给Leader记录操作日志"""
    if request.user.username:
        from calamari_rest.views.common.forward import ForwardView
        ForwardView().send_request_to_leader(
            comp_op=('COMP_OPERATION_LOG', 'OPLOG_save'),
            data={
                '__task__': content,
                '.OPLOG_user': request.user.username,
                '.OPLOG_ip': request.META.get('REMOTE_ADDR'),
                'result': result
            }
        )


def exec_local_cmd(command):
    """
    使用root身份执行本地命令行
    :param command: 命令行
    :return: 执行结果
    """
    filepath = '/opt/h3c/cmd/'
    _result = os.popen("%s./run %s" % (filepath, command)).read().rstrip()
    return _result


def set_leader_ip_in_docker(data):
    """
    docker环境中设置leader ip
    """
    if 'manage_node_ip' in data:
        from onestor import errno
        from onestor import message
        manage_node_ip = data['manage_node_ip']
        # 将IP写入etcd
        message.docker_set_leader_ip(manage_node_ip)
        # 将cloudos的vip发送给目标leader
        client = message.Messenger.create_leaderclient(forward_ip=manage_node_ip)
        request = message.Request(comp=message.COMP_HOST, op='CONFIG_cloudos_info')
        request.data = {
            'vip': message.get_cloudos_vip()
        }
        response = client.send_request(request)
        if not response.is_successful():
            raise errno.ONEStorError(response.result)


def docker_get_leader_ip():
    """
    容器环境下获取leader IP
    """
    from onestor.message import docker_get_leader_ip as get_leader_ip
    return get_leader_ip()


def docker_exec_cmd_on_leader(cmd):
    """
    容器环境下在leader节点上执行命令行
    """
    from onestor.utils.misc import exec_remote_cmd
    return exec_remote_cmd(docker_get_leader_ip(), cmd)


def validate_ac_token(request, refresh_token=0):
    """
    校验Token有效性
    """
    if os.path.exists('/tmp/use_onestor_auth'):
        LOG.debug('Use onestor auth.')
        return 200
    if not os.path.exists('/var/lib/auth-center/script/auth-api-server.sh'):
        LOG.debug('It is not vdi env, return 200.')
        return 200
    if not request.META['PATH_INFO'].startswith('/api/') and not request.META[
            'PATH_INFO'].startswith('/graphite/'):
        LOG.debug('It is not an url starts with api and graphite.')
        return 200
    # VDI场景下需要检查access token
    ac_token = request.COOKIES.get('AC_TOKEN')
    if ac_token is None:
        LOG.debug('The access token is None, return 401.')
        return 401
    if request.META['PATH_INFO'].startswith('/api/v3/onestor/keepAlive'):
        LOG.debug('Start to refresh token ...')
        refresh_token = 1
    # 调用认证服务器的接口检查access token的有效性
    try:
        url = 'http://center.authorization.h3c.com:6060/oauth2/token'
        response = requests.get(url, headers={
            'Authorization': ac_token,
            'REFRESH_TOKEN': refresh_token
        })
        LOG.debug('Token: %s, response: %s', ac_token, response)
        response.raise_for_status()
    except Exception, e:
        LOG.exception(e)
        return 403
    else:
        return 200
