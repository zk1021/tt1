#!/usr/bin/env python
# -*- coding:utf-8 -*-

from rest_framework.permissions import BasePermission


class IsAuthenticated(BasePermission):
    """
    Allows access only to authenticated users.
    """

    @staticmethod
    def has_permission(request, view):
        """
        authenticated user
        :param request:
        :param view:
        :return:
        """
        return request.user and request.user.is_authenticated()
